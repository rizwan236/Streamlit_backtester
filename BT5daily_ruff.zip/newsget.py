import sys


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
from gnews import GNews
from newspaper import Article
import nltk


nltk.download('punkt')

def get_articles_from_google_news(company_name, num_articles=500):
    gn = GNews(language='en', country='IN', period='2d', start_date=None, end_date=None, max_results=3, exclude_websites=['abc.com', 'fcb.com'])
    #                proxy=proxy)
    search_results = gn.get_news_by_topic("BUSINESS")
    #search_results = gn.get_news_by_site("moneycontrol.com")
    search_results = gn.get_news(f"{company_name} company india")# period = '1d' ,country = 'India' ,language = 'english' ) #max_results=num_articles)
    #search_results = gn.get_news_by_site("tradebrains.in","moneycontrol.com","economictimes.indiatimes.com","cnbctv18.com")
    articles = []
    
    '''
    for result in search_results[:num_articles]:
        # Extracting the URL from the 'url' field
        url = result.get('url', '')
        if url:
            article = Article(url)
            article.download()
            article.parse()
            articles.append(article)
    '''        

    for result in search_results[:num_articles]:
        # Extracting the URL from the 'url' field
        url = result.get('url', '')
        if url:# and any(site in url for site in sites): #if url:
            article = Article(url)
            try:
                article.download()
                article.parse()
                article.nlp()
                articles.append(article)
            except Exception as e:
                print(f"Error downloading article from {url}: {e}")
                
    return articles

def analyze_articles(articles):
    # You can perform NLP analysis here using the features provided by the newspaper3k library
    for article in articles:
        
        # Example: Printing the title and summary of each article
        print("Title:", article.title)
        print("Summary:", article.summary)
        print("\n")

if __name__ == "__main__":
    # List of company names
    company_names = ["Reliance industries", "TV18", "PCBL"]
    sites = ["tradebrains.in", "moneycontrol.com", "economictimes.indiatimes.com", "cnbctv18.com"]

    for company_name in company_names:
        print(f"\nFetching finance news for {company_name}...\n")
        company_articles = get_articles_from_google_news(company_name)
        analyze_articles(company_articles)
