import csv
from datetime import datetime
import os
import time

from matplotlib.dates import DateFormatter, MonthLocator
import matplotlib.pyplot as plt
import pandas as pd

# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
import pandas_ta as ta
import pytz
import seaborn as sns
import talib as tb

from telegram_bot import post_telegram_file


print("CCIST")


# Specify the folder path containing CSV files
# Replace with the actual folder path
folder_path = "/home/rizpython236/BT5/ticker-csv-files/"
folder_path = "/home/rizpython236/BT5/ticker_15yr"
ticker_path = "/home/rizpython236/BT5/myholding.csv"
ticker_path = "/home/rizpython236/BT5/Finalnse.csv"
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df["Symbol"].tolist()[:]
symbols = list(dict.fromkeys(symbols))
selected_files = []

valid_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
valid_df = pd.read_csv(valid_file)
Symbol_to_YFindustry_mapping = dict(
    zip(valid_df["Symbol"], valid_df["YFindustry"]))

# Base_name=symbol_to_company.get(base_name, base_name)
# symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

change_df = pd.read_csv("/home/rizpython236/BT5/MYindustry.csv")
YFindustry_to_MYindustry_mapping = dict(
    zip(change_df["Industry"], change_df["MYindustry"]))


# Create an empty DataFrame for storing the latest close prices
OHCLV = pd.DataFrame(columns=["Symbol", "Latest_DDWN"])

BUY = []
SELL = []
Fulllist = []
mktbreathUP = []
mktbreathDwn = []

# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    if file_name.endswith(".csv"):
        file_path = os.path.join(folder_path, file_name)
        # total_files += 1
        base_name = os.path.splitext(file_name)[0]
        # file_names.append(base_name)
        # print(base_name)
        if base_name in symbols:
            file_path = os.path.join(folder_path, file_name)
            selected_files.append(file_path)

            # Read the CSV file into a DataFrame
            df = pd.read_csv(file_path)

            df["CCI"] = tb.CCI(df["High"], df["Low"],
                               df["Close"], timeperiod=34)
            df["OBV"] = tb.OBV(df["Close"], df["Volume"])
            df["CCIavg"] = tb.EMA(df["CCI"], timeperiod=14)
            df["obvmovavg"] = tb.SMA(df["OBV"], timeperiod=14)
            # , offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
            supertrend_values = ta.supertrend(
                high=df["High"], low=df["Low"], close=df["Close"], length=10, multiplier=4)
            df["ST"] = supertrend_values["SUPERT_10_4.0"]
            df["EMA_13"] = tb.EMA(df["Close"], timeperiod=8 * 5)
            df["SMA_200"] = tb.SMA(df["Close"], timeperiod=40 * 5)
            df["EMA_200"] = tb.EMA(df["Close"], timeperiod=40 * 5)
            # df['zscore'] = ta.zscore(df['Close'], length=25, std=1.5, offset=None)

            Fulllist.append(base_name)
            if len(df) > 0 and df["CCI"].iloc[-1] > 50:
                mktbreathUP.append(base_name)
            if len(df) > 0 and df["CCI"].iloc[-1] < 0:
                mktbreathDwn.append(base_name)

            if len(df) > 0 and df["CCI"].iloc[-1] > df["CCIavg"].iloc[-1] and df["ST"].iloc[-1] < df["Close"].iloc[-1] and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-2] and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]:
                BUY.append(base_name)
            else:
                SELL.append(base_name)

buy_df = pd.DataFrame({"Signal": "BUY", "Symbol": BUY})
sell_df = pd.DataFrame({"Signal": "SELL", "Symbol": SELL})
Signal_df = pd.concat([buy_df, sell_df], ignore_index=True)

Signal_df["YFindustry"] = Signal_df["Symbol"].map(Symbol_to_YFindustry_mapping)

# Map 'YFindustry' to 'MYindustry'
Signal_df["MYindustry"] = Signal_df["YFindustry"].map(
    YFindustry_to_MYindustry_mapping)

Signal_df["Count"] = Signal_df["MYindustry"].map(
    Signal_df["MYindustry"].value_counts())

# Signal_df['Count'] = Signal_df.groupby('MYindustry').cumcount().add(1)

Signal_df = Signal_df[Signal_df["Count"] >= 2]
Signal_df = Signal_df.sort_values(by="Count")

# print(Signal_df)
# Group by MYindustry and Signal, and sum the counts
percentage_df = Signal_df.groupby(
    ["MYindustry", "Signal"]).size().unstack().fillna(0)
percentage_df = round(percentage_df.div(
    percentage_df.sum(axis=1), axis=0) * 100, 1)
# percentage_df.drop('MYindustry')


MYindustry_to_Count_mapping = dict(
    zip(Signal_df["MYindustry"], Signal_df["Count"]))
percentage_df = percentage_df.rename_axis("MYindustry").reset_index()
percentage_df["Count"] = percentage_df["MYindustry"].map(
    MYindustry_to_Count_mapping)
percentage_df = percentage_df[percentage_df["Count"] >= 2]
percentage_df = percentage_df.sort_values(by="Count")
percentage_df["MYindustry"] = percentage_df["MYindustry"] + \
    "-" + percentage_df["Count"].astype(str)

# print(percentage_df)

percentage_df[["BUY", "SELL"]] = percentage_df[[
    "BUY", "SELL"]].apply(pd.to_numeric, errors="coerce")
# percentage_df[['BUY','SELL']] = pd.to_numeric(percentage_df[['BUY','SELL']], errors='coerce')
# percentage_df[['BUY','SELL']].fillna(0, inplace=True)
percentage_df = percentage_df[["BUY", "SELL"]].copy()
percentage_df.fillna(0, inplace=True)

# percentage_df.to_csv('/home/rizpython236/BT5/screener-outputs/delete.csv')
# print(percentage_df)
# print(percentage_df.columns)

non_numeric_valuesBUY = percentage_df["BUY"].loc[percentage_df["BUY"].apply(
    lambda x: not pd.api.types.is_numeric_dtype(x))]
# print(non_numeric_valuesBUY)
non_numeric_valuesSELL = percentage_df["BUY"].loc[percentage_df["BUY"].apply(
    lambda x: not pd.api.types.is_numeric_dtype(x))]
# print(non_numeric_valuesSELL)

# Plot the histogram
plt.figure(figsize=(18, 8))
sns.barplot(x="MYindustry", y="BUY", data=percentage_df,
            color="green", label="BUY")
sns.barplot(x="MYindustry", y="SELL", data=percentage_df,
            color="red", bottom=percentage_df["BUY"], label="SELL")

plt.title("100% Stacked Histogram of Signal based on CCI & ST in Nse500,Micro250")
plt.xlabel("Industry with count")
plt.ylabel("Percentage")
plt.legend(title="Signal")
plt.xticks(rotation=90, ha="right")
plt.subplots_adjust(wspace=0.1, hspace=0.1)
# plt.grid(axis='y', linestyle='--', alpha=0.7)
# Set grid properties
plt.grid(axis="y", linestyle="--", alpha=0.7, linewidth=1, color="black")
# Add a permanent horizontal grid line at 50
plt.axhline(y=50, color="black", linestyle="-", linewidth=2)
plt.tight_layout()
chart_path = "/home/rizpython236/BT5/screener-outputs/Industry_Signal.png"
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)


###############################
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today = datetime.now(IST_TIMEZONE).date()
ISTnow = datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")

UP = len(mktbreathUP)
DOWN = len(mktbreathDwn)
FULL = len(Fulllist)

MKTBREATHUP = round(UP / FULL * 100, 2)
MKTBREATHDN = round(DOWN / FULL * 100, 2)

print(weekday)

if weekday == "Wednesday":   # 5 is Saturday and 6 is Sunday  "Wednesday":
    print(today.strftime("Today is %A, CCIMktBreath file updated !"))

    # Set the file path to the xxx.csv file in a specified folder
    folder_path = (r"/home/rizpython236/BT5/trade-logs")
    file_path = os.path.join(folder_path, "CCIMktBreath.csv")
    index = MKTBREATHUP
    index1 = MKTBREATHDN

    # Read the CSV file and get the latest index value
    if os.path.isfile(file_path) and os.stat(file_path).st_size > 0:
        df = pd.read_csv(file_path)
        if not df.empty:
            latest_MKTBREATHUP = df["MKTBREATHUP"].iloc[-1]
            latest_MKTBREATHDN = df["MKTBREATHDN"].iloc[-1]
            latest_date = df["Date"].iloc[-1]
            print("The latest index value in CCIMktBreath file: " +
                  str(latest_MKTBREATHUP))
        else:
            latest_MKTBREATHUP = 0
            latest_MKTBREATHDN = 0
            latest_date = today.strftime("%Y-%m-%d")

    # Write to the CSV file if the index value is different from the latest index value
    # and latest_date !=today.strftime("%Y-%m-%d"):
    if index != latest_MKTBREATHUP:
        # Open the CSV file for appending
        with open(file_path, "a", newline="") as csvfile:
            writer = csv.writer(csvfile)
            # Write the current date and index value to the file
            writer.writerow([today.strftime("%Y-%m-%d"),
                            MKTBREATHUP, MKTBREATHDN])
            print(today.strftime("Today is %A, CCIMktBreath csv file updated."))
            # time.sleep(2)
            # post_telegram_message(today.strftime("Today is %A, a weekday & csv file updated."))
    else:
        print("CCIMktBreath value already exists in the CCIMktBreath CSV file.")


folder_path_csv = "/home/rizpython236/BT5/trade-logs"
file_path_csv = os.path.join(folder_path_csv, "CCIMktBreath.csv")

df = pd.read_csv(file_path_csv).drop_duplicates()
df = df.sort_values(by="Date", ascending=True)
# print(df)


# df = pd.DataFrame(data)

# Convert 'Date' column to datetime type
df["Date"] = pd.to_datetime(df["Date"])

# Plotting
plt.figure(figsize=(10, 6))
plt.plot(df["Date"], df["MKTBREATHUP"], marker="o", label="CCI UP >50")
plt.plot(df["Date"], df["MKTBREATHDN"], marker="o", label="CCI DOWN <0")

# Customize the plot
plt.title("Chart for Market Breath CCI >50 & <0")
plt.xlabel("Date")
plt.ylabel("Values 0%-100%")
plt.legend()
months = MonthLocator()
plt.gca().xaxis.set_major_locator(months)
plt.gca().xaxis.set_major_formatter(DateFormatter("%b %y"))
plt.grid(True)
plt.tight_layout(pad=0.5)  # Adjust the pad value as needed
# plt.show()
chart_path = "/home/rizpython236/BT5/screener-outputs/CCIMktBreath.png"
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)

print("done")
