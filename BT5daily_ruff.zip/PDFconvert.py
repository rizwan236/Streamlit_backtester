import csv

# from reportlab.lib.styles import getSampleStyleSheet
# from reportlab.lib import colors
import os
import time

import pandas as pd
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import inch  # Import inch unit for measurements
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
)


def calculate_col_widths(table_data, font_name="Helvetica", font_size=10, padding=5):
    """Calculate accurate column widths based on text length in ReportLab.

    table_data: list of lists (rows of the table)
    font_name: font to measure with
    font_size: size of the font in points
    padding: extra space to add on each column for breathing room
    """
    num_cols = len(table_data[0])
    col_widths = []

    for col in range(num_cols):
        # Extract all cell values in this column as strings
        column_texts = [str(row[col]) for row in table_data if col < len(row)]

        # Measure text widths for this column
        max_width = max(
            (stringWidth(text, font_name, font_size) for text in column_texts),
            default=0,
        )

        # Add padding
        col_widths.append(max_width + padding)

    return col_widths


def delete_file(filepath):
    """Attempts to delete a file at the given path.

    Args:
        filepath (str): The path to the file to be deleted.

    Returns:
        None

    """
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            # print(f'File deleted: {filepath}')
        else:
            print(f"File not found: {filepath}")
    except OSError as e:
        print(f"Error deleting file: {filepath} - {e}")


def copy_csv_with_repeating_headers(input_csv, output_csv, header_interval=38):
    """Copies a CSV file with repeated headers after every specified interval using pandas.

    Args:
        input_csv (str): Path to the input CSV file.
        output_csv (str): Path to the output CSV file.
        header_interval (int, optional): The number of rows after which to repeat the header. Defaults to 38.

    """
    if os.path.getsize(input_csv) > 0:
        df = pd.read_csv(input_csv)
    else:
        print(f"{input_csv} is empty. Skipping.")
        return

    # df = pd.read_csv(input_csv)

    df.fillna("", inplace=True)
    # df.fillna("nan", inplace=True)
    headers = df.columns.tolist()  # Extract headers separately

    # List to hold modified data with repeated headers
    data_with_headers = []

    # Iterate through the DataFrame in chunks of 'header_interval' rows (excluding header)
    for i in range(0, df.shape[0], header_interval):
        # Extract the current data chunk (excluding headers)
        chunk = df.iloc[i:min(i + header_interval, df.shape[0])]

        # Create a list to hold the modified chunk with repeated header row (if needed)
        chunk_with_header = []

        # Check if header needs to be inserted (not for the first chunk)
        if i > 0:
            # Insert header row for subsequent chunks
            chunk_with_header.append(headers)

        # Append data rows to the chunk list
        # Iterate over rows as tuples without index
        for row in chunk.itertuples(index=False):
            # Convert tuple to list and append
            chunk_with_header.append(list(row))

        # Extend the main data list with the modified chunk
        data_with_headers.extend(chunk_with_header)

    # Save the data with headers to the output CSV file
    with open(output_csv, "w", newline="") as outfile:
        writer = csv.writer(outfile)
        writer.writerow(headers)  # Write the initial header row
        # Write all data with repeated headers
        writer.writerows(data_with_headers)

    # print(f'CSV copied with headers repeated every {header_interval} rows: {output_csv}')


def remove_column(data, column_name):
    # Find the index of the column to remove
    try:
        col_index = data[0].index(column_name)
    except ValueError:
        print(f"Column '{column_name}' not found.")
        return data

    # Remove the column from each row
    for row in data:
        del row[col_index]

    return data


def create_pdf(input_csv, output_pdf, pageA4=True):
    output_csv = "/home/rizpython236/BT5/screener-outputs/copycsvforpdf.csv"
    if pageA4:
        copy_csv_with_repeating_headers(
            input_csv, output_csv, header_interval=44)
    else:
        copy_csv_with_repeating_headers(
            input_csv, output_csv, header_interval=30)
    time.sleep(5)
    # Read CSV data
    with open(output_csv) as csv_file:
        csv_reader = csv.reader(csv_file)
        # df = pd.read_csv(csv_file)
        # Get headers directly from the DataFrame
        # headers = df.columns.tolist()  # Convert pandas Series to list
        # csv_readerHeader = csv.DictReader(csv_file)
        # headers = csv_readerHeader.fieldnames  # Access the fieldnames attribute for headers
        # headers = next(csv_reader)  # Get the header row
        data = [row for row in csv_reader]
        # data = list(csv_reader)  # Convert reader to list for header access
        # print(headers)

    if not data:
        print("CSV is empty, skipping PDF creation.")
        return

    # Remove 'ref' column
    # data = remove_column(data, 'ref')

    # Extract headers
    # headers = data[0]

    # Create PDF
    pdf_filename = output_pdf
    if pageA4:
        base_width, base_height = A4
        page_size = (base_width * 1.0, base_height)
        # document = SimpleDocTemplate(pdf_filename, pagesize=A4, leftMargin=1, rightMargin=1, topMargin=5, bottomMargin=5)
    else:
        base_width, base_height = landscape(A4)
        page_size = (base_width * 1.0, base_height)
        # document = SimpleDocTemplate(pdf_filename, pagesize=landscape(A4), leftMargin=1, rightMargin=1, topMargin=5, bottomMargin=5)
    # document = SimpleDocTemplate(pdf_filename, pagesize=letter)

    document = SimpleDocTemplate(pdf_filename, pagesize=page_size,
                                 leftMargin=2, rightMargin=2, topMargin=5, bottomMargin=5)

    # Create PDF
    left_margin, right_margin, top_margin, bottom_margin = 2, 2, 5, 5
    # document = SimpleDocTemplate(
    #    pdf_filename,
    #    pagesize=page_size,
    #    leftMargin=left_margin,
    #    rightMargin=right_margin,
    #    topMargin=top_margin,
    #    bottomMargin=bottom_margin,
    # )

    # table_rows = []
    # for chunk in [data[i:i + 100] for i in range(0, len(data), 100)]:  # Split data into chunks
    #    table_rows.extend([headers] + chunk)  # Add headers before each chunk
    #    table_rows.append(PageBreak())  # Add a page break after each chunk

    # table = Table(table_rows)

    def my_PageTemplate(canvas, doc):
        # Header content
        canvas.setFont("Helvetica-Bold", 10)  # Set font and size for header
        # canvas.drawString(0.5 * inch, 0.7 * inch, ".")  # Replace with your information
        canvas.drawString(0.5 * inch, 0.7 * inch, f"{', '.join(headers)}")

    # Define a function for different page templates
    # all_frames = [my_PageTemplate]

    def header_frame(canvas, **kwargs):  # Pass 'doc' as a keyword argument
        """Defines the header content and formatting."""
        # Access 'doc' from the keyword arguments
        doc = kwargs["doc"]
        canvas.setFont("Helvetica-Bold", 10)  # Set font and size for header
        # Replace with your information
        canvas.drawString(0.5 * inch, 0.7 * inch,
                          f"Your Company Name - Report Title - {', '.join(headers)}")

    # Define a frame for headers (appears on all pages)
    # header = Frame(doc.leftMargin, doc.topMargin, doc.width, doc.topMargin - 0.2 * inch, id='header')  # Adjust height and margins
    # frameT = PageTemplate(id='allpages', frames=[header, Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height - doc.topMargin - doc.bottomMargin, id='content')])

    # --- Auto-adjust column widths ---
    if data:
        num_columns = len(data[0])
        available_width = page_size[0] - left_margin - right_margin
        col_widths = [available_width / num_columns] * num_columns
    else:
        col_widths = None
        num_columns = 1

    # Estimate text width (len of longest entry in each column)
    max_lengths = [max(len(str(row[col])) for row in data)
                   for col in range(num_columns)]

    # Scale lengths proportionally to available page width
    total_length = sum(max_lengths)
    if total_length == 0:  # avoid divide-by-zero
        # col_widths = [available_width / num_columns] * num_columns
        col_widths = [(length * 5) + 3 for length in max_lengths]
    else:
        # col_widths = [(length / total_length) * available_width for length in max_lengths]
        col_widths = [(length * 5) + 3 for length in max_lengths]

    # col_widths = calculate_col_widths(data, font_name="Helvetica", font_size=10, padding=12)
    # --- Dynamic font size scaling ---
    # Base font size = 8, but reduce if too many columns
    # scales down gradually, min size = 6
    font_size = max(6, int(8 - (num_columns / 15)))

    # Create table
    # table = Table(data)
    center = False
    halignx = "CENTER" if center else "LEFT"
    table = Table(data, colWidths=col_widths, hAlign=halignx)
    # table = Table([headers] + data[1:])

    # table_data = df.values.tolist()  # Convert DataFrame to list of lists
    # table = Table([headers] + table_data)

    # Add style to table
    style = TableStyle([("BACKGROUND", (0, 0), (-1, 0), "#77b0d5"),
                        ("TEXTCOLOR", (0, 0), (-1, 0), (1, 1, 1, 1)),
                        # ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        # Right-align the first column
                        ("ALIGN", (0, 0), (0, -1), "RIGHT"),
                        # Center-align all columns except the last two
                        ("ALIGN", (1, 0), (-3, -1), "CENTER"),
                        # Left-align the last two columns
                        ("ALIGN", (-2, 0), (-1, -1), "LEFT"),
                        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                        ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                        ("BACKGROUND", (0, 1), (-1, -1), "#f8f8f8"),
                        # Apply dynamic font size
                        ("FONTSIZE", (0, 0), (-1, -1), font_size),
                        ("GRID", (0, 0), (-1, -1), 1, "#a5a5a5")])

    table.setStyle(style)
    # font_size = 8  # Adjust the font size as needed
    # table = Table(data, style=table_style, repeatRows=1, colWidths=[letter[0] / len(data[0])] * len(data[0]))
    # table.setStyle(TableStyle([('FONTSIZE', (0, 0), (-1, -1), font_size)]))

    # Build PDF
    document.build([table])
    # document.build([table], frameTemplate=frameT) # Apply header template to all pages except the first
    print(f"PDF created: {output_pdf}")
    delete_file(output_csv)


input_csv_file = "/home/rizpython236/BT5/trade-logs/52wkdataWkly.csv"
output_pdf_file = "/home/rizpython236/BT5/trade-logs/52wkdataWkly.pdf"
# create_pdf(input_csv_file, output_pdf_file,pageA4=False)


"""
#import sys
#sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
#from fpdf import FPDF

def create_pdf_FPDF(input_csv, output_pdf):

  # Read CSV data
  with open(input_csv, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    data = [row for row in csv_reader]

  # Create FPDF object
  pdf = FPDF()
  pdf.add_page()
  pdf.set_margins(2, 2, 5)  # Set margins

  # Set font and font size
  pdf.set_font("Arial", size=10)

  # Set background color for header (alternative approach)
  pdf.set_text_color(0, 0, 0)  # Black text for header
  pdf.set_fill_color(223, 223, 223)  # Light gray fill color

  # Header row (bold)
  for col in data[0]:
    pdf.cell(w=20, txt=col, align='C', border=1, fill=True)  # Fill cell with background color
  pdf.ln()  # Move to next line

  # Reset fill color for data rows
  pdf.set_fill_color(255, 255, 255)  # White background for data rows (default)

  # Data rows
  for row in data[1:]:
    for col in row:
      pdf.cell(w=20, txt=col, align='C', border=1)
    pdf.ln()  # Move to next line

  # Save the PDF
  pdf.output(output_pdf)
  print(f'PDF created: {output_pdf}')

input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf'
# Example usage
#create_pdf_FPDF(input_csv_file, output_pdf_file)



#if __name__ == '__main__':
#    input_csv_file = '/home/rizpython236/BT5/screener-outputs/Relative_perf.csv'  # Replace with your CSV file
#    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/output.pdf'  # Replace with desired output PDF file
#
#    create_pdf(input_csv_file, output_pdf_file)
#    print(f'PDF created: {output_pdf_file}')

"""
