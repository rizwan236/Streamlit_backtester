from datetime import datetime, timedelta
import os
import re
import sys
import time
import traceback

# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
# sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages')
import numpy as np  # numpy-1.26.4   1.21.6   2.0.2
import pandas as pd
import pytz

# import yfinance_cache as yfc
import yfinance as yf

from custum_index import (
    calculate_custom_index,
    load_index_constituents_from_csv,
    plot_index_close_prices,
)
from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    NIFTY_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    SYMBOLS_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    VALID_TICKERS_CSV,
)
from symbol_copy import fix_dates_fast
from telegram_bot import post_telegram_message


print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")
sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


# from scipy.stats import gmean
sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")

# from concurrent.futures import ThreadPoolExecutor, as_completed
# from tqdm import tqdm
# import asyncio


# yfc.options.session.offline = False

'''
data = yfc.download(
    symbol,
    start=START_DATE,
    end=END_DATE,
    interval="1d",  # or "1wk"
    rounding=True,
    multi_level_index=False,
    threads=True,
    progress=False,
    back_adjust=True,
    repair=True,       # Repair missing/corrupted data
    keepna=False,      # Drop rows with missing values
    actions=False,     # Exclude dividends and splits as separate events
    auto_adjust=True,  # Adjust OHLC for corporate actions
    adjust_splits=True,
    adjust_divs=True,
    max_age="1h"       # Cache expiry
)

import yfinance_cache as yfc
import pandas as pd

def fetch_nse_bse(symbol, years_to_keep=3):
    """
    Fetch NSE/BSE data with:
    - Rolling N-year cache
    - Incremental updates for missing/future dates
    - Adjusted for splits/dividends
    - Automatic full refresh if stock splits/bonus detected after most recent cached date
    """

    today = pd.Timestamp.today().normalize()
    cutoff_date = today - pd.DateOffset(years=years_to_keep)

    # Step 1: Trim old cache
    try:
        yfc.trim_cache(before=cutoff_date)
        print(f"🧹 Cache trimmed: only data after {cutoff_date.date()} kept.")
    except Exception as e:
        print(f"⚠️ trim_cache() failed: {e}")

    # Step 2: Determine last cached date
    try:
        cached_data = yfc.get_cache(symbol)
        if cached_data is not None and not cached_data.empty:
            last_cached_date = cached_data.index.max()
        else:
            last_cached_date = cutoff_date
    except Exception as e:
        print(f"⚠️ Could not read cache for {symbol}: {e}")
        last_cached_date = cutoff_date

    # Step 3: Detect corporate actions only after last cached date
    try:
        actions = yfc.download(
            symbol,
            start=last_cached_date + pd.Timedelta(days=1),
            end=today,
            actions=True,
            max_age="1d"
        )
        force_full_refresh = False
        if not actions.empty and "Stock Splits" in actions.columns and actions["Stock Splits"].sum() > 0:
            print(f"⚠️ New stock splits/bonus detected for {symbol}, forcing full refresh.")
            force_full_refresh = True
    except Exception as e:
        print(f"⚠️ Failed to check corporate actions for {symbol}: {e}")
        force_full_refresh = False

    # Step 4: Fetch data (incremental or full refresh)
    max_age = "0s" if force_full_refresh else f"{years_to_keep}y"
    try:
        data = yfc.download(
            symbol,
            start=cutoff_date,
            end=today,
            interval="1d",
            adjust_splits=True, #
            adjust_divs=True, #
            max_age=max_age, #
            back_adjust=True,
            repair=True,
            auto_adjust=True,
            progress=False,
            keepna=False
        ).sort_index()
    except Exception as e:
        print(f"⚠️ Failed to download data for {symbol}: {e}")
        data = pd.DataFrame()

    # Step 5: Keep only last N years in memory
    if not data.empty:
        data = data[data.index >= cutoff_date]

    return data



            symbol,
            start=START_DATE,
            end=END_DATE,
            interval="1d", #1wk
            rounding=True,
            multi_level_index=False,
            threads=True,
            progress=False,
            back_adjust=True,
            repair=True,  # Data repair is used to fill in missing or corrupted data
            keepna=False,  # removes any rows with missing data.
            actions=False,  #excludes dividend and stock split events from the dat
            auto_adjust=True  #adjusted for corporate actions like stock splits and dividends
            #ignore_tz=True
        )
'''


# import logging
# logger = logging.getLogger('yfinance')
# logger.setLevel(logging.ERROR)  # default: only print errors
# logger.setLevel(logging.CRITICAL)  # disable printing
# logger.setLevel(logging.DEBUG)  # verbose: print errors & debug info


def find_missing_bo_symbols(incomplete_data_tickers):
    base_path = "/home/rizpython236/BT5"
    ticker_path = os.path.join(base_path, "ticker_15yr")
    bse_nse_file = os.path.join(base_path, "bse_nse_common.csv")
    bse_nse_file1 = os.path.join(base_path, "bse_nse_common_download.csv")
    EXCLUDE_TICKERS_CSV = os.path.join(base_path, "exclude_tickers.csv")
    exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)
    # list1=incomplete_data_tickers
    list1 = [item.replace(".BO", "").replace(".NS", "")
             for item in incomplete_data_tickers]

    # Step 1: Get all filenames ending with .NS.csv and strip .NS.csv
    ns_files = [f for f in os.listdir(ticker_path) if f.endswith(".NS.csv")]
    ns_symbols = [f.replace(".NS.csv", "") for f in ns_files] + list1

    # Step 2: Read bse_nse_common.csv and strip ".BO"
    bse_nse_df = pd.read_csv(bse_nse_file)
    bse_nse_df["Symbol"] = bse_nse_df["Symbol"].str.replace(
        ".BO", "", regex=False)

    # Step 3: Find symbols in bse_nse_common but not in ticker_15yr
    missing_symbols = sorted(set(bse_nse_df["Symbol"]) - set(ns_symbols))

    # Step 4: Create DataFrame with .BO suffix
    missing_bo_df = pd.DataFrame(
        {"Symbol": [sym + ".BO" for sym in missing_symbols]})
    missing_bo_df = missing_bo_df[~missing_bo_df["Symbol"].isin(
        exclude_tickers["Symbol"])]

    # Step 5: Save to CSV (overwrite)
    missing_bo_df.to_csv(bse_nse_file1, index=False)

    # Step 4: Print symbols with .BO suffix
    missing_bo = [sym + ".BO" for sym in missing_symbols]

    # Step 6: Print percentage missing
    total_symbols = len(bse_nse_df)
    downloaded_symbols = len(ns_symbols)
    missing_count = len(missing_bo_df)
    percent_missing = (missing_count / total_symbols *
                       100) if total_symbols > 0 else 0

    print(f"Total symbols in bse_nse_common.csv: {total_symbols}")
    print(f"Downloaded symbols : {downloaded_symbols}")
    print(
        f"Missing symbols To be downloaded: {missing_count} ({percent_missing:.2f}%)")
    post_telegram_message(
        f"To be downloaded .BO symbols: {missing_count} from {total_symbols} ({percent_missing:.2f}%)")
    print(f"Saved missing .BO symbols to {bse_nse_file1}")
    # print(missing_bo)
    return missing_bo, missing_count


def download_ticker_data(symbol):
    try:
        # Check if ticker is valid
        ticker = yf.Ticker(symbol)
        # Your validation logic here
        last_price = 1000  # Your actual validation code
        reg_mp = last_price > 15

        if not reg_mp:
            return symbol, None  # Return None for invalid tickers

        # Download data
        data = yf.download(
            symbol,
            start=START_DATE,
            end=END_DATE,
            interval="1d",
            rounding=True,
            threads=False,
            multi_level_index=False,
            progress=False,
            back_adjust=True,
            repair=False,
            keepna=False,
            actions=False,
            auto_adjust=True,

            # adjust_splits=True,
            # adjust_divs=True,
            # max_age="3y"       # Cache expiry
        )

        if len(data) > 55:
            data.index = data.index.date
            data.rename_axis("Date", inplace=True)
            return symbol, data
        return symbol, None

    except Exception as e:
        return symbol, None


print("Initiating daily 15yr Data Downloader!")
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

# today = datetime.now(IST_TIMEZONE).date()
# yesterday = today - timedelta(days=1)
# end_date = yesterday


# - timedelta(days=1) # - timedelta(weeks=1)
end_date = datetime.now(IST_TIMEZONE).date()
# end_date = date.today()
# start_date = end_date - timedelta(days=320)
# start_date = end_date - timedelta(weeks=52 + 1)  - timedelta(days=1) # 77 weekly
start_date = end_date - timedelta(weeks=53, days=3)

END_DATE = str(end_date)
START_DATE = str(start_date)
# Calculate number of days
working_days = len(pd.bdate_range(start_date, end_date))
total_days = (end_date - start_date).days
print(f"Period: {start_date} to {end_date} = {working_days} working days ({total_days} total days)")

# print(START_DATE)
# post_telegram_message(START_DATE)
print(f"start date {START_DATE} ,end date {END_DATE}.")
time.sleep(1)
# post_telegram_message(END_DATE)
post_telegram_message(
    f"Period: {start_date} to {end_date} = {working_days} working days ({total_days} total days)")

dir5 = "/home/rizpython236/BT5/ticker_15yr"
for f in os.listdir(dir5):
    os.remove(os.path.join(dir5, f))


# SYMBOLS_CSV= "/home/rizpython236/BT5/Finalnse.csv"
# SYMBOLS_CSV= "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
SYMBOLS_CSV = "/home/rizpython236/BT5/symbol_list.csv"
ticker_csv_file_path = "/home/rizpython236/BT5/ticker_15yr"
TICKER_CSV_DATA_FOLDER_PATH = "/home/rizpython236/BT5/ticker_15yr"


# ticker_symbols_file = "symbol.csv"
tickers_df = pd.read_csv(SYMBOLS_CSV)
tickers_list = sorted(tickers_df["Symbol"].unique(), key=lambda x: (
    not str(x).endswith(".NS"), str(x)))[:]
# tickers_list = list(tickers_df["Symbol"].unique())[:20]
tickers_list.insert(0, "^NSEI")
# tickers_list.append("^NSEI")
# tickers_list= ["^NSEI","^NSEBANK","RELIANCE.NS","INFY"]
additional_tickers = ["^NSEI", "^NSEBANK", "^CRSLDX", "^NSMIDCP",
                      "^CRSMID", "^CNXSC", "RELIANCE.NS", "INFY", "LOTUSEYE.NS", "MARUTI.NS"]
# tickers_list.extend(additional_tickers)
# tickers_list = additional_tickers + tickers_list
additional_tickers = ["^NSEI", "^NSEBANK"]
# tickers_list.extend(additional_tickers)


# # Downloading data
print("-" * 100)
print(f"Starting download for data from {start_date} to {end_date}.")
print("-" * 100)

invalid_tickers = []
incomplete_data_tickers = []
valid_tickers = []
symbol_len = []


print("Total number of symbols: ", len(tickers_list))
count = 0
counterror = 0
datasum = 0
datacount = 0
total_symbols = len(tickers_list)


df_exclude = pd.DataFrame(columns=["Symbol"])
exclude_file = "/home/rizpython236/BT5/exclude_tickers.csv"
df_excludeold = pd.read_csv(exclude_file)

for symbol in tickers_list:
    count += 1
    if count % 220 == 0:
        print(f"Processed {count} symbols. Pausing for 5 minutes...")
        time.sleep(2 * 60)  # 600 seconds = 10 minutes

    # count +=1
    # print(count)
    # print("Total number of processed symbols: ", count, "({:.2f}%)".format(count / total_symbols * 100))
    remaining_symbols = total_symbols - count
    # print("Total number of remaining symbols: ", remaining_symbols, "({:.2f}%)".format(remaining_symbols / total_symbols * 100))
    # detecting invalid tickers

    try:
        # print("Downloading data for => {}".format(symbol))
        data = yf.download(
            symbol,
            start=START_DATE,
            end=END_DATE,
            interval="1d",  # 1wk
            rounding=True,
            multi_level_index=False,
            threads=False,
            progress=False,
            back_adjust=True,
            repair=True,  # Data repair is used to fill in missing or corrupted data
            keepna=False,  # removes any rows with missing data.
            actions=False,  # excludes dividend and stock split events from the dat
            auto_adjust=True,  # adjusted for corporate actions like stock splits and dividends
            # ignore_tz=True
        )
        # data = data.copy()

        if (count - counterror) % 200 == 0:
            print(f"{symbol}, len {len(data)}, count{count} downloded")

        ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
        # print(f"{symbol} {len(data)}")
        if len(data) > 245 and (data["Close"].iloc[-1] > 50 or symbol == "^INDIAVIX" or symbol.startswith("^") or symbol.startswith("CNXC") or symbol.startswith("TJI_") or re.search(r"BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP", symbol)):
            datalen = len(data)
            datasum += datalen
            datacount += 1
            data.index = data.index.date
            data.rename_axis("Date", inplace=True)
            data = data.reset_index()
            # columns_order = ["Date", "Close", "High", "Low", "Open", "Volume"] #"Repaired?",
            # drop "Repaired?" if it exists, keep the rest
            # columns_order = [col for col in data.columns if col != "Repaired?"]
            data = data.drop(columns=["Repaired?"], errors="ignore")
            # print(data)
            data.to_csv(ticker_csv_file_path, index=False)
            valid_tickers.append(symbol)
            # if (data['Close'].iloc[-126] and data['Close'].iloc[-1] ) > 50:
            # data.to_csv(ticker_csv_file_path)
        # and pd.notna(data['Volume'].iloc[-1])) :
        elif (len(data) > 5 and len(data) < 240) or (len(data) > 2 and data["Close"].iloc[-1] < 35 and symbol != "^INDIAVIX" and not symbol.startswith("^") and not symbol.startswith("TJI_")):
            # df_exclude = pd.DataFrame(columns=["Symbol"])
            # exclude_file = "/home/rizpython236/BT5/exclude_tickers.csv"
            # df_excludeold = pd.read_csv(exclude_file)
            incomplete_data_tickers.append(symbol)
            symbol_len.append({"Symbol": symbol, "Len": len(
                data), "Close": data["Close"].iloc[-1]})
            1 + 1
            # print(data)
            # df_exclude = pd.concat([df_excludeold, pd.DataFrame({"Symbol": [symbol]})], ignore_index=True)
            # df_exclude = df_exclude.drop_duplicates(subset=["Symbol"], ignore_index=True)
            # df_exclude.to_csv(exclude_file, index=False)

    except:  # yf.exceptions.TickerSymbolError: #
        traceback_str = traceback.format_exc()
        # print(traceback_str)
        # if not ( symbol == "^INDIAVIX" or symbol.startswith("^") or symbol.startswith("CNXC") or symbol.startswith("TJI_") or re.search(r"BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP", symbol) ):
        #    ###invalid_tickers.append(symbol)
        #    1+1
        counterror += 1

        # df_exclude = pd.concat([df_excludeold, pd.DataFrame({"Symbol": [symbol]})], ignore_index=True)
        # print("Invalid ticker - {}".format(symbol))
        continue

    time.sleep(1.5)


time.sleep(3 * 60)

exclude_file = "/home/rizpython236/BT5/exclude_tickers.csv"
df_exclude = pd.read_csv(exclude_file)
exclude_tickers = set(df_exclude["Symbol"].dropna().astype(str))
datacount1 = 0
datacount2 = 0

missing_bo, missing_count = find_missing_bo_symbols(incomplete_data_tickers)
# missing_bo = missing_bo

# missing_bo =['BAJAJFINSV.NS','BAJAJFINSV.BO','AWFIS.NS']
# for symbol in missing_bo:
# valid_tickers exclude_tickers
for symbol in (s for s in missing_bo if s not in exclude_tickers):
    datacount1 += 1
    if datacount1 % 220 == 0:
        print(f"Processed {datacount1} symbols. Pausing for 5 minutes...")
        time.sleep(2 * 60)  # 600 seconds = 10 minutes
    try:
        data = yf.download(
            symbol,
            start=START_DATE,
            end=END_DATE,
            interval="1d",  # 1wk
            rounding=True,
            multi_level_index=False,
            threads=False,
            progress=False,
            back_adjust=True,
            repair=True,  # Data repair is used to fill in missing or corrupted data
            keepna=False,  # removes any rows with missing data.
            actions=False,  # excludes dividend and stock split events from the dat
            auto_adjust=True,  # adjusted for corporate actions like stock splits and dividends
            # ignore_tz=True
        )
        # print(data)

        if (datacount1 - 0) % 200 == 0:
            print(f"{symbol}, len {len(data)}, count{datacount1} downloded")

        # print(f"{symbol} {len(data)}")
        file_symbol = symbol.replace(".BO", ".NS")
        ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + file_symbol + ".csv"
        # print(f"{symbol} {len(data)}")
        if len(data) > 245 and (data["Close"].iloc[-1] > 50 or symbol == "^INDIAVIX" or symbol.startswith("^") or symbol.startswith("CNXC") or symbol.startswith("TJI_") or re.search(r"BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP", symbol)):
            datalen = len(data)
            datasum += datalen
            datacount += 1
            datacount2 += 1
            data.index = data.index.date
            data.rename_axis("Date", inplace=True)
            data = data.reset_index()
            # columns_order = ["Date", "Close", "High", "Low", "Open", "Volume"] #"Repaired?",
            # drop "Repaired?" if it exists, keep the rest
            # columns_order = [col for col in data.columns if col != "Repaired?"]
            data = data.drop(columns=["Repaired?"], errors="ignore")
            # print(data)
            data.to_csv(ticker_csv_file_path, index=False)
            if symbol in incomplete_data_tickers:
                incomplete_data_tickers.remove(symbol)
            if symbol in invalid_tickers:
                invalid_tickers.remove(symbol)
            # incomplete_data_tickers.remove(symbol)
            # invalid_tickers.remove(symbol)
            valid_tickers.append(symbol)
            # if (data['Close'].iloc[-126] and data['Close'].iloc[-1] ) > 50:
            # data.to_csv(ticker_csv_file_path)
            # print(data)
        # and pd.notna(data['Volume'].iloc[-1])) :
        elif (len(data) > 5 and len(data) < 240) or (len(data) > 2 and data["Close"].iloc[-1] < 35 and symbol != "^INDIAVIX" and not symbol.startswith("^") and not symbol.startswith("TJI_")):
            # df_exclude = pd.DataFrame(columns=["Symbol"])
            # exclude_file = "/home/rizpython236/BT5/exclude_tickers.csv"
            # df_excludeold = pd.read_csv(exclude_file)
            incomplete_data_tickers.append(symbol)
            # symbol_len.append({"Symbol": symbol, "Len": len(data)})
            symbol_len.append({"Symbol": symbol, "Len": len(
                data), "Close": data["Close"].iloc[-1]})
            1 + 1
            # print(data)
            # df_exclude = pd.concat([df_excludeold, pd.DataFrame({"Symbol": [symbol]})], ignore_index=True)
            # df_exclude = df_exclude.drop_duplicates(subset=["Symbol"], ignore_index=True)
            # df_exclude.to_csv(exclude_file, index=False)

    except:  # yf.exceptions.TickerSymbolError: #
        traceback_str = traceback.format_exc()
        print(traceback_str)
        # if not ( symbol == "^INDIAVIX" or symbol.startswith("^") or symbol.startswith("CNXC") or symbol.startswith("TJI_") or re.search(r"BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP", symbol) ):
        #    ##########invalid_tickers.append(symbol)
        #    1+1
        counterror += 1
        # df_exclude = pd.concat([df_excludeold, pd.DataFrame({"Symbol": [symbol]})], ignore_index=True)
        # print("Invalid ticker - {}".format(symbol))
        continue

    time.sleep(.5)


percent_missing = (datacount2 / missing_count *
                   100) if missing_count > 0 else 0
print(
    f"Missing symbols downloaded: {datacount2} from {missing_count} ({percent_missing:.2f}%)")
post_telegram_message(
    f"Missing symbols downloaded: {datacount2} from {missing_count} ({percent_missing:.2f}%)")

# df_exclude = df_exclude.drop_duplicates(subset=["Symbol"], ignore_index=True)
# df_exclude.to_csv(exclude_file, index=False)


"""
# Using ThreadPoolExecutor to parallelize downloads
with ThreadPoolExecutor(max_workers=10) as executor:  # Adjust max_workers as needed
    # Submit all download tasks
    future_to_symbol = {
        executor.submit(download_ticker_data, symbol): symbol
        for symbol in tickers_list
    }

    # Use tqdm to show progress
    for future in tqdm(as_completed(future_to_symbol), total=len(tickers_list), desc="Downloading"):
        symbol = future_to_symbol[future]
        try:
            result_symbol, data = future.result()
            if data is None:
                invalid_tickers.append(symbol)
            else:
                # Save the data to CSV
                ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
                data.to_csv(ticker_csv_file_path)
                valid_data[symbol] = data
        except Exception as e:
            invalid_tickers.append(symbol)
        time.sleep(0.10)  # Small delay to avoid rate limiting

print(f"\nData download task completed. {len(valid_tickers)} valid tickers, {len(invalid_tickers)} invalid tickers.")
"""

print("Data download task completed.")
print("Validating data and removing incomplete ticker-data files.")

datamean = datasum / datacount if datacount != 0 else 0
# datamean = int(datasum/datacount)
print(datamean)


def get_filepaths(directory):
    """This function lists all the file names present in directory.
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)  # Add it to the list.

    return file_paths


def check_data_continuity(df, interval=7):
    """Input - df with datetime index and interval to check gaps for
    output - this func will return False if there are gaps present
    otherwise return True
    """
    deltas = df["Date"].diff()[1:]
    datetime_gaps = deltas[deltas > timedelta(days=interval)]
    return datetime_gaps.empty


def check_num_rows(df1, df2):
    return df1.shape[0] >= df2.shape[0]


files_to_process = get_filepaths(TICKER_CSV_DATA_FOLDER_PATH)
nifty_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + NIFTY_CSV
nifty_df = pd.read_csv(nifty_file_path)  # , parse_dates=["Date"])
nifty_df.dropna(inplace=True)
nifty_rows = len(nifty_df)
# nifty_row =len(nifty_df)
# print(nifty_row)

nifty_start_date, nifty_end_date = nifty_df["Date"][0], nifty_df["Date"][nifty_rows - 1]

if len(nifty_start_date) == 10:
    nifty_start_date_obj = datetime.strptime(
        nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()
elif len(nifty_start_date) == 25:
    nifty_start_date_obj = datetime.strptime(
        nifty_start_date, "%Y-%m-%d %H:%M:%S%z").date()
    nifty_end_date_obj = datetime.strptime(
        nifty_end_date, "%Y-%m-%d %H:%M:%S%z").date()
else:
    nifty_start_date_obj = datetime.strptime(
        nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()

nifty_df["Date"] = pd.to_datetime(nifty_df["Date"], errors="coerce")

# nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
# nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()

# nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d %H:%M:%S%z").date()
# nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d %H:%M:%S%z").date()

# incomplete_data_tickers = []
# valid_tickers = []


for file in files_to_process:
    """folder\\BHARTIAIRTEL.NS.csv"""
    ticker_name = file.split("/")[-1:][0]  # file.split("\\")[1]
    ticker_name = ticker_name.split(".csv")[0]

    # print("Validating {} file".format(ticker_name))
    ticker_df = pd.read_csv(file, parse_dates=["Date"])
    # print(len(ticker_df))

    # Drops rows where OHLC = 0 or value = NA
    ticker_df.dropna(inplace=True)
    ticker_df = ticker_df[ticker_df.Open != 0]
    ticker_df = ticker_df[ticker_df.High != 0]
    ticker_df = ticker_df[ticker_df.Low != 0]
    ticker_df = ticker_df[ticker_df.Close != 0]
    # ticker_df = ticker_df[ticker_df.Volume != 0] #
    # ticker_df = ticker_df[ticker_df.Close != ticker_df.Open] #
    ticker_df["Volume"] = ticker_df["Volume"].replace(0, 1)
    ticker_df["Volume"] = ticker_df["Volume"].fillna(1)

    ticker_df.reset_index(drop=True, inplace=True)
    Ticker_rows = len(ticker_df)
    # print(len(ticker_df))
    ticker_df["Date"] = pd.to_datetime(ticker_df["Date"]).dt.date

    # Delete rows earlier than nifty start-date
    # ticker_df = ticker_df[ticker_df["Date"] >= nifty_start_date_obj]
    # Delete rows if any present after nifty end date
    # ticker_df = ticker_df[ticker_df["Date"] <= nifty_end_date_obj]

    ticker_df["Date"] = pd.to_datetime(ticker_df["Date"], errors="coerce")
    # Keep only rows where Date is also in df2
    # ₹ticker_df = ticker_df[ticker_df["Date"].isin(nifty_df["Date"])]

    # CHECK IF DATA IS CONTINUOUS - PROPER WEEKLY GAPS
    # is_data_rows_equals_nifty = check_num_rows(ticker_df,nifty_df)  #for daily
    # is_data_continuous = check_data_continuity(ticker_df)   #weekly

    # if not check_data_continuity:  #is_data_rows_equals_nifty use for daily data
    #    print("Weekly gaps found in {}".format(ticker_name))
    # else:
    #    #print("Data is consistent in weekly TF for {}".format(ticker_name))
    #    1+1

    # DECIDE - HOW TO FILTER

    # Only check if the total rows are atleast 52 and data cont in weekly TF
    # >= 255:# and check_data_continuity:#  and is_data_rows_equals_nifty == True: #and check_data_continuity
    if len(ticker_df) >= nifty_rows:

        # Check if either rows are atleast 52 or atleast >= nifty-rows
        # if len(ticker_df) >= 52 or len(ticker_df) >= nifty_rows:
        # print(
        #    "Complete Data Ticker => {} with total rows => {} vs Nifty {} rows".format(
        #        ticker_name, Ticker_rows,nifty_rows
        #    )
        # )
        valid_tickers.append(ticker_name)
        ticker_df.to_csv(file, index=False)
    else:
        # incomplete_data_tickers.append(ticker_name)
        # df_exclude = pd.concat([df_excludeold, pd.DataFrame({"Symbol": [ticker_name]})], ignore_index=True)
        # print('xxx')
        # deleting the incomplete ticker data file
        if len(ticker_df) - 1 >= nifty_rows:  # 287
            print(
                f"Incomplete Data Ticker for => {ticker_name} with total rows => {len(file)} vs Nifty {nifty_rows} rows",
            )
        if os.path.exists(file):
            os.remove(file)

fix_dates_fast("/home/rizpython236/BT5/ticker_15yr")

# If order does not matters
# invalid_tickers = list(set(invalid_tickers))
# incomplete_data_tickers = list(set(incomplete_data_tickers))
# valid_tickers = list(set(valid_tickers))

# If order matters
invalid_tickers = list(dict.fromkeys(invalid_tickers))
incomplete_data_tickers = list(dict.fromkeys(incomplete_data_tickers))
valid_tickers = list(dict.fromkeys(valid_tickers))

exclude_List = incomplete_data_tickers + invalid_tickers
df_exclude_List = pd.DataFrame({"Symbol": exclude_List})
df_exclude = pd.concat([df_excludeold, df_exclude_List], ignore_index=True)
df_exclude = df_exclude.drop_duplicates(subset=["Symbol"], ignore_index=True)
df_exclude.to_csv(exclude_file, index=False)
print(f"df_exclude_List Len {len(df_exclude_List)}")


try:
    # Load index constituents from a CSV file
    csv_path = "/home/rizpython236/BT5/trade-logs/index_constituents.csv"
    index_constituents = load_index_constituents_from_csv(csv_path)
    path = TICKER_CSV_DATA_FOLDER_PATH  # '/home/rizpython236/BT5/ticker_15yr'
    # Calculate indices
    # valid_tickers = []
    # Choose 'price', 'Price_equal', return_equal or 'custom'." RSI  ATR
    calculate_custom_index(path, index_constituents,
                           weighting_method="return_equal", valid_tickers=valid_tickers)

    index_names = ["TJI_RTGAGY", "TJI_alkCHE"]
    # Define the index names to plot
    TJI_IC_path = "/home/rizpython236/BT5/trade-logs/TJI_index.csv"
    TJI_IC_path = pd.read_csv(TJI_IC_path)
    TJI_IC_path = TJI_IC_path["Symbol"].tolist()[:]
    # TJI_IC_path = list(set(TJI_IC_path))

    index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
    # path=  '/home/rizpython236/BT5/ticker_15yr'
    # Plot the Close Prices of the indices
    # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(
        path, TJI_IC_path[:33], index_csv_file, Frequency="Daily")
    # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(
        path, TJI_IC_path[33:], index_csv_file, Frequency="Daily")
    # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(
        path, TJI_IC_path[:], index_csv_file, Frequency="All200daily")

except Exception as e:
    print(f"Error occurred: {e!s}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    # print("Error type:", e.__class__.__name__)
    # print("Error message:", str(e))
    # print("Traceback:\n", traceback_str)
# ____________________________________________


invalid_tickers_df = pd.DataFrame()

invalid_tickers_df["invalid_ticker"] = invalid_tickers
INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
# invalid_tickers_df.to_csv(INVALID_TICKERS_FILE_PATH, index=False)

valid_tickers_df = pd.DataFrame()
valid_tickers_df["Symbol"] = valid_tickers


vt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + VALID_TICKERS_CSV
# valid_tickers_df.to_csv(vt_file_path, index=False)
vt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + "Valid15yr.csv"
# valid_tickers_df.to_csv(vt_file_path, index=False)

incomplete_data_tickers_df = pd.DataFrame()
incomplete_data_tickers_df["Symbol"] = incomplete_data_tickers
idt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV
# incomplete_data_tickers_df.to_csv(idt_file_path, index=False)


# Folder path where your ticker CSV files are stored
TICKER_CSV_DATA_FOLDER_PATH = "/home/rizpython236/BT5/ticker_15yr"

# 1️⃣ Collect all CSV filenames in the folder
download_list = [
    os.path.splitext(f)[0]  # remove ".csv" extension
    for f in os.listdir(TICKER_CSV_DATA_FOLDER_PATH)
    if f.endswith(".csv")
]

exclude_list = df_exclude["Symbol"].dropna().tolist()

# 2️⃣ Compute unique tickers (ignoring .NS / .BO suffixes)

unique_tickers = (
    set(t.replace(".NS", "").replace(".BO", "") for t in tickers_list)
    - set(t.replace(".NS", "").replace(".BO", "") for t in download_list)
    - set(t.replace(".NS", "").replace(".BO", "") for t in exclude_list)
    # - set(t.replace('.NS', '').replace('.BO', '') for t in exclude_list)
)

# Preserve original suffixes (.NS or .BO)
unique_tickers_with_suffix = [
    t for t in tickers_list
    if t.replace(".NS", "").replace(".BO", "") in unique_tickers
]


# 3️⃣ Print nicely
# print(f"Error Tickers ({len(unique_tickers)}):", ', '.join(sorted(unique_tickers)))
# post_telegram_message(f"Error Tickers ({len(unique_tickers)}):", ', '.join(sorted(unique_tickers)))

# print(f"Total valid 1.5yr symbols: {len(download_list)}")
# post_telegram_message(f"Total valid 1.5yr daily symbols: {len(download_list)}")

print(
    f"Error Tickers ({len(unique_tickers_with_suffix)}): {', '.join(sorted(unique_tickers_with_suffix))}\n "
    f"Total valid 1.5yr symbols: {len(download_list)}",
)

# post_telegram_message(
#    f"Error Tickers ({len(unique_tickers_with_suffix)}): {', '.join(sorted(unique_tickers_with_suffix))} | "
#    f"Total valid 1.5yr symbols: {len(download_list)}",
# )

post_telegram_message(
    f"Total valid 1.5yr symbols: {len(download_list)}")

print(
    f"EXCLUDE_TICKERS_manual_CSV updated with {len(unique_tickers_with_suffix)} error symbols")

if len(download_list) > 1500 and len(unique_tickers_with_suffix) < 1000:
    # from settings import (
    #    EXCLUDE_TICKERS_CSV,
    # )

    EXCLUDE_TICKERS_manual_CSV1 = "/home/rizpython236/BT5/exclude_tickersmanual.csv"

    # exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)
    EXCLUDE_TICKERS_manual_CSV = pd.read_csv(
        "/home/rizpython236/BT5/exclude_tickersmanual.csv")

    # Convert your list to a DataFrame
    # unique_tickers_with_suffix_df = pd.DataFrame({"Symbol": unique_tickers_with_suffix})

    import random
    # Add 'xxx' at the end of the list
    # unique_tickers_with_suffix.append("xxx")
    # Add 'xxx' + random 3-digit number (e.g., xxx742)
    unique_tickers_with_suffix.append(f"xxx{random.randint(1, 999)}")

    # Create DataFrame from list and sort alphabetically
    unique_tickers_with_suffix_df = (
        pd.DataFrame({"Symbol": unique_tickers_with_suffix})
        # .sort_values(by="Symbol")
        .reset_index(drop=True)
    )

    df_combined = (pd.concat([EXCLUDE_TICKERS_manual_CSV, unique_tickers_with_suffix_df],
                   ignore_index=True).drop_duplicates(subset="Symbol", keep="first"))
    df_combined.to_csv(EXCLUDE_TICKERS_manual_CSV1, index=False)
    # exclude_tickers = df_combined
    # print(
    #    f"EXCLUDE_TICKERS_manual_CSV updated with {len(unique_tickers_with_suffix)} error symbols")
    post_telegram_message(
        f"Error Tickers ({len(unique_tickers_with_suffix)}): {', '.join(sorted(unique_tickers_with_suffix))}\n"
        f"EXCLUDE_TICKERS_manual_CSV updated with error symbols")


df = pd.DataFrame(symbol_len)
# df2 = df.copy()
print(df)
if len(df) > 1:
    filtered_dfxx = df[df["Close"] > 35]
    print(f"Maximum data days: {filtered_dfxx['Len'].max()} days")
    print(f"Minimum data days: {filtered_dfxx['Len'].min()} days")
    print(f"Median data days: {filtered_dfxx['Len'].median()} days")

    # Filter rows where Len > 200
    filtered_df35 = df.loc[df["Close"] < 35, ["Symbol", "Len"]].dropna()
    # filtered_df = df.loc[(df["Len"] > 200) & (df["Len"] < 250), ["Symbol", "Len"]].dropna()
    filtered_df = df.loc[(df["Len"] > 200) & (df["Len"] < 250) & (
        df["Close"] > 35), ["Symbol", "Len", "Close"]].dropna()

    # Sort alphabetically by Symbol
    filtered_df = filtered_df.sort_values(by="Symbol")

    # Print all symbols and their lengths
    print(f"Symbols with Close < 35 ({len(filtered_df35)}):")
    # print(f"Symbols with Len > 200 ({len(filtered_df)}):")
    # print(", ".join(f"{row.Symbol} ({int(row.Len)})" for row in filtered_df.itertuples(index=False)))
    post_telegram_message(
        f"Incomplete Symbols with Len > 200 ({len(filtered_df)}):")
    post_telegram_message(", ".join(
        f"{row.Symbol} ({int(row.Len)})" for row in filtered_df.itertuples(index=False)))

    # Example: create bins every 50 units
    bins = [0, 50, 100, 150, 200, 225, 250, 300]

    df = df.loc[df["Close"] > 35, ["Symbol", "Len"]].dropna()

    # Create bin labels (optional)
    labels = [f"{bins[i]+1}-{bins[i+1]}" for i in range(len(bins)-1)]

    # Assign each row to a bin
    df["Len_bin"] = pd.cut(df["Len"], bins=bins,
                           labels=labels, include_lowest=True)

    # Group by those bins
    grouped = df.groupby("Len_bin").size().reset_index(name="Count")

    print(grouped)
