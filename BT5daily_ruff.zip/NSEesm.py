import os
import sys


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")
#import helium
import time

#import pytz
import traceback

from add_company_name import (
    add_company_names_and_industry,
    copyfile1,
    update_output_file,
    vlookup_and_merge,
)
import matplotlib.pyplot as plt
import pandas as pd
from PDFconvert import create_pdf
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By

#from selenium.webdriver.chrome.service import Service
#from selenium.webdriver.edge.service import Service
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.support import expected_conditions as EC

#from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager


print("IPO DATA")


# Set up Chrome options
chrome_options = Options()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--window-size=1920,1080")
chrome_options.add_argument("--disable-blink-features=AutomationControlled")
#chrome_options.add_argument("--disable-dev-shm-usage")  # Prevent shared memory issues
chrome_options.add_argument("--disable-crash-reporter")
chrome_options.add_argument("--disable-extensions")
#chrome_options.add_argument("--start-maximized")
#chrome_options.add_argument("--disable-infobars")

chrome_options.add_experimental_option("prefs", {
    #"download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True
})

#driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
#driver.quit()
'''
#_________________________________
# Edge browser specific options (similar to Chrome options)
edge_options = webdriver.EdgeOptions()
edge_options.add_argument("--no-sandbox")
edge_options.add_argument("--headless")  # Optional for headless mode
edge_options.add_argument("--disable-gpu")
edge_options.add_argument("--window-size=1920,1080")
edge_options.add_argument("--disable-blink-features=AutomationControlled")

# Other options can be similarly added as needed (refer to Edge options documentation)

# Download and install compatible Edge WebDriver using webdriver_manager
#service = Service(EdgeChromiumDriverManager().install())
#driver = webdriver.Edge(service=service, options=edge_options)
driver = webdriver.Edge(service=Service(EdgeChromiumDriverManager().install()), options=edge_options)
#driver = webdriver.Edge(options=edge_options)

# Your automation script using Edge WebDriver
url = "https://www.nseindia.com/reports/esm"
driver.get(url)

# ...

driver.quit()

#____________________________________ESM list
'''
# Firefox browser specific options
firefox_options = webdriver.FirefoxOptions()
firefox_options.add_argument("--no-sandbox")
firefox_options.add_argument("--headless")  # Optional for headless mode
firefox_options.add_argument("--disable-gpu")
firefox_options.add_argument("--window-size=1920,1080")
firefox_options.add_argument("--disable-blink-features=AutomationControlled")

# Download and install compatible GeckoDriver using webdriver_manager
#service = Service(GeckoDriverManager().install())
#driver = webdriver.Firefox(service=service, options=firefox_options)
driver = webdriver.Firefox(options=firefox_options)

# Your automation script using Edge WebDriver
url = "https://www.nseindia.com/reports/esm"
driver.get(url)



driver.quit()

# Initialize WebDriver
#driver = webdriver.Chrome(options=chrome_options)
#from selenium.webdriver.chrome.service import Service
#from selenium.webdriver.chrome.options import Options
#from selenium.webdriver.edge.options import Options
#options = Options()
#options.binary_location = '/path/to/microsoft-edge'  # Replace with the path to your Microsoft Edge binary
#driver = webdriver.Edge(options=options)

driver = webdriver.Chrome(options=chrome_options)


csv_filename = '/home/rizpython236/BT5/trade-logs/esm-latest.csv'
old_df = pd.read_csv(csv_filename)
old_df = old_df.drop(old_df.columns[0], axis=1)

# Replace "Limited" with an empty string in the second column of old_df
old_df[old_df.columns[1]] = old_df[old_df.columns[1]].str.replace("Limited", "", regex=False)
old_df[old_df.columns[1]] = old_df[old_df.columns[1]].str.replace("Ltd", "", regex=False)

# Selecting the 4th column by index
#fourth_column = old_df.iloc[:, 3]  # Remember, index starts at 0
#print(fourth_column.head())

# Alternatively, if you know the column name:
fourth_column_name = old_df.columns[2]
#print(old_df[fourth_column_name].head())

#print(old_df)


attempt = 0
max_attempts = 3
success = False

while attempt < max_attempts and not success:
    try:
        driver.refresh()
        time.sleep(10)

        # Open the webpage
        url = "https://www.nseindia.com/reports/esm"
        driver.get(url)

        driver.implicitly_wait(10)  # 10 seconds to wait for the page to load


        #ESM click

        element = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "/html/body/div[11]/div/section/div/div/div/div/div/div/div[1]/div[3]/ul/li/a/span"))
        )


        element = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "/html/body/div[11]/div/section/div/div/div/div/div/div/div[1]/div[3]/ul/li/a/span"))
        )

        # Scroll into view if needed
        driver.execute_script("arguments[0].scrollIntoView(true);", element)

        # Attempt to click using standard method
        try:
            element.click()
            print("Element clicked successfully using .click()!")
        except Exception as e:
            # Fallback to JavaScript click if standard click fails
            print(f"Standard click failed: {e}. Attempting JavaScript click.")
            driver.execute_script("arguments[0].click();", element)
            print("Element clicked successfully using JavaScript!")

        # Wait for the page to load
        driver.implicitly_wait(5)

        # Locate and click the export button to download the CSV file
        export_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Export')]"))
        )

        # Scroll into view
        driver.execute_script("arguments[0].scrollIntoView(true);", export_button)

        # Use JavaScript to click if needed
        #driver.execute_script("arguments[0].click();", export_button)


        # Attempt to click using standard method
        try:
            export_button.click()
            print("Element clicked successfully using .click()!")
        except Exception as e:
            # Fallback to JavaScript click if standard click fails
            print(f"Standard click failed: {e}. Attempting JavaScript click.")
            driver.execute_script("arguments[0].click();", export_button)
            print("Element clicked successfully using JavaScript!")


        # Wait for the file to download
        time.sleep(5)

        # Step 4: Load the downloaded CSV into a pandas DataFrame
        download_dir = '/home/rizpython236/BT5'
        csv_filename = f'{download_dir}/esm-latest.csv'
        new_df = pd.read_csv(csv_filename)

        input_file = '/home/rizpython236/BT5/esm-latest.csv'
        output_file = '/home/rizpython236/BT5/trade-logs/esm-latest.csv'
        copyfile1(input_file, output_file)

        # Drop the first column
        new_df = new_df.drop(new_df.columns[0], axis=1)

        # Replace "Limited" with an empty string in the second column of old_df
        new_df[new_df.columns[1]] = new_df[new_df.columns[1]].str.replace("Limited", "", regex=False)
        new_df[new_df.columns[1]] = new_df[new_df.columns[1]].str.replace("Ltd", "", regex=False)

        # Print and/or save the DataFrame as needed
        print(new_df.head())

        fourth_column_name = new_df.columns[2]

        # Identify new companies not in old DataFrame
        #new_companies = new_df[~new_df['ISIN \n'].isin(old_df['ISIN \n'])]
        new_companies = new_df[~new_df.columns[2].isin(old_df.columns[2])]

        print(new_companies)

        if not new_companies.empty:
            print("New Items Found:")
            file_path = '/home/rizpython236/BT5/screener-outputs/NEW_ESM_latest_Items.csv'
            updated_df.to_csv(file_path, index=False)

            input_csv_file = '/home/rizpython236/BT5/screener-outputs/NEW_ESM_latest_Items.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/NEW_added_ESM_Items.pdf'  # Replace with desired output PDF file
            create_pdf(input_csv_file, output_pdf_file)
            time.sleep(2)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/NEW_added_ESM_Items.pdf')
        else:
            print("NO added ESM_Items.")
            post_telegram_message("NO added ESM_Items")


        # Identify old companies not in new DataFrame
        #new_companies = new_df[~new_df['ISIN \n'].isin(old_df['ISIN \n'])]
        exited_companies = old_df[~old_df.columns[2].isin(new_df.columns[2])]

        print(exited_companies)

        if not exited_companies.empty:
            print("New Items Found:")
            file_path = '/home/rizpython236/BT5/screener-outputs/exited_ESM_companies.csv'
            updated_df.to_csv(file_path, index=False)

            input_csv_file = '/home/rizpython236/BT5/screener-outputs/exited_ESM_companies.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/exited_ESM_companies.pdf'  # Replace with desired output PDF file
            create_pdf(input_csv_file, output_pdf_file)
            time.sleep(2)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/exited_ESM_companies.pdf')
        else:
            print("NO exited ESM_Items")
            post_telegram_message("NO exited ESM_Items")


        success = True
        print("Download and processing successful.")

    except (TimeoutException, Exception) as e:
        attempt += 1
        print(f"Attempt {attempt} failed: {str(e)}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)

        if attempt < max_attempts:
            print("Retrying...")
        else:
            print("Max attempts reached. Failed to IPO_SME_data CSV.")
            post_telegram_message("ESM_data Error")

    finally:
        # Close the browser
        driver.quit()

'''
#________________________helium

driver.quit()


from selenium import webdriver
#from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

# Create ChromeOptions object
chrome_options = Options()

# Configure desired options
#chrome_options.add_argument("--headless")  # Run Chrome in headless mode (no GUI)
chrome_options.add_argument("--disable-gpu")  # Disable GPU for headless mode
chrome_options.add_argument("--no-sandbox")  # Required for Docker and other containerized environments


prefs = {
    #"download.default_directory": "/path/to/your/download/folder",  # Set your download folder
    "download.prompt_for_download": False,  # Disable download prompt
    "directory_upgrade": True  # Automatically overwrite existing files
}
chrome_options.add_experimental_option("prefs", prefs)

# Set up the WebDriver using webdriver-manager and ChromeOptions
#service = Service(ChromeDriverManager().install())
#driver = webdriver.Chrome(service=service, options=chrome_options)

driver = webdriver.Chrome(options=chrome_options)

csv_filename = '/home/rizpython236/BT5/trade-logs/esm-latest.csv'
old_df = pd.read_csv(csv_filename)
old_df = old_df.drop(old_df.columns[0], axis=1)

# Replace "Limited" with an empty string in the second column of old_df
old_df[old_df.columns[1]] = old_df[old_df.columns[1]].str.replace("Limited", "", regex=False)

# Selecting the 4th column by index
#fourth_column = old_df.iloc[:, 3]  # Remember, index starts at 0
#print(fourth_column.head())

# Alternatively, if you know the column name:
fourth_column_name = old_df.columns[2]
#print(old_df[fourth_column_name].head())

#print(old_df)


attempt = 0
max_attempts = 3
success = True

while attempt < max_attempts and not success:
    try:
        from helium import *
        time.sleep(10)
        # Open the webpage
        start_chrome("https://www.nseindia.com/reports/esm")
        # Rest of your script using Helium...
        #go_to("https://www.nseindia.com/reports/esm")
        click("Download (.csv)")  #<span id="dwldcsv">Download (.csv)</span>

        #kill_browser()


        # Wait for the file to download
        time.sleep(5)

        # Step 4: Load the downloaded CSV into a pandas DataFrame
        download_dir = '/home/rizpython236/BT5'
        csv_filename = f'{download_dir}/esm-latest.csv'
        new_df = pd.read_csv(csv_filename)

        input_file = '/home/rizpython236/BT5/esm-latest.csv'
        output_file = '/home/rizpython236/BT5/trade-logs/esm-latest.csv'
        copyfile1(input_file, output_file)

        # Drop the first column
        new_df = new_df.drop(new_df.columns[0], axis=1)

        # Replace "Limited" with an empty string in the second column of old_df
        new_df[new_df.columns[1]] = new_df[new_df.columns[1]].str.replace("Limited", "", regex=False)

        # Print and/or save the DataFrame as needed
        print(new_df.head())

        fourth_column_name = new_df.columns[2]

        # Identify new companies not in old DataFrame
        #new_companies = new_df[~new_df['ISIN \n'].isin(old_df['ISIN \n'])]
        new_companies = new_df[~new_df.columns[2].isin(old_df.columns[2])]

        print(new_companies)

        if not new_companies.empty:
            print("New Items Found:")
            file_path = '/home/rizpython236/BT5/screener-outputs/NEW_ESM_latest_Items.csv'
            updated_df.to_csv(file_path, index=False)

            input_csv_file = '/home/rizpython236/BT5/screener-outputs/NEW_ESM_latest_Items.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/NEW_ESM_Items.pdf'  # Replace with desired output PDF file
            create_pdf(input_csv_file, output_pdf_file)
            time.sleep(2)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/NEW_ESM_Items.pdf')
        else:
            print("No new items found.")
            post_telegram_message("NO ESM_Items")

        success = True
        print("Download and processing successful.")

    except (TimeoutException, Exception) as e:
        attempt += 1
        print(f"Attempt {attempt} failed: {str(e)}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)

        if attempt < max_attempts:
            print("Retrying...")
        else:
            print("Max attempts reached. Failed to IPO_SME_data CSV.")
            post_telegram_message("ESM_data Error")

    finally:
        # Close the browser
        kill_browser()

'''
