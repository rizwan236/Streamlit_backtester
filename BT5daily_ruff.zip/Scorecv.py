
import glob

#import talib
import numpy as np
import pandas as pd


def calculate_rate_of_change(prices,weeks=1):
    """
    Calculate the rate of change (ROC) of closing prices.

    Parameters:
        prices (list): A list of numerical closing prices.

    Returns:
        list: A list of rate of change values corresponding to the input prices.
    """
    roc = prices.pct_change()  *100 # for i in range(1, len(prices))]
    return roc

def calculate_lognormal_daily_returns(prices):
    """Calculates lognormal daily returns of a stock.

    Args:
        prices (pandas.Series): Time series of closing prices.

    Returns:
        pandas.Series: Time series of lognormal daily returns.
    """

    log_returns = np.log(prices)-np.log(prices.shift(1))   #np.log(prices.pct_change() + 1)
    return log_returns

def annualize_lognormal_returns(log_returns):
    """Annualizes lognormal returns.

    Args:
        log_returns (pandas.Series): Time series of lognormal returns.

    Returns:
        float: Annualized lognormal returns.
    """
    annualized_std = log_returns.std() * np.sqrt(252)  # Assuming 252 trading days in a year
    return annualized_std

def calculate_mean_and_std(data):
    """
    Calculate the mean and standard deviation of a list of numbers.

    Parameters:
        data (list): A list of numerical data.

    Returns:
        tuple: A tuple containing the mean and standard deviation.
    """
    mean = np.mean(data)
    std_dev = np.std(data)
    return mean, std_dev

#mean, std_dev = calculate_mean_and_std(data)


# List of CSV files for the 10 symbols
#csv_files = glob.glob("/home/rizpython236/BT5/ticker_15yr/*.csv")

csv_files = glob.glob("/home/rizpython236/BT5/ticker_daily1yr/*.csv")

# Limit to the first 5 CSV files
csv_files = csv_files[:1]

# Dictionary to store dataframes
dataframes = {}

# Read all CSV files into a dictionary of dataframes
for file in csv_files:
    symbol = file.split("/")[-1].replace(".csv", "")
    dataframes[symbol] = pd.read_csv(file, parse_dates=['Date'])

# Function to calculate the score for the last 5 dates using TA-Lib
def calculate_scores(dataframes):
    # Create a dictionary to hold the scores for each symbol
    scores = {symbol: [None] * (len(df) - 5) for symbol, df in dataframes.items()}

    # Get the list of dates from the first symbol's dataframe (assuming all symbols have the same dates)
    dates = dataframes[list(dataframes.keys())[0]]['Date']

    # Loop over each date for the last 5 dates (bottom up)
    for i in range(len(dates) - 5, len(dates)):
        # Initialize dictionaries to store mean and max closes
        mean_closes = {}
        max_closes = {}
        ROC3={}
        ROC6={}
        ROC12={}
        lognormal_returns={}
        annualized_lognormal_std={}
        momentum_ratio_3m={}
        momentum_ratio_6m={}
        momentum_ratio_12m={}
        mean_momentum_3m={}
        mean_momentum_6m={}
        mean_momentum_12m={}

        # Calculate mean close for the past 10 days for each symbol
        for symbol, df in dataframes.items():
            close_prices = df['Close'].values
            if i >= 10:
                mean_closes[symbol] = df['Close'][i-9:i+1].mean() #talib.SMA(close_prices, timeperiod=10)[i]
                max_closes[symbol] = df['Close'][i-9:i+1].max() #talib.MAX(close_prices, timeperiod=10)[i]

                ROC3[symbol] =calculate_rate_of_change(df['Close'][i-11:i+1],weeks=12)
                ROC6[symbol] =calculate_rate_of_change(df['Close'][i-23:i+1],weeks=24)
                ROC12[symbol] =calculate_rate_of_change(df['Close'][i-51:i+1],weeks=52)


                lognormal_returns[symbol] = calculate_lognormal_daily_returns(df['Close'][i-5:i+1])
                annualized_lognormal_std[symbol] = annualize_lognormal_returns(lognormal_returns[symbol])
                print(annualized_lognormal_std[symbol])
                #print(lognormal_returns)
                gg
                #annualized_std = np.std(returns_values, axis=0) * np.sqrt(52)
                #annualized_std = lognormal_returns.std(axis=0) * np.sqrt(52)

                momentum_ratio_3m[symbol]  = ROC3[symbol] / annualized_lognormal_std[symbol]
                momentum_ratio_6m[symbol]  = ROC6[symbol] / annualized_lognormal_std[symbol]
                momentum_ratio_12m[symbol]  = ROC12[symbol] / annualized_lognormal_std[symbol]

                number3m= len(momentum_ratio_3m)
                number6m= len(momentum_ratio_6m)
                number12m= len(momentum_ratio_12m)
                print(momentum_ratio_3m[symbol])
                print(number3m)


                mean_momentum_3m[symbol] = sum(momentum_ratio_3m[symbol][i-8:i+1]) #/number3m
                print(mean_momentum_3m)
                ff
                #df['mean_momentum_6m'] = sum(df['momentum_6m'])/number6m)
                #df['mean_momentum_12m'] = sum(df['momentum_12m'])/number12m)
                #df['std_momentum_3m'] = tb.STDDEV(df['momentum_3m'], timeperiod=number, nbdev=1)
                #df['std_momentum_6m'] = tb.STDDEV(df['momentum_6m'], timeperiod=number, nbdev=1) # Vectorized std calculation for 6m  df['momentum_6m'].pow(2).mean(axis=1)
                #df['std_momentum_12m'] = tb.STDDEV(df['momentum_12m'], timeperiod=number, nbdev=1)  #df['momentum_12m'].pow(2).mean(axis=1)  # Vectorized std calculation
                #print(df['Close'][i-9:i+1])
            else:
                mean_closes[symbol] = None
                max_closes[symbol] = None

        # Calculate the sum of max closes for the past 10 days across all symbols
        max_closes_sum = sum(value for value in max_closes.values() if value is not None)
        max_closes_values = [value for value in max_closes.values() if value is not None]
        #max_closes_mean = np.mean(max_closes_values)
        #max_closes_std_dev = np.std(max_closes_values)
        #print(max_closes_sum)

        # Calculate the score for each symbol
        for symbol in dataframes.keys():
            if max_closes[symbol] is not None and max_closes_sum != 0:
                score = mean_closes[symbol] / max_closes_sum

                z_score_3m =  (momentum_ratio_3m -df['mean_momentum_3m'].iloc[-1]) / df['std_momentum_3m'].iloc[-1]
                z_score_6m =  (momentum_ratio_6m -df['mean_momentum_6m'].iloc[-1]) / df['std_momentum_6m'].iloc[-1]
                z_score_12m = (momentum_ratio_12m -df['mean_momentum_12m'].iloc[-1])/ df['std_momentum_12m'].iloc[-1]


                # Calculate weighted average Z-score
                #weighted_zscore = 0.5 * z_score_12m + 0.5 * z_score_6m
                weighted_zscore = 0.45 * z_score_12m + 0.45 * z_score_6m + 0.1 * z_score_3m

                # Calculate normalized momentum score
                normalized_score = (1 + weighted_zscore) * (weighted_zscore >= 0) + (1 / (1 - weighted_zscore))**(-1) * (weighted_zscore < 0)
            else:
                score = None
            scores[symbol].append(score)
            #print(max_closes_sum)

    return scores


# Calculate scores
scores = calculate_scores(dataframes)

# Add the score column to each dataframe and save to CSV
for symbol, df in dataframes.items():
    # Update scores list to ensure correct length
    final_scores = scores[symbol][:len(df) - 5] + scores[symbol][-(5):]
    df['Score'] = final_scores
    #df.to_csv(f"/home/rizpython236/BT5/ticker_15yr/{symbol}.csv", index=False)
    #print(df)
    print(df.tail(7))

print("Scores calculated and added to CSV files for the last 5 dates from the bottom up.")







##########################

'''

import pandas as pd
import glob
#import talib
import numpy as np

def calculate_lognormal_daily_returns(prices):
    """Calculates lognormal daily returns of a stock.

    Args:
        prices (pandas.Series): Time series of closing prices.

    Returns:
        pandas.Series: Time series of lognormal daily returns.
    """

    log_returns = np.log(prices)-np.log(prices.shift())   #np.log(prices.pct_change() + 1)
    return log_returns

def calculate_mean_and_std(data):
    """
    Calculate the mean and standard deviation of a list of numbers.

    Parameters:
        data (list): A list of numerical data.

    Returns:
        tuple: A tuple containing the mean and standard deviation.
    """
    mean = np.mean(data)
    std_dev = np.std(data)
    return mean, std_dev

#mean, std_dev = calculate_mean_and_std(data)


# List of CSV files for the 10 symbols
#csv_files = glob.glob("/home/rizpython236/BT5/ticker_15yr/*.csv")

csv_files = glob.glob("/home/rizpython236/BT5/ticker_daily1yr/*.csv")

# Limit to the first 5 CSV files
csv_files = csv_files[:1]

# Dictionary to store dataframes
dataframes = {}

# Read all CSV files into a dictionary of dataframes
for file in csv_files:
    symbol = file.split("/")[-1].replace(".csv", "")
    dataframes[symbol] = pd.read_csv(file, parse_dates=['Date'])

# Function to calculate the score for the last 5 dates using TA-Lib
def calculate_scores(dataframes):
    # Create a dictionary to hold the scores for each symbol
    scores = {symbol: [None] * (len(df) - 5) for symbol, df in dataframes.items()}

    # Get the list of dates from the first symbol's dataframe (assuming all symbols have the same dates)
    dates = dataframes[list(dataframes.keys())[0]]['Date']

    # Loop over each date for the last 5 dates (bottom up)
    for i in range(len(dates) - 5, len(dates)):
        # Initialize dictionaries to store mean and max closes
        mean_closes = {}
        max_closes = {}

        # Calculate mean close for the past 10 days for each symbol
        for symbol, df in dataframes.items():
            close_prices = df['Close'].values
            if i >= 10:
                mean_closes[symbol] = df['Close'][i-9:i+1].mean() #talib.SMA(close_prices, timeperiod=10)[i]
                max_closes[symbol] = df['Close'][i-9:i+1].max() #talib.MAX(close_prices, timeperiod=10)[i]

                #data1['ROC_3m']=tb.ROC(data1['Close'], timeperiod=12)
                #data1['ROC_6m']=tb.ROC(data1['Close'], timeperiod=24)
                #data1['ROC_12m']=tb.ROC(data1['Close'], timeperiod=52)
                #lognormal_returns = calculate_lognormal_daily_returns(data1['Close'][-52:])
                #annualized_lognormal_std = lognormal_returns.std(axis=0) * np.sqrt(52)
                #momentum_ratio_3m = data1['ROC_3m'].iloc[-1] / annualized_lognormal_std
                #momentum_ratio_6m = data1['ROC_6m'].iloc[-1] / annualized_lognormal_std
                #momentum_ratio_12m = data1['ROC_12m'].iloc[-1] / annualized_lognormal_std
                #number= len(df['momentum_6m'])
                #df['mean_momentum_3m'] = sum(df['momentum_3m'])/len(df['momentum_3m'])
                #df['mean_momentum_6m'] = sum(df['momentum_6m'])/len(df['momentum_6m'])
                #df['mean_momentum_12m'] = sum(df['momentum_12m'])/len(df['momentum_12m'])
                #df['std_momentum_3m'] = tb.STDDEV(df['momentum_3m'], timeperiod=number, nbdev=1)
                #df['std_momentum_6m'] = tb.STDDEV(df['momentum_6m'], timeperiod=number, nbdev=1) # Vectorized std calculation for 6m  df['momentum_6m'].pow(2).mean(axis=1)
                #df['std_momentum_12m'] = tb.STDDEV(df['momentum_12m'], timeperiod=number, nbdev=1)  #df['momentum_12m'].pow(2).mean(axis=1)  # Vectorized std calculation
                #print(df['Close'][i-9:i+1])
            else:
                mean_closes[symbol] = None
                max_closes[symbol] = None

        # Calculate the sum of max closes for the past 10 days across all symbols
        max_closes_sum = sum(value for value in max_closes.values() if value is not None)
        max_closes_values = [value for value in max_closes.values() if value is not None]
        #max_closes_mean = np.mean(max_closes_values)
        #max_closes_std_dev = np.std(max_closes_values)
        #print(max_closes_sum)

        # Calculate the score for each symbol
        for symbol in dataframes.keys():
            if max_closes[symbol] is not None and max_closes_sum != 0:
                score = mean_closes[symbol] / max_closes_sum

                #z_score_3m =  (momentum_ratio_3m -df['mean_momentum_3m'].iloc[-1]) / df['std_momentum_3m'].iloc[-1]
                #z_score_6m =  (momentum_ratio_6m -df['mean_momentum_6m'].iloc[-1]) / df['std_momentum_6m'].iloc[-1]
                #z_score_12m = (momentum_ratio_12m -df['mean_momentum_12m'].iloc[-1])/ df['std_momentum_12m'].iloc[-1]


                # Calculate weighted average Z-score
                #weighted_zscore = 0.5 * z_score_12m + 0.5 * z_score_6m
                #weighted_zscore = 0.45 * z_score_12m + 0.45 * z_score_6m + 0.1 * z_score_3m

                # Calculate normalized momentum score
                #normalized_score = (1 + weighted_zscore) * (weighted_zscore >= 0) + (1 / (1 - weighted_zscore))**(-1) * (weighted_zscore < 0)
            else:
                score = None
            scores[symbol].append(score)
            #print(max_closes_sum)

    return scores


# Calculate scores
scores = calculate_scores(dataframes)

# Add the score column to each dataframe and save to CSV
for symbol, df in dataframes.items():
    # Update scores list to ensure correct length
    final_scores = scores[symbol][:len(df) - 5] + scores[symbol][-(5):]
    df['Score'] = final_scores
    #df.to_csv(f"/home/rizpython236/BT5/ticker_15yr/{symbol}.csv", index=False)
    #print(df)
    print(df.tail(7))

print("Scores calculated and added to CSV files for the last 5 dates from the bottom up.")

'''

