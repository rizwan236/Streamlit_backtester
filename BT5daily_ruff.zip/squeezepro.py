import backtrader as bt
from pandas_ta import squeeze


class SqueezeIndicator(bt.Indicator):
    alias = 'SQZ'  # Set alias for the indicator

    lines = ('sqz', 'sqz_on', 'sqz_off', 'sqz_no')  # Define indicator lines to plot

    params = (
        ('bb_length', 20),  # Bollinger Bands period
        ('bb_std', 2.0),  # Bollinger Bands standard deviation
        ('kc_length', 20),  # Keltner Channel period
        ('kc_scalar', 1.5),  # Keltner Channel scalar
        ('mom_length', 12),  # Momentum period
        ('mom_smooth', 6),  # Momentum smoothing period
        ('mamode', 'sma'),  # Moving average mode (ema or sma)
        ('offset', 0),  # Indicator offset
    )

    def __init__(self):
        # Initialize indicator lines
        super(SqueezeIndicator, self).__init__()
        self.lines.sqz = self.data.Indicator()
        self.lines.sqz_on = self.data.IntOperator(self.lines.sqz, 1)
        self.lines.sqz_off = self.data.IntOperator(self.lines.sqz, -1)
        self.lines.sqz_no = self.lines.sqz == 0

    def next(self):
        # Calculate Squeeze indicator from pandas-ta
        sqz = squeeze(
            high=self.data.high,
            low=self.data.low,
            close=self.data.close,
            bb_length=self.params.bb_length,
            bb_std=self.params.bb_std,
            kc_length=self.params.kc_length,
            kc_scalar=self.params.kc_scalar,
            mom_length=self.params.mom_length,
            mom_smooth=self.params.mom_smooth,
            mamode=self.params.mamode,
            offset=self.params.offset,
        )

        # Add calculated values to indicator lines
        self.lines.sqz[0] = sqz.iloc[-1]
        self.lines.sqz_on[0] = int(sqz.SQZ_ON.iloc[-1])
        self.lines.sqz_off[0] = int(sqz.SQZ_OFF.iloc[-1])
        self.lines.sqz_no[0] = int(sqz.SQZ_NO.iloc[-1])
