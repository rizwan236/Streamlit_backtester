from datetime import date
import gc
import os
import shutil
import traceback

import numpy as np  # numpy-1.26.4
import pandas as pd

from settings import (
    BT_SCREENER_CSV,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    TALIB_SCREENER_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
    TRADEBOOK_CSV,
)


def clean_memory(deep: bool = False, verbose: bool = True) -> None:
    """Comprehensive memory cleanup for pandas and NumPy.

    Args:
        deep: If True, runs full garbage collection (slower but more thorough)
        verbose: Prints memory status if True

    """
    # Track initial memory if verbose
    initial_mem = None
    if verbose:
        try:
            import psutil
            process = psutil.Process()
            # Resident Set Size
            print(f"RAM used: {process.memory_info().rss / 1024 ** 2:.2f} MB")
            print(
                f"Virtual memory: {process.memory_info().vms / 1024 ** 2:.2f} MB")
            initial_mem = psutil.Process().memory_info().rss
        except ImportError:
            print(
                "psutil not installed - install with 'pip install psutil' for memory reporting")
            verbose = False

    # --- Pandas Cleanup ---
    try:
        # Clear computation caches (varies by pandas version)
        if hasattr(pd, "core") and hasattr(pd.core, "computation") and False:
            if hasattr(pd.core.computation, "expressions"):
                # pd.core.computation.expressions._MIN_ELEMENTS = 0  # Disable expr caching
                1 + 1
            if hasattr(pd.core.computation, "ops"):
                1 + 1
                # pd.core.computation.ops._USE_NUMEXPR = False  # Disable numexpr

        # Clear display/formatter memory
        if hasattr(pd.io.formats.format, "_buffer"):
            pd.io.formats.format._buffer.clear()
    except Exception as e:
        if verbose:
            print(f"Pandas cleanup warning: {e!s}")

    # --- NumPy Cleanup ---
    try:
        # Reset internal caches
        if hasattr(np, "_unsafe") and hasattr(np._unsafe, "dtype_reset"):
            np._unsafe.dtype_reset()  # Clear dtype cache

        # Release BLAS/LAPACK memory
        np.zeros(0)  # Forces memory pool cleanup

        # Clear ufunc cache (NumPy 1.21+)
        if hasattr(np, "_no_nep50_warning"):
            np._no_nep50_warning = True  # Disable future warnings
    except Exception as e:
        if verbose:
            print(f"NumPy cleanup warning: {e!s}")

    # --- Python GC ---
    if deep:
        collected = gc.collect()
        if verbose:
            print(f"Garbage collector collected {collected} objects")

    # Report memory change if requested
    if verbose and initial_mem is not None:
        current_mem = psutil.Process().memory_info().rss
        print(
            f"Memory change: {(current_mem - initial_mem) / 1024 ** 2:.1f} MB freed")

# clean_pandas_memory()
# clean_memory(deep=True, verbose=True)


def delete_files_in_folder(folder_path):
    """Deletes all files in the specified folder.

    Args:
        folder_path (str): Path to the folder whose files will be deleted.

    """
    # Check if the folder exists
    if not os.path.exists(folder_path):
        print(f"The folder {folder_path} does not exist.")
        return

    # Iterate over all files in the folder and delete them
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            # Check if it's a file (not a subfolder)
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)  # Delete the file or symbolic link
                print(f"Deleted file: {file_path}")
            elif os.path.isdir(file_path):
                # If it's a subfolder, delete it recursively
                shutil.rmtree(file_path)
                print(f"Deleted folder: {file_path}")
        except Exception as e:
            print(f"Failed to delete {file_path}. Reason: {e}")


# Example usage
cache_folder = "/home/rizpython236/BT5/__pycache__"
delete_files_in_folder(cache_folder)
cache_folder = "/home/rizpython236/.local/share/virtualenv/wheel/house"
delete_files_in_folder(cache_folder)


def delete_large_files(directory_path, size_limit_mb):
    """Deletes all files in the specified directory if their size exceeds the size limit.

    Args:
        directory_path (str): The path of the directory to check.
        size_limit_mb (int): The size limit in megabytes. Files larger than this will be deleted.

    Returns:
        None

    """
    # size_limit_mb =30
    size_limit_bytes = size_limit_mb * 1024 * 1024  # Convert MB to bytes
    EXCLUDE_DIRS = ["/home/rizpython236/.local/lib/"]

    # Ensure the directory exists
    if not os.path.exists(directory_path):
        print(f"Directory {directory_path} does not exist.")
        return

    # Loop through all files in the directory
    for root, dirs, files in os.walk(directory_path):
        # Skip excluded directories early
        if any(root.startswith(excluded) for excluded in EXCLUDE_DIRS):
            continue

        for file in files:
            file_path = os.path.join(root, file)
            try:
                # Check the size of the file
                file_size = os.path.getsize(file_path)
                if file_size > size_limit_bytes:
                    # Delete the file if it's larger than the limit
                    os.remove(file_path)
                    print(
                        f"Deleted: {file_path} (Size: {file_size / (1024 * 1024):.2f} MB)")
            except Exception as e:
                print(f"Error processing file {file_path}: {e}")


# Example usage
delete_large_files("/home/rizpython236/", 50)


def delete_all_files_and_folders(directory):
    if os.path.exists(directory):
        # Remove all files and directories inside the specified directory
        for item in os.listdir(directory):
            try:
                item_path = os.path.join(directory, item)
                if os.path.isfile(item_path):
                    os.remove(item_path)
                elif os.path.isdir(item_path):
                    shutil.rmtree(item_path)
            except Exception as e:
                print(f"Error processing file {item_path}: {e}")
    else:
        print(f"The directory {directory} does not exist.")


# Example usage
delete_all_files_and_folders("/tmp")
delete_all_files_and_folders("/home/rizpython236/Downloads")


def delete_pdfs(file_path):
    """Deletes all PDF files within a specified folder.

    Args:
      file_path: Path to the folder containing the PDF files.

    """
    if not os.path.exists(file_path):
        print(f"Folder '{file_path}' does not exist.")
        return

    # Loop through all files in the folder
    for filename in os.listdir(file_path):
        file_path_full = os.path.join(file_path, filename)
        # if filename.endswith((".pdf", ".png","csv")): #filename.endswith(".pdf") or filename.endswith(".png"):
        # filename.endswith(".pdf") or filename.endswith(".png"):
        if filename.endswith((".pdf", ".png")):
            try:
                os.remove(file_path_full)
                print(f"Deleted PDF file: {filename}")
            except PermissionError:
                print(f"Error deleting {filename}: Permission denied.")
            except FileNotFoundError:
                print(f"Error deleting {filename}: File not found.")


"""
Deleted PDF file: OldwatchlistSELL.csv
Deleted PDF file: delete.csv
Deleted PDF file: symbol_list.csv  ###
Deleted PDF file: nse.csv       ####3
Deleted PDF file: OldwatchlistExpLinR.csv
Deleted PDF file: nse500.csv      #######
Deleted PDF file: equity_curve.png
Deleted PDF file: myholding.csv   ######
Deleted PDF file: Finalnse.csv      ########
Deleted PDF file: MYindustry.csv   #######
Deleted PDF file: common.csv
Deleted PDF file: yesterdayBTscreener.csv
Deleted PDF file: FinalISIN.csv
Deleted PDF file: file_path.png
Deleted PDF file: yesterdayWatchlist.csv
Deleted PDF file: bse500.csv          #######
Deleted PDF file: bse.csv
Deleted PDF file: OldwatchlistBUY.csv
Deleted PDF file: include_tickers.csv    ######3
Deleted PDF file: myholding_old.csv      #######
Deleted PDF file: exclude_tickers.csv     ######3
Deleted PDF file: FinalMicrocap250.csv      #######3
Deleted PDF file: Final.csv         #######3
"""

# Example usage
# Replace with your actual folder path
file_path = "/home/rizpython236/BT5/screener-outputs/"
# file_path = "/home/rizpython236/"  # Replace with your actual folder path
delete_pdfs(file_path)

# Replace with your actual folder path
file_path = "/home/rizpython236/BT5/trade-logs/"
# file_path = "/home/rizpython236/"  # Replace with your actual folder path
delete_pdfs(file_path)


"""
def delete_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)
        #print(f"Deleted file: {file_path}")
    else:
        1+1
        #print(f"File not found: {file_path}")


file_path0 ='/home/rizpython236/BT5/trade-logs/screener-output_mhtly.csv'
file_path1 ='/home/rizpython236/BT5/screener-outputs/trade_list_BT_mhtly_Screener.csv'
file_path2 ='/home/rizpython236/BT5/screener-outputs/200SMACrossWkly.csv'
file_path3 ='/home/rizpython236/BT5/screener-outputs/BTholding_signals.csv'
file_path4 ='/home/rizpython236/BT5/screener-outputs/TBholding_signals.csv'
file_path5 ='/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv'
file_path6 ='/home/rizpython236/BT5/screener-outputs/52wkdataWkly.csv'
file_path7 ='/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv'
file_path8 ='/home/rizpython236/BT5/screener-outputs/filteredBT.csv'
file_path9 ='/home/rizpython236/BT5/screener-outputs/Watchlist.csv'
file_path10 ='/home/rizpython236/BT5/screener-outputs/trade_list_BT_ScreenerIND.csv'
file_path11 = '/home/rizpython236/BT5/screener-outputs/databse.csv'
file_path12 = '/home/rizpython236/BT5/screener-outputs/datanse.csv'
file_path13 = '/home/rizpython236/BT5/screener-outputs/Chg52wkWeekly.csv'
file_path14 = '/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv'
file_path15 = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv'
file_path16 = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv'
file_path17 = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv'
file_path18 = '/home/rizpython236/BT5/screener-outputs/screener-output1.csv'
file_path19 = '/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.csv'
file_path20 = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv'
file_path21 = '/home/rizpython236/BT5/screener-outputs/MRPdataWkly.csv'
file_path22 = '/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv'
file_path23 = '/home/rizpython236/BT5/screener-outputs/RSIdataWkly.csv'
file_path24 = '/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv'
file_path25 = '/home/rizpython236/BT5/screener-outputs/Relative_perf.csv'
file_path26 = '/home/rizpython236/BT5/screener-outputs/sectorperf.csv'
file_path27 = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'
file_path28 = '/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.csv'
file_path29 = '/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv'
file_path30 = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
file_path31 = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv'
file_path32 = '/home/rizpython236/BT5/screener-outputs/holding_signals.csv'
file_path33 = '/home/rizpython236/BT5/screener-outputs/filtered_Final.csv'
file_path34 = '/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.csv'
file_path35 = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.csv'
file_path36 = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.csv'
file_path37 = '/home/rizpython236/BT5/screener-outputs/Pos1yrHighWkly.csv'
file_path38 = '/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.csv'
file_path39 = '/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.csv'
file_path40 = '/home/rizpython236/BT5/screener-outputs/MRPcross15yr.csv'
file_path41 = '/home/rizpython236/BT5/screener-outputs/MRPcrosswkly.csv'
file_path42 = '/home/rizpython236/BT5/screener-outputs/MergeNIFTY500MOMENTUM30.csv'
file_path43 = '/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv'
file_path44 = '/home/rizpython236/BT5/screener-outputs/combined_ticker_data.pkl.gz'
file_path45 = '/home/rizpython236/BT5/screener-outputs/combined_ticker_data.csv'
file_path46 = '/home/rizpython236/core'
file_path47 = '/home/rizpython236/Equity.csv'
file_path48 = '/home/rizpython236/core.163'
file_path49 = '/home/rizpython236/BT5/chart.png'


delete_file(file_path0)
delete_file(file_path2)
delete_file(file_path1)
delete_file(file_path3)
delete_file(file_path4)
delete_file(file_path5)
delete_file(file_path6)
delete_file(file_path7)
delete_file(file_path8)
delete_file(file_path9)
delete_file(file_path10)
delete_file(file_path11)
delete_file(file_path12)
delete_file(file_path13)
delete_file(file_path14)
delete_file(file_path15)
delete_file(file_path16)
delete_file(file_path17)
delete_file(file_path18)
delete_file(file_path19)
delete_file(file_path20)
delete_file(file_path21)
delete_file(file_path22)
delete_file(file_path23)
delete_file(file_path24)
delete_file(file_path25)
delete_file(file_path26)
delete_file(file_path27)
delete_file(file_path28)
delete_file(file_path29)
delete_file(file_path30)
delete_file(file_path31)
delete_file(file_path32)
delete_file(file_path33)
delete_file(file_path34)
delete_file(file_path35)
delete_file(file_path36)
delete_file(file_path37)
delete_file(file_path38)
delete_file(file_path39)
delete_file(file_path40)
delete_file(file_path41)
delete_file(file_path42)
delete_file(file_path43)
delete_file(file_path44)
delete_file(file_path45)
delete_file(file_path46)
delete_file(file_path47)
delete_file(file_path48)
delete_file(file_path49)
"""


def delete_file(file_path):
    """Delete file if it exists."""
    try:
        os.remove(file_path)
        # print(f"Deleted: {file_path}")
    except FileNotFoundError:
        print(f"file doesn't exist: {file_path}")
        # Ignore if file doesn't exist


file_paths = [
    "/home/rizpython236/BT5/trade-logs/screener-output_mhtly.csv",
    "/home/rizpython236/BT5/screener-outputs/trade_list_BT_mhtly_Screener.csv",
    "/home/rizpython236/BT5/screener-outputs/200SMACrossWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/BTholding_signals.csv",
    "/home/rizpython236/BT5/screener-outputs/TBholding_signals.csv",
    "/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv",
    "/home/rizpython236/BT5/screener-outputs/52wkdataWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv",
    "/home/rizpython236/BT5/screener-outputs/filteredBT.csv",
    "/home/rizpython236/BT5/screener-outputs/Watchlist.csv",
    "/home/rizpython236/BT5/screener-outputs/trade_list_BT_ScreenerIND.csv",
    "/home/rizpython236/BT5/screener-outputs/databse.csv",
    "/home/rizpython236/BT5/screener-outputs/datanse.csv",
    "/home/rizpython236/BT5/screener-outputs/Chg52wkWeekly.csv",
    "/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv",
    "/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv",
    "/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv",
    "/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv",
    "/home/rizpython236/BT5/screener-outputs/screener-output1.csv",
    "/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv",
    "/home/rizpython236/BT5/screener-outputs/MRPdataWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv",
    "/home/rizpython236/BT5/screener-outputs/RSIdataWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv",
    "/home/rizpython236/BT5/screener-outputs/Relative_perf.csv",
    "/home/rizpython236/BT5/screener-outputs/sectorperf.csv",
    "/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv",
    "/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv",
    "/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv",
    "/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv",
    "/home/rizpython236/BT5/screener-outputs/holding_signals.csv",
    "/home/rizpython236/BT5/screener-outputs/filtered_Final.csv",
    "/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.csv",
    "/home/rizpython236/BT5/screener-outputs/DDPCT15yr.csv",
    "/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.csv",
    "/home/rizpython236/BT5/screener-outputs/Pos1yrHighWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.csv",
    "/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.csv",
    "/home/rizpython236/BT5/screener-outputs/MRPcross15yr.csv",
    "/home/rizpython236/BT5/screener-outputs/MRPcrosswkly.csv",
    "/home/rizpython236/BT5/screener-outputs/MergeNIFTY500MOMENTUM30.csv",
    "/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv",
    "/home/rizpython236/BT5/screener-outputs/combined_ticker_data.pkl.gz",
    "/home/rizpython236/BT5/screener-outputs/combined_ticker_data.csv",
    "/home/rizpython236/BT5/screener-outputs/OpentradebookCharts.pdf",
    # "/home/rizpython236/BT5/trade-logs/Opentradebook.csv",
    # '/home/rizpython236/BT5/screener-outputs/Tickerdata.zip',
    "/home/rizpython236/core",
    "/home/rizpython236/Equity.csv",
    "/home/rizpython236/core.163",
    "/home/rizpython236/BT5/chart.png",
]

# Delete all files
for path in file_paths:
    delete_file(path)


BT_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + BT_SCREENER_CSV
TALIB_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + TALIB_SCREENER_CSV
CURRENT_DAY_SCREENER_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
TRADEBOOK_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + TRADEBOOK_CSV
TODAYS_DATE = date.today()


# bt_data = pd.read_csv(BT_FILE_PATH)
# talib_data = pd.read_csv(TALIB_FILE_PATH)
# new_screener_data = pd.read_csv(NEW_FILE_PATH)
tradebook = pd.read_csv(TRADEBOOK_FILE_PATH)


# remove Symbol list
# print("Emptying Symbol List")
# sym_df = pd.read_csv(SYMBOLS_CSV)
# sym_df.drop(sym_df.index, inplace=True)
# sym_df.to_csv(SYMBOLS_CSV, index=False)


def remove_ticker_data_csv_files():
    # remove ticker data csv files
    print("Deleting all the ticker data csv files.")
    dir2 = TICKER_CSV_DATA_FOLDER_PATH
    dir2 = "/home/rizpython236/BT5/ticker-csv-files"
    for f in os.listdir(dir2):
        os.remove(os.path.join(dir2, f))
    print(f"files deleted from {dir2}")

    dir3 = "/home/rizpython236/BT5/ticker-csv-files-weekly"
    for f in os.listdir(dir3):
        os.remove(os.path.join(dir3, f))
    print(f"files deleted from {dir3}")

    dir4 = "/home/rizpython236/BT5/ticker-csv-files-mhtly"
    for f in os.listdir(dir4):
        os.remove(os.path.join(dir4, f))
    print(f"files deleted from {dir4}")

    dir5 = "/home/rizpython236/BT5/ticker_15yr"
    for f in os.listdir(dir5):
        os.remove(os.path.join(dir5, f))
    print(f"files deleted from {dir5}")

    dir6 = "/home/rizpython236/BT5/ticker_daily1yr"
    for f in os.listdir(dir6):
        os.remove(os.path.join(dir6, f))
    print(f"files deleted from {dir6}")

    # remove BT Screener Output
    if os.path.exists(BT_FILE_PATH):
        os.remove(BT_FILE_PATH)
    print("Deleting BT Screener Output File.")

    # remove Talib Output
    if os.path.exists(TALIB_FILE_PATH):
        os.remove(TALIB_FILE_PATH)
    print("Deleting Talib Screener Output File.")

    # remove Talib Output
    if os.path.exists(CURRENT_DAY_SCREENER_FILE_PATH):
        os.remove(CURRENT_DAY_SCREENER_FILE_PATH)
        1 + 1
    print("Deleting Last Saved Screener Output File.")

    try:
        # remove valid, invalid and incomplete ticker csvs
        print("Emptying valid, invalid and incomplete ticker output files.")
        dir1 = SCREENER_OUTPUT_FOLDER_PATH
        for f in os.listdir(dir1):
            if f.endswith((".csv", ".xxx")):
                ff = dir1 + "/" + f
                print(f"Processing file: {ff}")
                temp_df = pd.read_csv(ff)
                temp_df.drop(temp_df.index, inplace=True)
                temp_df.to_csv(ff, index=False)
                # os.remove(os.path.join(dir1, f))
                # print(f"File {ff} processed successfully.")
    except Exception as e:
        print(f"⚠️Error occurred: {e!s}")
        traceback_str = traceback.format_exc()


def cleanup_files():
    try:

        # remove ticker data csv files
        print("Deleting all the ticker data csv files.")
        dir2 = TICKER_CSV_DATA_FOLDER_PATH
        for f in os.listdir(dir2):
            os.remove(os.path.join(dir2, f))
        print(f"files deleted from {dir2}")

        # remove Symbol list
        # print("Emptying Symbol List")
        # sym_df = pd.read_csv(SYMBOLS_CSV)
        # sym_df.drop(sym_df.index, inplace=True)
        # sym_df.to_csv(SYMBOLS_CSV, index=False)

        # remove valid, invalid and incomplete ticker csvs
        print("Emptying valid, invalid and incomplete ticker output files.")
        dir1 = SCREENER_OUTPUT_FOLDER_PATH
        for f in os.listdir(dir1):
            if f.endswith((".csv", ".xxx")):
                ff = dir1 + "/" + f
                print(f"Processing file: {ff}")
                temp_df = pd.read_csv(ff)
                temp_df.drop(temp_df.index, inplace=True)
                temp_df.to_csv(ff, index=False)
                # os.remove(os.path.join(dir1, f))  Do not uncomment
                # print(f"File {ff} processed successfully.")

    except Exception as e:
        print(f"⚠️Error occurred: {e!s}")
        traceback_str = traceback.format_exc()

# def main():
# cleanup_files()
