
from datetime import datetime, timedelta

from dateutil.relativedelta import relativedelta
import numpy as np
import pandas as pd
from scipy.optimize import newton


def get_date_difference(start_date, end_date):
    """Calculate difference between two dates in years, months, days"""
    delta = relativedelta(end_date, start_date)
    return {
        'years': delta.years,
        'months': delta.months,
        'days': delta.days,
        'total_days': (end_date - start_date).days,
        'decimal_years': (end_date - start_date).days / 365.25
    }


def convert_to_numeric(series):
    """Convert a pandas series to numeric, coercing errors to NaN and then filling with 0"""
    return pd.to_numeric(series, errors='coerce').fillna(0)

def calculate_xirr(transactions_file, holdings_file):
    # Read transactions file
    transactions = pd.read_csv(transactions_file)

    transactions['Transacted Units'] = (
        transactions['Transacted Units']
        .astype(str)  # Convert to string first to handle all cases
        .str.replace(',', '')  # Remove commas
        .apply(clean_number)  # Apply your existing clean_number function
    )
    transactions['Transacted Price (per unit)'] = (
        transactions['Transacted Price (per unit)']
        .astype(str)  # Convert to string first to handle all cases
        .str.replace(',', '')  # Remove commas
        .apply(clean_number)  # Apply your existing clean_number function
    )

    #transactions['Transacted Units'] = transactions['Transacted Units'].apply(clean_number)
    #transactions['Transacted Price'] = transactions['Transacted Price (per unit)'].apply(clean_number)

    transactions['Transacted Units'] = convert_to_numeric(transactions['Transacted Units'])
    transactions['Transacted Price (per unit)'] = convert_to_numeric(transactions['Transacted Price (per unit)'])

    #print("\nSample transactions:")
    #print(transactions[['Transacted Units', 'Transacted Price (per unit)']].head())
    #print(transactions.dtypes)

    # Calculate cash flows from transactions
    transactions['Cash Flow1'] = transactions['Transacted Units'] * transactions['Transacted Price (per unit)']
    transactions['Cash Flow1'] = np.where(transactions['Type'] == 'Buy',
                                       -transactions['Cash Flow1'],
                                       transactions['Cash Flow1'])

    # Read holdings file and get current value
    holdings = pd.read_csv(holdings_file)



    holdings['Current Val'] = (
        holdings['Current Val']
        .astype(str)  # Convert to string first to handle all cases
        .str.replace(',', '')  # Remove commas
        .apply(clean_number)  # Apply your existing clean_number function
    )

    #holdings['Current Val'] = holdings['Current Val'].apply(clean_number)
    holdings['Current Val'] = convert_to_numeric(holdings['Current Val'])

    #print("\nHoldings data types:")
    #print(holdings.dtypes)
    current_value = holdings['Current Val'].sum()

    # Create final cash flow (today's date as sell)
    # Create final cash flow (today's date as sell)
    today = datetime.now().date()
    final_cash_flow = pd.DataFrame({
        'Date': [today],
        'Cash Flow1': [current_value]
    })

    # Combine all cash flows
    all_cash_flows = pd.concat([
        transactions[['Date', 'Cash Flow1']],
        final_cash_flow
    ], ignore_index=True)

    # Convert to datetime and sort
    all_cash_flows['Date'] = pd.to_datetime(all_cash_flows['Date'], errors='coerce')
    all_cash_flows = all_cash_flows.dropna(subset=['Date']).sort_values('Date')

    # Calculate XIRR
    dates = all_cash_flows['Date'].values
    amounts = all_cash_flows['Cash Flow1'].values

    # Calculate XIRR using datetime and timedelta
    def xirr(dates, amounts):
        start_date = dates[0]

        today = datetime.now().date()

        # Calculate date difference
        date_diff = get_date_difference(start_date, today)
        print(f"Investment period: {date_diff['years']} years, "
              f"{date_diff['months']} months, {date_diff['days']} days")

        years = [(date - start_date).days / 365.0 for date in dates]

        residual = 1.0
        step = 0.05
        guess = 0.05
        epsilon = 0.0001
        limit = 10000

        for _ in range(limit):
            residual = 0.0
            for amt, year in zip(amounts, years):
                residual += amt / ((1 + guess) ** year)
            if abs(residual) < epsilon:
                return guess
            if residual > 0:
                guess += step
            else:
                guess -= step
                step /= 2.0
        return guess

    # Convert dates to datetime.date objects
    dates = [d.date() if isinstance(d, datetime) else d for d in all_cash_flows['Date']]
    amounts = all_cash_flows['Cash Flow1'].values

    return xirr(dates, amounts)


def clean_number(value):
    """Convert string numbers to floats"""
    if isinstance(value, str):
        cleaned = ''.join(c for c in value if c.isdigit() or c in '.-')
        return float(cleaned) if cleaned else 0.0
    return float(value)

def simple_xirr(cashflows):
    """Calculate XIRR for (date, amount) pairs"""
    if len(cashflows) < 2:
        return None

    try:
        cashflows = [(date, clean_number(amt)) for date, amt in cashflows]
        cashflows.sort(key=lambda x: x[0])
        amounts = [amt for _, amt in cashflows]

        if all(a >= 0 for a in amounts) or all(a <= 0 for a in amounts):
            return None

        dates = [date for date, _ in cashflows]
        min_date = min(dates)
        days = [(date - min_date).days for date in dates]

        def npv(rate):
            return sum(amt / (1 + rate) ** (day/365) for amt, day in zip(amounts, days))

        return newton(npv, 0.1)
    except Exception:
        return None

def calculate_actual_holding_period(transactions_df, stock):
    """Calculate actual holding period based on cumulative units"""
    stock_trans = transactions_df[transactions_df['Stock'] == stock].copy()
    stock_trans = stock_trans.sort_values('Date')

    if stock_trans.empty:
        return "N/A"

    # Use the existing Cumulative Units column
    if 'Cumulative Units' not in stock_trans.columns:
        return "N/A"

    holding_periods = []
    start_date = None

    for _, row in stock_trans.iterrows():
        date = row['Date']
        cum_units = clean_number(row['Cumulative Units'])

        if cum_units >= 1:  # At least 1 unit held
            if start_date is None:  # Start of a holding period
                start_date = date
        else:  # Fully sold out
            if start_date is not None:  # End of a holding period
                holding_periods.append((start_date, date))
                start_date = None

    # Add final period if still holding
    if start_date is not None:
        holding_periods.append((start_date, datetime.now()))

    if not holding_periods:
        return "N/A"

    # Calculate total duration by summing all periods
    total_duration = relativedelta()
    for period_start, period_end in holding_periods:
        total_duration += relativedelta(period_end, period_start)

    # Format the duration
    parts = []
    if total_duration.years > 0:
        parts.append(f"{total_duration.years}y")
    if total_duration.months > 0:
        parts.append(f"{total_duration.months}m")
    if total_duration.days > 0:
        parts.append(f"{total_duration.days}d")

    return ' '.join(parts) if parts else "0d"

def process_files(transactions_file, holdings_file, sort_by='Current Value', ascending=False):
    """Main processing function with sorting capability"""
    try:
        trans = pd.read_csv(transactions_file, parse_dates=['Date'])
        holdings = pd.read_csv(holdings_file)
    except Exception as e:
        print(f"Error reading files: {e}")
        return None, None

    results = []
    all_cashflows = []
    current_values = {}
    Cost_values ={}
    Absolute_PL ={}
    Percentage_Return ={}

    # Create dictionary of currently held stocks from holdings file
    held_stocks = {}
    for _, row in holdings.iterrows():
        try:
            #current_units = clean_number(row['Current Units'])
            current_units = clean_number(row['Units'])
            if current_units > 0:
                held_stocks[row['Name']] = {
                    'current_val': clean_number(row['Current Val']),
                    'current_units': current_units
                }
        except Exception:
            continue

    for stock in trans['Stock'].unique():
        stock_trans = trans[trans['Stock'] == stock]
        cashflows = []
        current_val = None
        is_held = stock in held_stocks  # Determine status solely from holdings file

        cost_val_total = None
        current_val_total = None

        # Process transactions
        for _, row in stock_trans.iterrows():
            if row['Type'] == 'Split':
                continue

            try:
                units = clean_number(row['Transacted Units'])
                price = clean_number(row['Transacted Price (per unit)'])
                amount = -units * price if row['Type'] == 'Buy' else units * price
                cashflows.append((row['Date'], amount))

                # Calculate cost value (sum of Buy amounts) and current value (sum of Sell amounts)
                if row['Type'] == 'Buy':
                    cost_val_total += abs(amount)  # Sum of absolute Buy amounts
                elif row['Type'] == 'Sell':
                    current_val_total += abs(amount)  # Sum of absolute Sell amounts

            except Exception:
                continue

        # Get current value if held
        if is_held:
            current_val = held_stocks[stock]['current_val'] #+ current_val_total
            cashflows.append((datetime.now(), current_val))
            current_values[stock] = current_val
        else:
            1+1
            #current_values[stock] = 0

            Cost_values[stock] = cost_val_total
            current_values[stock] = current_val=current_val_total
            #Absolute_PL[stock] = current_val_total - cost_val_total
            #if cost_val_total != 0:
            #    Percentage_Return[stock] = ((current_val_total - cost_val_total) / cost_val_total) * 100
            #else:
            #    Percentage_Return[stock] = 0

        # Calculate XIRR if valid
        xirr = simple_xirr(cashflows) if len(cashflows) >= 2 else None

        # Calculate actual holding period
        holding_period = calculate_actual_holding_period(trans, stock)
        #print(held_stocks)

        results.append({
            'Stock': stock,
            'XIRR (%)': f"{xirr*100:.2f}" if xirr is not None else "N/A",
            #'Cost Val1': cost_val_total if cost_val_total is not None else 0,
            'Current Value': current_val if current_val is not None else 0,
            'Formatted Value': f"{current_val:,.2f}" if current_val is not None else "N/A",
            'Transactions': len(cashflows) - (1 if is_held else 0),
            'Holding Period': holding_period,
            'Status': 'Held' if is_held else 'Sold'
        })
        all_cashflows.extend(cashflows)

    # Create DataFrame and sort
    df_results = pd.DataFrame(results)
    df_results['Current Value'] = pd.to_numeric(df_results['Current Value'], errors='coerce')

    valid_sort_columns = ['Stock', 'XIRR (%)', 'Current Value', 'Transactions', 'Holding Period', 'Status']
    sort_by = sort_by if sort_by in valid_sort_columns else 'Current Value'

    df_results.sort_values(by=sort_by, ascending=ascending, inplace=True, na_position='last')

    portfolio_xirr = simple_xirr(all_cashflows) if len(all_cashflows) >= 2 else None


    # Load holdings file
    holdings_file = pd.read_csv('Final Riz portfolio invtmoat - Current Holding.csv')

    # Calculate performance metrics for each stock
    df_results1 = pd.DataFrame({
        'Stock': holdings_file['Name'],
        'Cost Val': holdings_file['Cost Val'].apply(clean_number),
        'Current Val': holdings_file['Current Val'].apply(clean_number),
        # Include other existing columns you need
    })

    # Calculate Absolute P&L and Percentage Return
    df_results1['Cost Val'] = df_results1['Cost Val']
    df_results1['Absolute P&L'] = df_results1['Current Val'] - df_results1['Cost Val']
    df_results1['Percentage Return (%)'] = round((df_results1['Absolute P&L'] / df_results1['Cost Val']) * 100,2)


    if 'Current Val' in df_results1.columns:
        df_results1 = df_results1.drop(columns=['Current Val'])

    df_results = pd.merge(df_results, df_results1, on='Stock', how='outer')

    # Format the display DataFrame
    print("\nInvestment Performance (Sorted by Current Value):")
    display_df = df_results[[
        'Stock',
        'XIRR (%)',
        'Formatted Value',
        'Cost Val',
        'Holding Period',
        'Status',
        'Transactions',
        'Absolute P&L',
        'Percentage Return (%)'
    ]].copy()

    display_df.columns = [
        'Stock',
        'XIRR (%)',
        'Cost Val',
        'Current Value',
        'Holding Period',
        'Status',
        'Transactions',
        'Absolute P&L',
        'Return (%)'
    ]

    # Sort by Current Value (descending)
    display_df = display_df.sort_values('Current Value', ascending=False)

    #print(df_results)

    #print(display_df.to_string(index=False))
    return df_results, portfolio_xirr



def calculate_portfolio_stats(holdings_file):
    """Calculate and display portfolio-level statistics"""
    try:
        holdings = pd.read_csv(holdings_file)
    except Exception as e:
        print(f"Error reading holdings file: {e}")
        return None

    # Initialize totals
    total_cost = 0
    total_current = 0
    holdings_count = 0
    #print(holdings)

    # Calculate totals
    for _, row in holdings.iterrows():
        try:
            cost_val = clean_number(row['Cost Val'])
            current_val = clean_number(row['Current Val'])
            units = clean_number(row['Units'])

            if units > 0:  # Only count if actually holding
                total_cost += cost_val
                total_current += current_val
                holdings_count += 1
        except Exception:
            continue

    # Calculate profit/loss
    absolute_pl = total_current - total_cost
    if total_cost > 0:
        percent_return = (absolute_pl / total_cost) * 100
    else:
        percent_return = 0

    # Create and return portfolio stats
    portfolio_stats = {
        'Total Holdings': holdings_count,
        'Total Purchase Value': total_cost,
        'Portfolio Current Value': total_current,
        'Absolute P&L': absolute_pl,
        'Percentage Return': round(percent_return,2)
    }
    return portfolio_stats

def print_portfolio_stats(portfolio_stats, portfolio_xirr=None):
    """Print formatted portfolio statistics"""
    if portfolio_stats is None:
        print("\nCould not calculate portfolio statistics")
        return

    print("\n" + "="*50)
    print("PORTFOLIO SUMMARY")
    print("="*50)
    print(f"{'Total Holdings:':<25} {portfolio_stats['Total Holdings']:>15}")
    print(f"{'Total Purchase Value:':<25} ₹{portfolio_stats['Total Purchase Value']:>14,.2f}")
    print(f"{'Portfolio Current Value:':<25} ₹{portfolio_stats['Portfolio Current Value']:>14,.2f}")
    print(f"{'Absolute Profit/Loss:':<25} ₹{portfolio_stats['Absolute P&L']:>14,.2f}")
    print(f"{'Percentage Return:':<25} {portfolio_stats['Percentage Return']:>15.2f}%")
    if portfolio_xirr is not None:
        print(f"{'Portfolio XIRR:':<25} {portfolio_xirr*100:>15.2f}%")
    print("="*50)

# Example usage
if __name__ == "__main__":
    transactions_file = 'Final Riz portfolio invtmoat - ZDHTransactions.csv'
    holdings_file = 'Final Riz portfolio invtmoat - Current Holding.csv'

    print("XIRR Calculator - Sorted by Current Value")
    print("="*50)

    df_results, portfolio = process_files(
        transactions_file,
        holdings_file,
        sort_by='Current Value',
        ascending=False
    )

    if df_results is not None:
        print("\nInvestment Performance (Sorted by Current Value):")
        column_order = [
            'Stock',
            'XIRR (%)',
            'Percentage Return (%)',
            'Absolute P&L',
            'Cost Val',
            'Current Value',
            'Holding Period',
            'Status',
            'Transactions'
        ]

        # Reorder the columns in df_results
        df_results = df_results[column_order]

        #print(df_results)

        display_df = df_results[['Stock', 'XIRR (%)',  'Percentage Return (%)','Absolute P&L' ,  'Cost Val','Current Value', 'Holding Period', 'Status', 'Transactions',]] #
        display_df.columns = ['Stock', 'XIRR (%)',  'Percentage Return (%)','Absolute P&L' ,  'Cost Val','Current Value', 'Holding Period', 'Status', 'Transactions', ] #'Absolute P&L'  ,  'Return (%)'  'Cost Val' ,
        print(display_df.to_string(index=False))
        #print(display_df)

    if portfolio is not None:
        print(f"\nPortfolio XIRR: {portfolio*100:.2f}%")
    else:
        print("\nCould not calculate portfolio XIRR")

    # Calculate and print portfolio stats
    portfolio_XIRR = portfolio
    portfolio_stats = calculate_portfolio_stats(holdings_file)
    print_portfolio_stats(portfolio_stats, portfolio_XIRR)


        # Example usage
    xirr_value = calculate_xirr(transactions_file, holdings_file)
    print(f"Portfolio XIRR: {xirr_value:.2%}")