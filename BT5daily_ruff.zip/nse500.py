import io
import time
import traceback

import pandas as pd
import requests

from settings import (
    EXCLUDE_TICKERS_CSV,
    INCLUDE_TICKERS_CSV,
    MAX_RETRIES,
)
from symbol_copy import import_user_module
from telegram_bot import post_telegram_message


base_dir_module = "/home/rizpython236/BT5"


include_tickers = pd.read_csv(INCLUDE_TICKERS_CSV)
include_tickers = list(include_tickers["Symbol"].unique())
exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)
exclude_tickers = list(exclude_tickers["Symbol"].unique())

Final111 = pd.read_csv("/home/rizpython236/BT5/Finalnse.csv")
new_tickers = pd.read_csv("/home/rizpython236/BT5/trade-logs/new_tickers.csv")


def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].astype(str) + suffix
    # df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df


# Load BSE file
bse = pd.read_csv("/home/rizpython236/BT5/bse500.csv")
# https://www.bseindia.com/corporates/List_Scrips.html


# print("NIFTY_500 MICROCAP_250")

#######################################
download_successful = False
MAX_RETRIES = 5

while MAX_RETRIES > 0:
    try:
        time.sleep(2)
        # print("NIFTY_500")
        """
        print("Downloading NSE500 symbol list from NSE Website.")
        NIFTY_500 = convert_buffer_response_to_dataframe(
            download_tickers_from_url(NSE_NIFTY_500_URL)
        )
        print("Found {} tickers in NSE NIFTY 500".format(len(NIFTY_500)))
        MICROCAP_250 = convert_buffer_response_to_dataframe(
            download_tickers_from_url(NSE_MICROCAP_250_URL)
        )
        print("Found {} tickers in NSE MICROCAP 250".format(len(MICROCAP_250)))
        """
        url = "https://archives.nseindia.com/content/indices/ind_nifty500list.csv"
        response = requests.get(url)
        datanseold = pd.read_csv("/home/rizpython236/BT5/nse500.csv")
        if True:  # response.status_code == 200:
            # datanse = pd.read_csv(io.StringIO(response.text))
            csv_data = io.StringIO(response.text)
            csv_content = csv_data.getvalue()
            # print(csv_content)
            datanse = pd.read_csv(io.StringIO(response.text))
            if "Access Denied" in csv_content:
                print("ERROR: Access Denied - NSE is blocking the request for nse500.")
                datanseold.to_csv(
                    "/home/rizpython236/BT5/nse500.csv", index=False)
                # datanse = datanseold
                MAX_RETRIES -= 1
                download_successful = False
                break
            else:
                # datanse.to_csv("/home/rizpython236/BT5/nse500.csv", index=False)
                datanse = pd.read_csv(csv_data)
                datanse.to_csv("/home/rizpython236/BT5/nse500.csv")
                print(f"Found {len(datanse)} tickers in NSE500 symbol list")
                download_successful = True
                break  # Exit the loop since download was successful
        else:
            print("NSE500 no download")
        # MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(1)
        print("Download from NSE500 failed!")
        # print(f"⚠️Error occurred NSE500: {str(exc)}")
        traceback_str = traceback.format_exc()
        print(traceback_str)
        # post_telegram_message("Download from NSE500 failed! Retrying...")
        # print(exc)
        print("-" * 50)
        MAX_RETRIES -= 1

if download_successful == True:
    datanse.to_csv("/home/rizpython236/BT5/nse500.csv", index=False)
else:
    # if not download_successful:
    print("Download data from NSE500 Failed")
    post_telegram_message(message="Download ticker Failed NSE500")
    # sys.exit()
    datanse = pd.read_csv("/home/rizpython236/BT5/nse500.csv")
############################################

time.sleep(5)
# "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
# "https://www1.nseindia.com/content/indices/ind_niftymicrocap250_list.csv"
# "https://www1.nseindia.com/content/indices/ind_nifty500list.csv"
# "https://nsearchives.nseindia.com/content/indices/ind_niftymicrocap250_list.csv"
# "https://nsearchives.nseindia.com/content/indices/ind_nifty500list.csv"

MAX_RETRIES = 5
download_successful = False

while MAX_RETRIES > 0:
    try:
        time.sleep(2)
        # print("NIFTY_MICROCAP_250")
        # print("Downloading Niftymicrocap250 symbol list from NSE Website.")
        url = "https://archives.nseindia.com/content/indices/ind_niftymicrocap250_list.csv"
        response = requests.get(url)
        datanse250old = pd.read_csv(
            "/home/rizpython236/BT5/FinalMicrocap250.csv")
        if True:  # response.status_code == 200:
            csv_data = io.StringIO(response.text)
            csv_content = csv_data.getvalue()
            # print(csv_content)
            if "Access Denied" in csv_content:
                print(
                    "ERROR: Access Denied - NSE is blocking the request for FinalMicrocap250.")
                datanse250old.to_csv(
                    "/home/rizpython236/BT5/FinalMicrocap250.csv", index=False)
                # datanse250 = datanse250old
                MAX_RETRIES -= 1
                download_successful = False
                break
            else:
                datanse250 = pd.read_csv(io.StringIO(response.text))
                datanse250.to_csv(
                    "/home/rizpython236/BT5/FinalMicrocap250.csv")
                # print(datanse250)
                print(
                    f"Found {len(datanse250)} tickers in Niftymicrocap250 symbol list")
                download_successful = True
                break  # Exit the loop since download was successful
        else:
            print("Niftymicrocap250 no download")

        # MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(1)
        print("Download from Niftymicrocap250 failed!")
        # print(f"⚠️Error occurred Niftymicrocap250: {str(exc}")
        traceback_str = traceback.format_exc()
        print(traceback_str)
        # post_telegram_message("Download from NSE500 failed! Retrying...")
        # print(exc)
        print("-" * 50)
        MAX_RETRIES -= 1

if download_successful == True:
    datanse250.to_csv(
        "/home/rizpython236/BT5/FinalMicrocap250.csv", index=False)
else:
    # if not download_successful:
    print("Download data from Niftymicrocap250 Failed")
    post_telegram_message(message="Download ticker Failed Niftymicrocap250")
    # sys.exit()
    datanse250 = pd.read_csv("/home/rizpython236/BT5/FinalMicrocap250.csv")
########################
datanse = pd.concat([datanse, datanse250], ignore_index=True)
# print(datanse)


# datanse = pd.read_csv("/home/rizpython236/BT5/nse500.csv")
# print(datanse)


# Rename Security Id column to SYMBOL
bse.drop(
    columns=[
        # "Scrip Code",
        # "ISIN No.",
        # "COMPANY"
        "Close Price",
        # "Group",
        # "Face Value",
        # "ISIN No",
        # "Industry",
        # "Instrument",
        # "Sector Name",
        # "Industry New Name",
        # "Igroup Name",
        # "ISubgroup Name",
    ],
    inplace=True,
)


bse.rename(columns={"Scrip Code": "SymbolB"}, inplace=True)
bse.rename(columns={"COMPANY": "Company NameB"}, inplace=True)
bse.rename(columns={"ISIN No.": "ISIN CodeB"}, inplace=True)
# bse = bse[bse["Security Name"] == "Active"]
# accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]
# bse = bse[~bse["Security Id"].str.contains("ETF")]
# bse = bse[~bse["Security Id"].str.contains("EXCHANGE TRADED")]
# bse = bse[~bse["Security Id"].str.contains("FUND")]
# bse = bse[~bse["Security Id"].str.contains("Fund")]
# bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
# condition = bse['SYMBOL'].str.endswith('*')
# bse.loc[condition, 'SYMBOL'] = bse.loc[condition, 'SYMBOL'].str[:-1]
# Filter dataframe
# bse = bse[bse["Status"].isin(accepted_values)]


"""
#url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
#response = requests.get(url)
#datanse = pd.read_csv(url)
"""

# lower_bound = datetime.datetime.today() - datetime.timedelta(days=370)
# print(lower_bound)
# upper_bound = datetime.datetime.today()
"""
datanse[" DATE OF LISTING"] = pd.to_datetime(
    datanse[" DATE OF LISTING"], format="%d-%b-%Y"
)
datanse1 = datanse[(datanse[" DATE OF LISTING"] <= lower_bound)]
"""

datanse.drop(
    columns=[
        "Series",
        # "Industry"
        # " DATE OF LISTING",
        # " PAID UP VALUE",
        # " MARKET LOT",
        # " ISIN NUMBER",
        # " FACE VALUE",
    ],
    inplace=True,
)

# bse=bse['Igroup Name'].fillna("Zero", inplace=True)
# print(bse)
# print(datanse)

datansebse = datanse
datansebse = pd.merge(datanse, bse, left_on=["ISIN Code"], right_on=[
                      "ISIN CodeB"], how="left")
# datansebse1 = pd.merge(datanse, bse, left_on=[' ISIN NUMBER'], right_on=['Face Value'], how='right')
# print(datansebse1)

# datansebse = pd.merge(datanse, bse, on=' ISIN NUMBER', how='left')
# print(datansebse)
# datanse.to_csv('/home/rizpython236/BT5/screener-outputs/datanse.csv', index=False)
# bse.to_csv('/home/rizpython236/BT5/screener-outputs/databse.csv', index=False)


common_symbols = bse[bse["ISIN CodeB"].isin(
    datanse["ISIN Code"])]  # common isin
# common_symbols = bse[bse["SYMBOL"].isin(datanse["SYMBOL"])]

# print(len(common_symbols))


bse = bse[~bse["ISIN CodeB"].isin(common_symbols["ISIN CodeB"])]
# Deleting the rows with common symbols in the bse file
# bse = bse[~bse["SYMBOL"].isin(common_symbols["SYMBOL"])]


add_suffix_to_column(bse, "SymbolB", ".BO")
add_suffix_to_column(datanse, "Symbol", ".NS")

bse.rename(columns={"SymbolB": "Symbol"}, inplace=True)
bse.rename(columns={"Company NameB": "Company Name"}, inplace=True)
bse.rename(columns={"ISIN CodeB": "ISIN Code"}, inplace=True)
# print(bse)

# Merging the two files
result = datanse  # pd.concat([bse, datanse], axis=0, ignore_index=True)
# datanse = result[~result["Security Id"]astype(str).str.contains("ETF", na=False)]
result.rename(columns={"SYMBOL": "Symbol"}, inplace=True)
# print(result)
# result.insert(0, "^NSEI")
# result.insert(1, "^NSEBANK")
# result.insert(2, "^CRSLDX")
# result.insert(3, "^NSEMDCP50")
result.drop(
    columns=[
        # "NAME OF COMPANY",
        # "Security Id",
        # "Security Name",
        # "Status",
        # " ISIN NUMBER",
        # " FACE VALUE",
    ],
    inplace=True,
)


include_tickers_df = pd.DataFrame(include_tickers, columns=["Symbol"])
# result=result['Symbol']
# print(include_tickers_df)
# print(result)
# result = result.append(include_tickers_df['Symbol'], ignore_index=True)


common_symbols = include_tickers_df[~include_tickers_df["Symbol"].isin(
    result["Symbol"])]  # common isin
common_symbols = common_symbols["Symbol"]
# print(common_symbols)
# print((len(common_symbols)))
# common_symbols.to_csv("common.csv", index=False)


# result = pd.concat([result, include_tickers_df], ignore_index=True)
# result = result.append(include_tickers[['Symbol']], ignore_index=True)
"""
#print(exclude_tickers)
result = result[~result["Symbol"].isin(exclude_tickers)]

for ex_ticker in result["Symbol"].values: #ex_ticker in exclude_tickers:
    if ex_ticker in result:
        print(ex_ticker)
        result = result[result["Symbol"] != ex_ticker] #result.remove(ex_ticker)
    else:
        1+1
"""
# result=list(result["Symbol"].unique())
# result=pd.DataFrame(result)
# result = result.rename(columns={result.columns[0]: "Symbol"})
"""
result.loc[len(result), 'Symbol'] = 'ABSLAMC.NS '
result.loc[len(result), 'Symbol'] = 'AKZOINDIA.NS'
result.loc[len(result), 'Symbol'] = 'BRITANNIA.NS'
result.loc[len(result), 'Symbol'] = 'EICHERMOT.NS'

result.loc[len(result), 'Symbol'] = 'MON100.NS'
result.loc[len(result), 'Symbol'] = 'MAFANG.NS'
result.loc[len(result), 'Symbol'] = 'MAHKTECH.NS'
result.loc[len(result), 'Symbol'] = 'SBIGETS.BO'
result.loc[len(result), 'Symbol'] = 'AXISCETF.NS'
result.loc[len(result), 'Symbol'] = 'ICICIINFRA.NS'
result.loc[len(result), 'Symbol'] = '^CNXCMDT'
result.loc[len(result), 'Symbol'] = '^CNXINFRA'
result.loc[len(result), 'Symbol'] = '^CNXAUTO'
result.loc[len(result), 'Symbol'] = '^CNXPHARMA'
result.loc[len(result), 'Symbol'] = '^CNXPSUBANK'
result.loc[len(result), 'Symbol'] = '^CNXIT'
result.loc[len(result), 'Symbol'] = '^CNXCONSUM'
result.loc[len(result), 'Symbol'] = 'NIFTYPVTBANK.NS'
result.loc[len(result), 'Symbol'] = '^CNXMETAL'
result.loc[len(result), 'Symbol'] = '^CNXREALTY'
result.loc[len(result), 'Symbol'] = '^CNXENERGY'
result.loc[len(result), 'Symbol'] = '^CNXFMCG'
result.loc[len(result), 'Symbol'] = 'NIFTYSMLCAP250.NS'
result.loc[len(result), 'Symbol'] = 'NIFTY_MICROCAP250.NS'
result.loc[len(result), 'Symbol'] = '^NSEI'
result.loc[len(result), 'Symbol'] = 'NIFTY_FIN_SERVICE.NS'
"""

result.loc[len(result), "Symbol"] = "^NSEI"
result = list(result["Symbol"].unique())
result = pd.DataFrame(result)
# print(result)
# result = result[~result['Symbol'].str.contains('DUMMY')]
result = result[~result[0].str.contains("DUMMY")]
# print(len(result))
# result = result.append({"Symbol": "^NSEI"}, ignore_index=True)
result = result.rename(columns={result.columns[0]: "Symbol"})
result.to_csv("/home/rizpython236/BT5/Finalnse.csv", index=False)

print(f"Found {len(Final111)} tickers in OLD NSE500/Microcap250 Symbol list")
print(f"Found {len(result)} tickers in NEW NSE500/Microcap250 Symbol list")

result_set = set(result["Symbol"])
Final111_set = set(Final111["Symbol"])
new_tickers_set = set(new_tickers["NSE750"])

# Find items in result but not in Final111
items_not_in_Final111 = result_set - Final111_set - new_tickers_set


items_as_list = list(items_not_in_Final111)
if items_as_list:
    # Load the existing CSV data into a DataFrame
    df = pd.read_csv("/home/rizpython236/BT5/myholding.csv")
    # Append items_not_in_Final111 to the 'symbol' column
    df = df.append(pd.DataFrame({"Symbol": items_as_list}), ignore_index=True)
    # Save the modified DataFrame back to the CSV file
    print(df)
    # df.to_csv("/home/rizpython236/BT5/myholding.csv", index=False)
else:
    print("items_as_list is empty")

# Print the items
print(", ".join(items_not_in_Final111))
post_telegram_message(message=", ".join(items_not_in_Final111))

# Assuming new_tickers.csv has a column named 'FULLSymbol'
csv_file_path = "/home/rizpython236/BT5/trade-logs/new_tickers.csv"

# Read the existing CSV file into a DataFrame
existing_tickers_df = pd.read_csv(csv_file_path)
existing_tickers_df["FULLSymbol"] = existing_tickers_df["FULLSymbol"].astype(
    str)
existing_tickers_df["NSE750"] = existing_tickers_df["NSE750"].astype(str)
try:
    # existing_tickers_df.dropna(subset=['FULLSymbol', 'NSE750'], inplace=True)

    # existing_tickers_df = existing_tickers_df.dropna(subset=['FULLSymbol', 'NSE750'])

    # Convert the items_not_in_Final111 set to a DataFrame
    new_tickers_df = pd.DataFrame(items_not_in_Final111, columns=["NSE750"])

    # Append new_tickers_df to existing_tickers_df
    merged_df = pd.concat(
        [existing_tickers_df, new_tickers_df], ignore_index=True)

    # Remove rows with blank items in each column
    # merged_df = merged_df.dropna(subset=['FULLSymbol', 'NSE750'])

    if len(new_tickers_df) < 20:
        # Save the merged DataFrame back to the CSV file
        merged_df.to_csv(csv_file_path, index=False)

    time.sleep(3)
    import_user_module(base_dir_module, "holding_unique")
except Exception as exc:
    print(exc)

print("NSE500 Microcap250 Ticker download operation finished successfully!")
