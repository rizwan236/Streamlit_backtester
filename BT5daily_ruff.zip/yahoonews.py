import sys


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")
import time

import pandas as pd
import yfinance as yf


def get_mergers_demergers(ticker_path):
    """
    Analyzes news headlines for keywords related to mergers and demergers for a list of symbols.
    
    Args:
    ticker_path (str): Path to the CSV file containing the list of symbols.
    
    Returns:
    None: Prints relevant merger/demerger headlines.
    """
    headlines_list = []

  # Read ticker symbols from CSV
    try:
        ticker_df = pd.read_csv(ticker_path)
        symbols = ticker_df['Symbol'].tolist()
        symbols = list(dict.fromkeys(symbols))  # Remove duplicates
    except FileNotFoundError:
        print(f"Error: File not found at {ticker_path}")
        return

  # Process symbols with rate limiting
    counter = 0
    for ticker in symbols:
        try:
            counter += 1
            if counter % 200 == 0:
                print(f"Processed {counter} tickers. Pausing for 5 minutes...")
                time.sleep(5 * 60)  # Sleep for 5 minutes to avoid exceeding API rate limits        
        
            stock_info = yf.Ticker(ticker)
            news_df = stock_info.news
            #print(news_df)
    
            for index, row in news_df.iterrows():
                headline = row['title'].lower()
                if any(keyword in headline for keyword in ["merger", "acquisition", "acquire", "demerger", "spin-off", "de-merger", "spinoff"]):
                    print(f"Merger/Demerger Headline for {ticker}: {headline}")
                    headlines_list.append({'Ticker': ticker, 'Headline': headline})
            
            
        except Exception as e:
            1+1
            #print(f"Error processing ticker {ticker}: {e}")
            
    return pd.DataFrame(headlines_list)        

# Example usage (replace with your actual ticker list path)
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
get_mergers_demergers(ticker_path)

merger_demerger_df = get_mergers_demergers(ticker_path)

# Print the DataFrame
print(merger_demerger_df)

# Save the DataFrame to a CSV file (optional)
##merger_demerger_df.to_csv('merger_demerger_headlines.csv', index=False) 





