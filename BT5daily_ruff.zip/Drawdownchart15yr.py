import os
import sys
import time

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import pandas as pd
import pandas_ta as ta

# import yfinance as yf
import seaborn as sns
import talib as ta

from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")


"""
print("Deleting all the ticker_15yr data csv files.")
dir2 = '/home/rizpython236/BT5/ticker_15yr/'
for f in os.listdir(dir2):
    os.remove(os.path.join(dir2, f))
"""

print("Drawdownchart15yr")


def get_stock_csv_files(folder_path):
    csv_files = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            csv_files.append(os.path.join(folder_path, file))

    return csv_files


def calculate_mrp(stock_csv_file):  # , index_csv_file):
    # Load stock and index data from CSV files
    stock_data = pd.read_csv(stock_csv_file)
    # index_data = pd.read_csv(index_csv_file)

    MDD_df = pd.DataFrame()
    MDD_df = stock_data
    # MDD_df.ta.exchange = "NSE"
    MDD_df_52 = MDD_df.iloc[-60:]
    # print(MDD_df_52)
    # fffffff

    # Calculate daily returns
    stock_data_df = pd.DataFrame()
    # index_data_df = pd.DataFrame()
    stock_data_df["Close"] = stock_data["Close"].pct_change()
    # index_data_df['Close'] = index_data['Close'].pct_change()

    MDD_df1 = ta.drawdown(MDD_df.Close)
    MDD_df52 = ta.drawdown(MDD_df_52.Close)
    MDD_df1["DD_PCT52"] = (MDD_df52["DD_PCT"] * 100).round(2)
    # MDD_df1 = ta.cdl_pattern(MDD_df.Open, MDD_df.High, MDD_df.Low, MDD_df.Close,name=["2crows", "3blackcrows","3whitesoldiers","identical3crows","morningstar",])
    MDD_df1["DD"] = (MDD_df1["DD"] * 1).round(2)
    MDD_df1["DD_PCT"] = (MDD_df1["DD_PCT"] * 100).round(2)
    MDD_df1["DD_LOG"] = (MDD_df1["DD_LOG"] * 100).round(2)
    # MDD_df1['ZS_52'] = ta.zscore(MDD_df.Close, length=52, std=1.5, offset=None)
    # print(MDD_df1)
    # MDD_df1['ZS_52'] = MDD_df1['ZS_52'].replace([np.inf, -np.inf], np.nan)
    # MDD_df1['ZS_52'] = MDD_df1['ZS_52'].fillna(0)  # or replace with another value as needed
    # MDD_df1['ZS_52'] = (MDD_df1['ZS_52'] * 1).round(2)
    # print(MDD_df1['ZS_52'])

    stock_data = pd.concat([stock_data, MDD_df1], axis=1)
    # print(stock_data)
    stock_data.to_csv(stock_csv_file, index=False)


# Provide the folder path where the stock CSV files are located
stock_folder_path = "/home/rizpython236/BT5/ticker_15yr/"

# Get the list of stock CSV files in the folder
stock_csv_files = get_stock_csv_files(stock_folder_path)
index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

# Calculate MRP and update each stock CSV file
for stock_csv_file in stock_csv_files:
    calculate_mrp(stock_csv_file)  # , index_csv_file)
    1 + 1

# Provide the folder path where the stock CSV files are located
stock_folder_path = "/home/rizpython236/BT5/ticker_15yr/"

# Get the list of stock CSV files in the folder
stock_csv_files = [os.path.join(stock_folder_path, file) for file in os.listdir(
    stock_folder_path) if file.endswith(".csv")]

try:
    1 + 1
    # import csv15yrs
except Exception as e:
    print(f"csv15yrs error: {e}")

# Specify the folder path containing CSV files
# Replace with the actual folder path
folder_path = "/home/rizpython236/BT5/ticker_15yr/"
ticker_path = "/home/rizpython236/BT5/myholding.csv"
ticker_path = "/home/rizpython236/BT5/Finalnse.csv"
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df["Symbol"].tolist()[:]
symbols = list(dict.fromkeys(symbols))
selected_files = []

valid_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
valid_df = pd.read_csv(valid_file)
Symbol_to_YFindustry_mapping = dict(
    zip(valid_df["Symbol"], valid_df["YFindustry"]))

# Base_name=symbol_to_company.get(base_name, base_name)
# symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

change_df = pd.read_csv("/home/rizpython236/BT5/MYindustry.csv")
YFindustry_to_MYindustry_mapping = dict(
    zip(change_df["Industry"], change_df["MYindustry"]))


# Create an empty DataFrame for storing the latest close prices
latest_DD = pd.DataFrame(columns=["Symbol", "Latest_DDWN", "Median_DDWN"])

# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    if file_name.endswith(".csv"):
        file_path = os.path.join(folder_path, file_name)
        # total_files += 1
        base_name = os.path.splitext(file_name)[0]
        # file_names.append(base_name)
        # print(base_name)
        if base_name in symbols:
            file_path = os.path.join(folder_path, file_name)
            selected_files.append(file_path)

            # Read the CSV file into a DataFrame
            df = pd.read_csv(file_path)

            # Get the latest close price
            latest_DDWN = round(df["DD_PCT"].iloc[-1], 1)  # DD_PCT
            Median_DDWN = round(df["DD_PCT"].median(), 1)  # DD_PCT
            # zscore = round(df['ZS_52'].iloc[-1],1)
            latest_DDWN52 = round(df["DD_PCT52"].iloc[-1], 1)  # DD_PCT

            if latest_DDWN52 <= 70 or latest_DDWN <= 70:
                # Append the data to the DataFrame
                latest_DD = latest_DD.append({"Symbol": base_name, "Latest_DDWN": latest_DDWN,
                                             "Median_DDWN": Median_DDWN}, ignore_index=True)  # 'zscore':zscore
                # print(base_name, latest_DDWN)

                # Convert the 'Latest_DDWN' column to numeric
                #
                latest_DD["Latest_DDWN"].fillna(0, inplace=True)
                latest_DD["Latest_DDWN"] = pd.to_numeric(
                    latest_DD["Latest_DDWN"], errors="coerce")
                latest_DD["Median_DDWN"].fillna(0, inplace=True)
                latest_DD["Median_DDWN"] = pd.to_numeric(
                    latest_DD["Median_DDWN"], errors="coerce")
                # latest_DD['zscore'].fillna(0, inplace=True)
                # latest_DD['zscore'] = pd.to_numeric(latest_DD['zscore'], errors='coerce')
                latest_DD["Latest_DDWN"].fillna(0, inplace=True)
                latest_DD["Latest_DDWN"] = latest_DD["Latest_DDWN"].dropna()
                # latest_DD = latest_DD.sort_values(by='Latest_DDWN')
                # print(base_name)
                # print(latest_DD)

                # Map 'Symbol' to 'YFindustry'
                latest_DD["YFindustry"] = latest_DD["Symbol"].map(
                    Symbol_to_YFindustry_mapping)

                # Map 'YFindustry' to 'MYindustry'
                latest_DD["MYindustry"] = latest_DD["YFindustry"].map(
                    YFindustry_to_MYindustry_mapping)
                latest_DD["MYindustry"] = latest_DD["MYindustry"].astype(str)

                # latest_DD[columns_to_check] = latest_DD[columns_to_check].apply(pd.to_numeric, errors='coerce')
                # Append the count to 'MYindustry'
                latest_DD["Count"] = latest_DD.groupby(
                    "MYindustry").cumcount().add(1)

                # Modify 'MYindustry' to append the count
                # latest_DD['MYindustry'] = latest_DD['MYindustry'] + '-' + latest_DD['Count'].astype(str)
                latest_DD["Latest_DDWN"] = latest_DD["Latest_DDWN"].dropna()

                # Calculate the median 'Latest_DDWN' and count separately
                median_by_MYindustry = latest_DD.groupby(
                    "MYindustry")["Latest_DDWN"].median().reset_index()  # .sort_values()
                count_by_MYindustry = latest_DD.groupby("MYindustry")[
                    "Count"].max()
                min_max_df = latest_DD.groupby("MYindustry")["Latest_DDWN"].agg([
                    "min", "max"]).reset_index()
                # MaxDD_by_MYindustry  = latest_DD.groupby('MYindustry')['Latest_DDWN'].max().reset_index()
                # MinDD_by_MYindustry  = latest_DD.groupby('MYindustry')['Latest_DDWN'].min().reset_index()
                # Modify 'MYindustry' to append the count
                # latest_DD['MYindustry'] = latest_DD['MYindustry'] + '-' + latest_DD['Count'].astype(str)

                # print(median_by_MYindustry)
                # print(count_by_MYindustry)

                # Combine the results into a DataFrame
                # summary_df = pd.DataFrame({'Median_Latest_DDWN': median_by_MYindustry, 'Count': count_by_MYindustry})
                summary_df = pd.merge(
                    median_by_MYindustry, count_by_MYindustry, on="MYindustry")
                summary_df = pd.merge(summary_df, min_max_df, on="MYindustry")
                # summary_df = pd.merge(summary_df, MaxDD_by_MYindustry, on='MYindustry')  # Merge the result with the third DataFrame
                # summary_df = pd.merge(summary_df, MinDD_by_MYindustry, on='MYindustry')  # Merge the result with the fourth DataFrame
                # Append the count to 'MYindustry'
                summary_df["MYindustry"] = summary_df["MYindustry"] + \
                    "-" + summary_df["Count"].astype(str)

                # summary_df = summary_df[summary_df['Count'] >= 1]
                # Drop the 'Count' column if you no longer need it
                # summary_df = summary_df.drop('Count', axis=1)

                # Sort the DataFrame by the median values
                # summary_df = summary_df.sort_values(by='Count')

                # median_by_MYindustry = latest_DD.groupby('MYindustry')['Latest_DDWN'].median().sort_values()

                # print(latest_DD)
                invalid_rows = latest_DD[pd.to_numeric(
                    latest_DD["Latest_DDWN"], errors="coerce").isna()]

                # print(invalid_rows)
                # valid_values = latest_DD['Latest_DDWN'].dropna()
                # print(valid_values)


summary_df["min"].fillna(0, inplace=True)
summary_df["min"] = pd.to_numeric(summary_df["min"], errors="coerce")

summary_df["max"].fillna(0, inplace=True)
summary_df["max"] = pd.to_numeric(summary_df["max"], errors="coerce")

summary_df["Latest_DDWN"].fillna(0, inplace=True)
summary_df["Latest_DDWN"] = pd.to_numeric(
    summary_df["Latest_DDWN"], errors="coerce")

summary_df["Count"].fillna(0, inplace=True)
summary_df["Count"] = pd.to_numeric(summary_df["Count"], errors="coerce")

latest_DD["Count"].fillna(0, inplace=True)
latest_DD["Count"] = pd.to_numeric(latest_DD["Count"], errors="coerce")

latest_DD["Latest_DDWN"].fillna(0, inplace=True)
latest_DD["Latest_DDWN"] = pd.to_numeric(
    latest_DD["Latest_DDWN"], errors="coerce")
latest_DD["Latest_DDWN"].fillna(0, inplace=True)
latest_DD["Latest_DDWN"] = latest_DD["Latest_DDWN"].dropna()

latest_DD = latest_DD.sort_values(by="Latest_DDWN")
summary_df = summary_df[summary_df["Count"] >= 2]
summary_df = summary_df.sort_values(by="Count")
# latest_DD.to_csv('/home/rizpython236/BT5/delete.csv')
# print(median_by_MYindustry)
# print(count_by_MYindustry)
# print(latest_DD)
# print(latest_DD)
# print(invalid_rows)

# print(summary_df)
# print(latest_DD['Latest_DDWN'].dropna().unique())
print(latest_DD["Latest_DDWN"].isnull().sum())

# print(latest_DD)
industries_with_no_match = latest_DD[latest_DD["MYindustry"].isna()]
unique_values = industries_with_no_match["MYindustry"].unique().tolist()
post_telegram_message(unique_values)
print(unique_values)

print(latest_DD[latest_DD["MYindustry"].isnull()])
print(latest_DD[latest_DD["Latest_DDWN"].isnull()])
print(latest_DD[latest_DD["YFindustry"].isnull()])
print(latest_DD[latest_DD["Count"].isnull()])
print(latest_DD.info())


# bin_edges = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
# Calculate histogram values and bin edges
hist_values, bin_edges, _ = plt.hist(latest_DD["Latest_DDWN"].dropna(
), bins=range(0, 101, 10), density=True, edgecolor="black", alpha=0.7)

# Convert counts to percentages
percentage_values = hist_values / sum(hist_values)


Medianhist_values, Medianbin_edges, _ = plt.hist(latest_DD["Median_DDWN"].dropna(
), bins=range(0, 101, 10), density=True, edgecolor="black", alpha=0.7)

# Convert counts to percentages
Medianpercentage_values = Medianhist_values / sum(Medianhist_values)

"""
# Create bins for drawdown values
bins = range(0, 101, 10)
# Create a new column in the DataFrame to represent the bins
latest_DD['Drawdown_Bins'] = pd.cut(latest_DD['Latest_DDWN'], bins=bins, right=False)
# Calculate the percentage frequency
percentage_frequency = latest_DD['Drawdown_Bins'].value_counts(normalize=True) * 100
print(latest_DD)
plt.figure(figsize=(10, 6))
ax=sns.countplot(x='Drawdown_Bins',data=latest_DD, color='skyblue',)#
plt.xlabel('Drawdown % bins of 10')
plt.ylabel('Latest_DDWN %')
from matplotlib.ticker import PercentFormatter
ax.yaxis.set_major_formatter(PercentFormatter())
plt.grid(axis='y', linestyle='--', alpha=0.7)
#plt.gca().yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
plt.tight_layout()
chart_path = '/home/rizpython236/BT5/screener-outputs/Drawdown.png'
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)

# Create histogram
plt.figure(figsize=(10, 6))  # Create a new figure
#sns.histplot(latest_DD['Latest_DDWN'].dropna(), bins=range(0, 101, 10), kde=False ,label='Drawdown bins of 10',density=True)
bar=plt.bar(bin_edges[:-1], percentage_values, width=10, edgecolor='black', alpha=0.7, label='Cr Drawdown % bins of 10')
#plt.hist(latest_DD['Latest_DDWN'], bins=range(0, 101, 10), edgecolor='black', alpha=0.7)
# Add frequency labels on each bar
for bar, freq in zip(bar, percentage_values):
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, height, f'{freq:.0%}', ha='center', va='bottom')
plt.title('Histogram of 15yr Drawdown for NSE500 & MICROCAP_250')
plt.xlabel('Latest_DDWN %')
plt.ylabel('Frequency %')
plt.xticks(range(0, 101, 10))  # Optional: Set custom x-axis ticks
# Show y-axis in percentage format
from matplotlib.ticker import PercentFormatter
plt.gca().yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
plt.grid(axis='y', linestyle='--', alpha=0.7)
# Adjust margins for the first chart
plt.subplots_adjust(wspace=0.3, hspace=0.5)
plt.tight_layout()
chart_path = '/home/rizpython236/BT5/screener-outputs/Drawdown15yr.png'
plt.savefig(chart_path)
#plt.show()
time.sleep(2)
#post_telegram_file(chart_path)
########################

# Create histogram
plt.figure(figsize=(10, 6))  # Create a new figure
#sns.histplot(latest_DD['Latest_DDWN'].dropna(), bins=range(0, 101, 10), kde=False ,label='Drawdown bins of 10',density=True)
bar=plt.bar(bin_edges[:-1], Medianpercentage_values, width=10, edgecolor='black', alpha=0.7, label='Median Drawdown % bins of 10')
#plt.hist(latest_DD['Latest_DDWN'], bins=range(0, 101, 10), edgecolor='black', alpha=0.7)
# Add frequency labels on each bar
for bar, freq in zip(bar, Medianpercentage_values):
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, height, f'{freq:.0%}', ha='center', va='bottom')
plt.title('Histogram of 15yr Median Drawdown for NSE500 & MICROCAP_250')
plt.xlabel('Latest_DDWN %')
plt.ylabel('Frequency %')
plt.xticks(range(0, 101, 10))  # Optional: Set custom x-axis ticks
# Show y-axis in percentage format
from matplotlib.ticker import PercentFormatter
plt.gca().yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
plt.grid(axis='y', linestyle='--', alpha=0.7)
# Adjust margins for the first chart
plt.subplots_adjust(wspace=0.3, hspace=0.5)
plt.tight_layout()
chart_path = '/home/rizpython236/BT5/screener-outputs/MedianDrawdown15yr.png'
plt.savefig(chart_path)
#plt.show()
time.sleep(2)
#post_telegram_file(chart_path)
###########################

# Plot the histogram
plt.figure(figsize=(18, 8))  # Create a new figure
sns.barplot(x=summary_df['MYindustry'], y=summary_df['Latest_DDWN'], color='blue', edgecolor='black',label='Median Drawdown % by Industry',palette='Set3')
# Scatter plot for minimum and maximum
sns.scatterplot(x=summary_df['MYindustry'], y=summary_df['min'], color='White', marker='_',s=100,linewidth=3, label='Min Drawdown % by Industry')
sns.scatterplot(x=summary_df['MYindustry'], y=summary_df['max'], color='red', marker='_',s=100,linewidth=2, label='Max Drawdown % by Industry')
#sns.pointplot(x=summary_df['MYindustry'], y=summary_df['min'].min(), color='green', markers="_", scale=0.5, label='Min Drawdown % by Industry')
#sns.pointplot(x=summary_df['MYindustry'], y=summary_df['max'].max(), color='red', markers="_", scale=0.5, label='Max Drawdown % by Industry')
#plt.bar(summary_df['MYindustry'], summary_df['Latest_DDWN'], color='blue', edgecolor='black', alpha=0.7)
#plt.bar(median_by_MYindustry.index, median_by_MYindustry.values, color='blue', edgecolor='black', alpha=0.7)
plt.title('Median 15yr Drawdown by Industry for NSE500 & MICROCAP_250')
plt.xlabel('Industry with Count')
plt.ylabel('Median Latest_DDWN %')
plt.xticks(rotation=90, ha='right')  # Adjust rotation for better readability
# Adjust margins for the first chart
plt.subplots_adjust(wspace=0.1, hspace=0.1)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

# Show the plot or save it to a file
# plt.show()
chart_path = '/home/rizpython236/BT5/screener-outputs/IndustryDrawdown.png'
plt.savefig(chart_path)
time.sleep(2)
#post_telegram_file(chart_path)
"""
##############
# box plot
# print(latest_DD)

summary_df["Left_Part"] = summary_df["MYindustry"].str.rsplit("-", n=1).str[0]
summary_df = summary_df.rename(columns={"MYindustry": "MYindustrySummary"})
summary_df = summary_df.rename(columns={"Count": "CountSummary"})
# print(summary_df)
merged_df = pd.merge(latest_DD, summary_df[["Left_Part", "MYindustrySummary", "CountSummary"]],
                     left_on="MYindustry", right_on="Left_Part", how="left", suffixes=("_latest_DD", "_summary_df"))
merged_df = merged_df[merged_df["CountSummary"] >= 2.5]
merged_df = merged_df.sort_values(by="CountSummary")
# print(latest_DD)
# print(summary_df)
# print(merged_df)

# latest_DD = latest_DD[latest_DD['Count'] >= 2]
# latest_DD = latest_DD.sort_values(by='Count')
plt.figure(figsize=(18, 8))
# sns.set(style='darkgrid', palette='dark')
sns.boxplot(x=merged_df["MYindustrySummary"],
            y=merged_df["Latest_DDWN"], palette="Set3")
# sns.boxplot(x=latest_DD['MYindustry'], y=latest_DD['Latest_DDWN'],palette='Set3')#, data=latest_DD ,flierprops=dict(marker='o', markersize=8, markerfacecolor='red'
plt.title("Industry-wise 4yr Drawdown Summary for NSE500 & MICROCAP_250")
plt.xlabel("Industry with count")
plt.ylabel("Drawdown%")
plt.xticks(rotation=90, ha="right")
plt.subplots_adjust(wspace=0.1, hspace=0.1)
plt.grid(axis="y", linestyle="--", alpha=0.7)
plt.tight_layout()
# plt.show()
chart_path = "/home/rizpython236/BT5/screener-outputs/IndustryDrawdownBoxplot15yr.png"
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)

######################################
latest_DD = latest_DD[latest_DD["Count"] >= 2]
latest_DD = latest_DD.sort_values(by="Count")
plt.figure(figsize=(18, 8))
# sns.set(style='darkgrid', palette='dark')
sns.boxplot(x=merged_df["MYindustrySummary"],
            y=merged_df["Median_DDWN"], palette="Set3")
# sns.boxplot(x=latest_DD['MYindustry'], y=latest_DD['Latest_DDWN'],palette='Set3')#, data=latest_DD ,flierprops=dict(marker='o', markersize=8, markerfacecolor='red'
plt.title("Industry-wise 4yr Median Drawdown Summary for NSE500 & MICROCAP_250")
plt.xlabel("Industry with count")
plt.ylabel("Drawdown%")
plt.xticks(rotation=90, ha="right")
plt.subplots_adjust(wspace=0.1, hspace=0.1)
plt.grid(axis="y", linestyle="--", alpha=0.7)
plt.tight_layout()
# plt.show()
chart_path = "/home/rizpython236/BT5/screener-outputs/IndustryDrawdownBoxplot15yrMedian.png"
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)
######################

plt.figure(figsize=(18, 6))
# custom_bin_edges = [0-10,10-20, 20-30, 30-40, 40-50, 50-60, 60-70, 70-80, 80-90, 90-100]# 100]
# Plot the first histogram
bar_width = 5  # Adjust the width of the bars as needed
gap1 = 2
gap2 = 2
bars1 = plt.bar(bin_edges[:-1] - bar_width / 2, percentage_values, width=bar_width,
                edgecolor="black", alpha=0.7, label="Current Drawdown % bins of 10")

# Plot the second histogram next to the first one
bars2 = plt.bar(bin_edges[:-1] + bar_width / 2, Medianpercentage_values, width=bar_width,
                edgecolor="black", alpha=0.7, label="Median Drawdown % bins of 10")

# Set labels, title, ticks, grid, and legend
plt.title(
    "Combined Histogram of 4yr current & Median Drawdown for NSE500 & MICROCAP_250")
plt.xlabel("DDWN %")
plt.ylabel("Frequency %")
# plt.xticks(custom_bin_edges)
plt.xticks(bin_edges[:-1])
plt.grid(axis="y", linestyle="--", alpha=0.7)
plt.gca().yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
plt.legend(loc="upper center")
# Add frequency labels on each bar
for bar, freq in zip(bars1, percentage_values):
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, height,
             f"{freq:.0%}", ha="center", va="bottom")

for bar, freq in zip(bars2, Medianpercentage_values):
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, height,
             f"{freq:.0%}", ha="center", va="bottom")

# Adjust layout and save the chart
plt.tight_layout()
chart_path = "/home/rizpython236/BT5/screener-outputs/Cr&MedianDrawdown15yr.png"
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)


print("done")
