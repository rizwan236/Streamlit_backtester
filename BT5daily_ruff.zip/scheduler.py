from datetime import datetime
import os
import time

# sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
import schedule


print("Starting Scheduler")
print(datetime.utcnow())


def func():
    print("Running the Trade Compiler")
    print(datetime.utcnow())
    print("-"*50)
    os.system("python /home/rizpython236/BT5/trade_compiler.py")


# schedule.every(4).seconds.do(func)
# Set datetime in UTC
schedule.every().day.at("19:40").do(func)


while True:
    schedule.run_pending()
    seconds_in_a_day = 86400
    time.sleep(seconds_in_a_day - 3600*1.5)
