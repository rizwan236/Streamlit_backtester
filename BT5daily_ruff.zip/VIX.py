
import csv
from datetime import datetime
import os
import sys
import time
import traceback

import numpy as np
import pandas as pd
import pytz
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
import investpy
from telegram_bot import post_telegram_file, post_telegram_message


df = investpy.get_stock_historical_data(stock='AAPL',country='United States',from_date='01/01/2023',to_date='01/01/2024')
print(df.head())