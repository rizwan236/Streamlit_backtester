import os
import sys

import pandas as pd

from telegram_bot import post_telegram_message


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


print("started sector list")
"""
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
#today = datetime.now()
if today.day <= 7:
    symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers_mhtly.csv')
else:
    symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers.csv')
"""


file_path = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_mhtly_Screener.csv"
if os.path.exists(file_path):
    1 + 1
    # symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers_mhtly.csv')
else:
    symbol_df = pd.read_csv(
        "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv")


# Remove industry file if it exists
# if os.path.exists('/home/rizpython236/BT5/screener-outputs/industry.csv'):
#    os.remove('/home/rizpython236/BT5/screener-outputs/industry.csv')


# Load symbols from CSV file
# symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers_mhtly.csv')
# symbol_df = pd.read_csv('/home/rizpython236/BT5/symbol_list.csv')


# Create an empty DataFrame to store the symbol and sector details
industry_df = pd.DataFrame(columns=[
                           "Symbol", "Industry", "Sector", "LongName", "MarketCapCr", "Employees", "MYindustry"])

# Iterate through each symbol
for symbol in symbol_df["Symbol"][:]:
    try:
        # Fetch stock information for the symbol
        stock = xxxyf.Ticker(symbol)
        try:
            # Get the sector of the stock
            industry = xxxstock.info["industry"]  # stock.info['sector']
        except Exception as e:
            industry = "Blank"
        try:
            sector = xxstock.info["sector"]
        except Exception as e:
            sector = "Blank"
        Employees = "Blank"  # stock.info['Full Time Employees']
        try:
            marketCap = xxstock.info["marketCap"]
            marketCap = round(marketCap / 10000000, 2)
        except Exception as e:
            marketCap = "Blank"  # stock.info['marketCap']
        try:
            longName = xxxstock.info["longName"]
        except Exception as e:
            longName = "Blank"
        # Print the symbol name and sector
        # print(f"Symbol: {symbol},LongName:{longName},MarketCapCr:{marketCap}, Sector: {sector},Industry: {industry}")

        # Append the symbol and sector to the industry DataFrame
        industry_df = industry_df.append({"Symbol": symbol, "LongName": longName, "Industry": industry,
                                         "Sector": sector, "MarketCapCr": marketCap, "Employees": Employees}, ignore_index=True)
    except Exception as e:
        longName = "Blank"
        marketCap = "Blank"
        sector = "Blank"
        industry = "Blank"
        Employees = "Blank"
        # Append the symbol and assumed sector to the industry DataFrame
        industry_df = industry_df.append({"Symbol": symbol, "LongName": longName, "Industry": industry,
                                         "Sector": sector, "MarketCapCr": marketCap, "Employees": Employees}, ignore_index=True)
        # If an error occurs, handle it (e.g., symbol not found)
        # print(f"Error fetching data for symbol: {symbol}")
        # print(f"Error getting dividend for {symbol}: {type(e).__name__} - {e}")

input_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
valid_df = pd.read_csv(input_file)

# Create a mapping dictionary from valid_df
symbol_to_industry_mapping = dict(
    zip(valid_df["Symbol"], valid_df["YFindustry"]))

# print(symbol_to_industry_mapping)

# Update 'Industry' column in industry_df using the mapping
industry_df["Industry"] = industry_df["Symbol"].map(
    symbol_to_industry_mapping).combine_first(industry_df["Industry"])


# Sort the DataFrame by sector, with black sector symbols at the bottom
# industry_df = industry_df.sort_values(by='Industry', key=lambda x: x.str.contains('Blank'))


change_df = pd.read_csv("/home/rizpython236/BT5/MYindustry.csv")
# change_df['Industry'] = change_df['Industry'].astype(industry_df['Industry'].dtype)

Industry_to_myindustry_mapping = dict(
    zip(change_df["Industry"], change_df["MYindustry"]))

# print(symbol_to_industry_mapping)

# Update 'Industry' column in industry_df using the mapping
industry_df["MYindustry"] = industry_df["Industry"].map(
    Industry_to_myindustry_mapping).combine_first(industry_df["MYindustry"])


# industry_df = industry_df.merge(change_df[['Industry', 'MYindustry']], on='Industry', how='left')
# print(industry_df)

industries_with_no_match = industry_df[industry_df["MYindustry"].isna()]
# industries_with_no_match=industries_with_no_match['Industry'].unique())
unique_values = industries_with_no_match["Industry"].unique().tolist()
post_telegram_message(unique_values)
# post_telegram_message((industries_with_no_match['Industry'].unique()))
# print((industries_with_no_match['Industry'].unique()))
print(unique_values)

# industry_df = industry_df['MYindustry'].fillna('Blank', inplace=True)
# print(industry_df)
industry_df = industry_df
industry_df = industry_df.sort_values("MYindustry")

# Save the industry DataFrame to a CSV file
industry_df.to_csv(
    "/home/rizpython236/BT5/screener-outputs/industry.csv", index=False)

# print(industry_df)

print("completed sector list")
