import sys


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")

# sys.path.append(os.path.join(os.path.
# /home/rizwan236z/.virtualenvs/FARBT/lib/python3.7/site-packages/backtrader(__init__), '..'))
from datetime import date, datetime, timedelta
import os
import time

import backtrader as bt
from backtrader.indicators.smma import SmoothedMovingAverage
from BBSqueeze import BBSqueeze
from BollingerBandsSqueeze import BBSqueeze
from Donchain_Channels import DonchianChannels  # custum indicator
from exp_ln_reg_Momentum import Momentum  # custum observer
import pandas as pd
import pytz
from realsupertrend import SuperTrend  # custum indicator
from SCtrade_list import trade_list  # custum analyzer

# from Baranalysis1 import BarAnalysis
from settings import (
    SCREENER_OUTPUT_FOLDER_PATH,
    TICKER_CSV_DATA_FOLDER_PATH,
)

#from RelativeStrength import NiftyBankNiftyRelativePerformance
# from limited_test_report import LimitedTestReport  # custum analyzer
from tabulate import tabulate
import talib

#import snoop
# from pandas_datareader import data as pdr
from telegram_bot import post_telegram_message
from vwap import VolumeWeightedAveragePrice
import yfinance as yf


print("BTscreener")
monthly="YES"

class GenericCSVDataR(bt.feeds.GenericCSVData):
    lines = ('MRP13','MRP25',)
    params = (
        ('dtformat', '%Y-%m-%d'),
        ('datetime', 0),
        ('Open', 1),
        ('High', 2),
        ('Low', 3),
        ('Close', 4),
        ('Adj Close', 5),
        ('Volume', 6),
        ('MRP13', 7),
        ('MRP25', 8),
    )
'''
    params = (
        ('nullvalue', float('NaN')),
        ('dtformat','%Y-%m-%d %H:%M:%S'),  #('dtformat', '%Y-%m-%d %H:%M:%S'),
        ('tmformat', '%H:%M:%S'),

        ('datetime', 0),
        ('time', -1),
        ('open', 1),
        ('high', 2),
        ('low', 3),
        ('close', 4),
        ('volume', 5),
        ('openinterest', 6),  #('openinterest', 6),
    )

'''




class firstStrategy(bt.Strategy):
    params = (("sma10", 40), ("oneplot", True))

    #@snoop
    def __init__(self):
        self.inds = dict()

        #self.nifty = self.datas[0]
        #self.NSEBANK = self.datas[1]
        #self.CRSLDX=self.datas[1]
        #self.NSEMDCP50=self.datas[2]
        #self.CNXSC=self.datas[3]

        self.stocks = self.datas[0:]

        #self.nifty_ema200 = bt.talib.EMA(self.nifty.close,timeperiod=40)
        #self.CRSLDX_ema200 = bt.talib.EMA(self.CRSLDX.close,timeperiod=40)
        #self.NSEMDCP50_ema200 = bt.talib.EMA(self.NSEMDCP50.close,timeperiod=40)
        #self.CNXSC_ema200 = bt.talib.EMA(self.CNXSC.close,timeperiod=40)


        for i, d in enumerate(self.stocks):
            if True == False:  # (d.buflen() - 50)# <= len(d):#  #
                raise bt.errors.StrategySkipError
            else:
                self.inds[d] = dict()
                self.inds[d]["CCI"]=bt.talib.CCI(d.high, d.low, d.close, timeperiod=12)
                self.inds[d]["CCImovavg"] = bt.talib.SMA(self.inds[d]["CCI"], timeperiod=4
                )
                self.inds[d]["ADX"] = bt.indicators.AverageDirectionalMovementIndex(
                    d, period=14, plotname="ADX", plot=False
                )
                self.inds[d]["DIind"] = bt.indicators.DirectionalIndicator(d, period=14, plotname="-+DI", plot=False)
                #self.inds[d]["RSI"] = bt.indicators.RSI(d.close, period=14,safediv=True, plot=False)
                self.inds[d]["OBV"] = bt.talib.OBV(d.close, d.volume)
                self.inds[d]["obvmovavg"] = bt.talib.SMA(
                    self.inds[d]["OBV"], timeperiod=14
                )
                #self.inds[d]["OBVcheck"] = self.inds[d]["OBV"] > self.inds[d]["obvmovavg"]
                self.inds[d]["ST"] = SuperTrend(period=10, multiplier=3)
                #self.inds[d]["ALLN"]= bt.indicators.all(d, period=40)
                #self.inds[d]["VWAPF"]= VolumeWeightedAveragePrice(d,period=4)
                #self.inds[d]["VWAPS"]= VolumeWeightedAveragePrice(d,period=14)
                #self.inds[d]["SMA_VOL12"] = bt.talib.SMA(d.volume, timeperiod=16)
                #self.inds[d]["SMA_VOL3"] = bt.talib.SMA(d.volume, timeperiod=8)
                self.inds[d]["macd"] = bt.indicators.MACD(
                    d, period_me1=12, period_me2=26, period_signal=9,plot=False
                )
                self.inds[d]["macdH"] = bt.indicators.MACDHisto()
                self.inds[d]["macdsignal"] = self.inds[d]["macd"].signal
                #self.inds[d]["SMA_SLOW"] = bt.talib.SMA(d.close, timeperiod=6)
                #self.inds[d]["EMA_FAST"] = bt.talib.EMA(d.close, timeperiod=3)
                #self.inds[d]["KAMA"] = bt.talib.KAMA(d.close, timeperiod=4)
                self.inds[d]["DCH"] = DonchianChannels(period=12)
                self.inds[d]["DCHema"] = bt.talib.SMA(
                    self.inds[d]["DCH"], timeperiod=3
                )
                #self.inds[d]["Exp_lin_reg"] = Momentum(d.close, period=14, subplot=False) #18-90 days, 12-60 days  9wk
                #self.inds[d]["Exp_lin_regslow"] = Momentum(d.close, period=24, subplot=False)   # 18wk
                self.inds[d]["BBSqueezeid"] = BBSqueeze(d, period=12, devfactor=2)
                self.inds[d]["BBSqueezeavg"] = bt.talib.SMA(self.inds[d]["BBSqueezeid"], timeperiod=6)
                self.inds[d]["BollingerBandsind"] = bt.indicators.BollingerBands(d, period=12, devfactor=2)
                #self.inds[d]["BBS"] = BBSqueeze(
                #    period=14, bbdevs=2, kcdevs=1.5, movav=bt.ind.MovAv.Simple
                #)
                #self.inds[d]["BBSavg"] = bt.talib.SMA(self.inds[d]["BBS"], timeperiod=7)
                #self.inds[d]["EFI"] = bt.indicators.ExponentialMovingAverage(
                #    d.volume(0) * (d.close(0) - d.close(-1)),
                #    period=13,
                #    subplot=False,
                #    plotname="EFI",
                #)
                #self.inds[d]["EFIavg"] = bt.talib.SMA(
                #    self.inds[d]["EFI"], timeperiod=10, plotname="EFIavg"
                #)
                #self.inds[d]["52wkH"] = bt.talib.MAX(d.close, timeperiod=40)
                #self.inds[d]["52wkL"] = bt.talib.MIN(d.close, timeperiod=40)
                self.inds[d]["totallen"] = d.buflen() - 1

                if i > 0:  # Check we are not on the first loop of data feed:
                    if self.p.oneplot == True:
                        d.plotinfo.plotmaster = self.datas[0]

                # first_date=date.today()-timedelta(weeks=51)
                # if d.high[0]  > 0.01:
                #    True==True
                # else:
                #    raise bt.StrategySkipError
    #@snoop
    def next(self):
        finals = " "
        for i, d in enumerate(self.datas):
            dt, dn, dv, dl, db = (
                self.datetime.date(),
                d._name,
                d.close[0],
                len(d),
                d.buflen(),
            )
            # finals=finals+"|" + "{} {} {} {} {}".format(dt,dn,dv,dl,db)
            # print(finals)

            # print("_________________")
            # print(dt, dn)
            # print("_________________")
            pos = self.getposition(d).size
            # print(len(d))
            yesterday = len(d) == (d.buflen() - 1)
            #yesterdayNFT = len(self.nifty) == (self.nifty.buflen() - 1)
            #yesterdayCRSLDX = len(self.CRSLDX) == (self.CRSLDX.buflen() - 1)
            #yesterdayNSEMDCP50 = len(self.NSEMDCP50) == (self.NSEMDCP50.buflen() - 1)
            #yesterdayCNXSC = len(self.CNXSC) == (self.CNXSC.buflen() - 1)

            # yesterdayold = len(d) == (d.buflen() - 1)
            # totallen = d.buflen() - 1  #!= (d(1).buflen() - 1)
            # oldddate = date.today() - timedelta(weeks=52)
            # oldddate1 = date.today() - timedelta(weeks=4)
            # datebt = d.datetime.date(0)
            # print(oldddate, datebt)
            # datelist=pd.date_range(end = datetime.today()- timedelta(weeks=50), periods = 100).to_pydatetime().tolist()
            # list=d.oldddate

            # self.position(d):  # no market / no orders
            if yesterday and not pos: #and yesterdayNFT and yesterdayCRSLDX and yesterdayNSEMDCP50:
                if (
                    d.close[0] > 30 # d.high[0]*1.3
                    and (d.MRP13[0] or d.MRP25[0]) >.00000000000001
                    #and self.inds[d]["ALLN"] == 1
                    #and d.close[0] > 10000000000
                    #and self.inds[d]["VWAPF"]>self.inds[d]["VWAPS"]*1.02
                    #1and d.close[0] > d.low[-1] # > d.close[-2]
                    #d.volume[0] >500
                    #and (self.nifty[0] > self.nifty_ema200[0] or self.CRSLDX[0] > self.CRSLDX_ema200[0] or self.NSEMDCP50[0] > self.NSEMDCP50_ema200[0])
                    and self.inds[d]["ST"][0] < d.close[0]
                    and self.inds[d]["CCI"] > self.inds[d]["CCImovavg"] and self.inds[d]["CCI"] > 0
                    and self.inds[d]["BBSqueezeavg"] > 0
                    #and d.volume[0] >5000
                    #and self.inds[d]["ADX"][0] > 20
                    and self.inds[d]["DIind"].plusDI > self.inds[d]["DIind"].minusDI
                    #and self.inds[d]["SMA_SLOW"] < d.close[0]
                    #and self.inds[d]["52wkH"]*.85 < d.high[0]
                    #and self.inds[d]["RSI"][0] > 30
                    #and self.inds[d]["macdH"][0] > 0
                    and self.inds[d]["macdsignal"][0] < self.inds[d]["macd"][0]
                    #and self.inds[d]["EFI"] > self.inds[d]["EFIavg"]
                    #and self.inds[d]["EMA_FAST"] > self.inds[d]["SMA_SLOW"]
                    #and (self.inds[d]["BBSqueezeid"][-26] < 0 and self.inds[d]["BBSqueezeid"][-17] < 0 and self.inds[d]["BBSqueezeid"][-8] < 0 and self.inds[d]["BBSqueezeid"][0] > 2 and self.inds[d]["SMA_VOL12"][-8]< self.inds[d]["SMA_VOL3"]*1.1)
                    #and ((self.inds[d]["Exp_lin_reg"][0] > 30 and self.inds[d]["OBVcheck"] == 1 ) or self.inds[d]["Exp_lin_regslow"] > 35 or (self.inds[d]["BBSqueezeid"][-20] < 4 and self.inds[d]["BBSqueezeid"][-15] < 4 and self.inds[d]["BBSqueezeid"][-10] < 4 and self.inds[d]["BBSqueezeid"][-5] < 4 and self.inds[d]["BBSqueezeid"][0] > 2 and self.inds[d]["OBVcheck"] == 1))
                    ##and ((self.inds[d]["Exp_lin_reg"][0] > 25 ) or self.inds[d]["Exp_lin_regslow"] > 30 or (self.inds[d]["BBSqueezeavg"][-20] < 4 and self.inds[d]["BBSqueezeavg"][-15] < 4 and self.inds[d]["BBSqueezeavg"][-10] < 4 and self.inds[d]["BBSqueezeavg"][-5] < 4 and self.inds[d]["BBSqueezeid"][0] > 2 ))
                    #and self.inds[d]["OBV"][0] > self.inds[d]["obvmovavg"][0]
                ):
                    self.buy(data=d, size=1)
                else:
                    if (
                        self.inds[d]["ST"][0] > d.close[0]
                        #and self.inds[d]["ALLN"] == 1
                        #and self.inds[d]["RSI"][0] < 35
                        #and d.close[0] > 10000000000
                        and self.inds[d]["CCI"] < self.inds[d]["CCImovavg"] and self.inds[d]["CCI"] < 4
                        #and self.inds[d]["ADX"] > 30
                        and self.inds[d]["DIind"].plusDI < self.inds[d]["DIind"].minusDI
                        #and self.inds[d]["OBVcheck"] == 0
                        #and self.inds[d]["Exp_lin_reg"][0] < self.inds[d]["Exp_lin_regslow"] and self.inds[d]["OBVcheck"] == 0
                        #and self.inds[d]["DCH"] > self.inds[d]["DCHema"] or self.inds[d]["DCH"] >28)
                        #and self.inds[d]["OBV"][0] < self.inds[d]["obvmovavg"][0]
                        and self.inds[d]["macdsignal"][0] > self.inds[d]["macd"][0]
                        #and self.inds[d]["macdH"][0] < 0
                    ):
                        self.sell(data=d, size=1)
                    else:
                        if (
                            #self.inds[d]["ST"][0] > d.close[0]
                            #and self.inds[d]["ALLN"] == 1
                            #and d.close[0] > 10000000000
                            self.inds[d]["CCI"] < self.inds[d]["CCImovavg"] and self.inds[d]["CCI"] < 4
                            #and self.inds[d]["52wkL"]*1.50 > d.close[0]
                            #and self.inds[d]["macdH"][0] < 0
                            and self.inds[d]["ADX"][0] < 30
                            and self.inds[d]["BBSqueezeavg"][-4] < 4 and self.inds[d]["BBSqueezeavg"][-8] < 4 and self.inds[d]["BBSqueezeavg"][-4] < 4 and self.inds[d]["BBSqueezeid"][0] < 4
                            and self.inds[d]["BBSqueezeid"] < 4
                            #and d.close[0] < self.inds[d]["BollingerBandsind"].lines.bot
                            and (
                                self.inds[d]["DCH"] < self.inds[d]["DCHema"]
                                or self.inds[d]["DCH"] < 30
                            )
                        ):
                            self.sell(data=d, size=1)
            # else:
            #    if yesterdayold and not pos:
            #        if bt.talib.MIN(d.date,timeperiod=2)<oldddate1:    #len(d) == (d.buflen() - 40):
            #            self.sell(data=d, size=1)
        #
        #                self.sell(data=d, size=1)
        # if(self.inds[d]["totallen"][0] < [50]):
        # self.sell(data=d, size=1)

    '''
    def notify_trade(self, trade):
        dt = self.data.datetime.date()
        dp = trade.history[len(trade.history) - 1].status.price
        dir = trade.history[0].event.size
        dir = "SELL"
        if trade.history[0].event.size > 0:
            dir = "BUY"
        if trade.isopen:
            print("{} {} {} {} Price:".format(dt, trade.data._name, dir, dp))
            #post_telegram_message(
            #    "{} {} {} {} Price:".format(dt, trade.data._name, dir, dp)
            #)
            #time.sleep(1)
    '''
    """
    def next(self):
        if len(self.data) == (self.data.buflen()-1) and not self.position:
            if (
                #self.ADX[0] > 0
                d.close > 1000
                #and self.macdH[0] > 0
            ):
                self.buy()
            else:
                if(
                    #self.ADX[0] > 28
                    #and self.macdH[0] < 0
                    d.close < 1000
                    ):
                    self.sell()
                else:
                    if (
                        self.ADX[0] < 28
                        and self.RSI[0] > 80
                    ):
                        self.sell()
    """


"""
def printTradeAnalysis(
    analyzer,
):
    total_open = analyzer.total.open
    total_closed = analyzer.total.closed
    total_won = analyzer.won.total
    total_lost = analyzer.lost.total
    win_streak = analyzer.streak.won.longest
    lose_streak = analyzer.streak.lost.longest
    pnl_net = round(analyzer.pnl.net.total, 2)
    strike_rate = round((total_won / total_closed) * 100, 2)
    # Designate the rows
    h1 = ["Total Open", "Total Closed", "Total Won", "Total Lost"]
    h2 = ["Strike Rate", "Win Streak", "Losing Streak", "PnL Net"]
    r1 = [total_open, total_closed, total_won, total_lost]
    r2 = [strike_rate, win_streak, lose_streak, pnl_net]
    # Check which set of headers is the longest.
    if len(h1) > len(h2):
        header_length = len(h1)
    else:
        header_length = len(h2)
    # Print the rows
    print_list = [h1, r1, h2, r2]
    row_format = "{:<15}" * (header_length + 1)
    print("Trade Analysis Results:")
    for row in print_list:
        print(row_format.format("", *row))

len(d) == (d.buflen()-1) and

def printSQN(analyzer):
    sqn = round(analyzer.sqn, 2)
    print("SQN: {}".format(sqn))
"""


TICKER_CSV_DATA_FOLDER_PATH='/home/rizpython236/BT5/ticker-csv-files-mhtly'


def get_stock_symbols_from_csv(csv_file_path):
    symbols_df = pd.read_csv(csv_file_path)
    symbols_column_name = "Symbol"
    symbols_list = list(symbols_df[symbols_column_name].unique())
    return symbols_list


cerebro = bt.Cerebro()

startcash = 1000000000
#nifty = bt.feeds.YahooFinanceCSVData(dataname="/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv")
#cerebro.adddata(nifty, name="^NSEI")

#NSEBANK = bt.feeds.YahooFinanceCSVData(dataname="/home/rizpython236/BT5/ticker-csv-files/^^NSEBANK.csv")
#cerebro.adddata(NSEBANK, name="^NSEBANK")

#CRSLDX = bt.feeds.YahooFinanceCSVData(dataname="/home/rizpython236/BT5/ticker-csv-files/^CRSLDX.csv")
#cerebro.adddata(CRSLDX, name="^CRSLDX")

#NSEMDCP50 = bt.feeds.YahooFinanceCSVData(dataname="/home/rizpython236/BT5/ticker-csv-files/^NSEMDCP50.csv")
#cerebro.adddata(NSEMDCP50, name="^NSEMDCP50")

#CNXSC = bt.feeds.YahooFinanceCSVData(dataname="/home/rizpython236/BT5/ticker-csv-files/^CNXSC.csv")
#cerebro.adddata(CNXSC, name="^CNXSC")

# symbol_list = ["UTIAMC.NS","GLAND.NS"] #,"WIPRO.NS", "KEC.NS", "TATASTEEL.NS", "RCOM.NS",]#"ZOMATO.NS"]
symbol_list = get_stock_symbols_from_csv("/home/rizpython236/BT5/symbol_list.csv")
valid_tickers_list = get_stock_symbols_from_csv("/home/rizpython236/BT5/screener-outputs/valid_tickers_mhtly.csv")[
    :
]
# IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
# END_DATE = datetime.now(IST_TIMEZONE).replace(
#    hour=0, minute=0, second=0, microsecond=0
# ) - timedelta(days=0)
# TIME_DELTA_DAYS = 1*12*52*7
# START_DATE = END_DATE - timedelta(days=TIME_DELTA_DAYS)
# End1=END_DATE.replace(tzinfo=None)
# Start1=End1.replace(tzinfo=None)- timedelta(days=TIME_DELTA_DAYS)

# now1=datetime.today()
# present= datetime.today().strftime('%Y,%m,%d')
# past = present- 5 #timedelta(days=250)


"""
dataj = yf.download("^NSEI", start=START_DATE.replace(tzinfo=None), end=END_DATE.replace(tzinfo=None))
dataj.to_csv("./{}.csv".format("^NSEI"))
datapath = ('./^NSEI.csv')
dataframe = pd.read_csv(datapath,
                            skiprows=0,
                            header=0,
                            parse_dates=True,
                            index_col=0
                            )
datak = bt.feeds.PandasData(dataname=dataframe)
cerebro.adddata(datak, name="NIFTY")
"""

"""
data = bt.feeds.YahooFinanceData(
        dataname="WIPRO.NS",
        timeframe=bt.TimeFrame.Days,
        fromdate=START_DATE.replace(tzinfo=None),
        todate=END_DATE.replace(tzinfo=None),
        compression=1,
        buffered=True,
        adjclose=True,
        decimals=2,
        plot=True,
)
"""
TICKER_CSV_DATA_FOLDER_PATH='/home/rizpython236/BT5/ticker-csv-files-mhtly'
for symbol in symbol_list:

    if symbol not in valid_tickers_list:
        # skipping ticker because either ticker is invalid or data is incomplete
        continue

    symbol_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"

    # data = bt.feeds.YahooFinanceData(
    #     dataname=symbol,
    #     timeframe=bt.TimeFrame.Weeks,
    #     fromdate=date.today()
    #     - timedelta(
    #         weeks=51
    #     ),  # datetime(2020, 1, 1),           #START_DATE.replace(tzinfo=None),
    #     todate=date.today(),  #datetime(2021, 10, 27),# ,   #END_DATE.replace(tzinfo=None),
    #     compression=1,
    #     buffered=True,
    #     adjclose=True,
    #     decimals=2,
    #     plot=False,
    # )

    #data = bt.feeds.YahooFinanceCSVData(dataname=symbol_csv_file_path)
    data = GenericCSVDataR(dataname=symbol_csv_file_path)
    # cerebro.resampledata(
    #    data, name=symbol, timeframe=bt.TimeFrame.Weeks, compression=1
    # )  # ,compression =1,bar2edge=True, adjbartime=True,rightedge=True,boundoff=0)
    # if (data.buflen() - 1) < 49:
    #    continue
    # else:
    # print(type(data))
    #    print(data.buflen() - 1)
    # time.sleep(5)
    cerebro.adddata(data, name=symbol)  # cerebro.adddata(data)


"""
feed = bt.feeds.YahooFinanceData(
    dataname="^NSEI",
    timeframe=bt.TimeFrame.Days,
    fromdate=START_DATE.replace(tzinfo=None),
    todate=END_DATE.replace(tzinfo=None),
    compression=1,
    buffered=True,
    adjclose=True,
    decimals=2,
    plot=False,
)
"""


"""
data3 = bt.feeds.YahooFinanceData(
    dataname= "VINATIORGA.NS",
    timeframe=bt.TimeFrame.Months,
    fromdate=datetime(2012, 1, 1),
    todate=datetime(2021, 8, 15),
    compression =1,
    buffered=True,
    calendar='BSE',
    adjclose =True,
    decimals =2,
    plot=True,
)
"""
"""
data = bt.feeds.Quandl(
    dataname='TSLA',
    timeframe=bt.TimeFrame.Days,
    apikey='QBb7Ym7AFLYZ3CkamXys',
    fromdate = datetime(2010,1,6),
    todate = datetime(2021,2,15),
    buffered= True
    )

"""

cerebro.addstrategy(firstStrategy, oneplot=True)

# cerebro = bt.Cerebro()
# cerebro.adddata(data)
# cerebro.adddata(feed)
cerebro.broker.setcash(startcash)
cerebro.addsizer(bt.sizers.FixedSize)
"""
cerebro.broker.setcommission(
    commission=0.000, margin=False
)
"""
cerebro.broker.set_shortcash(True)


# cerebro.addwriter(bt.WriterFile, csv=True, rounding=1)

# cerebro.addobserver(bt.observers.FundValue)
cerebro.addanalyzer(trade_list, _name="trade_list")
# cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name="ta")
# cerebro.addanalyzer(bt.analyzers.Transactions)
# cerebro.addanalyzer(BarAnalysis, _name="bar_data")

results = cerebro.run(tradehistory=True)
# try:
firstStrat = results[0]
# except IndexError:
#    pass
# continue

for strat in results:
    print("=" * 79)
    print(strat.__class__.__name__)

trade_list = results[0].analyzers.trade_list.get_analysis()
print(tabulate(trade_list, headers="keys"))

"""
LimitedTestReport = results[0].analyzers.LimitedTestReport.get_analysis()
print (tabulate(LimitedTestReport, headers="keys"))
"""
portvalue = cerebro.broker.getvalue()
pnl = round(portvalue - startcash, 1)

print("Final Portfolio Value: %.2f" % cerebro.broker.getvalue())
print(
    "Final value is %.2f times the initial investment"
    % (cerebro.broker.getvalue() / startcash)
)
print("P/L: ${}".format(pnl))


# trade_list = results[0].analyzers.getbyname("trade_list").get_analysis()
df = pd.DataFrame(trade_list)

SCREENER_OUTPUT_FILENAME = "trade_list_BT_mhtly_Screener.csv"
BT_SCREENER_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + SCREENER_OUTPUT_FILENAME
df.to_csv(BT_SCREENER_FILE_PATH, index=False)
# print("ALL OVER")
# https://backtest-rookies.com/2017/08/22/backtrader-multiple-data-feeds-indicators/

# cerebro.plot(iplot=False, numfigs=1, volume=False)
