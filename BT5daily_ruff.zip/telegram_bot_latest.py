

###################################
#refactored and optimized version

# pip install python-telegram-bot==13.15
import asyncio
import atexit
from datetime import date
import os
import sys

import pandas as pd


#sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.13/site-packages/")
#import sys
sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
import asyncio
import json

#from telegram.ext import Application, JobQueue
#from apscheduler.schedulers.asyncio import AsyncIOScheduler
import time

from aiohttp import ClientSession, TCPConnector
from PDFconvert import create_pdf
import pytz
from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
)
from telegram import Bot, InputFile

#from telegram.error import TelegramError
from telegram.error import RetryAfter, TelegramError, TimedOut


INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
invalid_tickers_df = pd.read_csv(INVALID_TICKERS_FILE_PATH)
invalid_tickers = list(invalid_tickers_df["invalid_ticker"].unique())

INCOMPLETE_TICKERS_FILE_PATH = (
    SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV
)
incomplete_tickers_df = pd.read_csv(INCOMPLETE_TICKERS_FILE_PATH)
incomplete_tickers = list(incomplete_tickers_df["Symbol"].unique())


# Configuration
TOKEN = "6108615209:AAF8ZiMMxbrT1D46enyrO0rSlChCuo9d4ro"
CHAT_IDS = [-1001757309399] # List of chat IDs
SUPPORTED_IMAGES = ('.png', '.jpg', '.jpeg', '.webp')
TIMEZONE = pytz.timezone('UTC')

'''
import os
import asyncio
from telegram import Bot, InputFile
from telegram.error import TelegramError, RetryAfter, TimedOut
import csv

# =======================
# Internal bot instance
# =======================
_bot_instance = None
LOG_FILE = SCREENER_OUTPUT_FOLDER_PATH + "/" + "telegram_log.csv"  # persistent log file

async def _get_bot_instance_safe():
    """Initialize or return the existing Bot instance."""
    global _bot_instance
    #if _bot_instance is None:
    if _bot_instance is None or getattr(_bot_instance, 'loop', None) and _bot_instance.loop.is_closed():
        try:
            _bot_instance = Bot(token=TOKEN)
            await _bot_instance.initialize()
        except TelegramError as e:
            print(f"❌ Bot initialization failed: {e}")
            raise
    return _bot_instance

# =======================
# Async-safe runner
# =======================

def _run_async(coro):
    """
    Run coroutine safely whether an event loop is running or not.
    If the loop is already running, wait until the coroutine completes.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running() and not loop.is_closed():
        # Loop is already running; schedule and wait for result
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result()  # This blocks until coro finishes
    else:
        # No loop running; safe to start a new one
        return asyncio.run(coro)

# =======================
# Logging helper
# =======================
def _log_telegram_event(event_type, content, chat_id, status):
    """Log Telegram events to a CSV file."""
    headers = ["timestamp", "event_type", "content", "chat_id", "status"]
    from datetime import datetime
    row = [datetime.now().isoformat(), event_type, content, chat_id, status]

    file_exists = os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(headers)
        writer.writerow(row)

# =======================
# Retry helper
# =======================
async def _retry_async(func, *args, retries=3, delay=5, **kwargs):
    """Retry an async function on TelegramError, with exponential backoff."""
    attempt = 0
    while attempt <= retries:
        try:
            return await func(*args, **kwargs)
        except (TelegramError, TimedOut, RetryAfter) as e:
            attempt += 1
            if attempt > retries:
                print(f"❌ Maximum retries reached. Last error: {e}")
                raise
            sleep_time = delay * (2 ** (attempt - 1))
            print(f"⚠️ Attempt {attempt} failed: {e}. Retrying in {sleep_time}s...")
            await asyncio.sleep(sleep_time)

# =======================
# Async message/file senders
# =======================
async def send_telegram_message(
    message: str,
    retries: int = 3,
    delay: int = 2
) -> None:
    print("📤 Triggering Telegram Alerts!")
    try:
        bot = await _get_bot_instance_safe()
        for chat_id in CHAT_IDS:
            try:
                await _retry_async(bot.send_message, chat_id=chat_id, text=message,
                                   retries=retries, delay=delay)
                print(f"✅ Message sent to chat {chat_id}")
                _log_telegram_event("message", message, chat_id, "success")
            except Exception as e:
                print(f"❌ Failed to send to chat {chat_id}: {e}")
                _log_telegram_event("message", message, chat_id, "failure")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("Message NOT posted to Telegram")

async def send_telegram_file(
    file_path: str,
    retries: int = 3,
    delay: int = 2
) -> None:
    print(f"📎 Triggering Telegram attachment for {file_path}!")
    if not os.path.exists(file_path):
        print(f"❌ File not found: {file_path}")
        _log_telegram_event("file", file_path, chat_id, "failure")
        return

    try:
        bot = await _get_bot_instance_safe()
        file_extension = os.path.splitext(file_path)[1].lower()

        with open(file_path, 'rb') as file:
            input_file = InputFile(file)
            for chat_id in CHAT_IDS:
                try:
                    if False:  # file_extension in SUPPORTED_IMAGES:
                        await _retry_async(bot.send_photo, chat_id=chat_id, photo=input_file,
                                           retries=retries, delay=delay)
                    else:
                        await _retry_async(bot.send_document, chat_id=chat_id,
                                           document=input_file,
                                           filename=os.path.basename(file_path),
                                           retries=retries, delay=delay)
                    print(f"✅ File sent to chat {chat_id}")
                    _log_telegram_event("file", file_path, chat_id, "success")
                except Exception as e:
                    print(f"❌ Failed to send to chat {chat_id}: {e}")
                    _log_telegram_event("file", file_path, chat_id, "failure")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("File NOT posted to Telegram")
        for chat_id in CHAT_IDS:
            _log_telegram_event("file", file_path, chat_id, "failure")

# =======================
# Synchronous wrappers
# =======================
def post_telegram_message(message: str, retries: int = 3, delay: int = 5) -> None:
    _run_async(send_telegram_message(message, retries=retries, delay=delay))

def post_telegram_file(file_path: str, retries: int = 3, delay: int = 15) -> None:
    _run_async(send_telegram_file(file_path, retries=retries, delay=delay))

# =======================
# Safe shutdown
# =======================

async def _shutdown_bot_async():
    """Internal async shutdown."""
    global _bot_instance
    if _bot_instance:
        try:
            await _bot_instance.shutdown()
        except Exception as e:
            print(f"⚠️ Bot shutdown error: {e}")
        finally:
            _bot_instance = None



def shutdown_bot():
    """Shutdown bot in the same loop it was created in."""
    global _bot_instance
    if not _bot_instance:
        return

    try:
        loop = _bot_instance.loop  # the loop it belongs to
    except AttributeError:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

    if loop and loop.is_running() and not loop.is_closed():
        fut = asyncio.run_coroutine_threadsafe(_shutdown_bot_async(), loop)
        fut.result()
    else:
        asyncio.run(_shutdown_bot_async())
'''
import asyncio
import csv
from datetime import datetime
import os
import time

import numpy as np
import pandas as pd
from telegram import Bot, InputFile
from telegram.error import RetryAfter, TelegramError, TimedOut


# =======================
# Internal bot instance
# =======================
_bot_instance = None
LOG_FILE = SCREENER_OUTPUT_FOLDER_PATH + "/" + "telegram_log.csv"  # persistent log file


# =======================
# Bot instance helper
# =======================
async def _get_bot_instance_safe():
    """Initialize or return the existing Bot instance safely."""
    global _bot_instance
    if (
        _bot_instance is None
        or getattr(_bot_instance, "loop", None) and _bot_instance.loop.is_closed()
    ):
        try:
            # Create a reusable aiohttp session with pooling
            session = ClientSession(
                connector=TCPConnector(limit=30, keepalive_timeout=3.5*60*60)
            )
            _bot_instance = Bot(token=TOKEN,session=session)
            await _bot_instance.initialize()
        except TelegramError as e:
            print(f"❌ Bot initialization failed: {e}")
            raise
    return _bot_instance



# =======================
# Deduplication state
# =======================
_last_sent = {"message": ("", 0), "file": ("", 0)}
DEDUP_WINDOW = 10  # seconds


def _is_duplicate(kind: str, content: str) -> bool:
    """Check if this content was already sent recently."""
    last_content, last_time = _last_sent[kind]
    now = time.time()
    if last_content == content and (now - last_time) < DEDUP_WINDOW:
        return True
    _last_sent[kind] = (content, now)
    return False

# =======================
# Async-safe runner
# =======================
def _run_async_old(coro):
    """
    Run coroutine safely whether an event loop is running or not.
    - If in an active loop, schedule as a task (non-blocking).
    - If no loop, create a temporary loop with asyncio.run.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and not loop.is_closed():
        if loop.is_running():
            # Already inside a loop → schedule and return task
            return asyncio.create_task(coro)
        else:
            return loop.run_until_complete(coro)
    else:
        return asyncio.run(coro)

def _run_async(coro):
    """
    Run coroutine safely in both sync and async contexts.
    Always blocks until the coroutine is finished.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and not loop.is_closed():
        # Already in a running loop: run blocking via thread-safe future
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result()
    else:
        # No loop running, safe to start a fresh one
        return asyncio.run(coro)



# =======================
# Logging helper
# =======================
def _log_telegram_event(event_type, content, chat_id, status):
    """Log Telegram events to a CSV file."""
    headers = ["timestamp", "event_type", "content", "chat_id", "status"]
    row = [datetime.now().isoformat(), event_type, content, chat_id, status]

    file_exists = os.path.exists(LOG_FILE)
    with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(headers)
        writer.writerow(row)


# =======================
# Retry helper
# =======================
async def _retry_async(func, *args, retries=3, delay=5, **kwargs):
    """Retry an async function on TelegramError, CancelledError, etc."""
    attempt = 0
    while attempt <= retries:
        try:
            return await func(*args, **kwargs)
        except asyncio.CancelledError:
            print("⚠️ Task was cancelled")
            raise
        except (TelegramError, TimedOut, RetryAfter) as e:
            attempt += 1
            if attempt > retries:
                print(f"❌ Maximum retries reached. Last error: {e}")
                raise
            sleep_time = delay * (2 ** (attempt - 1))
            print(f"⚠️ Attempt {attempt} failed: {e}. Retrying in {sleep_time}s...")
            await asyncio.sleep(sleep_time)


# =======================
# Async message/file senders
# =======================
async def send_telegram_message(
    message: str,
    retries: int = 3,
    delay: int = 2,
) -> None:
    print("📤 Triggering Telegram Alerts!")
    try:
        bot = await _get_bot_instance_safe()
        for chat_id in CHAT_IDS:
            try:
                await _retry_async(
                    bot.send_message,
                    chat_id=chat_id,
                    text=message,
                    retries=retries,
                    delay=delay,
                )
                print(f"✅ Message sent to chat {chat_id}")
                _log_telegram_event("message", message, chat_id, "success")
            except asyncio.CancelledError:
                print(f"⚠️ Message task cancelled for chat {chat_id}")
                #raise
            except Exception as e:
                print(f"❌ Failed to send to chat {chat_id}: {e}")
                _log_telegram_event("message", message, chat_id, "failure")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("Message NOT posted to Telegram")


async def send_telegram_file(
    file_path: str,
    retries: int = 3,
    delay: int = 2,
) -> None:
    print(f"📎 Triggering Telegram attachment for {file_path}!")
    if not os.path.exists(file_path):
        print(f"❌ File not found: {file_path}")
        for chat_id in CHAT_IDS:
            _log_telegram_event("file", file_path, chat_id, "failure")
        return

    try:
        bot = await _get_bot_instance_safe()
        file_extension = os.path.splitext(file_path)[1].lower()

        with open(file_path, "rb") as file:
            input_file = InputFile(file)
            for chat_id in CHAT_IDS:
                try:
                    if False:  # placeholder for SUPPORTED_IMAGES
                        await _retry_async(
                            bot.send_photo,
                            chat_id=chat_id,
                            photo=input_file,
                            retries=retries,
                            delay=delay,
                        )
                    else:
                        await _retry_async(
                            bot.send_document,
                            chat_id=chat_id,
                            document=input_file,
                            filename=os.path.basename(file_path),
                            retries=retries,
                            delay=delay,
                        )
                    print(f"✅ File sent to chat {chat_id}")
                    _log_telegram_event("file", file_path, chat_id, "success")
                except asyncio.CancelledError:
                    print(f"⚠️ File send task cancelled for chat {chat_id}")
                    #raise
                except Exception as e:
                    print(f"❌ Failed to send to chat {chat_id}: {e}")
                    _log_telegram_event("file", file_path, chat_id, "failure")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("File NOT posted to Telegram")
        for chat_id in CHAT_IDS:
            _log_telegram_event("file", file_path, chat_id, "failure")


# =======================
# Synchronous wrappers
# =======================
def oldpost_telegram_message(message: str, retries: int = 3, delay: int = 5) -> None:
    _run_async(send_telegram_message(message, retries=retries, delay=delay))


def oldpost_telegram_file(file_path: str, retries: int = 3, delay: int = 15) -> None:
    _run_async(send_telegram_file(file_path, retries=retries, delay=delay))


def post_telegram_message(message: str, retries: int = 3, delay: int = 8) -> None:
    """Send message and block until it is sent (no duplicates within dedup window)."""
    if message == ("" or np.nan or pd.isna(message)):
        return
    if _is_duplicate("message", message):
        print(f"⚠️ Duplicate message skipped within {DEDUP_WINDOW}s: {message}")
        return
    return _run_async(send_telegram_message(message, retries=retries, delay=delay))


def post_telegram_file(file_path: str, retries: int = 3, delay: int = 15) -> None:
    """Send file and block until it is sent (no duplicates within dedup window)."""
    if _is_duplicate("file", file_path):
        print(f"⚠️ Duplicate file skipped within {DEDUP_WINDOW}s: {file_path}")
        return
    return _run_async(send_telegram_file(file_path, retries=retries, delay=delay))


# =======================
# Safe shutdown
# =======================
async def _shutdown_bot_async():
    """Internal async shutdown."""
    global _bot_instance
    if _bot_instance:
        try:
            await _bot_instance.shutdown()
        except asyncio.CancelledError:
            print("⚠️ Bot shutdown task was cancelled")
            #raise
        except Exception as e:
            print(f"⚠️ Bot shutdown error: {e}")
        finally:
            _bot_instance = None


def shutdown_bot():
    """Shutdown bot in the same loop it was created in."""
    global _bot_instance
    if not _bot_instance:
        return

    loop = getattr(_bot_instance, "loop", None)
    if not loop or loop.is_closed():
        return

    if loop.is_running():
        fut = asyncio.run_coroutine_threadsafe(_shutdown_bot_async(), loop)
        try:
            fut.result()
        except asyncio.CancelledError:
            print("⚠️ Shutdown was cancelled")
    else:
        asyncio.run(_shutdown_bot_async())
        print("⚠️ Shutdown was Succesfull")



def trigger_telegram_notifications():
    #post_telegram_message("Hey! Telegram alerts for {}".format(str(date.today())))

    if invalid_tickers:
        #post_telegram_message("Invalid Tickers Found - {}".format(invalid_tickers))
        #post_telegram_file('/home/rizpython236/BT5/screener-outputs/invalid_tickers.csv')
        1+1

    if incomplete_tickers:
        #post_telegram_message(
        #    "Incomplete Data Tickers Found - {}".format(incomplete_tickers)
        #)
        #post_telegram_file('/home/rizpython236/BT5/screener-outputs/incomplete_data_tickers.csv')
        1+1
    #SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
    #if monthly=="YES":
    #SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
    #else:
    #    1+1

    csv_to_send = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
    trade_list = pd.read_csv(csv_to_send)
    try:
        trade_list.drop(["talib_date", "talib_price", "talib_signal", "trade_id","trade_logged_on","status"], axis=1, inplace=True)
    except:
        1+1
    trade_list = trade_list.to_dict('records')
    chunk_size = 5
    chunked_trade_list = [trade_list[i:i + chunk_size] for i in range(0, len(trade_list), chunk_size)]

    print("Sending Ticker Alert Messages and CSV now ...")
    for trade_packet in chunked_trade_list:
        time.sleep(1)
        #post_telegram_message(json.dumps(trade_packet, sort_keys=True, indent=4))

    input_csv_file = '/home/rizpython236/BT5/trade-logs/screener-output.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/screener-output.pdf'  # Replace with desired output PDF file
    input_csv_file1 = '/home/rizpython236/BT5/screener-outputs/screener-output1.csv'

    new_df = pd.read_csv(input_csv_file)
    try:
        notmatching1=new_df.drop(['trade_logged_on','trade_id','status','talib_date','talib_signal','talib_price'], axis=1, inplace=True)
    except:
        1+1
    new_df.to_csv(input_csv_file1, index=False)
    #print(new_df)
    create_pdf(input_csv_file1, output_pdf_file)
    time.sleep(2)
    post_telegram_file(output_pdf_file)
    #except:
    #    1+1

    time.sleep(2)
    #create_pdf(input_csv_file, output_pdf_file)

    #post_telegram_file(output_pdf_file)
    #post_telegram_message("That was all for today!")


'''
for _ in range(1):
#    1+1
    post_telegram_message("That was all for today!")
    post_telegram_file('/home/rizpython236/BT5/pybrokerBT.py')

atexit.register(shutdown_bot)
#shutdown_bot()

'''






'''
async def _get_bot_instance():
    """Initialize and return a properly configured Bot instance.

    Returns:
        Bot: Initialized Telegram Bot instance.

    Raises:
        TelegramError: If bot initialization fails.
    """
    try:
        bot = Bot(token=TOKEN)
        await bot.initialize()  # Explicit initialization
        return bot
    except TelegramError as e:
        print(f"❌ Bot initialization failed: {e}")
        raise  # Re-raise to handle in calling function

async def send_telegram_message(message: str) -> None:
    """Send a text message to all specified Telegram chats."""
    print("📤 Triggering Telegram Alerts!")
    try:
        bot = await _get_bot_instance()
        await asyncio.sleep(2)
        for chat_id in CHAT_IDS:
            try:
                await bot.send_message(
                    chat_id=chat_id,
                    text=message
                )
                print(f"✅ Message sent to chat {chat_id}")
            except TelegramError as e:
                print(f"❌ Failed to send to chat {chat_id}: {e}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("Message NOT posted to Telegram")
    finally:
        await asyncio.sleep(2)
        if 'bot' in locals():
            #await bot.session.close()
            await bot.shutdown()
            #await bot.close()

async def send_telegram_file(file_path: str) -> None:
    """Send a file (document or photo) to all specified Telegram chats."""
    print(f"📎 Triggering Telegram attachment for {file_path}!")
    try:
        bot = await _get_bot_instance()
        file_extension = os.path.splitext(file_path)[1].lower()

        with open(file_path, 'rb') as file:
            input_file = InputFile(file)
            await asyncio.sleep(2)
            for chat_id in CHAT_IDS:
                try:
                    if False:#file_extension in SUPPORTED_IMAGES:
                        await bot.send_photo(
                            chat_id=chat_id,
                            photo=input_file
                        )
                    else:
                        await bot.send_document(
                            chat_id=chat_id,
                            document=input_file,
                            filename=os.path.basename(file_path)
                        )
                    print(f"✅ File sent to chat {chat_id}")
                except TelegramError as e:
                    print(f"❌ Failed to send to chat {chat_id}: {e}")
    except FileNotFoundError:
        print(f"❌ File not found: {file_path}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        print("File NOT posted to Telegram")
    finally:
        await asyncio.sleep(2)
        if 'bot' in locals():
            #await bot.session.close()
            await bot.shutdown()
            #await bot.close()



# Synchronous wrappers for easier use in non-async contexts
def post_telegram_message(message: str) -> None:
    """Synchronous wrapper for send_telegram_message"""
    asyncio.run(send_telegram_message(message))

def post_telegram_file(file_path: str) -> None:
    """Synchronous wrapper for send_telegram_file"""
    asyncio.run(send_telegram_file(file_path))


def trigger_telegram_notifications():
    #post_telegram_message("Hey! Telegram alerts for {}".format(str(date.today())))

    if invalid_tickers:
        #post_telegram_message("Invalid Tickers Found - {}".format(invalid_tickers))
        #post_telegram_file('/home/rizpython236/BT5/screener-outputs/invalid_tickers.csv')
        1+1

    if incomplete_tickers:
        #post_telegram_message(
        #    "Incomplete Data Tickers Found - {}".format(incomplete_tickers)
        #)
        #post_telegram_file('/home/rizpython236/BT5/screener-outputs/incomplete_data_tickers.csv')
        1+1
    #SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
    #if monthly=="YES":
    #SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
    #else:
    #    1+1

    csv_to_send = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
    trade_list = pd.read_csv(csv_to_send)
    try:
        trade_list.drop(["talib_date", "talib_price", "talib_signal", "trade_id","trade_logged_on","status"], axis=1, inplace=True)
    except:
        1+1
    trade_list = trade_list.to_dict('records')
    chunk_size = 5
    chunked_trade_list = [trade_list[i:i + chunk_size] for i in range(0, len(trade_list), chunk_size)]

    print("Sending Ticker Alert Messages and CSV now ...")
    for trade_packet in chunked_trade_list:
        time.sleep(1)
        #post_telegram_message(json.dumps(trade_packet, sort_keys=True, indent=4))

    input_csv_file = '/home/rizpython236/BT5/trade-logs/screener-output.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/screener-output.pdf'  # Replace with desired output PDF file
    input_csv_file1 = '/home/rizpython236/BT5/screener-outputs/screener-output1.csv'

    new_df = pd.read_csv(input_csv_file)
    try:
        notmatching1=new_df.drop(['trade_logged_on','trade_id','status','talib_date','talib_signal','talib_price'], axis=1, inplace=True)
    except:
        1+1
    new_df.to_csv(input_csv_file1, index=False)
    #print(new_df)
    create_pdf(input_csv_file1, output_pdf_file)
    time.sleep(2)
    post_telegram_file(output_pdf_file)
    #except:
    #    1+1

    time.sleep(2)
    #create_pdf(input_csv_file, output_pdf_file)

    #post_telegram_file(output_pdf_file)
    #post_telegram_message("That was all for today!")


#post_telegram_message("That was all for today!")


'''



'''
import os
import asyncio
from telegram import Bot, InputFile
from telegram.error import TelegramError
from telegram.ext import Application

# Configuration
TOKEN = "6108615209:AAF8ZiMMxbrT1D46enyrO0rSlChCuo9d4ro"
CHAT_IDS = [-1001757309399]  # List of chat IDs

async def send_telegram_message(message: str) -> None:
    """
    Send a text message to all specified Telegram chats

    Args:
        message: Text message to send
    """
    application = Application.builder().token(TOKEN).build()

    print("Triggering Telegram Alerts!")
    try:
        for chat_id in CHAT_IDS:
            try:
                await application.bot.send_message(
                    chat_id=chat_id,
                    text=message
                )
                print(f"Message sent to chat {chat_id}")
            except TelegramError as e:
                print(f"Failed to send to chat {chat_id}: {e}")
                continue

    except Exception as e:
        print(f"Unexpected error: {e}")
        print("NOT posted to Telegram-----###########*******$$$$$$$$$@@@@@@@@@@@@%%%%%%%%%%%%")
    finally:
        await application.shutdown()

async def send_telegram_file(file_path: str) -> None:
    """
    Send a file (document or photo) to all specified Telegram chats

    Args:
        file_path: Path to the file to send
    """
    application = Application.builder().token(TOKEN).build()
    file_extension = os.path.splitext(file_path)[1].lower()
    supported_images = ('.png', '.jpg', '.jpeg', '.webp')

    print(f"Triggering Telegram attachment for {file_path}!")

    try:
        with open(file_path, 'rb') as file:
            input_file = InputFile(file)

            for chat_id in CHAT_IDS:
                try:
                    if file_extension in supported_images:
                        await application.bot.send_photo(
                            chat_id=chat_id,
                            photo=input_file
                        )
                    else:
                        await application.bot.send_document(
                            chat_id=chat_id,
                            document=input_file,
                            filename=os.path.basename(file_path))
                    print(f"File sent to chat {chat_id}")

                except TelegramError as e:
                    print(f"Failed to send to chat {chat_id}: {e}")
                    continue

    except FileNotFoundError:
        print(f"File not found: {file_path}")
    except Exception as e:
        print(f"Unexpected error: {e}")
        print("NOT posted to Telegram-----###########*******$$$$$$$$$@@@@@@@@@@@@%%%%%%%%%%%%")
    finally:
        await application.shutdown()

# Synchronous wrappers for easier use in non-async contexts
def post_telegram_message(message: str) -> None:
    """Synchronous wrapper for post_telegram_message"""
    asyncio.run(send_telegram_message(message))

def post_telegram_file(file_path: str) -> None:
    """Synchronous wrapper for post_telegram_file"""
    asyncio.run(send_telegram_file(file_path))


#    def post_telegram_file(file_path)   send_telegram_file
#    def post_telegram_message(message)   send_telegram_message
######################
from your_module_name import post_telegram_message, post_telegram_file

# Example usage in another script
post_telegram_message("This is an alert from another script!")
post_telegram_file("/path/to/your/file.pdf")
##################
#Or if you're working in an async context:
from your_module_name import post_telegram_message, post_telegram_file

async def main():
    await post_telegram_message("Async message")
    await post_telegram_file("async_file.png")

asyncio.run(main())


'''