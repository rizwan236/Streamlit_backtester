import datetime
import email
import imaplib

import telegram


def send_email_to_telegram(email_subject, email_body, bot_token, channel_name):
    # Define the Telegram Bot token and create a bot instance
    bot = telegram.Bot(token=bot_token)

    # Send the email subject and body to the specified Telegram channel
    bot.send_message(chat_id=channel_name,
                     text=email_subject + "\n\n" + email_body)


# Connect to the Gmail account and select the inbox
mail = imaplib.IMAP4_SSL("imap.gmail.com")
mail.login("<moneyzs786@gmail.com>", "<your_email_password>")
mail.select("Screener")  # ("inbox")

# Get the current date and calculate yesterday's date
today = datetime.datetime.now().date()
yesterday = (today - datetime.timedelta(days=1)).strftime("%d-%b-%Y")

# Search for all unread emails with the subject "Screener" received yesterday
status, emails = mail.search(
    None, f'(UNSEEN SUBJECT "Screener" SINCE "{yesterday}")')
emails = emails[0].split()

# For each email with the subject "Screener", extract its subject and body
for email_id in emails:
    status, email_data = mail.fetch(email_id, "(RFC822)")
    email_body = email.message_from_bytes(email_data[0][1])

    email_subject = email_body["subject"]
    email_body = email_body.get_payload()

    # Forward the email to the Telegram channel
    send_email_to_telegram(email_subject, email_body, "<6094020677:AAGNGbEEMwQKji5ORCjduf9FzPl8FXWo9bU>",
                           "<-1001863996731>")  # "<your_bot_token>", "@<your_channel_name>")

# Close the connection to the Gmail account
mail.close()
mail.logout()
