import os
import sys
import time

import pytz


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
import pandas as pd


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
import logging

from telegram_bot import post_telegram_message
import yfinance as yf


logger = logging.getLogger('yfinance')
logger.setLevel(logging.ERROR)  # default: only print errors
#logger.setLevel(logging.CRITICAL)  # disable printing
#logger.setLevel(logging.DEBUG)  # verbose: print errors & debug info

from datetime import date, datetime, timedelta

from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    NIFTY_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    SYMBOLS_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    VALID_TICKERS_CSV,
)


print("Initiating Data Downloader!")
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

#today = datetime.now(IST_TIMEZONE).date()
#yesterday = today - timedelta(days=1)
#end_date = yesterday


end_date = datetime.now(IST_TIMEZONE).date()
#end_date = date.today()
# start_date = end_date - timedelta(days=365)
start_date = end_date - timedelta(weeks=75) #75 weekly
END_DATE = str(end_date)
START_DATE = str(start_date)
#print(START_DATE)
#post_telegram_message(START_DATE)
print(f"start date {START_DATE} ,end date {END_DATE}.")
time.sleep(1)
#post_telegram_message(END_DATE)
post_telegram_message(f"The start date is {START_DATE} and the end date is {END_DATE}.")


# ticker_symbols_file = "symbol.csv"
tickers_df = pd.read_csv(SYMBOLS_CSV)
tickers_list = list(tickers_df["Symbol"].unique())[3830:]
#tickers_list= ["^NSEI","^NSEBANK"]

# # Downloading data
print("-" * 100)
print("Starting download for data from {} to {}.".format(start_date, end_date))
print("-" * 100)

invalid_tickers = []

print("Total number of symbols: ", len(tickers_list))
count=0
total_symbols = len(tickers_list)
for symbol in tickers_list:

    count +=1
    #print(count)
    print("Total number of processed symbols: ", count, "({:.2f}%)".format(count / total_symbols * 100))
    remaining_symbols = total_symbols - count
    print("Total number of remaining symbols: ", remaining_symbols, "({:.2f}%)".format(remaining_symbols / total_symbols * 100))
    # detecting invalid tickers

    ticker = yf.Ticker(symbol) #line77

    #ticker = yf.Ticker(symbol).info  #line80
    ticker_info = None
    try:
        #ticker_info = ticker.info
        #reg_mp =ticker_info.get("regularMarketPrice")
        #reg_mp=ticker

        history = ticker.history(period='1d')
        last_price = history['Close'].iloc[-1]
        #marketCap =ticker.info['marketCap']
        reg_mp=last_price>30 #and marketCap > 500000000

        #reg_mp=last_price = ticker['regularMarketPrice']

        #reg_mp=ticker_info = ticker.fast_info.get('last_price')#ticker.info
        #reg_mp =ticker_info.get("regularMarketPrice")


        #print(reg_mp)
        if not reg_mp:
            invalid_tickers.append(symbol)
            continue
    except:# yf.exceptions.TickerSymbolError: #
        invalid_tickers.append(symbol)
        print("Invalid ticker - {}".format(symbol))
        continue

    print("Downloading data for => {}".format(symbol))
    data = yf.download(
        symbol,
        start=START_DATE,
        end=END_DATE,
        interval="1d", #1wk 1d
        rounding=True,
        threads=True,
        repair=False,
        keepna=False,
        multi_level_index=False,
        actions=False
        #ignore_tz=True
    )
    ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
    data.to_csv(ticker_csv_file_path)
    time.sleep(0.20)



print("Data download task completed.")
print("Validating data and removing incomplete ticker-data files.")


def get_filepaths(directory):
    """
    This function lists all the file names present in directory.
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)  # Add it to the list.

    return file_paths


def check_data_continuity(df, interval=1):
    """
    input - df with datetime index and interval to check gaps for
    output - this func will return False if there are gaps present
    otherwise return True
    """
    deltas = df['Date'].diff()[1:]
    datetime_gaps = deltas[deltas > timedelta(days=interval)]
    return datetime_gaps.empty

def check_num_rows(df1, df2):
    return df1.shape[0] == df2.shape[0]



files_to_process = get_filepaths(TICKER_CSV_DATA_FOLDER_PATH)
nifty_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + NIFTY_CSV
nifty_df = pd.read_csv(nifty_file_path)
nifty_df.dropna(inplace=True)
nifty_rows = len(nifty_df)
# print(nifty_rows)

nifty_start_date, nifty_end_date = nifty_df["Date"][0], nifty_df["Date"][nifty_rows - 1]

if len(nifty_start_date) == 10:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date,"%Y-%m-%d").date()
elif len(nifty_start_date) == 25:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d %H:%M:%S%z").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d %H:%M:%S%z").date()
else:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()


#nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
#nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()

#nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d %H:%M:%S%z").date()
#nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d %H:%M:%S%z").date()

incomplete_data_tickers = []
valid_tickers = []


for file in files_to_process:
    """folder\\BHARTIAIRTEL.NS.csv"""
    ticker_name = file.split("/")[-1:][0]     #file.split("\\")[1]
    ticker_name = ticker_name.split(".csv")[0]

    print("Validating {} file".format(ticker_name))
    ticker_df = pd.read_csv(file)
    # print(len(ticker_df))

    # Drops rows where OHLC = 0 or value = NA
    ticker_df.dropna(inplace=True)
    ticker_df = ticker_df[ticker_df.Open != 0]
    ticker_df = ticker_df[ticker_df.High != 0]
    ticker_df = ticker_df[ticker_df.Low != 0]
    ticker_df = ticker_df[ticker_df.Close != 0]
    ticker_df = ticker_df[ticker_df.Volume != 0] #
    ticker_df = ticker_df[ticker_df.Close != ticker_df.Open] #

    ticker_df.reset_index(drop=True, inplace=True)
    # print(len(ticker_df))
    ticker_df["Date"] = pd.to_datetime(ticker_df["Date"]).dt.date

    ## Delete rows earlier than nifty start-date
    # ticker_df = ticker_df[ticker_df["Date"] >= nifty_start_date_obj]
    ## Delete rows if any present after nifty end date
    ticker_df = ticker_df[ticker_df["Date"] <= nifty_end_date_obj]


    # CHECK IF DATA IS CONTINUOUS - PROPER WEEKLY GAPS
    is_data_rows_equals_nifty = check_num_rows(ticker_df,nifty_df)  #for daily
    is_data_continuous = check_data_continuity(ticker_df)   #weekly

    if not check_data_continuity:  #is_data_rows_equals_nifty use for daily data
        print("Weekly gaps found in {}".format(ticker_name))
    else:
        #print("Data is consistent in weekly TF for {}".format(ticker_name))
        1+1

    # DECIDE - HOW TO FILTER

    # Only check if the total rows are atleast 52 and data cont in weekly TF
    if check_data_continuity:# and len(ticker_df) >= 52: #is_data_rows_equals_nifty

        # Check if either rows are atleast 52 or atleast >= nifty-rows
        # if len(ticker_df) >= 52 or len(ticker_df) >= nifty_rows:

        valid_tickers.append(ticker_name)
        ticker_df.to_csv(file, index=False)
    else:
        incomplete_data_tickers.append(ticker_name)
        # deleting the incomplete ticker data file
        print(
            "Incomplete Data Ticker => {} with total rows => {}".format(
                ticker_name, len(file)
            )
        )
        if os.path.exists(file):
            os.remove(file)




invalid_tickers_df = pd.DataFrame()
invalid_tickers_df["invalid_ticker"] = invalid_tickers
INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
#invalid_tickers_df.to_csv(INVALID_TICKERS_FILE_PATH, index=False)

valid_tickers_df = pd.DataFrame()
valid_tickers_df["Symbol"] = valid_tickers
from telegram_bot import post_telegram_message


print("Total number of valid symbols: {}".format(len(valid_tickers)))
post_telegram_message("Total number of valid symbols: {}".format(len(valid_tickers)))
vt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + VALID_TICKERS_CSV
valid_tickers_df.to_csv(vt_file_path, index=False)

incomplete_data_tickers_df = pd.DataFrame()
incomplete_data_tickers_df["Symbol"] = incomplete_data_tickers
idt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV
#incomplete_data_tickers_df.to_csv(idt_file_path, index=False)


time.sleep(30)

## convert daily to weekly
def get_filepaths(directory):
    """
    This function lists all the file names present in directory.
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)  # Add it to the list.

    return file_paths

files_to_process = get_filepaths(TICKER_CSV_DATA_FOLDER_PATH)

for file in files_to_process:
    """folder\\BHARTIAIRTEL.NS.csv"""
    ticker_namefull = file.split("/")[-1:][0]     #file.split("\\")[1]
    ticker_name = ticker_namefull.split(".csv")[0]

    #print("Validating {} file".format(ticker_name))
    daily_data = pd.read_csv(file)
    #daily_data = daily_data[::-1]
    daily_data['Date'] = pd.to_datetime(daily_data['Date'])
    daily_data.set_index('Date', inplace=True)
    weekly_data1 = daily_data.resample('M', label='right', closed='right').agg({
    'Open': 'first',
    'High': 'max',
    'Low': 'min',
    'Close': 'last',
    'Adj Close': 'last',
    'Volume': 'sum'
    })
    weekly_data = daily_data.groupby(pd.Grouper(freq='W', closed='right', label='right')).agg({
        'Open': 'first',
        'High': 'max',
        'Low': 'min',
        'Close': 'last',
        'Adj Close': 'last',
        'Volume': 'sum'
    })
    weekly_data.reset_index(inplace=True)
    #weekly_data = weekly_data[::-1]
    weekly_data.to_csv("/home/rizpython236/BT5/ticker-csv-files-weekly"+"/"+ticker_namefull, index=False)
    print("weekly_data validated for {}".format(ticker_name))
'''
for file in files_to_process:
    """folder\\BHARTIAIRTEL.NS.csv"""
    ticker_namefull = file.split("/")[-1:][0]     #file.split("\\")[1]
    ticker_name = ticker_namefull.split(".csv")[0]
    daily_data = pd.read_csv(file)

    weekly_data = pd.DataFrame(columns=daily_data.columns)

    current_week = None

    # Iterate over the daily data and convert to weekly data
    for index, row in daily_data.iterrows():
        week_start = index - pd.offsets.Week(weekday=6)  # Sunday is the end of the week
        week_start = pd.Timestamp(week_start.date())
        if current_week is None or week_start > current_week:
            current_week = week_start
            weekly_data.loc[current_week] = row
        else:
            # Update the weekly data with the latest daily data
            weekly_data.loc[current_week, 'High'] = max(weekly_data.loc[current_week, 'High'], row['High'])
            weekly_data.loc[current_week, 'Low'] = min(weekly_data.loc[current_week, 'Low'], row['Low'])
            weekly_data.loc[current_week, 'Close'] = row['Close']
            weekly_data.loc[current_week, 'Adj Close'] = row['Adj Close']
            weekly_data.loc[current_week, 'Volume'] += row['Volume']

    weekly_data.reset_index(inplace=True)
    weekly_data.to_csv("/home/rizpython236/BT5/ticker-csv-files-weekly"+"/"+ticker_namefull, index=False)
    print("weekly_data validated for {}".format(ticker_name))
    #return weekly_data
'''

