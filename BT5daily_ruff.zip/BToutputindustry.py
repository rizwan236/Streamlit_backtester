import os
import re
import sys
import time

import pandas as pd
import yfinance as yf

from settings import (
    EXCLUDE_TICKERS_CSV,
    INCLUDE_TICKERS_CSV,
)
from symbol_copy import NSE_BSE_symbol_name_df


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


print("company details started")

if True:
    def apply_replacements(name, replacements):
        """Robust text cleaner that handles order, overlaps, and spacing issues."""
        # Sort by length (longest first) to avoid partial matches overriding larger phrases
        for old, new in sorted(replacements.items(), key=lambda x: len(x[0]), reverse=True):
            # Use word boundaries only if old is alphanumeric
            if re.search(r"\w", old):
                pattern = r"(?i)\b" + re.escape(old.strip()) + r"\b"
            else:
                # Allow flexible matching for non-word items like " - " or "&"
                pattern = r"\s*" + re.escape(old.strip()) + r"\s*"
            name = re.sub(pattern, f" {new.strip()} ", name)

        # Remove duplicated punctuation and normalize spaces
        name = re.sub(r"\s{2,}", " ", name)      # collapse multiple spaces
        # remove space before punctuation
        name = re.sub(r"\s([,.\-:/&])", r"\1", name)
        # normalize space after punctuation
        name = re.sub(r"([,.\-:/&])\s+", r"\1 ", name)
        return name.strip()

    # Load replacement data once (from CSV)
    company_REPLACEMENTS_CSV = "/home/rizpython236/BT5/Company_replacements.csv"

    if os.path.exists(company_REPLACEMENTS_CSV):
        company_replacements = pd.read_csv(company_REPLACEMENTS_CSV)
        # Normalize column names
        # company_replacements.columns = [c.strip().lower() for c in company_replacements.columns]
        # if not {"old", "new"}.issubset(company_replacements.columns):
        #    raise ValueError(f"CSV must contain 'old' and 'new' columns. Found: {company_replacements.columns.tolist()}")

        company_replacements = company_replacements.dropna(
            subset=["old"])  # ensure valid rows
        company_replacements = dict(zip(company_replacements["old"].astype(str).str.strip(),
                                        company_replacements["new"].fillna("").astype(str)))
    else:
        print(
            f"⚠️ Warning: {company_REPLACEMENTS_CSV} not found. Using empty replacements.")
        company_replacements = {}

    # Load replacement data once (from CSV)
    Industry_REPLACEMENTS_CSV = "/home/rizpython236/BT5/Industry_replacements.csv"

    if os.path.exists(Industry_REPLACEMENTS_CSV):
        Industry_replacements = pd.read_csv(Industry_REPLACEMENTS_CSV)
        Industry_replacements = Industry_replacements.dropna(
            subset=["old"])  # ensure valid rows
        Industry_replacements = dict(zip(Industry_replacements["old"].astype(str).str.strip(),
                                         Industry_replacements["new"].fillna("").astype(str)))
    else:
        print(
            f"⚠️ Warning: {Industry_REPLACEMENTS_CSV} not found. Using empty replacements.")
        Industry_replacements = {}


def clean_company_name(name, company_replacements):

    replacements = {
        " Company Limited": "", " Corporation Limited": "", " (India) Limited": "", " India Limited": " India",
        " Pharmaceuticals Limited": " Pharma", " (Delhi) Limited": "", " (Maharashtra) Limited": "",
        " Ltd.": "", " Co. Ltd.": "", " (India) Ltd.": "", " Ltd": "", " Co.": "", " Commercial ": " Comm.",
        " Advanced ": " Adv.", " Solutions ": " Solu.", " Appliances ": " App.", " Logistics ": " Logis.", " Insurance ": " Insur.", " Accessories ": " Accs.", " Specialities ": " Spcl.", " National ": " Nat.", " Software ": " Soft.", " Instrumental ": " Instr.", " System ": " Sys.", " Transformers ": " Transfor.",
        "ICICI Prudential ": "ICICI ", "Special Economic Zone": "Spl Eco Zone.", " Limited": "",
        " and ": " & ", " (India)": "", " Company": " Co.", " Infrastructure": " Infra.",
        " & ": " & ", " Corporation ": "Corp. ", " (Gujarat)": "", " (S.A.)": "",
        " And ": " & ", "Engineers": "Engrs.", " (Chennai)": "", " Infrastructures ": " Infra. ",
        " limited": "", "Technologies": "Tech.", " Infrastructure": " Infra.", " Infrastructures": " Infra.",
        " (Kalamandir)": "", " (Madras)": "", "Nippon India Mutual Fund ": "Nippon India ",
        "Nippon India ": "", " Financial ": " Fin. ", " Engineering ": " Eng. ",
        " Industries": " Ind.", " Industries ": " Ind. ", " International": " Intl.",
        " Engineering": " Eng.", "(International)": "", " Development ": " Dev. ",
        " Development": " Dev.", " International ": " Intl. ", " Technology": " Tech.",
        " Technology ": " Tech. ", " Services": " Srvs.", " Holding": " Hldg.",
        " Agricultural ": " Agri. ", " Management ": " Mgmt. ", " Investment ": " Invest. ", " E-Governance": " e-Gov.",
        " Consolidated ": " Consol. ", " Chemicals ": " Chem. ", " Chemicals": " Chem.",
        " Fertilizers ": " Fert. ", " Fertilizers": " Fert.", " Biochemicals": " Biochem.",
        " Associated ": " Assoc. ", " Associated": " Assoc.", " Hospital": " Hosp.",
        " Hospital ": " Hosp. ", " Manufacturing": " Mfg.", " Manufacturing ": " Mfg. ",
        "The ": "", "General ": " Gen. ", " Ventures": " Vntrs.", " Enterprises": " Entp.",
        " Industrial ": " Ind. ", " Industrial": " Ind.", " International": " Int.",
        "(International)": "", " Technologies": " Tech.", " (Coimbatore)": "",
        " Petrochemicals": " petrochem.", "Petrochemical": "Petrochem.",
        " Petrochemicals ": " Petrochem.", " Fertilisers ": " Fert. ", " -$ ": "", " MARKET": " MKT.", " Laboratory": " Lab.", " Automobile": " Auto.",
        " Infrastructure": " Infra. ", " Technologies": " Tech. ", " Pharmaceuticals": " Pharma. ", " Industries ": " Ind. ", " Immunologicals ": " Immunog. ", " Biologicals ": " Bio. ", " Petroleum ": " Petro. ", " Electronics ": " Electro. ", " Telecommunications ": " Telec. ", " Systems ": " Sys. ", " Petroleum ": " Petro. ", " Petroleum ": " Petro. ",
        " Institute ": " Inst. ", "Electricals": "Elect.", "Construction": "Constr.",
        "Systems": "Sys.", "Investments": "Invest.", "Management": "Mgmt.",
        "Exchange": "Exch.", " Fertilisers": " Fert.", "Housing Finance": "Hsg. Fin.", "Procter & Gamble": "P&G ",
        "Housing": "Hsg.", "Motilal Oswal S&P": "Motilal Oswal", "Developers": "Develp.",
        " Corporation": "", " Standard": " Std.", " Manufactures": " Mfg..", " Laboratories": " Lab.",
        " Industry": " Ind.", " Estates": " Est.", " Communications": " comm.", " Infrastructure": " Infra.",
        " Pharmaceutical": " Pharma.", " Development": " Develp.", " Equipment": " Equip.", " Specialty": " Spl.",
        " Education": " Edu.", " Chemicals": " Chem.", "Indian Railway Catering & Tourism": "IRCTC", "Renewable": "Renew", "Corporate": "Corp.",
        "Products": "Prod.", "Investment": "Invest.", "Consultancy": "Consult.", "Electrical": "Elect.", "Performance": "Perf.", "Consolidated": "Consol.",
        "Intermediaries": "intermeds.", "Automotive": "Auto.", "Entertainment": "Entmt.", "Institute": "Inst.", "Limited": "", "Company": "Compy.", "of India": "",
    }

    # Check for NaN at the beginning
    if pd.isna(name):
        return name

    # for old, new in company_replacements.items():
    #    # print(name)
    #    # name = name.replace(old, new)
    #    # Use re.sub with flexible whitespace matching
    #    pattern = r"\s*" + re.escape(old.strip()) + r"\s*"
    #    name = re.sub(pattern, new, name, flags=re.IGNORECASE)
    #    # name = re.sub(re.escape(old), new, name, flags=re.IGNORECASE)
    # return name
    return apply_replacements(name, company_replacements)


"""
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
#today = datetime.now()
if today.day <= 7:
    symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers_mhtly.csv')
else:
    symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers.csv')
"""

"""
file_path= '/home/rizpython236/BT5/screener-outputs/trade_list_BT_mhtly_Screener.csv'

if os.path.exists(file_path):
    symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers_mhtly.csv')
else:
    symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers.csv')
"""


include_tickers = pd.read_csv(INCLUDE_TICKERS_CSV)
include_tickers = list(include_tickers["Symbol"].unique())
exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)
# exclude_tickers = list(exclude_tickers["Symbol"].unique())


def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df


# bse = pd.read_csv("/home/rizpython236/BT5/bse.csv")
bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")

# Rename Security Id column to SYMBOL
"""
bse.drop(
    columns=[
        "Group",
        #"Face Value",
        "ISIN No",
        "Industry",
        "Instrument",
        "Sector Name",
        "Industry New Name",
        "Igroup Name",
        "ISubgroup Name",
    ],
    inplace=True,
)
"""
bse.drop(
    columns=[
        # "Group",
        # "Face Value",
        # "ISIN No",
        "Industry",
        "Instrument",
        "Sector Name",
        "Industry New Name",
        "Igroup Name",
        "ISubgroup Name",
    ],
    inplace=True, errors="ignore",
)

"""
bse.rename(columns={"Issuer Name": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Code": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Security Name"] == "Active" ]
#bse = bse[bse["Security Name"] != "Delisted" ]
#bse = bse["Security Name"].isin(["Active", "Suspended"])
accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]  #XD Z P ZP IP
bse = bse[~bse["Security Id"].str.contains("ETF")]
bse = bse[~bse["Security Id"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["Security Id"].str.contains("FUND")]
bse = bse[~bse["Security Id"].str.contains("Fund")]
#bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
condition = bse['SYMBOL'].str.endswith('*')
bse.loc[condition, 'SYMBOL'] = bse.loc[condition, 'SYMBOL'].str[:-1]
# Filter dataframe
bse = bse[bse["Status"].isin(accepted_values)]
"""
bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Status"] == "Active"]
accepted_values = ["A ", "B ", "T ", "X ", "XT",
                   "R ", "M ", "MT"]  # ,"IP","P","XD","Z","ZP"]
accepted_values = ["A ", "B ", "T ", "X ",
                   "XT", "R ", "M ", "MT", "IP", "XD", "Z"]
# Get unique items in the "Group" column
unique_items = bse["Group"].unique()
# Convert to a list
accepted_values = unique_items.tolist()
# Print the result
print("Unique items in 'Group':", accepted_values)
bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("FUND")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("Fund")]
# bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
condition = bse["SYMBOL"].str.endswith("*")
bse.loc[condition, "SYMBOL"] = bse.loc[condition, "SYMBOL"].str[:-1]
# Filter dataframe
# accepted_values =  ['A ', 'X ', 'B ', 'T ', 'XT', 'Z ', 'MT', 'M ', 'R ', 'IP']

accepted_valuesx = unique_items.tolist()
to_remove = {"P", "ZP", "IP", "Y"}  # use a set for fast lookup
accepted_values = [v for v in accepted_valuesx if v not in to_remove]

bse = bse[bse["Group"].isin(accepted_values)]

# print(datanse)

datanse.drop(
    columns=[
        " SERIES",
        " DATE OF LISTING",
        " PAID UP VALUE",
        " MARKET LOT",
        # " ISIN NUMBER",
        " FACE VALUE",
    ],
    inplace=True,
)
# datansebse = pd.merge(datanse, bse, left_on=[' ISIN NUMBER'], right_on=['Face Value'], how='left')
datansebse = pd.merge(datanse, bse, left_on=[" ISIN NUMBER"], right_on=[
                      "ISIN No"], how="right")
# common_symbols = bse[bse["Face Value"].isin(datanse[" ISIN NUMBER"])]  #common isin
common_symbols = bse[bse["ISIN No"].isin(datanse[" ISIN NUMBER"])]
bse = bse[~bse["ISIN No"].isin(common_symbols["ISIN No"])]
add_suffix_to_column(bse, "SYMBOL", ".BO")
add_suffix_to_column(datanse, "SYMBOL", ".NS")
result = pd.concat([bse, datanse], axis=0, ignore_index=True)
result.rename(columns={"SYMBOL": "Symbol"}, inplace=True)
result.drop(
    columns=[
        "NAME OF COMPANY",
        # "Security Id",
        # "Security Name",
        "Status",
        " ISIN NUMBER",
        # " FACE VALUE",
    ],
    inplace=True,
)
include_tickers_df = pd.DataFrame(include_tickers, columns=["Symbol"])
common_symbols = include_tickers_df[~include_tickers_df["Symbol"].isin(
    result["Symbol"])]  # common isin
common_symbols = common_symbols["Symbol"]
# print(common_symbols)
# print((len(common_symbols)))
# common_symbols.to_csv("common.csv", index=False)
result = pd.concat([result, include_tickers_df], ignore_index=True)


result = result[~result["Symbol"].isin(exclude_tickers["Symbol"])]
exclude_fromresult = result[result["Symbol"].isin(exclude_tickers["Symbol"])]
print(exclude_fromresult)

for ex_ticker in result["Symbol"]:  # ex_ticker in exclude_tickers:
    if ex_ticker in result:
        print(ex_ticker)
        # result.remove(ex_ticker)
        result = result[result["Symbol"] != ex_ticker]
    else:
        1 + 1


"""
result = result[~result["Symbol"].isin(exclude_tickers)]
for ex_ticker in result["Symbol"].values: #ex_ticker in exclude_tickers:
    if ex_ticker in result:
        print(ex_ticker)
        result = result[result["Symbol"] != ex_ticker] #result.remove(ex_ticker)
    else:
        1+1
"""

result.loc[len(result), "Symbol"] = "^NSEI"
result.loc[len(result), "Symbol"] = "^NSEBANK"
result.loc[len(result), "Symbol"] = "^CRSLDX"
result.loc[len(result), "Symbol"] = "^NSEMDCP50"
result.loc[len(result), "Symbol"] = "MON100.NS"
result.loc[len(result), "Symbol"] = "MAFANG.NS"
result.loc[len(result), "Symbol"] = "MAHKTECH.NS"
result.loc[len(result), "Symbol"] = "SBIGETS.BO"
result.loc[len(result), "Symbol"] = "AXISCETF.NS"
result.loc[len(result), "Symbol"] = "ICICIINFRA.NS"
result.loc[len(result), "Symbol"] = "^CNXCMDT"
result.loc[len(result), "Symbol"] = "^CNXINFRA"
result.loc[len(result), "Symbol"] = "^CNXAUTO"
result.loc[len(result), "Symbol"] = "^CNXPHARMA"
result.loc[len(result), "Symbol"] = "^CNXPSUBANK"
result.loc[len(result), "Symbol"] = "^CNXIT"
result.loc[len(result), "Symbol"] = "^CNXCONSUM"
result.loc[len(result), "Symbol"] = "NIFTYPVTBANK.NS"
result.loc[len(result), "Symbol"] = "^CNXMETAL"
result.loc[len(result), "Symbol"] = "^CNXREALTY"
result.loc[len(result), "Symbol"] = "^CNXENERGY"
result.loc[len(result), "Symbol"] = "^CNXFMCG"
result.loc[len(result), "Symbol"] = "NIFTYSMLCAP250.NS"
result.loc[len(result), "Symbol"] = "NIFTY_MICROCAP250.NS"
result.loc[len(result), "Symbol"] = "BSE-IPO.BO"
result.loc[len(result), "Symbol"] = "NIFTY_FIN_SERVICE.NS"

result = list(result["Symbol"].unique())
result = pd.DataFrame(result)
result = result.rename(columns={result.columns[0]: "Symbol"})
# Remove any rows where the 'Symbol' column contains '-RE'
result = result[~result["Symbol"].str.contains("-RE.")]
result = result[~result["Symbol"].str.contains("DUMMY")]
result.to_csv(
    "/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv", index=False)
print(len(datanse), "nse")
print(len(bse), "bse")
print(len(datansebse), "NSE-BSE")
print(len(result), "final")
# print(result)


# Remove industry file if it exists
# if os.path.exists('/home/rizpython236/BT5/screener-outputs/industry.csv'):
#    os.remove('/home/rizpython236/BT5/screener-outputs/industry.csv')


# Load symbols from CSV file
# symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers_mhtly.csv')
# symbol_df = pd.read_csv('/home/rizpython236/BT5/symbol_list.csv')

# symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv')
# symbol_df = pd.read_csv('/home/rizpython236/BT5/myholding.csv')
# symbol_df = pd.read_csv('/home/rizpython236/BT5/trade-logs/new_tickers.csv')
# symbol_df = pd.read_csv('/home/rizpython236/BT5/Final.csv')
# symbol_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/incomplete_data_tickers.csv')
# symbol_df = pd.read_csv('/home/rizpython236/BT5/exclude_tickers.csv')  #exclude_tickers.csv
# Create an empty DataFrame to store the symbol and sector details
# industry_df = pd.DataFrame(columns=['Symbol', 'Industry','Sector','LongName','MarketCapCr','Price','Volume','EPS','Equity','Debt','Sales','Dividend','payoutRatio'])
# symbol_df = list(dict.fromkeys(symbol_df))
# symbol_df=symbol_df[:]


def fetch_stock_info(symbol, symbol_to_name):
    try:
        stock = yf.Ticker(symbol)
        info = stock.info
        longName = symbol_to_name[symbol]  # info.get('longName', "Blank")
        # print(longName)
        # info.get('trailingAnnualDividendRate', 0) #dividendRate
        dividend1 = 0
        dividend2 = 0  # info.get('trailingAnnualDividendRate', 0)
        # if dividend1 != 0 or dividend2 != 0 else "Blank"
        dividend = max(dividend1, dividend2)
        # round(info.get('payoutRatio', 0) * 100, 2) #if 'payoutRatio' in info else "Blank"
        payoutRatio = 0
        eps = 0  # info.get('trailingEps', "Blank")
        equity = 0  # info.get('totalStockholderEquity', "Blank")
        debt = 0  # info.get('totalDebt', "Blank")
        sales = 0  # info.get('totalRevenue', "Blank")
        # longName = info.get('longName', "Blank")
        try:
            history = stock.history(period="1d", auto_adjust=True)
            price = round(history["Close"].iloc[-1],
                          2) if history is not None else "Blank"
            Volume = round(history["Volume"].iloc[-1],
                           2) if history is not None else "Blank"
        except:
            price = "Blank"
            Volume = "Blank"
        marketCap = round(info.get("marketCap", 0) / 10000000,
                          0) if "marketCap" in info else "Blank"
        industry = info.get("industry", "Blank")
        sector = info.get("sector", "Blank")
        return pd.Series([symbol, longName, industry, sector, marketCap, price, Volume, eps, equity, debt, sales, dividend, payoutRatio], index=["Symbol", "LongName", "Industry", "Sector", "MarketCapCr", "Price", "Volume", "EPS", "Equity", "Debt", "Sales", "Dividend", "payoutRatio"])
    except Exception:
        return pd.Series([symbol] + ["Blank"] * 12, index=["Symbol", "LongName", "Industry", "Sector", "MarketCapCr", "Price", "Volume", "EPS", "Equity", "Debt", "Sales", "Dividend", "payoutRatio"])


def update_output_file(input_file, output_file):
    symbol_df = pd.read_csv(input_file)
    # industry_df = pd.DataFrame(columns=['Symbol', 'LongName', 'Industry', 'Sector', 'MarketCapCr', 'Price', 'Volume', 'EPS', 'Equity', 'Debt', 'Sales', 'Dividend', 'payoutRatio'])
    # industry_df.dropna(inplace=True)

    # Use a list to collect data and then convert to DataFrame outside the loop
    data = []
    counter = 0
    bse_nse_common = pd.read_csv("/home/rizpython236/BT5/bse_nse_common.csv")
    bse_symbols = bse_nse_common["Symbol"].tolist()
    sym_name_df = NSE_BSE_symbol_name_df()
    symbol_to_name = dict(
        zip(sym_name_df["SYMBOL"], sym_name_df["NAME OF COMPANY"]))
    for symbol in symbol_df["Symbol"][:]:
        counter += 1
        time.sleep(1)
        if counter % 200 == 0:
            print(f"Processed {counter} tickers. Pausing for 5 minutes...")
            time.sleep(4 * 60)  # Sleep for 15 minutes
        # data.append(fetch_stock_info(symbol,symbol_to_name))

        info = fetch_stock_info(symbol, symbol_to_name)   # run once
        data.append(info)

        # If symbol ends with .NS, duplicate entry with .BO
        # if symbol.endswith(".NS"):
        #    bo_info = info.copy()   # make a shallow copy of dict (or DataFrame row)
        #    bo_info['Symbol'] = symbol.replace(".NS", ".BO")  # overwrite only Symbol
        #    data.append(bo_info)

        if symbol.endswith(".NS"):
            bo_symbol = symbol.replace(".NS", ".BO")
            if bo_symbol in bse_symbols:
                bo_info = info.copy()       # shallow copy
                bo_info["Symbol"] = bo_symbol
                data.append(bo_info)

    industry_df = pd.DataFrame(data)
    # display(industry_df)
    industry_df.to_csv(output_file, index=False)


input_file = "/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv"
output_file = "/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv"

# input_file ='/home/rizpython236/BT5/exclude_tickers.csv'
# output_file ='/home/rizpython236/BT5/trade-logs/delete_exclude_tickers.csv'

# input_file ='/home/rizpython236/BT5/symbol_list.csv'
# input_file = '/home/rizpython236/BT5/trade-logs/new_tickers.csv'

# industry_df = pd.DataFrame(columns=['Symbol', 'LongName', 'Industry', 'Sector', 'MarketCapCr', 'Price', 'Volume', 'EPS', 'Equity', 'Debt', 'Sales', 'Dividend', 'payoutRatio'])


# Example usage
update_output_file(input_file, output_file)


try:
    pass
except Exception:
    1 + 1

trade_list = pd.read_csv(
    "/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv")
final_isin = pd.read_csv("/home/rizpython236/BT5/trade-logs/FinalISIN.csv")


# Apply the cleaning function to the LongName column
# final_isin["COMPANY"] = final_isin["COMPANY"].apply(clean_company_name)
final_isin["COMPANY"] = final_isin["COMPANY"].apply(
    lambda x: clean_company_name(x, company_replacements))

# print(final_isin)

# Filter trade_list for Symbols ending with .BO
filtered_trade_list = trade_list[trade_list["Symbol"].str.endswith(".BO")]
# Filter trade_list for Symbols ending with .BO and LongName is NaN
filtered_trade_list = trade_list[trade_list["Symbol"].str.endswith(
    ".BO") & trade_list["LongName"].isna()]
filtered_trade_list = trade_list[trade_list["Symbol"].str.endswith(".BO") & (
    trade_list["LongName"].isna() | (trade_list["LongName"] == "Blank"))]

# print(filtered_trade_list)


# Create a mapping from Symbol to COMPANY from the final_isin DataFrame
symbol_to_company = final_isin.set_index("Symbol")["COMPANY"].to_dict()


# Print entries in 'LongName' where the value is NaN
na_long_names = trade_list[trade_list["LongName"].str.contains(
    "Blank", na=False)]
# Display the result
print("Entries in 'LongName' where the value is Blank:")
print(na_long_names)


# Fill NaN values in LongName using the mapping
# filtered_trade_list['LongName'] = filtered_trade_list['LongName'].fillna(filtered_trade_list['Symbol'].map(symbol_to_company))
trade_list["LongName"] = trade_list["LongName"].fillna(
    filtered_trade_list["Symbol"].map(symbol_to_company))

# Fill LongName where it is "BLANK" using the mapping
trade_list.loc[trade_list["LongName"] == "Blank",
               "LongName"] = trade_list["Symbol"].map(symbol_to_company)


# Apply the cleaning function to the LongName column
# trade_list['LongName'] = trade_list['LongName'].apply(clean_company_name)


# Optionally, you can save the result to a new CSV file
trade_list.to_csv(
    "/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv", index=False)

# Display the result
print(trade_list)


"""
# Iterate through each symbol
for symbol in symbol_df['Symbol']:   #symbol_df['ticker']: FULLSymbol  Symbol
    try:
        # Fetch stock information for the symbol
        stock = yf.Ticker(symbol)

        try:
            dividend1 = stock.info.get('1dividendRate',0)
            if dividend1 ==0:
                dividend2 = stock.info.get('trailingAnnualDividendRate',0)
                dividend = max(dividend1,dividend2)
        except:
            dividend="Blank"  #payoutRatio

        try:
            payoutRatio = round(stock.info['payoutRatio']*100,2)
        except:
            payoutRatio="Blank"

        try:
            eps = stock.info['trailingEps']
        except:
            eps="Blank"
        try:
            equity = stock.info['totalStockholderEquity']
        except:
            equity="Blank"
        try:
            debt = stock.info['totalDebt']
        except:
            debt="Blank"
        try:
            sales = stock.info['totalRevenue']
        except:
            sales="Blank"
        try:
            longName =stock.info['longName']  #longName
        except:
            longName="Blank"
        try:
            history = stock.history(period='1d',auto_adjust=False)
            price = round(history['Close'].iloc[-1],2)
            Volume = round(history['Volume'].iloc[-1],2)
            #price = stock.info['price']
        except:
            price = "Blank"
            Volume ="Blank"
        try:
            marketCap = stock.info['marketCap']
            marketCap= round(marketCap/10000000,2)
        except:
            marketCap= "Blank"
        # Get the sector of the stock
        try:
            industry = stock.info['industry']# stock.info['sector']
            sector = stock.info['sector']
        except:
            sector = "Blank"
            industry= "Blank"
        #marketCap = "Blank" # stock.info['marketCap']
        #longName =stock.info['longName']
        # Print the symbol name and sector
        #print(f"Symbol: {symbol},LongName:{longName},MarketCapCr:{marketCap}, Sector: {sector},Industry: {industry},Price:{price},Volume:{Volume},EPS:{eps},Equity:{equity},Debt:{debt},Sales:{sales},Dividend:{dividend},payoutRatio:{payoutRatio}")

        # Append the symbol and sector to the industry DataFrame
        industry_df = industry_df.append({'Symbol': symbol,'LongName':longName, 'Industry': industry,'Sector': sector,'MarketCapCr':marketCap,'Price':price,'Volume':Volume,'EPS':eps,'Equity':equity,'Debt':debt,'Sales':sales,'Dividend':dividend,'payoutRatio':payoutRatio}, ignore_index=True)
    except:
        if longName != "Blank":
            longName="Blank"
        if marketCap != "Blank":
            marketCap= "Blank"
        if sector != "Blank":
            sector = "Blank"
        if industry != "Blank":
            industry= "Blank"
        if price != "Blank":
           price = "Blank"
        if Volume != "Blank":
           Volume = "Blank"
        if dividend != "Blank":
           dividend = "Blank"
        #print(f"Symbol: {symbol},LongName:{longName},MarketCapCr:{marketCap}, Sector: {sector},Industry: {industry},Volume:{Volume}")
        # Append the symbol and assumed sector to the industry DataFrame
        industry_df = industry_df.append({'Symbol': symbol,'LongName':longName, 'Industry': industry,'Sector': sector,'MarketCapCr':marketCap,'Price':price,'Volume':Volume,'Dividend':dividend,'payoutRatio':payoutRatio}, ignore_index=True)
        #industry_df =.to_csv('/home/rizpython236/BT5/screener-outputs/myholdingIND.csv', index=False)
        # If an error occurs, handle it (e.g., symbol not found)
        #print(f"Error fetching data for symbol: {symbol}")

# Sort the DataFrame by sector, with black sector symbols at the bottom
#industry_df = industry_df.sort_values(by='Industry', key=lambda x: x.str.contains('Blank'))
#industry_df.to_csv('/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDdelete.csv', index=False)
industry_df.to_csv('/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDexclude_tickers', index=False)
"""

print("company details completed")
