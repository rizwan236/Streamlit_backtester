import glob
import os
from pathlib import Path
import sys
import time
import traceback

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pandas_ta as ta
from scipy import stats
import talib as tb

from custum_index import (
    load_index_constituents_from_csv,
    plot_index_close_prices,
)
from telegram_bot import post_telegram_file, post_telegram_message


# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
# import yfinance as yf
sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


# import talib as tb


TICKER_CSV_DATA_FOLDER_PATH = "/home/rizpython236/BT5/ticker_15yr"

print("BTmombroker")

'''
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def market_volatility_ratio(
    ticker="^CRSLDX",
    lookback_days=252,       # ~1 year trading days
    longterm_days=252*5      # ~5 years trading days
):
    """
    Calculate market volatility ratio:
    (current market volatility / long-term average market volatility)

    If current volatility is high (e.g., crisis, beta stocks rallying wildly): scaling factor < 1 → momentum scores shrink.

    If current volatility is low (calm period, quiet uptrend): scaling factor > 1 → rewards stocks that are quietly compounding.

    This penalizes “beta passengers” and highlights true alpha momentum stocks.

    Parameters
    ----------
    ticker : str
        Yahoo Finance ticker for market index (^CRSLDX for Nifty 500 TRI).
    lookback_days : int
        Rolling window for current volatility (default = 252 trading days ≈ 1 year).
    longterm_days : int
        Period for long-term volatility average (default = 5 years).

    Returns
    -------
    tuple
        (volatility ratio, current_vol, longterm_avg_vol)
    """

    # Define date range: last 6 years till today
    end = datetime.today().strftime("%Y-%m-%d")
    start = (datetime.today() - timedelta(days=6*365)).strftime("%Y-%m-%d")

    # Download data
    data = yf.download(ticker, start=start, end=end, progress=False)["Close"].dropna()

    # Daily log returns
    log_returns = np.log(data / data.shift(1)).dropna()

    # Current volatility (annualized, past 1 year)
    current_vol = log_returns[-lookback_days:].std() * np.sqrt(252)

    # Long-term average volatility (annualized, rolling 1-year vol over 5 years)
    longterm_vol = (
        log_returns[-longterm_days:].rolling(lookback_days).std().dropna() * np.sqrt(252)
    ).mean()

    # Volatility ratio
    #vol_ratio = current_vol / longterm_vol
    vol_ratio = longterm_vol / current_vol
    return vol_ratio, current_vol, longterm_vol

# Example usage
ratio, curr_vol, avg_vol = market_volatility_ratio()
print(f"Volatility Ratio: {ratio:.2f}")
print(f"Current Volatility: {curr_vol:.2%}")
print(f"Long-term Average Volatility: {avg_vol:.2%}")

'''


data_path = "/home/rizpython236/BT5/ticker-csv-files/"
data_pathpathlib = Path("/home/rizpython236/BT5/ticker-csv-files/")

data_path = "/home/rizpython236/BT5/ticker_15yr/"
data_pathpathlib = Path("/home/rizpython236/BT5/ticker_15yr/")
"""
symbol=123
file_path = data_path / f"{symbol}.csv"
print(file_path)
ff
"""


nse500 = "/home/rizpython236/BT5/Finalnse.csv"  # nse750 Symbol
# nse500 = '/home/rizpython236/BT5/symbol_list.csv'
nse500 = pd.read_csv(nse500)
NSE570symbols1 = nse500["Symbol"].tolist()[:]
# NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols1))
symbolsNSE = list(dict.fromkeys(NSE570symbols1))
# symbolsNSE750 = list(dict.fromkeys(NSE570symbols1))
number = len(symbolsNSE)
print(number)


def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df


bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
bse.drop(
    columns=[
        # "Group",
        # "Face Value",
        # "ISIN No",
        "Industry",
        "Instrument",
        "Sector Name",
        "Industry New Name",
        "Igroup Name",
        "ISubgroup Name",
    ],
    inplace=True, errors="ignore",
)

bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Status"] == "Active"]
accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]
accepted_values = ["A ", "B ", "T ", "X ", "XT",
                   "R ", "M ", "MT", "IP", "P", "XD", "Z", "ZP"]
# Get unique items in the "Group" column
unique_items = bse["Group"].unique()
# Convert to a list
accepted_values = unique_items.tolist()
# Print the result
print("Unique items in 'Group':", accepted_values)
bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("FUND")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("Fund")]
condition = bse["SYMBOL"].str.endswith("*")
bse.loc[condition, "SYMBOL"] = bse.loc[condition, "SYMBOL"].str[:-1]
# Filter dataframe
#                  ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT" ,"IP","P","XD","Z","ZP"]
accepted_values = ["A ", "B "]  # "P","XD","ZP" , 'IP'
# accepted_values = unique_items.tolist()
to_remove = {"P", "ZP", "IP", "Y"}  # use a set for fast lookup
# accepted_valuesx = [v for v in accepted_valuesx if v not in to_remove]
bse = bse[bse["Group"].isin(accepted_values)]
bse["SYMBOLNSE"] = bse["SYMBOL"].copy()
add_suffix_to_column(bse, "SYMBOL", ".BO")
# bse["SYMBOLNSE"] = bse["SYMBOL"].copy()
add_suffix_to_column(bse, "SYMBOLNSE", ".NS")
# print(len(bse))

# bseAsymbols1 = bse['SYMBOL'].tolist()[:]
bseAsymbols1 = bse["SYMBOL"].tolist() + bse["SYMBOLNSE"].tolist()
# NSE570symbols = list(dict.fromkeys(symbols))
bseAsymbols1 = list(set(bseAsymbols1))
bseAsymbols1symbols = list(dict.fromkeys(bseAsymbols1))
# symbolsNSE750 = list(dict.fromkeys(NSE570symbols1))
number = len(bseAsymbols1symbols)
print(number)

symbols = list(dict.fromkeys(NSE570symbols + bseAsymbols1))
number = len(symbols)
print(number)
# print(symbols)


nse500 = "/home/rizpython236/BT5/nse500.csv"
nse5001 = "/home/rizpython236/BT5/Finalnse.csv"  # nse750 Symbol
# nse500 = '/home/rizpython236/BT5/symbol_list.csv'
nse500 = pd.read_csv(nse500)
nse5001 = pd.read_csv(nse5001)

# NSE570symbols1 = nse500['Symbol'].tolist()[:]
# NSE570symbols1 = [sym + ".NS" for sym in nse500['Symbol'].tolist()] + [sym + ".NS" for sym in nse5001['Symbol'].tolist()]
NSE570symbols12 = list(set(
    [sym + ".NS" for sym in nse500["Symbol"].tolist()] +
    [sym + ".NS" for sym in nse5001["Symbol"].tolist()],
))


# NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbolsx = list(set(NSE570symbols12))
symbolsx = list(dict.fromkeys(NSE570symbols12))
# symbolsNSE750 = list(dict.fromkeys(NSE570symbols1))
numberx = len(symbolsx)
print(numberx)
print("_______")


# symbols_of_interest = ['^NSEI','^CRSLDX','^CRSMIDxx','^CNXSCxx','NIFTY_MICROCAP250xx.NS','^NSMIDCP', '^NSEMDCP50xx','^NSEBANKxx']
symbols_of_interest = symbols


def avgScore(Lateststocks, symbolsx):
    try:
        # Calculate statistics
        all_data = []
        for symbol in symbolsx:
            if symbol in Lateststocks:
                df = Lateststocks[symbol]
                if not df.empty and "Date" in df.columns and "Score" in df.columns:
                    df_copy = df[["Date", "Score"]].copy()
                    df_copy["Symbol"] = symbol
                    all_data.append(df_copy)

        if all_data:
            combined_df = pd.concat(all_data, ignore_index=True)
            combined_df["Date"] = pd.to_datetime(combined_df["Date"])

            daily_stats = combined_df.groupby("Date").agg(
                Average=("Score", "mean"),
                Median=("Score", "median"),
                Q1=("Score", lambda x: x.quantile(0.25)),
                Q3=("Score", lambda x: x.quantile(0.75)),
                # Min=("Score", "min"),
                # Max=("Score", "max"),
                # Std=("Score", "std"),
                # Count=("Score", "count"),
            ).reset_index()

            # daily_stats = combined_df.groupby("Date")["Score"].agg([
            #    "mean", "median",
            #    #"Q1": lambda x: x.quantile(0.25),
            #    #"Q3": lambda x: x.quantile(0.75),
            #    #"min", "max",
            #    ("Q1", lambda x: x.quantile(0.25)),
            #    ("Q3", lambda x: x.quantile(0.75)),
            #    #lambda x: x.quantile(0.25),  # Q1
            #    #lambda x: x.quantile(0.75),  # Q3
            # ]).reset_index()  # 'count', 'std' , "min", "max"
            # 'Count', 'Std']

            daily_stats = daily_stats.dropna()
            # daily_stats.columns = ["Date", "Average", "Median","Q1", "Q3"]
            daily_stats["IQR"] = daily_stats["Q3"] - daily_stats["Q1"]

            daily_stats = daily_stats.sort_values("Date")

            # Create chart
            plt.figure(figsize=(22, 18))

            # Plot lines
            plt.plot(daily_stats["Date"], daily_stats["Average"],
                     label="Average Score", color="blue", linewidth=2, marker="o")
            plt.plot(daily_stats["Date"], daily_stats["Median"],
                     label="Median Score", color="green", linewidth=2, marker="s", linestyle="--")

            # Plot Q1 and Q3 as solid lines
            plt.plot(daily_stats["Date"], daily_stats["Q1"],
                     label="Q1 (25th percentile)", color="orange", linewidth=2,
                     linestyle="-.", alpha=1)
            plt.plot(daily_stats["Date"], daily_stats["Q3"],
                     label="Q3 (75th percentile)", color="purple", linewidth=2,
                     linestyle="-.", alpha=1)

            """
            # Plot quartile range as shaded area
            plt.fill_between(daily_stats["Date"],
                             daily_stats["Q1"],
                             daily_stats["Q3"],
                             alpha=0.3, color="lightblue", label="Interquartile Range (Q1-Q3)")

            # Add fill between
            plt.fill_between(daily_stats["Date"],
                             daily_stats["Average"],
                             daily_stats["Median"],
                             alpha=0.2, color="gray", label="Average-Median Range")
            """

            # Customize chart
            plt.title(
                f"Daily Score Statistics for {len(symbolsx)} Symbols", fontsize=14, fontweight="bold")
            plt.xlabel("Date", fontsize=12)
            plt.ylabel("Score", fontsize=12)
            plt.legend(loc="best")
            plt.grid(True, alpha=0.3)

            # Set y-axis limits if needed
            y_min = daily_stats[["Average", "Median", "Q1", "Q3"]].min().min()
            y_max = daily_stats[["Average", "Median", "Q1", "Q3"]].max().max()
            plt.ylim(y_min * 0.95, y_max * 1.05)

            # Format x-axis dates
            plt.gcf().autofmt_xdate()

            # Format x-axis to show labels on a quarterly basis
            # plt.gca().xaxis.set_major_locator(
            #    mdates.MonthLocator(interval=1))  # Quarterly labels  3
            # plt.gca().xaxis.set_major_formatter(
            #    mdates.DateFormatter("%Y-%m"))  # Format as 'YYYY-MM'

            # Rotate x-axis labels for better readability
            # plt.xticks(rotation=25)
            # plt.xticks(rotation=90, ha="right")

            # Add text box with statistics
            stats_text = f"""
            Overall Stats:
            Avg Score: {daily_stats['Average'].mean():.2f}
            Med Score: {daily_stats['Median'].median():.2f}
            Average Q1: {daily_stats['Q1'].mean():.2f}
            Average Q3: {daily_stats['Q3'].mean():.2f}
            Average IQR: {daily_stats['IQR'].mean():.2f}
            Days: {len(daily_stats)}
            Symbols: {len(symbolsx)}
            """
            plt.text(0.02, 0.98, stats_text, transform=plt.gca().transAxes,
                     fontsize=10, verticalalignment="top",
                     bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5))
            plt.tight_layout()

            # Save chart
            folder_path = "/home/rizpython236/BT5/screener-outputs/"
            file_path = os.path.join(folder_path)
            chart_path = os.path.join(
                folder_path, "daily_scores_statistics.png")
            plt.savefig(chart_path, bbox_inches="tight")

            # plt.savefig('daily_scores_statistics.png', dpi=300, bbox_inches='tight')
            print("Chart saved as 'daily_scores_statistics.png'")
            time.sleep(3)
            post_telegram_file(chart_path)
            os.remove(chart_path)

        # plt.show()
    except Exception as e:
        print(f"Error occurred: {e!s}")
        traceback_str = traceback.format_exc()
        post_telegram_message(traceback_str)

    # return


def calculate_exponential_linear_regression(dataexp, period=12):
    # Download historical data from yfinance
    dataexp = dataexp.iloc[-(period + 5):]

    # Calculate the natural logarithm of returns
    # returns = np.log(data['Close'])
    returns = np.log(dataexp["Close"])
    x = np.arange(len(returns))

    slope = returns.rolling(window=period).apply(
        lambda x: stats.linregress(np.arange(len(x)), x)[0])
    annualized_slope = (np.power(np.exp(slope), 252) - 1) * 100
    r_value = returns.rolling(window=period).apply(
        lambda x: stats.linregress(np.arange(len(x)), x)[2])
    annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # print(annualized_slope_r_value)

    # Calculate linear regression
    # slope, _, r_value, _, _ = stats.linregress(x, returns)

    # Calculate annualized slope
    # annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    # Calculate annualized_slope_r_value
    # annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Round the annualized slope and annualized_slope_r_value
    # rounded_annualized_slope = round(annualized_slope, 2)

    # Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    # higher_value = annualized_slope_r_value #np.maximum(annualized_slope_r_value, rounded_annualized_slope)

    return annualized_slope_r_value


def rolling_beta(stock: np.ndarray, index: np.ndarray, window: int = 5) -> np.ndarray:
    """Compute rolling Beta of stock vs index.

    Parameters
    ----------
        stock (np.ndarray): Stock price series (1D array)
        index (np.ndarray): Index price series (1D array)
        window (int): Lookback period

    Returns
    -------
        np.ndarray: Rolling beta series, same length as input, with NaNs for initial periods

    """
    stock = np.asarray(stock, dtype=float)
    index = np.asarray(index, dtype=float)

    if len(stock) != len(index):
        raise ValueError("Stock and index must be same length")

    beta = np.full(len(stock), np.nan)  # initialize output with NaN

    for i in range(window - 1, len(stock)):
        y = stock[i - window + 1:i + 1]
        x = index[i - window + 1:i + 1]
        cov = np.cov(x, y, ddof=0)[0, 1]  # covariance between X and Y
        var = np.var(x, ddof=0)            # variance of X
        beta[i] = cov / var if var != 0 else np.nan

    return beta


def calculate_mrp(stock_csv_file, index_csv_file):
    # Load stock and index data from CSV files using chunksize for large files
    chunksize = 10 ** 6  # Adjust based on available memory
    # pd.concat(pd.read_csv(stock_csv_file, chunksize=chunksize))
    stock_data = stock_csv_file
    # pd.concat(pd.read_csv(index_csv_file, chunksize=chunksize))
    index_data = index_csv_file

    # Assuming MDD_df is a placeholder for stock_data, adjust as necessary
    MDD_df = stock_data.copy()
    # MDD_df.ta.exchange = "NSE"

    # Calculate daily returns
    # max_rows = min(len(stock_data), len(index_data))
    # stock_data = stock_data.iloc[max_rows:]  # Slice stock_data to match index_data
    # index_data = index_data.iloc[max_rows:]  # Slice stock_data to match index_data
    # MDD_df =MDD_df.iloc[max_rows:]
    stock_data1 = pd.DataFrame()
    index_data1 = pd.DataFrame()
    stock_data1["Close"] = stock_data["Close"].pct_change()
    index_data1["Close"] = index_data["Close"].pct_change()

    MDD_df1 = ta.drawdown(MDD_df["Close"])
    MDD_df7 = ta.ad(MDD_df["High"], MDD_df["Low"], MDD_df["Close"],
                    MDD_df["Volume"], open_=None, talib=False, offset=None)  # AD line
    MDD_df2 = ta.supertrend(
        MDD_df["High"], MDD_df["Low"], MDD_df["Close"], length=10, multiplier=4)
    MDD_df5 = ta.obv(MDD_df["Close"], MDD_df["Volume"], talib=False)
    # MDD_df1['Qstick'] = qstick(MDD_df,period=22)

    MDD_df1[["DD", "DD_PCT", "DD_LOG"]] = MDD_df1[[
        "DD", "DD_PCT", "DD_LOG"]].round(4)
    MDD_df1 = MDD_df1.rename(columns={"DD_LOG": "ta_DD_LOG"})

    MDD_df1["ST"] = MDD_df2["SUPERTd_10_4.0"]
    MDD_df1["OBV"] = round(MDD_df5, 2)
    MDD_df1["AD"] = round(MDD_df7, 4)

    MDD_df1["Beta"] = tb.BETA(
        stock_data["Close"].values, index_data["Close"].values, timeperiod=250)
    # print(MDD_df1['Beta'] )

    # MDD_df1['Beta'] = rolling_beta(stock_data['Close'].values, index_data['Close'].values, window=252)
    # print(MDD_df1['Beta'] )

    MDD_df1[["OBV", "AD"]] = MDD_df1[["OBV", "AD"]].round(1)

    # Calculate cumulative returns
    stock_data["Stock_Cumulative_Return"] = 100 * \
        (1 + stock_data1["Close"]).cumprod()
    index_data["Dow_Cumulative_Return"] = 100 * \
        (1 + index_data1["Close"]).cumprod()

    # Adjust initial value calculation
    initial_value = 1
    stock_data1["Close"] = initial_value * \
        stock_data["Stock_Cumulative_Return"]
    index_data1["Close"] = initial_value * index_data["Dow_Cumulative_Return"]

    # Assuming calculate_exponential_linear_regression is defined elsewhere
    result = calculate_exponential_linear_regression(stock_data, period=22 * 3)

    rolling_max = MDD_df["Close"].rolling(window=252, min_periods=200).max()

    # Calculate the drawdown as a percentage
    drawdown24 = abs(((MDD_df["Close"] - rolling_max) / rolling_max) * 1)

    # Calculate cumulative returns
    # stock_cumulative_returns = (1 + stock_returns).cumprod()
    # index_cumulative_returns = (1 + index_returns).cumprod()

    # Calculate MRP
    # mrp = stock_cumulative_returns / index_cumulative_returns

    # Assuming calculate_exponential_linear_regression is defined elsewhere
    # result = calculate_exponential_linear_regression(stock_data, period=24)

    # Calculate Relative Performance (RP)
    # RP = stock_data['Close'] / index_data['Close']
    min_length = min(len(stock_data1), len(index_data1))
    divisor = index_data1["Close"].ffill()  # .fillna(1)
    # RP = (stock_data1['Close'][min_length:] / index_data1['Close'][min_length:])
    # RP = (stock_data1['Close'].iloc[:min_length] / divisor.iloc[:min_length]).append(pd.Series([0] * (len(stock_data1) - min_length)))
    RP = (1 + stock_data1["Close"] * 100) / (1 + index_data1["Close"] * 100)

    RP = round(RP, 4).ffill()
    RP = RP.reset_index(drop=True)
    stock_data["MRP"] = RP
    pd.set_option("display.max_rows", None)
    # pd.reset_option('display.max_rows')
    # print(stock_data['Close','MRP'])

    # Calculate RP52W (Simple Moving Average over 52 weeks)
    # RP13SMA = RP.rolling(window=13).mean()
    # RP25SMA = RP.rolling(window=26).mean()
    # RP13EMA = RP.ewm(span=13).mean()
    # RP25EMA = RP.ewm(span=26).mean()

    # Calculate Mansfield Relative Performance (MRP)
    # MRP13S = ((RP / RP13SMA) - 1) * 100
    # MRP25S = ((RP / RP25SMA) - 1) * 100
    # MRP13E = ((RP / RP13EMA) - 1) * 100
    # MRP25E = ((RP / RP25EMA) - 1) * 100
    # MAX13 = pd.concat([MRP13S, MRP13E], axis=1).min(axis=1)
    # MAX25 = pd.concat([MRP25S, MRP25E], axis=1).min(axis=1)

    # Add MRP values to the stock data
    # stock_data['MRP13'] = round(MAX13, 3)
    # stock_data['MRP25'] = round(MAX25, 3)
    # stock_data['MRP'] = RP.round(3) #round(RP, 3)
    # stock_data['Exp'] = round(result, 3)

    # Add MRP values to the stock data
    stock_data["MRP13"] = round(RP, 3).ffill()
    stock_data["MRP25"] = round(RP, 3).ffill()
    stock_data["MRP"] = round(RP, 3).ffill()  # round(RP, 3)
    stock_data["Exp"] = round(result, 3).ffill()
    stock_data["DD_LOG"] = round(drawdown24, 1).ffill()

    # Assuming MDD_df1 is a DataFrame with relevant columns
    stock_data = pd.concat([stock_data, MDD_df1], axis=1)
    stock_data[["DD_PCT", "DD_LOG", "ta_DD_LOG"]] *= 100
    # Save the updated stock data to a new CSV file
    # print(stock_data)
    # stock_data = stock_data.fillna(method='ffill')
    stock_data = stock_data.ffill()

    # stock_data.to_csv(stock_csv_file, index=False)

    return stock_data


def downside_deviation_from_pricesaaa(log_returns, mar=0):

    # Calculate the returns that are below the minimum acceptable return (MAR)
    downside_returns = log_returns[log_returns < mar]

    # Square these returns
    squared_downside_returns = downside_returns ** 2

    # Calculate the mean of these squared returns
    mean_squared_downside = squared_downside_returns.mean()

    # Take the square root of the mean squared downside returns
    downside_deviation = np.sqrt(mean_squared_downside)
    # print(downside_deviation)

    return downside_deviation


def downside_deviation(x, mar=0):
    # mar = np.percentile(x, 25)  # 1st quartile (25th percentile)
    # mar = x.mean()  # use group mean as MAR
    # mar =  np.mean(x)
    downside = x[x < mar]  # keep only values below MAR
    if len(downside) == 0:
        # eps=np.finfo(float).eps
        return 0.00000001
    return np.sqrt(np.mean((downside - mar) ** 2))


def calculate_lognormal_daily_returns(prices):
    """Calculates lognormal daily returns of a stock.

    Args:
        prices (pandas.Series): Time series of closing prices.

    Returns:
        pandas.Series: Time series of lognormal daily returns.

    """
    # np.log(prices.pct_change() + 1)
    log_returns = np.log(prices) - np.log(prices.shift(1))
    return log_returns


def get_available_symbols_by_mr12(all_data, symbols_of_interest, z=2.0):
    """Return symbols whose latest MR12 is at least z robust std deviations
    below the median (using MAD instead of mean/std to handle non-normal data).

    Parameters
    ----------
    - all_data: DataFrame with columns ['Symbol','Date','MR12'].
    - symbols_of_interest: list of symbols to filter.
    - z: cutoff in MAD-based z-score units (default=2.0).

    Returns
    -------
    - List of symbols considered "extreme low MR12".

    """
    df = all_data[["Symbol", "Date", "MR12"]].copy()
    df["Date"] = pd.to_datetime(df["Date"])
    df = df[df["Symbol"].isin(symbols_of_interest)]

    # Take the latest row per symbol
    latest = df.sort_values(["Symbol", "Date"]).groupby(
        "Symbol", as_index=False).last()
    latest["MR12"] = pd.to_numeric(latest["MR12"], errors="coerce")
    latest = latest.dropna(subset=["MR12"])
    if latest.empty:
        return []

    # Robust location & scale
    median = latest["MR12"].median()
    mad = (latest["MR12"] - median).abs().median()
    if pd.isna(mad) or mad == 0:
        return []

    # Scale MAD to behave like std under normality
    robust_std = 1.4826 * mad
    thresh = median - z * robust_std

    return latest.loc[latest["MR12"] < thresh, "Symbol"].tolist()


def calculate_scores(data_path, symbolsx):
    stocks = {}
    Lateststocks = {}

    index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
    index_df = pd.read_csv(index_csv_file)

    try:
        INDIAVIX_csv_file = "/home/rizpython236/BT5/ticker_15yr/^INDIAVIX.csv"
        INDIAVIX_df = pd.read_csv(index_csv_file)
        # INDIAVIX_df['Mean']= INDIAVIX_df['Close'].rolling(window=252).mean()
        INDIAVIX_df["Mean"] = INDIAVIX_df["Close"].rolling(window=252).median()
    except Exception as e:
        INDIAVIX_df = pd.DataFrame(columns=["Close", "Mean"])
        INDIAVIX_df["Close"] = 0
        INDIAVIX_df["Mean"] = 0

    # load data for each stock and calcuate MR12
    for file in glob.glob(data_path + "/*.csv"):
        symbol = file.split("/")[-1].replace(".csv", "")
        df = pd.read_csv(
            file, usecols=["Date", "Close", "High", "Low", "Open", "Volume"])
        # Date,Close,High,Low,Open,Volume,

        df = calculate_mrp(df, index_df)

        # log_returns = np.log(prices)-np.log(prices.shift(1))
        # Aannualized_lognormal_std = log_returns.std(axis=0) * np.sqrt(52)
        # data['ROC_3m']=tb.ROC(data['Close'], timeperiod=12)
        # Amomentum_ratio_12m = data['ROC_12m'].iloc[-1] / Aannualized_lognormal_std
        # df['Return'] = df['Close'].pct_change()
        # df['Std'] = df['Return'].rolling(window=52).std()
        # df['MR12'] = df['Return']/df['Std']
        # df= df.dropna()

        df["log_returns"] = np.log(df["Close"]) - np.log(df["Close"].shift(1))
        # df['Annualized_lognormal_std'] = df['log_returns'].std() * np.sqrt(52)

        # 12-month log return
        # df['ROC_1m'] = np.log(df['Close'] / df['Close'].shift(22))
        # df['ROC_3m'] = np.log(df['Close'] / df['Close'].shift(63))
        # df['ROC_6m'] = np.log(df['Close'] / df['Close'].shift(126))
        # df['ROC_12m'] = np.log(df['Close'] / df['Close'].shift(252))

        df["ROC_1m"] = df["Close"].pct_change(22)
        df["ROC_3m"] = df["Close"].pct_change(63)
        df["ROC_6m"] = df["Close"].pct_change(126)
        df["ROC_9m"] = df["Close"].pct_change(189)
        df["ROC_12m"] = df["Close"].pct_change(248)  # get 52 window rolling
        # df['Annualized_lognormal_std'] = df['log_returns'].rolling(window=52).std()* np.sqrt(52)
        # df['Annualized_lognormal_std'] = df['log_returns'].rolling(window=252).std()* np.sqrt(252)

        df["Annualized_lognormal_std_12m"] = df["log_returns"].rolling(
            248).std() * np.sqrt(252)
        df["Annualized_lognormal_std_9m"] = df["log_returns"].rolling(
            189).std() * np.sqrt(252)
        df["Annualized_lognormal_std_6m"] = df["log_returns"].rolling(
            126).std() * np.sqrt(252)
        df["Annualized_lognormal_std_3m"] = df["log_returns"].rolling(
            63).std() * np.sqrt(252)
        df["Annualized_lognormal_std_1m"] = df["log_returns"].rolling(
            22).std() * np.sqrt(252)

        # df['Annualized_lognormal_std_12m']= df['log_returns'].rolling(252).apply(downside_deviation, raw=True) * np.sqrt(252)
        # df['Annualized_lognormal_std_6m']= df['log_returns'].rolling(126).apply(downside_deviation, raw=True) * np.sqrt(252)
        # df['Annualized_lognormal_std_3m']= df['log_returns'].rolling(63).apply(downside_deviation, raw=True) * np.sqrt(252)
        # df['Annualized_lognormal_std_1m']= df['log_returns'].rolling(22).apply(downside_deviation, raw=True) * np.sqrt(252)
        df["MR1"] = (df["ROC_1m"] - 0.0) / df["Annualized_lognormal_std_1m"]
        df["MR3"] = (df["ROC_3m"] - 0.0) / df["Annualized_lognormal_std_3m"]
        df["MR6"] = (df["ROC_6m"] - 0.0) / df["Annualized_lognormal_std_6m"]
        df["MR9"] = (df["ROC_9m"] - 0.0) / df["Annualized_lognormal_std_9m"]
        df["MR12"] = (df["ROC_12m"] - 0.0) / df["Annualized_lognormal_std_12m"]
        cols = ["MR1", "MR3", "MR6", "MR12"]

        # df[cols] = df[cols].fillna(0.01)
        # Replace inf/-inf with NaN first
        # df[cols] = df[cols].replace([np.inf, -np.inf], np.nan)

        # Forward fill NaN
        # df[cols] = df[cols].fillna(method='ffill')
        df[cols] = df[cols].ffill()

        # Optional: fill any remaining NaN with 0 (in case first row is NaN)
        df[cols] = df[cols].fillna(0.0001)

        df["Symbol"] = symbol
        # df = df.drop(columns=['log_returns','ROC_1m', 'ROC_3m', 'ROC_6m','ROC_9m', 'ROC_12m', 'Annualized_lognormal_std_12m','Annualized_lognormal_std_6m','Annualized_lognormal_std_3m','Annualized_lognormal_std_1m'], errors='ignore')
        stocks[symbol] = df

        # df= df.drop(log_returns,ROC_3m,ROC_6m,ROC_12m,Annualized_lognormal_std,)
        # print(df.tail(5))
        # print(stocks[symbol])
        # ff
    # print(stocks)

    # Combine Dataframes of all stocks into a single dataframe
    # combined_df = functools.reduce(lambda left, right: pd.merge(left, right, on='Date'),stocks.values())

    # Initialize an empty DataFrame to store mean and std for each date
    combined_df = pd.DataFrame()  # columns=['Date', 'Mean_MR3', 'Std_MR3'])

    # Combine all stock data to calculate mean and std for MR12 across all stocks
    all_data = pd.concat(
        [df[["Date", "MR1", "MR3", "MR6", "MR9", "MR12", "Symbol"]] for df in stocks.values()])

    # Define the symbols of interest
    # symbols_of_interest = ['^CNXMEDIA','GOLDBEES.NS','^CRSLDX','^CNXIT', '^CRSMID','NIFTY_MICROCAP250.NS', '^NSEI','^CNXSC', '^NSEMDCP50','^NSEBANK','^CNXFMCG', '^CNXCONSUM', '^CNXAUTO','^CNXINFRA','^CNXENERGY','^CNXMETAL','^CNXREALTY','^CNXCMDT','^CNXPHARMA','^CNXFIN','NIFTY_HEALTHCARE.NS','^CNXPSUBANK','^CNXMNC']
    # symbols_of_interest = ['^NSEI','^CRSLDX','^CRSMID','^CNXSC','NIFTY_MICROCAP250xx.NS','^NSMIDCP', '^NSEMDCP50xx','^NSEBANKxx']

    # Check which symbols are present in the data
    # available_symbols = set(all_data['Symbol'].unique())
    available_symbols = set(
        all_data["Symbol"].unique()).intersection(symbols_of_interest)

    # If ddof=0 → divisor = n → population standard deviation.
    # If ddof=1 → divisor = n-1 → sample standard deviation (Bessel’s correction / unbiased estimator).

    # available_symbols = get_available_symbols_by_mr12(all_data, symbols_of_interest,z=2.0, ddof=1)
    print(f"available_symbols are {len(available_symbols)}")
    post_telegram_message(
        f"Available_symbols score calc {len(available_symbols)}")

    # unique_symbols = all_data['Symbol'].unique()
    # Filter for the available symbols
    filtered_data = all_data[all_data["Symbol"].isin(available_symbols)]
    # filtered_data = all_data

    # ____________________________________________
    # downside deviation function

    def downside_deviation_xx(x, mar=0):
        # mar = np.percentile(x, 25)  # 1st quartile (25th percentile)
        mar = x.mean()  # use group mean as MAR
        downside = x[x < mar]  # keep only values below MAR
        if len(downside) == 0:
            return 0.0000001
        return np.sqrt(np.mean((downside - mar) ** 2))

    # Group by 'Date' and aggregate the mean and std for 'MR3', 'MR6', and 'MR12'
    grouped = filtered_data.groupby("Date").agg({
        "MR1": ["median", "std"],
        "MR3": ["median", "std"],
        "MR6": ["median", "std"],
        "MR9": ["median", "std"],
        "MR12": ["median", "std"],
    }).reset_index()

    # rename columns
    grouped.columns = [
        "Date",
        "Mean_MR1", "Std_MR1",
        "Mean_MR3", "Std_MR3",
        "Mean_MR6", "Std_MR6",
        "Mean_MR9", "Std_MR9",
        "Mean_MR12", "Std_MR12",
    ]

    # grouped = (
    #    filtered_data
    #    .groupby('Date')
    #    .agg({
    #        'MR3': 'median',
    #        'MR6': 'median',
    #        'MR12': 'median'
    #    })
    #    .reset_index()
    # )

    """
    # Group by 'Date' and aggregate with mean and downside deviation
    grouped = filtered_data.groupby('Date').agg({
        'MR1': ['mean', downside_deviation_xx],
        'MR3': ['mean', downside_deviation_xx],
        'MR6': ['mean', downside_deviation_xx],
        'MR12': ['mean', downside_deviation_xx]
    }).reset_index()


    grouped = (
        filtered_data
        .groupby('Date')
        .agg({
            'MR1': 'mean',
            'MR3': 'mean',
            'MR6': 'mean',
            'MR12': 'mean'
        })
        .reset_index()
    )

    # Rename columns
    grouped.columns = [
        'Date',
        'Mean_MR1',
        'Mean_MR3',
        'Mean_MR6',
        'Mean_MR12'
    ]
    """

    # grouped['Std_MR1']= grouped['Mean_MR1'].rolling(22).apply(downside_deviation, raw=True)
    # grouped['Std_MR3']= grouped['Mean_MR3'].rolling(63).apply(downside_deviation, raw=True)
    # grouped['Std_MR6']= grouped['Mean_MR6'].rolling(126).apply(downside_deviation, raw=True)
    # grouped['Std_MR12']= grouped['Mean_MR12'].rolling(252).apply(downside_deviation, raw=True)  #.std()

    # grouped['Std_MR1']= grouped['Mean_MR1'].rolling(22).std()
    # grouped['Std_MR3']= grouped['Mean_MR3'].rolling(63).std()
    # grouped['Std_MR6']= grouped['Mean_MR6'].rolling(126).std()
    # grouped['Std_MR12']= grouped['Mean_MR12'].rolling(252).std()

    # eps = 1e-9
    # f['Std_MR1'] = df['Std_MR1'].replace(0, eps)
    # df['Std_MR3'] = df['Std_MR3'].replace(0, eps)
    # df['Std_MR6'] = df['Std_MR6'].replace(0, eps)
    # df['Std_MR12'] = df['Std_MR12'].replace(0, eps)

    cols_to_scale = ["Std_MR1", "Std_MR3", "Std_MR6", "Std_MR9", "Std_MR12"]
    grouped[cols_to_scale] = grouped[cols_to_scale] * 1

    grouped.columns = ["Date", "Mean_MR1", "Std_MR1", "Mean_MR3", "Std_MR3",
                       "Mean_MR6", "Std_MR6", "Mean_MR9", "Std_MR9", "Mean_MR12", "Std_MR12"]
    combined_df = grouped

    # print(combined_df.tail(17))

    # merge mean_MR12 , std_MR12 values back into individual stock dataframes
    for symbol, df in stocks.items():
        # print(len(df))
        # print(len(combined_df))
        # df =df.merge(combined_df[['Date','Mean_MR3','Std_MR3','Mean_MR6','Std_MR6','Mean_M12','Std_MR12']],on= 'Date')
        df = pd.merge(df, combined_df, on="Date", how="left")

        cols = ["Mean_MR3", "Mean_MR6", "Mean_MR12",
                "Std_MR3", "Std_MR6", "Std_MR12"]
        # Replace inf/-inf with NaN first
        # df[cols] = df[cols].replace([np.inf, -np.inf], np.nan)

        # Forward fill NaN
        # df[cols] = df[cols].fillna(method='ffill')

        # Optional: fill any remaining NaN with 0 (in case first row is NaN)
        # df[cols] = df[cols].fillna(0.01)

        # calculate score

        df["Score1m"] = (df["MR1"] - df["Mean_MR1"]) / df["Std_MR1"]
        df["Score3m"] = (df["MR3"] - df["Mean_MR3"]) / df["Std_MR3"]
        df["Score6m"] = (df["MR6"] - df["Mean_MR6"]) / df["Std_MR6"]
        df["Score9m"] = (df["MR9"] - df["Mean_MR9"]) / df["Std_MR9"]
        df["Score12m"] = (df["MR12"] - df["Mean_MR12"]) / df["Std_MR12"]
        # df['Score3m']= (df['MR3']-df['Mean_MR3'])/df['Annualized_lognormal_stdMean_MR3']
        # df['Score6m']= (df['MR6']-df['Mean_MR6'])/df['Annualized_lognormal_stdMean_MR6']
        # df['Score12m']= (df['MR12']-df['Mean_MR12'])/df['Annualized_lognormal_stdMean_MR12']

        # Az_score_3m =  (Amomentum_ratio_3m -df1['mean_momentum_3m'].iloc[-1]) / df1['std_momentum_3m'].iloc[-1]

        if 13 < INDIAVIX_df["Close"].iloc[-1] > INDIAVIX_df["Mean"].iloc[-1]:
            # df['weighted_zscore'] = 0.375 * df['Score12m'] + 0.375 * df['Score6m'] + 0.25 * df['Score3m']
            df["weighted_zscore"] = 0.216666666667 * df["Score12m"] + 0.216666666667 * df["Score9m"] + \
                0.216666666667 * df["Score6m"] + 0.25 * \
                df["Score3m"] + 0.1 * df["Score1m"]
            df["weighted_excessMR"] = 0.216666666667 * (df["MR12"] - df["Mean_MR12"]) + 0.216666666667 * (df["MR9"] - df["Mean_MR9"]) + 0.216666666667 * (
                df["MR6"] - df["Mean_MR6"]) + 0.25 * (df["MR3"] - df["Mean_MR3"]) + 0.1 * (df["MR1"] - df["Mean_MR1"])
            df["weighted_MR"] = 0.216666666667 * df["MR12"] + 0.216666666667 * \
                df["MR9"] + 0.216666666667 * df["MR6"] + \
                0.25 * df["MR3"] + 0.1 * df["MR1"]
        else:
            # df['weighted_zscore'] = 0.45 * df['Score12m'] + 0.45 * df['Score6m'] + 0.1 * df['Score3m']
            # df['weighted_zscore'] = 0.375 * df['Score12m'] + 0.375 * df['Score6m'] + 0.25 * df['Score3m']
            df["weighted_zscore"] = 0.25 * df["Score12m"] + 0.25 * df["Score9m"] + \
                0.25 * df["Score6m"] + 0.25 * \
                df["Score3m"] + 0.00 * df["Score1m"]
            df["weighted_excessMR"] = 0.25 * (df["MR12"] - df["Mean_MR12"]) + 0.25 * (df["MR9"] - df["Mean_MR9"]) + 0.25 * (
                df["MR6"] - df["Mean_MR6"]) + 0.25 * (df["MR3"] - df["Mean_MR3"]) + 0.0 * (df["MR1"] - df["Mean_MR1"])
            df["weighted_MR"] = 0.25 * df["MR12"] + 0.25 * df["MR9"] + \
                0.25 * df["MR6"] + 0.25 * df["MR3"] + 0.0 * df["MR1"]

        # df['weighted_zscore'] = 0.45 * df['Score12m'] + 0.45 * df['Score6m'] + 0.1 * df['Score3m']  #0.475*2+0.05
        # df['normalized_score'] = (1 + df['weighted_zscore']) * (df['weighted_zscore'] >= 0) + (1 / (1 - df['weighted_zscore']))**(-1) * (df['weighted_zscore'] < 0)
        # df['normalized_score'] = np.where(
        #    df['weighted_zscore'] >= 0,
        #    1 + df['weighted_zscore'],    # case A: positive
        #    1 - df['weighted_zscore']     # case B: negative
        # )

        # z = df['weighted_zscore']

        df["Score"] = np.where(
            df["weighted_zscore"] >= 0,
            1 + df["weighted_zscore"],          # case Z >= 0
            1 / (1 - df["weighted_zscore"]),     # case Z < 0
         )

        #df["Score"] = np.where(
        #    df["weighted_zscore"] >= 0,
        #    1 + df["weighted_zscore"],          # case Z >= 0
        #    df["weighted_zscore"],     # case Z < 0
        #)

        #df['Score'] = np.where(
        #    (df['Score3m'] >= 0) & (df['weighted_zscore'] >= 0),
        #    1 + df['weighted_zscore'],                 # case Score3m >= 0 and Z >= 0
        #    1 / (1 - df['weighted_zscore'])            # else
        # )

        df["Score"] = round(df["Score"], 3)
        df["weighted_excessMR"] = round(df["weighted_excessMR"], 3)
        df["weighted_MR"] = round(df["weighted_MR"], 3)

        df.iloc[-1] = df.iloc[-1].bfill().ffill()
        df.ffill(inplace=True)
        df.fillna(0, inplace=True)

        # df['Score'] =round(df['normalized_score'],4)
        # print(df['Score'] )

        Lateststocks[symbol] = df

        df = df.drop(columns=["Symbol", "Annualized_lognormal_std_12m", "Annualized_lognormal_std_9m", "Annualized_lognormal_std_6m", "MR1", "MR3", "MR6", "MR9", "MR12", "ROC_12m", "Mean_MR1", "Mean_MR3", "Mean_MR6",
                     "Mean_MR9", "Mean_MR12", "Std_MR1", "Std_MR3", "Std_MR6", "Std_MR9", "Std_MR12", "Score1m", "Score3m", "Score6m", "Score9m", "Score12m", "weighted_zscore", "normalized_score"], errors="ignore")
        df = df.drop(columns=["log_returns", "ROC_1m", "ROC_3m", "ROC_6m", "ROC_9m", "ROC_12m", "Annualized_lognormal_std_12m",
                     "Annualized_lognormal_std_6m", "Annualized_lognormal_std_3m", "Annualized_lognormal_std_1m"], errors="ignore")
        # df = df.drop(columns=['log_returns', 'ROC_3m', 'ROC_6m', 'ROC_12m', 'Annualized_lognormal_std'], errors='ignore')
        # df['Score'].fillna(0.0000, inplace=True)
        # df['Score'].replace([np.inf, -np.inf], np.nan, inplace=True)

        # Then forward-fill NaN values
        # df['Score'].fillna(method='ffill', inplace=True)
        stocks[symbol] = df
        # print(stocks[symbol])
        # print(symbol)
        file_path = data_pathpathlib / f"{symbol}.csv"
        # print(file_path)
        df.to_csv(file_path, index=False)
        #print(df[["Score", "weighted_excessMR", "weighted_MR","weighted_zscore","Score12m","Score9m", "Score6m", "Score3m", "Score1m"]].tail(5))
        # df.to_csv(symbol+".csv", index=False)


    # -------------------------
    # NEW: collect latest row per symbol
    latest_rows = []
    for symbol, df in Lateststocks.items():
        if not df.empty:
            last = df.iloc[-1].copy()
            last["Symbol"] = symbol
            latest_rows.append(last)

    # latest_df = pd.DataFrame(latest_rows)[[
    #    'Symbol','ROC_1m', 'ROC_3m', 'ROC_6m','ROC_9m', 'ROC_12m',
    #    'MR1','MR3','MR6','MR9','MR12',
    #    'Mean_MR1','Mean_MR3','Mean_MR6','Mean_MR9','Mean_MR12',
    #    'Std_MR1','Std_MR3','Std_MR6','Std_MR9','Std_MR12',
    #    'Score1m','Score3m','Score6m','Score9m','Score12m','Score'
    # ]]

    # Build DataFrame using all available columns in latest_rows
    latest_df = pd.DataFrame(latest_rows)

    # Reorder so 'Symbol' comes first, keep the rest as-is
    cols = ["Symbol"] + [c for c in latest_df.columns if c != "Symbol"]
    latest_df = latest_df[cols]

    try:
        1+1
        #avgScore(Lateststocks, symbolsx)
    except Exception as e:
        print(f"Error occurred: {e!s}")

    return stocks, latest_df

    # return stocks
    # print(stocks)


stocks, latest_df = calculate_scores(data_path, symbolsx)



if latest_df["MR12"].mean() == 0 or latest_df["Score"].mean() == 0:
    print("Mean of MR12/Score is 0.0")
    post_telegram_message("Mean of MR12/Score is 0.0 so Exit")
    sys.exit(1)
    # do something
else:
    print("Mean of MR12/Score is positive")
    # do something else


def plot_histograms(df, columns, bins=60, figsize=(18, 12), labelx="Histogram", n_colsx=5):
    try:
        """Plot histograms with density curves for selected columns in a grid layout.
        Outlier bins (based on 1.5*IQR rule) are shaded in orange.
        """
        n_cols = n_colsx
        n_rows = -(-len(columns) // n_cols)  # ceiling division

        fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize)
        axes = axes.flatten()

        for i, col in enumerate(columns):
            ax = axes[i]
            series = df[col].dropna()

            # ---- Outlier detection (IQR method) ----
            q1 = series.quantile(0.25)
            q3 = series.quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr

            # Plot histogram first
            counts, bin_edges, patches = ax.hist(
                series, bins=bins, density=True, alpha=0.6, label=col)

            # Shade bins outside IQR bounds
            for patch, left, right in zip(patches, bin_edges[:-1], bin_edges[1:]):
                if right < lower_bound or left > upper_bound:
                    patch.set_facecolor("orange")
                    patch.set_alpha(0.7)

            # Vertical lines for outlier thresholds
            # ax.axvline(lower_bound, color="blue", linestyle="--", linewidth=1.2, label="Lower Bound")
            # ax.axvline(upper_bound, color="blue", linestyle="--", linewidth=1.2, label="Upper Bound")

            # Vertical lines for actual min and max values
            ax.axvline(series.min(), color="red", linestyle="--",
                       linewidth=1.2, label="Min")
            ax.axvline(series.max(), color="green",
                       linestyle="--", linewidth=1.2, label="Max")
            ax.axvline(series.mean(), color="pink",
                       linestyle="-.", linewidth=1.2, label="Mean")

            # Add KDE
            series.plot(kind="kde", ax=ax, color="brown", label="Density")

            # Add mean text
            mean_val = series.mean()
            ax.text(0.05, 0.95, f"Mean: {mean_val:.2f}",
                    transform=ax.transAxes, fontsize=12,
                    verticalalignment="top", horizontalalignment="left",
                    bbox=dict(facecolor="white", alpha=0.6, edgecolor="none"))

            ax.set_title(col)
            ax.legend()

        # Hide empty subplots if any
        for j in range(i + 1, len(axes)):
            fig.delaxes(axes[j])

        plt.tight_layout()
        # plt.show()
        folder_path = "/home/rizpython236/BT5/screener-outputs/"
        file_path = os.path.join(folder_path)
        chart_path = os.path.join(folder_path, f"Histogram {labelx}.png")
        plt.savefig(chart_path)
        time.sleep(5)
        post_telegram_file(chart_path)
        os.remove(chart_path)
    except Exception as e:
        print(f"Error occurred: {e!s}")
        traceback_str = traceback.format_exc()


try:
    1 + 1
    plot_histograms(latest_df, ["ROC_1m", "ROC_3m", "ROC_6m",
                    "ROC_9m", "ROC_12m"], labelx="Histogram ROC", n_colsx=3)
    plot_histograms(latest_df, ["Annualized_lognormal_std_1m", "Annualized_lognormal_std_3m", "Annualized_lognormal_std_6m",
                    "Annualized_lognormal_std_9m", "Annualized_lognormal_std_12m"], labelx="Histogram Annualized_lognormal_std", n_colsx=3)
    # 'ROC_1m', 'ROC_3m', 'ROC_6m','ROC_9m', 'ROC_12m'
    plot_histograms(latest_df, ["MR1", "MR3", "MR6",
                    "MR9", "MR12"], labelx="Histogram MR", n_colsx=3)
    # plot_histograms(latest_df, ["Mean_MR1", "Mean_MR3", "Mean_MR6",
    #                "Mean_MR9", "Mean_MR12"], labelx="Histogram MR Mean", n_colsx=5)
    plot_histograms(latest_df, ["Std_MR1", "Std_MR3", "Std_MR6",
                    "Std_MR9", "Std_MR12"], labelx="Histogram Std MR", n_colsx=5)
    plot_histograms(latest_df, [
                    "weighted_MR", "weighted_excessMR", "Score"], labelx="Histogram Score", n_colsx=1)
    plot_histograms(latest_df, ["Score1m", "Score3m", "Score6m", "Score9m",
                    "Score12m", "Score"], labelx="Histogram Score", n_colsx=3)
    # plot_histograms(latest_df, ["Score"] ,labelx = "Histogram",n_colsx =1)
except Exception as e:
    print(f"Error occurred: {e!s}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    # print("Error type:", e.__class__.__name__)
    # print("Error message:", str(e))
    # print("Traceback:\n", traceback_str)


def plot_index_close_prices(folder_path, index_names, index_csv_file=None, Frequency=None):
    """Plot the Close Price of multiple indices in a single chart for comparison.
    - x-axis labels are displayed on a quarterly basis.
    - Different colors and line styles are used for each index line.
    - Line styles change after every 16 indices.

    Parameters
    ----------
    - folder_path: Path to the folder containing the index CSV files.
    - index_names: List of index names (e.g., ['Autoindex', 'FMCGindex']).

    """
    def calculate_rolling_mrp(stock_csv_file, window=252, index_csv_file=None, Frequency=None):
        """Calculates the rolling Market Relative Performance (MRP) for a given stock over a specified window.

        Args:
            stock_csv_file (str): Path to the CSV file containing stock data.
            window (int): Rolling window size in trading days (default is 252).

        Returns:
            pandas.Series: Series containing the rolling MRP values for the stock.

        """
        # Path to the index data file
        # index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

        # Load stock and index data
        # usecols=['Date','High', 'Low', 'Close'])
        stock_data = pd.read_csv(stock_csv_file, usecols=[
                                 "Date", "High", "Low", "Close", "Volume", "Score"])
        nifty_data = pd.read_csv(index_csv_file, usecols=[
                                 "Date", "High", "Low", "Close", "Volume", "Score"])  # usecols=['Date', 'Close'])
        if Frequency == "Wk":
            stock_data = stock_data[-52:]
            nifty_data = nifty_data[-52:]
        elif Frequency == "Daily":
            stock_data = stock_data[-252:]
            nifty_data = nifty_data[-252:]
        elif Frequency == "All52wk":
            stock_data = stock_data[-52:]
            nifty_data = nifty_data[-52:]
        elif Frequency == "All200daily":
            stock_data = stock_data[-252:]
            nifty_data = nifty_data[-252:]
        else:
            # Frequency == 'Allfull'
            stock_data = stock_data[:]
            nifty_data = nifty_data[:]

        stock_data = stock_data.reset_index(drop=True)
        nifty_data = nifty_data.reset_index(drop=True)
        window = min(len(stock_data), len(nifty_data)) - 10

        # Ensure the data is sorted by date
        stock_data["Date"] = pd.to_datetime(stock_data["Date"])
        nifty_data["Date"] = pd.to_datetime(nifty_data["Date"])
        # stock_data = stock_data.sort_values('Date')
        # nifty_data = nifty_data.sort_values('Date')

        # Merge stock and index data on the 'Date' column
        merged_data = pd.merge(stock_data, nifty_data,
                               on="Date", suffixes=("_stock", "_nifty"))
        # print(merged_data)

        # Find the row with the minimum Close price
        # min_close_row = merged_data['Close_nifty'].idxmin()

        # Slice the DataFrame from the row with the minimum Close price to the end
        # merged_data = merged_data.loc[min_close_row:]

        # Reset the index (optional)
        # merged_data = merged_data.reset_index(drop=True)

        # Calculate daily returns
        merged_data["stock_returns"] = merged_data["Close_stock"].pct_change()
        merged_data["nifty_returns"] = merged_data["Close_nifty"].pct_change()

        # Calculate rolling cumulative returns for stock and index
        # (1 + merged_data['stock_returns']).rolling(window=window, min_periods=1).apply(np.prod, raw=True) - 1
        merged_data["stock_cumreturns"] = (
            1 + merged_data["stock_returns"]).cumprod()
        # (1 + merged_data['nifty_returns']).rolling(window=window, min_periods=1).apply(np.prod, raw=True) - 1
        merged_data["nifty_cumreturns"] = (
            1 + merged_data["nifty_returns"]).cumprod()

        # Calculate rolling MRP (Market Relative Performance)
        merged_data["MRP"] = (1 + merged_data["stock_cumreturns"]
                              * 100) / (1 + merged_data["nifty_cumreturns"] * 100)
        if Frequency == "Daily" or Frequency == "All200daily":
            merged_data["RSI"] = tb.RSI(
                merged_data["Close_stock"], timeperiod=14)
        else:
            merged_data["RSI"] = tb.RSI(
                merged_data["Close_stock"], timeperiod=14)

        if Frequency == "Daily" or Frequency == "All200daily" or Frequency == "Wk" or Frequency == "All52wk":
            merged_data["CCI"] = tb.CCI(
                merged_data["High_stock"], merged_data["Low_stock"], merged_data["Close_stock"], timeperiod=34)
        else:
            merged_data["CCI"] = tb.CCI(
                merged_data["High_stock"], merged_data["Low_stock"], merged_data["Close_stock"], timeperiod=34)

        # Round MRP to 3 decimal places
        merged_data["MRP"] = merged_data["MRP"].round(3).ffill()
        # stock_data['MRP'] = merged_data['MRP'].fillna(method='ffill')
        stock_data["MRP"] = merged_data["MRP"].ffill()
        # stock_data['Nifty50'] =merged_data['nifty_cumreturns'].round(3).ffill()

        # Get the first value of the 'Close' column
        first_value = merged_data["Close_nifty"].iloc[0]
        merged_data["Nifty50"] = round(
            (merged_data["Close_nifty"] / first_value) * 1, 3)
        merged_data["Nifty50"] = merged_data["Nifty50"].round(3).ffill()
        merged_data["Close_nifty"] = merged_data["Close_nifty"].round(2)
        stock_data["Nifty50"] = merged_data["Nifty50"].round(3).ffill()

        # print(merged_data)
        # Return the MRP series
        # return stock_data[['Date', 'MRP','Nifty50']]
        return merged_data

    # index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
    nifty_data = pd.read_csv(index_csv_file, usecols=["Date", "Close"])
    if Frequency == "Wk":
        file_label = "52wk"
        nifty_data = nifty_data[-52:]
    elif Frequency == "Daily":
        file_label = "200day"
        nifty_data = nifty_data[-252:]
    elif Frequency == "All52wk":
        file_label = "All52wk"
        nifty_data = nifty_data[-52:]
    elif Frequency == "All200daily":
        file_label = "All200daily"
        nifty_data = nifty_data[-252:]
    else:
        # Frequency == 'Allfull'
        file_label = "Allfull"
        nifty_data = nifty_data[:]

    nifty_data["Date"] = pd.to_datetime(nifty_data["Date"])

    # Get the first value of the 'Close' column
    first_value = nifty_data["Close"].iloc[0]
    nifty_data["Close"] = round((nifty_data["Close"] / first_value) * 1, 3)
    nifty_data["Nifty50"] = nifty_data["Close"].round(3).ffill()

    index_constituents = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
    index_constituents = pd.read_csv(index_constituents)
    Index_to_Longname = dict(
        zip(index_constituents["Symbol"], index_constituents["Company"]))

    plt.figure(figsize=(22, 18))  # Set the figure size
    plt.title("Comparison of Index MRP levels.")
    plt.xlabel("Date", fontsize=12)
    plt.ylabel("Close MRP (Indexed to 1)", fontsize=10)
    plt.grid(True)  # Add a grid for better readability

    def niftyplot(file_path=None, window=252, index_csv_file=index_csv_file, Frequency=Frequency):
        nifty_data1 = calculate_rolling_mrp(
            file_path, window=252, index_csv_file=index_csv_file, Frequency=Frequency)
        Long_Name = f"Nifty50_{nifty_data1['Nifty50'].iloc[-1]}"
        # print(Long_Name)
        plt.plot(nifty_data1["Date"], nifty_data1["Nifty50"],
                 label=Long_Name, linestyle="--", color="black")
        plt.text(nifty_data1["Date"].iloc[-1], nifty_data1["Nifty50"].iloc[-1], Long_Name, fontsize=11, color="black",
                 va="baseline", ha="left", backgroundcolor="white")
        # Find the date and value of the Min Nifty price
        min_nifty_price = nifty_data1["Close_nifty"].min()
        min_nifty_date = nifty_data1.loc[nifty_data1["Close_nifty"].idxmin(
        ), "Date"]
        min_nifty_date_str = min_nifty_date.strftime("%Y-%m-%d")
        # Find the date and value of the maximum Nifty price
        max_nifty_price = nifty_data1["Close_nifty"].max()
        max_nifty_date = nifty_data1.loc[nifty_data1["Close_nifty"].idxmax(
        ), "Date"]
        # Format the date as a string without the time
        max_nifty_date_str = max_nifty_date.strftime("%Y-%m-%d")

        # Add a vertical line at the date of maximum Nifty price
        plt.axvline(x=max_nifty_date, color="red", linestyle="-", linewidth=1,
                    label=f"Nifty Max: {max_nifty_price}-{max_nifty_date_str}")
        # Add a vertical line at the date of min Nifty price
        plt.axvline(x=min_nifty_date, color="green", linestyle="-", linewidth=1,
                    label=f"Nifty Min: {min_nifty_price}-{min_nifty_date_str}")

        return min_nifty_date, max_nifty_date

    # Define a list of colors for the lines
    colors = ["yellow", "red", "blue", "green", "purple", "orange", "brown", "teal",
              "fuchsia", "gold", "darkcyan", "limegreen", "magenta", "pink", "grey"]

    # Define a list of line styles
    line_styles = ["-", "--", "-.", ":"]

    no = 0
    run = False
    for i, index_name in enumerate(index_names):
        Long_Name1 = Index_to_Longname.get(index_name)
        # Construct the file name
        file_name = f"{index_name}.csv"
        file_path = os.path.join(folder_path, file_name)

        # Check if the file exists
        if not os.path.exists(file_path):
            print(f"File {file_path} not found. Skipping.")
            continue

        if run == False:
            niftyplot(file_path=file_path, window=252,
                      index_csv_file=index_csv_file, Frequency=Frequency)
            run = True

        # Read the index data
        # index_data = pd.read_csv(file_path)
        index_data = calculate_rolling_mrp(
            file_path, window=252, index_csv_file=index_csv_file, Frequency=Frequency)

        # Convert the 'Date' column to datetime format
        index_data["Date"] = pd.to_datetime(index_data["Date"])
        # index_data['MRP'] = index_data['MRP'].fillna(method='ffill')
        index_data["MRP"] = index_data["MRP"].ffill()
        # index_data["RSI"] = tb.RSI(index_data['Close'], timeperiod=34)

        # print(index_data.tail())

        # Determine the line style based on the index number
        line_style = line_styles[no % len(line_styles)]

        if (index_data["Score_stock"].iloc[-1] > 1 and index_data["Score_stock"].iloc[-2] > 1 and index_data["MRP"].iloc[-1] * 100 > nifty_data["Nifty50"].iloc[-1] * 1.1 and index_data["RSI"].iloc[-1] > 50 and index_data["CCI"].iloc[-1] > 0) or (index_data["Score_stock"].iloc[-1] < 1 and index_data["Score_stock"].iloc[-2] < 1 and index_data["MRP"].iloc[-1] < nifty_data["Nifty50"].iloc[-1] * 100 and index_data["RSI"].iloc[-1] < 50 and index_data["CCI"].iloc[-1] < 0):
            # if (index_data['MRP'].iloc[-1] > nifty_data['Nifty50'].iloc[-1]*1.1 and index_data["RSI"].iloc[-1] > 55 and index_data["CCI"].iloc[-1] > 10) or (index_data['MRP'].iloc[-1] < nifty_data['Nifty50'].iloc[-1] and index_data["RSI"].iloc[-1] < 45 and index_data["CCI"].iloc[-1] < 10) :
            # line_style = line_styles[(no // 16) % len(line_styles)]
            Long_Name = f"{Long_Name1}_{index_data['MRP'].iloc[-1]}"
            if Long_Name1 == None:
                print(Long_Name, index_name)
            # print(f" Plot Index {Long_Name} & {index_name}")
            # print(Long_Name)
            # Plot the Close_Index column with a unique color and line style
            plt.plot(index_data["Date"], index_data["MRP"],
                     label=Long_Name, linestyle=line_style, color=colors[no % len(colors)])

            last_date = index_data["Date"].iloc[-1]
            last_mrp = index_data["MRP"].iloc[-1]
            plt.text(last_date, last_mrp, Long_Name, fontsize=11, color=colors[no % len(colors)],
                     va="baseline", ha="left", backgroundcolor="white")
            no += 1
        else:
            Long_Name = f"{Long_Name1}_{index_data['MRP'].iloc[-1]}"
            print(
                f"Index is betwwen {index_data['Nifty50'].iloc[-1]} & 2 {Long_Name},{index_name}")

    # Add a legend
    # plt.legend(loc='upper left', fontsize=9)
    plt.legend(ncol=2, loc="upper left", fontsize=16)

    # Format x-axis to show labels on a quarterly basis
    plt.gca().xaxis.set_major_locator(
        mdates.MonthLocator(interval=1))  # Quarterly labels  3
    plt.gca().xaxis.set_major_formatter(
        mdates.DateFormatter("%Y-%m"))  # Format as 'YYYY-MM'

    # Rotate x-axis labels for better readability
    # plt.xticks(rotation=25)
    plt.xticks(rotation=90, ha="right")

    # Show the plot
    plt.tight_layout()

    # plt.show()
    folder_path = "/home/rizpython236/BT5/screener-outputs/"
    file_path = os.path.join(folder_path)
    chart_path = os.path.join(
        folder_path, f"TJI_IndicesScore_{file_label}.png")
    plt.savefig(chart_path)
    time.sleep(3)
    post_telegram_file(chart_path)
    os.remove(chart_path)


try:
    # Load index constituents from a CSV file
    csv_path = "/home/rizpython236/BT5/trade-logs/index_constituents.csv"
    index_constituents = load_index_constituents_from_csv(csv_path)
    path = TICKER_CSV_DATA_FOLDER_PATH  # '/home/rizpython236/BT5/ticker_15yr'
    # Calculate indices
    # valid_tickers = []
    # calculate_custom_index(path, index_constituents, weighting_method='return_equal', valid_tickers=valid_tickers) #Choose 'price', 'Price_equal', return_equal or 'custom'." RSI  ATR

    index_names = ["TJI_RTGAGY", "TJI_alkCHE"]
    # Define the index names to plot
    TJI_IC_path = "/home/rizpython236/BT5/trade-logs/TJI_index.csv"
    TJI_IC_path = pd.read_csv(TJI_IC_path)
    # numberlen = len(TJI_IC_path)
    TJI_IC_path = TJI_IC_path["Symbol"].tolist()[:]
    # TJI_IC_path = list(set(TJI_IC_path))

    index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
    # path=  '/home/rizpython236/BT5/ticker_15yr'
    # Plot the Close Prices of the indices
    # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(
        path, TJI_IC_path[:33], index_csv_file, Frequency="Daily")
    # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(
        path, TJI_IC_path[33:], index_csv_file, Frequency="Daily")
    # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(
        path, TJI_IC_path[:], index_csv_file, Frequency="All200daily")

except Exception as e:
    print(f"Error occurred: {e!s}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    # print("Error type:", e.__class__.__name__)
    # print("Error message:", str(e))
    print("Traceback:\n", traceback_str)

print("Done BTmombroker")
