import alphalens as al
import pandas as pd
import pandas_ta as ta
import yfinance as yf


# ------------------------------
# 1. Download price data
# ------------------------------
symbols = ["RELIANCE.NS", "TCS.NS", "INFY.NS"]  # Add more NSE/BSE tickers
prices = yf.download(symbols, start="2020-01-01", end="2025-01-01")["Adj Close"]

# ------------------------------
# 2. Create factor (RSI)
# ------------------------------
rsi_data = {}
for symbol in symbols:
    df = prices[[symbol]].dropna().copy()
    df["RSI"] = ta.rsi(df[symbol], length=14)
    rsi_data[symbol] = df["RSI"]

factors = pd.concat(rsi_data, axis=1)
factors = factors.stack().reset_index()
factors.columns = ["date", "asset", "RSI"]

# ------------------------------
# 3. Prepare data for Alphalens
# ------------------------------
# Align factor values with forward returns
factor_data = al.utils.get_clean_factor_and_forward_returns(
    factor=factors.set_index(["date", "asset"])["RSI"],
    prices=prices,
    periods=(1, 5, 10)  # forward return horizons in days
)

# ------------------------------
# 4. Run Alphalens analysis
# ------------------------------
# Information Coefficient (predictive power)
al.performance.factor_information_coefficient(factor_data)

# Factor returns by quantile
al.performance.mean_return_by_quantile(factor_data)

# Tearsheet (full report with plots)
al.tears.create_full_tear_sheet(factor_data)
