"""
Portfolio Tracker — Full Final Script
Features:
- SAMPLE files fallback if missing
- FIFO lot accounting, splits/bonus adjustments
- No short positions, no fractional STOCK units
- Dividends, fees, partial sells
- Per-unit cost, latest price (yfinance + fallback)
- Realized & Unrealized P/L amounts and percentages
- Holding duration
- XIRR per symbol and portfolio using numpy_financial.xirr
- Single Excel workbook with sheets: Open_Positions, Closed_Positions, Sector, Industry, Asset_Type, Portfolio
- CSV exports for each sheet
- Verbose prints for important operations
"""

import os
from datetime import datetime, date
from collections import deque, defaultdict
import pandas as pd
import numpy as np
import yfinance as yf
import numpy_financial as nf

# ---------------------------
# SAMPLE DATA (used if files missing)
# ---------------------------
SAMPLE_TRANSACTIONS = """Date,Type,Symbol,Units,Price,Fees,Ratio
2023-01-05,BUY,RELIANCE.NS,10,2300,20,
2023-01-05,Split,RELIANCE.NS,,,,2
2023-03-10,BUY,TCS.NS,5,3300,15,
2024-02-15,BUY,AXISMF,1000,10.5,0,
2024-07-20,SELL,RELIANCE.NS,3,2500,20,
2025-01-10,DIV,TCS.NS,,50,0,
"""

SAMPLE_MAPPING = """symbol,name,sector,industry,asset_type
RELIANCE.NS,Reliance Industries,Energy,Integrated Oil & Gas,STOCK
TCS.NS,Tata Consultancy Services,Technology,IT Services,STOCK
AXISMF,Axis Mutual Fund,Financials,Mutual Fund,MF
"""

TRANSACTIONS_FILE = "transactions.csv"
MAPPING_FILE = "mapping.csv"
REPORT_XLSX = "master_report.xlsx"
REPORT_DIR = "reports"


# ---------------------------
# Utilities
# ---------------------------
def ensure_sample_files():
    if not os.path.exists(TRANSACTIONS_FILE):
        print(
            f"[INFO] {TRANSACTIONS_FILE} not found — creating from SAMPLE_TRANSACTIONS"
        )
        with open(TRANSACTIONS_FILE, "w", encoding="utf-8", newline="") as f:
            f.write(SAMPLE_TRANSACTIONS)
    else:
        print(f"[INFO] Found {TRANSACTIONS_FILE}")

    if not os.path.exists(MAPPING_FILE):
        print(f"[INFO] {MAPPING_FILE} not found — creating from SAMPLE_MAPPING")
        with open(MAPPING_FILE, "w", encoding="utf-8", newline="") as f:
            f.write(SAMPLE_MAPPING)
    else:
        print(f"[INFO] Found {MAPPING_FILE}")

    if not os.path.exists(REPORT_DIR):
        os.makedirs(REPORT_DIR)


def parse_date(x):
    if pd.isna(x):
        return None
    if isinstance(x, (datetime, date)):
        return x.date() if isinstance(x, datetime) else x
    try:
        return pd.to_datetime(x).date()
    except:
        return None


def float_or_zero(x):
    try:
        if pd.isna(x):
            return 0.0
        return float(x)
    except:
        return 0.0


# ---------------------------
# Data models
# ---------------------------
class Lot:
    """Represents a buy lot."""

    def __init__(self, units, unit_cost, total_cost, buy_date):
        self.units = float(units)
        self.unit_cost = float(unit_cost)
        self.total_cost = float(total_cost)
        self.buy_date = parse_date(buy_date)

    def __repr__(self):
        return f"Lot(units={self.units}, unit_cost={self.unit_cost}, total_cost={self.total_cost}, buy_date={self.buy_date})"


class Position:
    """Track a symbol: active lots (FIFO), realized P/L, dividends, fees"""

    def __init__(self, symbol, meta):
        self.symbol = symbol
        self.meta = meta
        self.lots = deque()  # FIFO: deque of Lot
        self.realized_amount = 0.0
        self.realized_details = []  # list of dicts with sell info
        self.dividends = 0.0
        self.fees = 0.0
        self.transactions = (
            []
        )  # list of (date, amount) for XIRR (negative buys, positive sells/divs)

    def total_units(self):
        return sum(l.units for l in self.lots)

    def total_cost(self):
        return sum(l.total_cost for l in self.lots)

    def avg_unit_cost(self):
        units = self.total_units()
        return (self.total_cost() / units) if units != 0 else 0.0

    def add_buy(self, units, price, fees, buy_date):
        asset_type = self.meta.get("asset_type", "STOCK").upper()
        if asset_type == "STOCK":
            # Disallow fractional stocks: round down with warning
            if float(units) != int(float(units)):
                print(
                    f"[WARN] BUY fractional units for STOCK {self.symbol}: requested {units}. Rounding down to integer."
                )
            units = int(float(units))
        units = float(units)
        if units <= 0:
            print(f"[ERROR] BUY with non-positive units ignored for {self.symbol}")
            return
        total_cost = units * float(price) + float(fees or 0.0)
        unit_cost = total_cost / units
        lot = Lot(
            units=units, unit_cost=unit_cost, total_cost=total_cost, buy_date=buy_date
        )
        self.lots.append(lot)
        self.fees += float(fees or 0.0)
        self.transactions.append((parse_date(buy_date), -total_cost))
        print(
            f"[BUY] {self.symbol} | Date: {buy_date} | Units: {units} | Price: {price} | Fees: {fees} | TotalCost: {total_cost:.2f}"
        )

    def apply_split(self, ratio, event_date, event_type="Split"):
        ratio = float(ratio)
        if ratio <= 0:
            print(
                f"[ERROR] Invalid ratio {ratio} for {self.symbol} {event_type}. Ignored."
            )
            return
        if not self.lots:
            print(f"[WARN] {event_type} for {self.symbol} but no active lots.")
            return
        print(
            f"[ADJUSTMENT] {event_type} for {self.symbol} on {event_date} with ratio {ratio}."
        )
        for i, lot in enumerate(self.lots):
            old_units = lot.units
            old_unit_cost = lot.unit_cost
            lot.units = lot.units * ratio
            # total_cost remains same; unit_cost adjusted
            lot.unit_cost = lot.total_cost / lot.units if lot.units != 0 else 0.0
            print(
                f"  Lot {i}: units {old_units} -> {lot.units}, unit_cost {old_unit_cost:.4f} -> {lot.unit_cost:.4f}"
            )
        # record adjustment as a zero cashflow transaction for audit
        self.transactions.append((parse_date(event_date), 0.0))

    def add_dividend(self, amount, div_date, per_unit=False):
        amount = float(amount)
        dividends_received = amount
        if per_unit:
            dividends_received = amount * self.total_units()
        self.dividends += dividends_received
        self.transactions.append((parse_date(div_date), dividends_received))
        print(
            f"[DIVIDEND] {self.symbol} | Date: {div_date} | Amount: {dividends_received:.2f}"
        )

    def sell(self, units_to_sell, price, fees, sell_date):
        units_to_sell = float(units_to_sell)
        asset_type = self.meta.get("asset_type", "STOCK").upper()
        if asset_type == "STOCK":
            if float(units_to_sell) != int(float(units_to_sell)):
                print(
                    f"[WARN] SELL fractional units for STOCK {self.symbol}: requested {units_to_sell}. Rounding down to integer."
                )
            units_to_sell = int(float(units_to_sell))
        available = self.total_units()
        if units_to_sell <= 0:
            print(f"[ERROR] Sell with non-positive units ignored for {self.symbol}")
            return
        if units_to_sell > available + 1e-9:
            print(
                f"[ERROR] Cannot sell {units_to_sell} units of {self.symbol} — only {available} available. No shorting allowed. Transaction ignored."
            )
            return

        proceeds_total = 0.0
        cost_removed = 0.0
        units_remaining = units_to_sell

        while units_remaining > 0 and self.lots:
            lot = self.lots[0]
            take = min(lot.units, units_remaining)
            cost_for_take = lot.unit_cost * take
            proceeds = take * float(price)
            proceeds_total += proceeds
            cost_removed += cost_for_take

            # adjust lot
            lot.units -= take
            lot.total_cost -= cost_for_take
            if lot.units <= 1e-9:
                buy_date = lot.buy_date
                # record closed lot info in realized_details with buy_date for duration
                self.realized_details.append(
                    {
                        "symbol": self.symbol,
                        "buy_date": buy_date,
                        "sell_date": parse_date(sell_date),
                        "units": take,
                        "buy_price": lot.unit_cost,
                        "sell_price": price,
                        "cost": cost_for_take,
                        "proceeds": proceeds,
                    }
                )
                self.lots.popleft()
            units_remaining -= take
            print(
                f"  [LOT_CONSUMED] {self.symbol} took {take} units from lot | cost_for_take {cost_for_take:.2f} | proceeds {proceeds:.2f}"
            )

        fees = float(fees or 0.0)
        net_proceeds = proceeds_total - fees
        realized = net_proceeds - cost_removed
        self.realized_amount += realized
        self.fees += fees
        self.transactions.append((parse_date(sell_date), net_proceeds))
        print(
            f"[SELL] {self.symbol} | Date: {sell_date} | Units sold: {units_to_sell} | Proceeds: {proceeds_total:.2f} | Fees: {fees:.2f} | CostRemoved: {cost_removed:.2f} | Realized P/L: {realized:.2f}"
        )


# ---------------------------
# Load files and mapping
# ---------------------------
ensure_sample_files()

tx = pd.read_csv(TRANSACTIONS_FILE, parse_dates=["Date"], dayfirst=False)
mapping_df = pd.read_csv(MAPPING_FILE)

# build mapping dict with default meta
mapping = {}
for _, r in mapping_df.iterrows():
    sym = r["symbol"]
    mapping[sym] = {
        "symbol": sym,
        "name": r.get("name", ""),
        "sector": r.get("sector", ""),
        "industry": r.get("industry", ""),
        "asset_type": r.get("asset_type", "STOCK"),
    }

# ---------------------------
# Main processing: iterate transactions chronological
# ---------------------------
tx = tx.sort_values("Date").reset_index(drop=True)
positions = {}  # symbol -> Position

for idx, row in tx.iterrows():
    ttype = str(row["Type"]).strip()
    symbol = str(row["Symbol"]).strip()
    units = row.get("Units", None)
    price = row.get("Price", None)
    fees = row.get("Fees", 0.0)
    ratio = row.get("Ratio", None)
    tx_date = parse_date(row["Date"])

    meta = mapping.get(
        symbol,
        {
            "symbol": symbol,
            "name": symbol,
            "sector": "",
            "industry": "",
            "asset_type": "STOCK",
        },
    )
    if symbol not in positions:
        positions[symbol] = Position(symbol, meta)
    pos = positions[symbol]

    ttype_up = ttype.upper()
    if ttype_up == "BUY":
        if pd.isna(price) or price == 0:
            # try get latest price then ask user
            latest = None
            try:
                latest = yf.Ticker(symbol).history(period="5d")["Close"].iloc[-1]
            except Exception:
                latest = None
            if latest is None or np.isnan(latest):
                while True:
                    s = input(
                        f"[INPUT] Price missing for BUY {symbol} on {tx_date}. Enter price: "
                    ).strip()
                    try:
                        price = float(s)
                        break
                    except:
                        print("  Invalid number, try again.")
            else:
                price = float(latest)
                print(f"[INFO] Using latest yfinance price for BUY {symbol}: {price}")
        if units is None or units == 0:
            print(
                f"[ERROR] BUY transaction missing Units for {symbol} on {tx_date}. Skipping."
            )
            continue
        pos.add_buy(units=units, price=price, fees=fees, buy_date=tx_date)

    elif ttype_up in ("SPLIT", "BONUS"):
        if ratio is None or pd.isna(ratio):
            print(f"[ERROR] {ttype} for {symbol} missing Ratio on {tx_date}. Skipping.")
            continue
        pos.apply_split(ratio=ratio, event_date=tx_date, event_type=ttype_up)

    elif ttype_up == "SELL":
        if pd.isna(price) or price == 0:
            # try yfinance then ask
            latest = None
            try:
                latest = yf.Ticker(symbol).history(period="5d")["Close"].iloc[-1]
            except Exception:
                latest = None
            if latest is None or np.isnan(latest):
                while True:
                    s = input(
                        f"[INPUT] Price missing for SELL {symbol} on {tx_date}. Enter price: "
                    ).strip()
                    try:
                        price = float(s)
                        break
                    except:
                        print("  Invalid number, try again.")
            else:
                price = float(latest)
                print(f"[INFO] Using latest yfinance price for SELL {symbol}: {price}")
        if units is None or units == 0:
            print(
                f"[ERROR] SELL transaction missing Units for {symbol} on {tx_date}. Skipping."
            )
            continue
        pos.sell(units_to_sell=units, price=price, fees=fees, sell_date=tx_date)

    elif ttype_up in ("DIV", "DIVIDEND"):
        # Price column is treated as amount; if Units present and >0 we treat price as per-unit amount
        if pd.isna(price) or price == 0:
            print(
                f"[ERROR] DIV for {symbol} missing Price/Amount on {tx_date}. Skipping."
            )
            continue
        per_unit = not pd.isna(units) and units != 0
        pos.add_dividend(
            amount=price, div_date=tx_date, per_unit=False if not per_unit else True
        )
    else:
        print(
            f"[WARN] Unknown transaction type '{ttype}' for {symbol} on {tx_date}. Ignored."
        )

# ---------------------------
# After processing all tx: build reports
# ---------------------------
TODAY = datetime.today().date()

open_rows = []
closed_rows = []

# Build closed positions from realized_details across positions
for sym, pos in positions.items():
    # closed sells already appended into pos.realized_details during sells
    for detail in pos.realized_details:
        buy_date = detail.get("buy_date")
        sell_date = detail.get("sell_date")
        units = detail.get("units", 0)
        buy_price = detail.get("buy_price", 0.0)
        sell_price = detail.get("sell_price", 0.0)
        cost = detail.get("cost", 0.0)
        proceeds = detail.get("proceeds", 0.0)
        pnl = (
            proceeds - cost
        )  # note fees already allocated at sell as net proceeds adjustment in pos.sell
        pnl_pct = (pnl / cost * 100) if cost != 0 else 0.0
        holding_days = (sell_date - buy_date).days if (sell_date and buy_date) else None

        closed_rows.append(
            {
                "symbol": sym,
                "name": pos.meta.get("name", ""),
                "sector": pos.meta.get("sector", ""),
                "industry": pos.meta.get("industry", ""),
                "asset_type": pos.meta.get("asset_type", ""),
                "units": units,
                "per_unit_cost": round(buy_price, 6),
                "sell_price": round(sell_price, 6),
                "cost": round(cost, 6),
                "proceeds": round(proceeds, 6),
                "realized_pnl": round(pnl, 6),
                "realized_pnl_pct": round(pnl_pct, 4),
                "dividend_collected": round(pos.dividends, 6),
                "holding_days": holding_days,
                "buy_date": buy_date,
                "sell_date": sell_date,
            }
        )

# Build open positions
for sym, pos in positions.items():
    units = pos.total_units()
    if units <= 0:
        continue
    meta = pos.meta
    # latest price (yfinance fallback to user)
    latest_price = None
    try:
        hist = yf.Ticker(sym).history(period="5d")
        if hist is not None and len(hist) > 0:
            latest_price = float(hist["Close"].iloc[-1])
    except Exception as e:
        latest_price = None

    if latest_price is None or np.isnan(latest_price):
        while True:
            s = input(
                f"[INPUT] Latest price for {sym} not available via yfinance. Enter price: "
            ).strip()
            try:
                latest_price = float(s)
                break
            except:
                print("  Invalid number, try again.")

    cost_value = sum(l.total_cost for l in pos.lots)
    market_value = units * latest_price
    unrealized_amt = market_value - cost_value
    unrealized_pct = (unrealized_amt / cost_value * 100) if cost_value != 0 else 0.0
    per_unit_cost = (cost_value / units) if units != 0 else 0.0
    dividend_collected = pos.dividends
    holding_start_dates = [l.buy_date for l in pos.lots if l.buy_date is not None]
    holding_days = (
        (TODAY - min(holding_start_dates)).days if holding_start_dates else None
    )

    # Build cashflows for XIRR: buys (negative), sells (positive), dividends (positive), final market value at TODAY (positive)
    flows = list(pos.transactions)  # list of (date, amount)
    flows = [(d, a) for (d, a) in flows if d is not None]
    # append final market value as positive inflow to compute XIRR-to-date
    flows.append((TODAY, market_value))

    # prepare xirr input
    xirr_value = None
    try:
        # numpy_financial.xirr accepts a list of tuples (date, amount)
        # but to be safe we will try the (dates, amounts) variant too
        try:
            xirr_value = nf.xirr(flows)  # try list of (date, amount)
        except Exception:
            # try (amounts, dates)
            dates = [d for d, a in flows]
            amounts = [a for d, a in flows]
            xirr_value = nf.xirr(list(zip(dates, amounts)))
    except Exception as e:
        xirr_value = None
        print(f"[WARN] XIRR calculation failed for {sym}: {e}")

    open_rows.append(
        {
            "symbol": sym,
            "name": meta.get("name", ""),
            "sector": meta.get("sector", ""),
            "industry": meta.get("industry", ""),
            "asset_type": meta.get("asset_type", ""),
            "units": units,
            "per_unit_cost": round(per_unit_cost, 6),
            "latest_price": round(latest_price, 6),
            "cost_value": round(cost_value, 6),
            "market_value": round(market_value, 6),
            "unrealized_pnl": round(unrealized_amt, 6),
            "unrealized_pnl_pct": round(unrealized_pct, 4),
            "dividend_collected": round(dividend_collected, 6),
            "holding_days": holding_days,
            "xirr_pct": (
                round(xirr_value * 100, 4) if xirr_value is not None else None
            ),
        }
    )

open_df = pd.DataFrame(open_rows)
closed_df = pd.DataFrame(closed_rows)

# ---------------------------
# Aggregations: sector, industry, asset_type
# ---------------------------
if not open_df.empty:
    sector_df = (
        open_df.groupby("sector", dropna=False)[
            ["market_value", "cost_value", "unrealized_pnl"]
        ]
        .sum()
        .reset_index()
    )
    industry_df = (
        open_df.groupby("industry", dropna=False)[
            ["market_value", "cost_value", "unrealized_pnl"]
        ]
        .sum()
        .reset_index()
    )
    atype_df = (
        open_df.groupby("asset_type", dropna=False)[
            ["market_value", "cost_value", "unrealized_pnl"]
        ]
        .sum()
        .reset_index()
    )
else:
    sector_df = pd.DataFrame(
        columns=["sector", "market_value", "cost_value", "unrealized_pnl"]
    )
    industry_df = pd.DataFrame(
        columns=["industry", "market_value", "cost_value", "unrealized_pnl"]
    )
    atype_df = pd.DataFrame(
        columns=["asset_type", "market_value", "cost_value", "unrealized_pnl"]
    )

# ---------------------------
# Portfolio-level XIRR
# ---------------------------
# Aggregate all position transactions across symbols and add today market value sum
all_flows = []
for sym, pos in positions.items():
    for d, a in pos.transactions:
        if d is not None:
            all_flows.append((d, a))

# Append total market value at TODAY
total_market_value = open_df["market_value"].sum() if not open_df.empty else 0.0
all_flows.append((TODAY, total_market_value))

portfolio_xirr = None
try:
    try:
        portfolio_xirr = nf.xirr(all_flows)
    except Exception:
        # fallback
        dates = [d for d, a in all_flows]
        amounts = [a for d, a in all_flows]
        portfolio_xirr = nf.xirr(list(zip(dates, amounts)))
except Exception as e:
    print(f"[WARN] Portfolio XIRR failed: {e}")
    portfolio_xirr = None

portfolio_summary = {
    "total_cost": round(open_df["cost_value"].sum() if not open_df.empty else 0.0, 6),
    "total_market_value": round(
        open_df["market_value"].sum() if not open_df.empty else 0.0, 6
    ),
    "total_unrealized": round(
        open_df["unrealized_pnl"].sum() if not open_df.empty else 0.0, 6
    ),
    "total_dividends_collected": round(
        sum(pos.dividends for pos in positions.values()), 6
    ),
    "portfolio_xirr_pct": (
        round(portfolio_xirr * 100, 4) if portfolio_xirr is not None else None
    ),
}

portfolio_df = pd.DataFrame([portfolio_summary])

# ---------------------------
# Export CSVs and single Excel workbook
# ---------------------------
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
excel_path = os.path.join(REPORT_DIR, f"portfolio_report_{timestamp}.xlsx")

with pd.ExcelWriter(excel_path, engine="xlsxwriter") as writer:
    open_df.to_excel(writer, sheet_name="Open_Positions", index=False)
    closed_df.to_excel(writer, sheet_name="Closed_Positions", index=False)
    sector_df.to_excel(writer, sheet_name="Sector", index=False)
    industry_df.to_excel(writer, sheet_name="Industry", index=False)
    atype_df.to_excel(writer, sheet_name="Asset_Type", index=False)
    portfolio_df.to_excel(writer, sheet_name="Portfolio", index=False)

# CSVs
open_df.to_csv(os.path.join(REPORT_DIR, f"open_positions_{timestamp}.csv"), index=False)
closed_df.to_csv(
    os.path.join(REPORT_DIR, f"closed_positions_{timestamp}.csv"), index=False
)
sector_df.to_csv(
    os.path.join(REPORT_DIR, f"sector_summary_{timestamp}.csv"), index=False
)
industry_df.to_csv(
    os.path.join(REPORT_DIR, f"industry_summary_{timestamp}.csv"), index=False
)
atype_df.to_csv(
    os.path.join(REPORT_DIR, f"asset_type_summary_{timestamp}.csv"), index=False
)
portfolio_df.to_csv(
    os.path.join(REPORT_DIR, f"portfolio_summary_{timestamp}.csv"), index=False
)

print("\n[COMPLETE] Reports written to directory:", REPORT_DIR)
print("  - Excel:", excel_path)
print(
    "  - CSVs:",
    ", ".join(sorted([f for f in os.listdir(REPORT_DIR) if f.endswith(".csv")])),
)
print("\nKey portfolio summary:")
for k, v in portfolio_summary.items():
    print(f"  {k}: {v}")

# End of script
