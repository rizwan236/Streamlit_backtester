import sys


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")
from datetime import datetime, timedelta

import pytz
import requests_cache
import yfinance as yf


yf.enable_debug_mode()
yf.set_tz_cache_location("/home/rizpython236/.cache/py-yfinance")

from pyrate_limiter import Duration, Limiter, RequestRate
from requests import Session
from requests_cache import CacheMixin, SQLiteCache
from requests_ratelimiter import LimiterMixin, MemoryQueueBucket


class CachedLimiterSession(CacheMixin, LimiterMixin, Session):
   pass

session = CachedLimiterSession(
   limiter=Limiter(RequestRate(2, Duration.SECOND*5)),  # max 2 requests per 5 seconds
   bucket_class=MemoryQueueBucket,
   backend=SQLiteCache("yfinance.cache"),
)





IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

#today = datetime.now(IST_TIMEZONE).date()
#yesterday = today - timedelta(days=1)
#end_date = yesterday

end_date = datetime.now(IST_TIMEZONE).date() #- timedelta(weeks=2)

#end_date = date.today()
# start_date = end_date - timedelta(days=365)
start_date = end_date - timedelta(days = 511+15) #73 weekly  52+12 64   511+225
END_DATE = str(end_date)
START_DATE = str(start_date)
difference = start_date- end_date

# Attach session to yfinance
#yf.set_session(session)

# ===== 2. FETCH DATA WITH CACHING & AUTO-UPDATE =====
# Enable yfinance_cache with the cached session
#yfc.setup_cache(session=session)

# Fetch historical data for Dow Jones Industrial Average (^DJI)
hist = yf.download(
        '^DJI',
        start=START_DATE,
        end=END_DATE,
        interval="1d", #1wk 1d
        rounding=True,
        threads=True,
        multi_level_index=False,
        progress=False,
        back_adjust=True,
        repair=False,  # Data repair is used to fill in missing or corrupted data
        keepna=False,  # removes any rows with missing data.
        actions=False,  #excludes dividend and stock split events from the dat
        auto_adjust=True,  #adjusted for corporate actions like stock splits and dividends
        session=session,  # <-- Critical change: Pass session here
        #ignore_tz=True
        )





import sqlite3


# Connect to the cache database
conn = sqlite3.connect("yfinance.cache")
cursor = conn.cursor()

# List tables
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
print("Tables:", cursor.fetchall())

# Show cached Yahoo Finance requests
cursor.execute("SELECT url, created_at, expires_at FROM responses;")
for row in cursor.fetchall():
    print(row)

conn.close()
