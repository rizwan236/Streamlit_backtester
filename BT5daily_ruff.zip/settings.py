SCREENER_OUTPUT_FOLDER_PATH = "/home/rizpython236/BT5/screener-outputs"
TRADE_LOGS_FOLDER_PATH = "/home/rizpython236/BT5/trade-logs"
TICKER_CSV_DATA_FOLDER_PATH = "/home/rizpython236/BT5/ticker-csv-files"

VirTual_env_path = "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/"


INVALID_TICKERS_FILE = "invalid_tickers.csv"
VALID_TICKERS_CSV = "valid_tickers.csv"
INCOMPLETE_TICKERS_CSV = "incomplete_data_tickers.csv"
SCREENER_OUTPUT_CSV = "screener-output.csv"
BT_SCREENER_CSV = "trade_list_BT_Screener.csv"
TALIB_SCREENER_CSV = "trade_list_Talib_Screener.csv"
INCLUDE_TICKERS_CSV = "/home/rizpython236/BT5/include_tickers.csv"
EXCLUDE_TICKERS_CSV = "/home/rizpython236/BT5/exclude_tickers.csv"
SYMBOLS_CSV = "/home/rizpython236/BT5/symbol_list.csv"
TRADEBOOK_CSV = "tradebook.csv"
NIFTY_CSV = "^NSEI.csv"


NIFTY_WEEKLY_AVG_STATS_IMAGE = "/home/rizpython236/BT5/nifty_weekly_avg_stats.png"


MAX_RETRIES = 2


EMPTY_BT_SCREENER_MSG = "Error! BT-Screener output was found to be empty."
NO_NEW_SIGNALS_FOUND_MSG = (
    "Hey! The scanner ran successfully but there were no new signals found."
)


NSE_NIFTY_500_URL = "https://www1.nseindia.com/content/indices/ind_nifty500list.csv"
NSE_MICROCAP_250_URL = (
    "https://www1.nseindia.com/content/indices/ind_niftymicrocap250_list.csv"
)
