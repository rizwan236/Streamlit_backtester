

(CurrentPeriodClose - PreviousPeriod Close) X Volume

self.elder = (self.datas[0].close(0)- self.datas[0].close(-1)) * self.datas[0].volume(0)



self.efi = bt.indicators.ExponentialMovingAverage(self.datas[0].volume(0)*(self.datas[0].close(0)-self.datas[0].close(-1)), period=self.params.period, subplot=True, plotname='EFI')