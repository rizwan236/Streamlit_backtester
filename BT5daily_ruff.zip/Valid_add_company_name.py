import sys

import pandas as pd


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
import shutil

import yfinance as yf


print("Valid_add_company_name&Industry")

count=0
countBB=999999

def Valid_add_company_name(input_file, output_file):
    # Read CSV file
    df = pd.read_csv(input_file)
    df = df.astype(str)
    print("Valid_add_company_name&Industry")

    # Function to clean company name
    def clean_company_name(name):
        name = name.replace(" Company Limited", "").replace(" Corporation Limited", "").replace(" (India) Limited", "").replace(" India Limited", " India").replace("", "").replace(" Pharmaceuticals Limited", " Pharma").replace("Pharmaceutical", "Pharma").replace(" (Delhi) Limited", "").replace(" (Maharashtra) Limited", "").replace(" Ltd.", "").replace(" Co. Ltd.", "").replace(" (India) Ltd.", "").replace(" Ltd", "").replace(" Co.", "").replace("ICICI Prudential ", "ICICI ").replace("Special Economic Zone", "Spl Eco Zone.").replace(" Limited", "").replace(" and ", " & ").replace(" (India)", "").replace(" Company", " Co.").replace(" Infrastructure", " Infra.").replace(" & " , " & ").replace(" Corporation ", "Corp. ").replace(" (Gujarat)", "").replace(" (S.A.)", "").replace(" And ", " & ").replace("Engineers", "Engrs.").replace(" (Chennai)", "").replace(" Infrastructures ", " Infra. ").replace(" limited", "").replace("Technologies", "Tech.").replace(" Infrastructure", " Infra.").replace(" Infrastructures", " Infra.").replace(" (Kalamandir)", "").replace(" (Madras)", "").replace("Nippon India Mutual Fund ", "").replace("Nippon India ", "").replace(" Financial ", " Fin. ").replace(" Engineering ", " Eng. ").replace(" Industries", " Ind.").replace(" Industries ", " Ind. ").replace(" International", " Intl.").replace(" Engineering", " Eng.").replace("(International)", "").replace(" Development ", " Dev. ").replace(" Development", " Dev.").replace(" International ", " Intl. ").replace(" Technology", " Tech.").replace(" Technology ", " Tech. ").replace(" Services", " Srvs.").replace(" Holding", " Hldg.").replace(" Agricultural ", " Agri. ").replace(" Management ", " Mgmt. ").replace(" Investment ", " Invest. ").replace(" Consolidated ", " Consol. ").replace(" Chemicals ", " Chem. ").replace(" Chemicals", " Chem.").replace(" Fertilizers ", " Fert. ").replace(" Fertilizers", " Fert.").replace(" Biochemicals", " Biochem.").replace(" Associated ", " Assoc. ").replace(" Associated", " Assoc.").replace(" Hospital", " Hosp.").replace(" Hospital ", " Hosp. ").replace(" Manufacturing", " Mfg.").replace(" Manufacturing ", " Mfg. ").replace("The ", "").replace("General ", " Gen. ").replace(" Ventures", " Vntrs.").replace(" Enterprises", " Ent.").replace(" Industrial ", " Ind. ").replace(" Industrial", " Ind.").replace(" International", " Int.").replace("(International)", "").replace(" Technologies", " Tech.").replace(" (Coimbatore)", "").replace(" Petrochemicals", " petrochem.").replace("Petrochemical", "Petrochem.").replace(" Petrochemicals ", " Petrochem.").replace(" Fertilisers ", " Fert. ").replace(" Institute ", " Inst. ").replace("Electricals", "Elect.").replace("Construction", "Constr.").replace("Systems", "Sys.").replace("Investments", "Invest.").replace("Management", "Mgmt.").replace("Exchange", "Exch.").replace(" Fertilisers", " Fert.").replace("Housing Finance", "Hsg. Fin.").replace("Housing", "Hsg.").replace("Motilal Oswal S&P", "Motilal Oswal").replace("Developers", "Develp.").replace(" Corporation", "")#  .replace("", "").replace("", "")  .replace("", "").replace("", "")    #Nippon India
        return name
    def clean_Industry_name(name):
        name = name.replace("Corporation of India", "Corp. of India").replace("Drug Manufacturers—General", "Pharma-General").replace("Engineering & Construction", "Engr./Constr").replace("Agricultural", "Agri.").replace("Chemicals", "Chem.").replace("Financial", "Fin.").replace("Estate", "Est.").replace(" - Regional", "").replace("Drug Manufacturers—Specialty & Generic", "Pharma-Specialty/Generic").replace("Regional", "").replace("Drug Manufacturers - Specialty & Generic", "Pharma-Specialty/Generic").replace("Drug Manufacturers - General", "Pharma-General").replace("Farm & Heavy Construction Machinery", "Farm/Heavy Mach.").replace("Information Technology ", "IT ").replace(" Equipment ", " Equip ").replace(" Equipment", " Equip").replace("Other Industrial Metals & Mining", "Other Metals/Mining").replace("Pharmaceutical ", "Pharma ").replace(" Infrastructure", " Infra").replace("Independent", "").replace("Infrastructure ", "Infra ").replace("Lodging", "Hotel").replace("Medical Care Facilities", "Hospital").replace("Integrated Freight & Logistics", "Freight/Logistics").replace(" & ", "/").replace(" - ", "-").replace(" — ", "-").replace(" and ", "/").replace("Manufacturing", "Mfg.").replace("Development", "Develp.").replace("Industrial", "Ind.").replace("Services", "Serv.").replace("Manufacturers", "Mfg.").replace("Electrical", "Elect.").replace("Manufacturing", "Mfg.").replace("Products", "prod.").replace("Machinery", "Mach.").replace("Communication", "Comm.").replace("Specialty", "Spl.").replace("Biotechnology", "Biotech").replace("Fabrication", "Fab.").replace("Production", "Prod.").replace("Conglomerates", "Conglo.").replace("Finance", "Fin.").replace("Management", "Mgmt.").replace("Packaged", "Pkg.").replace("Advertising", "Advert.").replace("Education", "Edu.").replace("", "").replace("", "").replace("", "").replace("", "")
        return name

    # Function to get company name from ticker
    def get_company_info(Symbol):
        for _, row in df.iterrows():
            print(row['Industry'])
            if pd.isna(row['Industry']) or row['Industry'] == 'Blank': #
            #for index, row in df.iterrows():
            #if pd.isna(row['Industry']) or row['Industry'] in ['Blank']:
                print("a")
                try:
                    #company_name=Symbol
                    stock = yf.Ticker(Symbol)
                    company_name =stock.info['longName']
                    company_name = clean_company_name(company_name)
                    comparison_string = "Garden Reach Shipbuilders & Engineers"
                    if len(company_name) >= len(comparison_string):
                        company_name=Symbol
                    industry = "Blank"
                    YFindustry = "Blank"
                    try:
                        industry = stock.info['industry'] #industry sector
                        YFindustry=industry
                        industry = clean_Industry_name(industry)
                    except Exception as e:
                        #print(f"Error fetching Industry name for {Symbol}: {e}")
                        industry = "Blank"
                        YFindustry = "Blank"
                    #print(industry)
                    #print(company_name)
                    return company_name,YFindustry,industry
                except Exception as e:
                    industry = "Blank"
                    YFindustry = "Blank"
                    #print(f"Error fetching company name for {Symbol}: {e}")
                    return Symbol,YFindustry,industry
            else:
                #print("b")
                # Use existing values if 'Company' column exists and not empty
                row = df.loc[df['Symbol'] == Symbol, ['Company', 'YFindustry', 'Industry']].to_numpy()[0]
                return [str(val) if not pd.isna(val) else "Blank" for val in row]



    # Add 'company' column to DataFrame
    #df['Company'] = df['Symbol'].apply(get_company_name)
    #df['Industry'] = df['Symbol'].apply(get_Industry_name)
    df['Company'],df['YFindustry'], df['Industry'] = zip(*df['Symbol'].apply(get_company_info))

    result=list(df["Industry"].unique())
    result=pd.DataFrame(result)
    #print(result)

    # Save the DataFrame to a new CSV file
    df.to_csv(output_file, index=False)

# Example usage:
input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickersdeletexxxx.csv'
#Valid_add_company_name(input_file, output_file)

#ULTRAMAR.BO,Ultramarine & Pigments,Blank,Blank
#SHBAJRG.BO,Shri Bajrang Alliance,Blank,Blank


#output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'

output_file='/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'

def Validvlookup_and_merge(output_file):
    print("vlookup_and_merge")
    # Read the input files
    trade_logsvalid_tickers = pd.read_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv')
    screener_outputstrade_list = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers.csv')
    #if 'Company' not in screener_outputstrade_list.columns:
    #    # Add columns with empty values initially
    #    trade_logsvalid_tickers['Company'] = None
    #    trade_logsvalid_tickers['YFindustry'] = None
    #    trade_logsvalid_tickers['Industry'] = None
    # Perform VLOOKUP and merge
    merged_data = pd.merge(screener_outputstrade_list, trade_logsvalid_tickers[['Symbol','Company','YFindustry','Industry']], left_on='Symbol', right_on='Symbol', how='left')
    print(merged_data.columns)
    #print(merged_data)
    merged_data = merged_data.drop(columns=['Symbol'])
    merged_data.to_csv(output_file, index=False)
    print(f"Successfully merged data and saved to {output_file}")

# Example usage
##Validvlookup_and_merge(output_file)


dinput_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
doutput_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'

def copyfile(input_file, output_file):
    try:
        shutil.copyfile(input_file, output_file)
        print(f"File copied successfully: {output_file}")
    except Exception as e:
        print(f"Error copying file: {e}")

#copyfile(input_file, output_file)



print('done')