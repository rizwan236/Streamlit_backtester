import csv
from datetime import datetime, timedelta
import os
import shutil
import sys
import time
import traceback
import uuid

import pandas as pd
from PDFconvert import create_pdf
import pytz


sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
import pandas_ta as ta


#import asyncio
#import logging
#logger = logging.getLogger(__name__)
#logger.setLevel(logging.INFO)  # Adjust logging level as needed (e.g., DEBUG, WARNING)

#if account_is_in_tarpit_state():  # Replace with your logic to check tarpit state
#    logger.info("Account entered tarpit state. Printing 'abc'.")

'''
Security Code,Issuer Name,Security Id,Security Name,Status,Group,Face Value,ISIN No,Industry,Instrument,Sector Name,Industry New Name,Igroup Name,ISubgroup Name
500002,ABB India Limited,ABB,ABB India Limited,Active,A ,2.00,INE117A01022,Heavy Electrical Equipment,Equity,Industrials,Capital Goods,Electrical Equipment,Heavy Electrical Equipment
'''

from add_company_name import (
  add_company_names_and_industry,
  copyfile1,
  update_output_file,
  vlookup_and_merge,
)
from telegram_bot import post_telegram_file, post_telegram_message


#from Valid_add_company_name import Valid_add_company_name,Validvlookup_and_merge,copyfile

#import cleanup
#input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
#update_output_file(input_file, output_file)



print("Python version:", sys.version)

'''
import BSENSEtickerdownloader
time.sleep(2)
input_file = '/home/rizpython236/BT5/Final.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
copyfile1(input_file, output_file)
time.sleep(2)
input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
add_company_names_and_industry(input_file, output_file)
time.sleep(2)
input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
copyfile1(input_file, output_file)
print("End")

found = (data['Close'].iloc[-1] == data['Close'].iloc[-24:].rolling(window=24).min()).any() & (rsi > 60)
ffhhhhhh
'''
#import datetime
import calendar

from dateutil.relativedelta import MO  # Import from dateutil.relativedelta


def print_on_first_business_day():
  """Prints "abc" on the 1st day of the every month (if applicable)."""
  IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
  now = datetime.now(IST_TIMEZONE)
  #day1=now.day
  #print(day1)

  # Check if today is already the 1st business day
  if now.day == 1:
    print("Run momNSE750")
    try:
        import momNSE750
    except Exception as e:
        print(f"Error occurred momNSE750 {str(e)}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        post_telegram_message("momNSE750 error")
        pass
  else:
    print("Do not run momNSE750")



Monday=True
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")

current_datetimeUTC = datetime.now()
weekdayUTC = datetime.now().strftime("%A")

formatted_datetimeUTC = current_datetimeUTC.strftime("%d %b %Y %I:%M %p")
formatted_datetimeIST = ISTnow.strftime("%d %b %Y %I:%M %p")

day=today.weekday() == 1


post_telegram_message("Scan started")

post_telegram_message(f"Now IST Date & Time: {formatted_datetimeIST} {weekday}")
print(f"Now IST Date & Time: {formatted_datetimeIST} {weekday}")
#print(weekday)



#asyncio.run(post_telegram_message("Scan started!"))

#post_telegram_message(message=Scan started)

#print("Nifty PE, PB, Dividend Yield Stats")
# import nifty_pe_downloader




print("Now UTC Date and Time:", formatted_datetimeUTC)
print(f"UTC: Today is {weekdayUTC}...")

print("Now Date & Time in IST:", formatted_datetimeIST)
print(f"IST: Today is {weekday}...")
#post_telegram_message(f"Now IST Date & Time: {formatted_datetimeIST}")

time.sleep(1)


try:
    import cleanup
    1+1
except Exception as e:
    print(f"cleanup error: {e}")
    pass


try:
    import BSENSEtickerdownloader
    time.sleep(1)
    import symbol_copy
except Exception as e:
    print(f"BSENSEtickerdownloader error: {e}")
    pass


if False: #weekday != "Wednesday":
    input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
    output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
    copyfile1(input_file, output_file)
else:
    1+1


try:
    if True: #weekday == "Wednesday":
        import data_downloader
        import relative_performance
except Exception as e:
    print(f"data_downloader error: {e}")
    pass


time.sleep(2)

try:
    if True: #weekday == "Wednesday":
        input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
        output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
        update_output_file(input_file, output_file)
except Exception as e:
    print(f"valid_tickers copy error: {e}")
    pass



print("BT")

try:
    if True: #weekday == "Wednesday":
        import bt_screener2  #momentum
        import BTmomNSE750
        import csv_file2copy
        1+1
except Exception as e:
    print(f"bt_screener2 error: {e}")
    pass


try:
    if True: #weekday == "Wednesday":
        time.sleep(2)
        output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
        vlookup_and_merge(output_file)
except Exception as e:
    print(f"vlookup_and_merge error: {e}")
    pass




try:
    if True: #weekday == "Wednesday":
        import sectorupdate
        time.sleep(2)
        import sector_rotation
        #import csv_file2 time.sleep(2)
except Exception as e:
    print(f"sector signal error: {e}")
    post_telegram_message("sector signal failed!")
    pass



#post_telegram_message("weekly Scan started!")
#import new_screener
try:
    1+1
    import order_common  # holding signal
except Exception as e:
    print(f"order_common error: {e}")
    post_telegram_message("order_common failed!")
    pass



from datetime import date

from mail_utils import trigger_email_notification, trigger_generic_email
from settings import (
  BT_SCREENER_CSV,
  EMPTY_BT_SCREENER_MSG,
  MAX_RETRIES,
  NIFTY_WEEKLY_AVG_STATS_IMAGE,
  NO_NEW_SIGNALS_FOUND_MSG,
  SCREENER_OUTPUT_CSV,
  SCREENER_OUTPUT_FOLDER_PATH,
  SYMBOLS_CSV,
  TALIB_SCREENER_CSV,
  TICKER_CSV_DATA_FOLDER_PATH,
  TRADE_LOGS_FOLDER_PATH,
  TRADEBOOK_CSV,
)
from telegram_bot import post_telegram_message, trigger_telegram_notifications


BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
#post_telegram_file("/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv")
bt_data = pd.read_csv(BT_FILE_PATH)
holding_file = "/home/rizpython236/BT5/myholding.csv"
holding_file = pd.read_csv(holding_file)

filtered = bt_data[bt_data['ticker'].isin(holding_file['Symbol'])]
filtered.to_csv("/home/rizpython236/BT5/screener-outputs/filteredBT.csv", index=False)
time.sleep(2)
BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/filteredBT.csv"
#post_telegram_file("/home/rizpython236/BT5/screener-outputs/filteredBT.csv")


#BT_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + BT_SCREENER_CSV
TALIB_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + TALIB_SCREENER_CSV
CURRENT_DAY_SCREENER_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
TRADEBOOK_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + TRADEBOOK_CSV
TODAYS_DATE = date.today()
empty_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/emptyscreener.csv"


dir6 = "/home/rizpython236/BT5/ticker-csv-files"
for f in os.listdir(dir6):
    os.remove(os.path.join(dir6, f))



with open(BT_FILE_PATH, "r") as f:
    reader = csv.reader(f)
    header = next(reader)
    data = [row for row in reader]
    if not data:
        print("NO_NEW_SIGNALS_FOUND_MSG")
        post_telegram_message("NO_NEW_SIGNALS_FOUND_MSG")
        src_path = empty_FILE_PATH
        dst_path = BT_FILE_PATH
        #shutil.copy2(src_path, dst_path)
        #shutil.copy2(trade_list_BT_Screener.csv, trade_list_Talib_Screener.csv)
        #print("The file has no data under the header column.")
    else:
        #post_telegram_message("BT_file_has_screener_data")
        print("BT file has screener data")
        #continue
        #shutil.copy2(BT_FILE_PATH.csv, empty_FILE_PATH)
        # Continue with the rest of the code here

bt_data = pd.read_csv(BT_FILE_PATH)
talib_data = pd.read_csv(TALIB_FILE_PATH)
# new_screener_data = pd.read_csv(NEW_FILE_PATH)
tradebook = pd.read_csv(TRADEBOOK_FILE_PATH)


"""
Checking if the BT-data is empty or not and
triggering a mail if it's empty.
"""
if len(bt_data) == 0:
    print(EMPTY_BT_SCREENER_MSG)
    trigger_generic_email(msg=EMPTY_BT_SCREENER_MSG)
    sys.exit()


bt_tickers = list(bt_data["ticker"].unique())
talib_tickers = list(talib_data["ticker"].unique())


active_tradebook = tradebook[tradebook["status"] == "active"]
active_tradebook_tickers = list(active_tradebook["ticker"].unique())


def fetch_talib_results_for_ticker(ticker):

    talib_record = {"talib_date": "", "talib_signal": "", "talib_price": ""}

    if ticker not in talib_tickers:
        return talib_record

    talib_record["talib_date"] = talib_data.loc[
        talib_data["ticker"] == ticker, "datein"
    ].iloc[0]
    talib_record["talib_signal"] = talib_data.loc[
        talib_data["ticker"] == ticker, "dir"
    ].iloc[0]
    talib_record["talib_price"] = talib_data.loc[
        talib_data["ticker"] == ticker, "pricein"
    ].iloc[0]

    return talib_record


def trigger_compilation():

    new_trades = []
    signal_changed_messages = []

    for row in range(len(bt_data)):

        ticker = bt_data["ticker"][row]
        generated_signal = bt_data["dir"][row]

        ticker_date = bt_data.loc[bt_data["ticker"] == ticker, "datein"].iloc[0]
        ticker_signal = bt_data.loc[bt_data["ticker"] == ticker, "dir"].iloc[0]
        ticker_price = bt_data.loc[bt_data["ticker"] == ticker, "pricein"].iloc[0]
        ticker_Company = bt_data.loc[bt_data["ticker"] == ticker, "Company"].iloc[0]
        ticker_Industry = bt_data.loc[bt_data["ticker"] == ticker, "Industry"].iloc[0]
        pnl_percentage = None



        if ticker in active_tradebook_tickers:
            #print("Ticker already present, checking for active signal ...")
            active_signal = active_tradebook.loc[
                active_tradebook["ticker"] == ticker, "signal"
            ].iloc[0]

            if active_signal == generated_signal:
                # signal has not changed, hence continue
                continue
            else:
                print("Signal changed for => {}. Updating status to...".format(ticker))
                message = "Signal changed {}.".format(ticker)
                signal_changed_messages.append(message)
                time.sleep(0)
                #post_telegram_message("Signal changed for => {}. Updating status ...".format(ticker))
                trade_id = active_tradebook.loc[
                    active_tradebook["ticker"] == ticker, "trade_id"
                ].iloc[0]
                old_trade_price = active_tradebook.loc[
                    active_tradebook["trade_id"] == trade_id, "price"
                ].iloc[0]

                tradebook.loc[
                    (tradebook["trade_id"] == trade_id), ["status"]
                ] = "closed"
                tradebook.loc[
                    (tradebook["trade_id"] == trade_id), ["trade_updated_on"]
                ] = str(TODAYS_DATE)

                if active_signal == "BUY" and generated_signal == "SELL":
                    print(
                        "Buy + Sell completed for {}, calculating PnL.".format(ticker)
                    )
                    pnl_percentage = round(
                        ((ticker_price - old_trade_price) / old_trade_price) * 100, 2
                    )
                    # tradebook.loc[
                    #     active_tradebook["trade_id"] == trade_id, "pnl"
                    # ] = pnl_percentage

        talib_data_dict = fetch_talib_results_for_ticker(ticker)
        # new_screener_dict = fetch_new_screener_dict(ticker)



        record = {
            "trade_logged_on": str(TODAYS_DATE),
            "trade_id": str(uuid.uuid4()),
            "status": "active",
            "date": ticker_date,
            "ticker": ticker,
            "signal": ticker_signal,
            "price": ticker_price,
            "Company": ticker_Company,
            "Industry": ticker_Industry,
        }

        if pnl_percentage:
            record.update({"pnl": pnl_percentage})

        record.update(talib_data_dict)
        # record.updated(new_screener_dict)
        new_trades.append(record)
        record = {}

    try:
        for i in range(0, len(signal_changed_messages), 35):
            block = signal_changed_messages[i:i+35]
            print('\n'.join(block))
            time.sleep(2)
            post_telegram_message('\n'.join(block))
    except Exception as e:
        print(f"signal_changed_messages error: {e}")
        post_telegram_message("signal_changed_messages error")
        pass

    return new_trades


def cleanup_files():

    print("-" * 50)
    print("Removing the files ...")
    print("-" * 50)

    # remove BT Screener Output
    print("Deleting BT Screener Output File.")
    if os.path.exists(BT_FILE_PATH):
        os.remove(BT_FILE_PATH)

    # remove Talib Output
    print("Deleting Talib Screener Output File.")
    if os.path.exists(TALIB_FILE_PATH):
        os.remove(TALIB_FILE_PATH)

    # remove Talib Output
    print("Deleting Last Saved Screener Output File.")
    if os.path.exists(CURRENT_DAY_SCREENER_FILE_PATH):
        os.remove(CURRENT_DAY_SCREENER_FILE_PATH)

    # remove valid, invalid and incomplete ticker csvs
    print("Emptying valid, invalid and incomplete ticker output files.")
    dir1 = SCREENER_OUTPUT_FOLDER_PATH
    for f in os.listdir(dir1):
        ff = dir1 + "/" + f
        temp_df = pd.read_csv(ff)
        temp_df.drop(temp_df.index, inplace=True)
        temp_df.to_csv(ff, index=False)
        # os.remove(os.path.join(dir1, f))

    # remove Symbol list
    #print("Emptying Symbol List")
    #sym_df = pd.read_csv(SYMBOLS_CSV)
    #sym_df.drop(sym_df.index, inplace=True)
    #sym_df.to_csv(SYMBOLS_CSV, index=False)

    # ff = "./screener-outputs/valid_tickers.csv"
    # temp_df = pd.read_csv(ff)
    # temp_df.drop(temp_df.index, inplace=True)
    # temp_df.to_csv(ff, index=False)

    # remove ticker data csv files
    print("Deleting all the ticker data csv files.")
    dir2 = TICKER_CSV_DATA_FOLDER_PATH
    for f in os.listdir(dir2):
        #os.remove(os.path.join(dir2, f))
        1+1

    print("Deleting Nifty Weekly Avg Stats Image")
    if os.path.exists(NIFTY_WEEKLY_AVG_STATS_IMAGE):
        os.remove(NIFTY_WEEKLY_AVG_STATS_IMAGE)

    # folder = TICKER_CSV_DATA_FOLDER_PATH
    # for filename in os.listdir(folder):
    #    file_path = os.path.join(folder, filename)
    #    try:
    #        if os.path.isfile(file_path) or os.path.islink(file_path):
    #            os.unlink(file_path)
    #        elif os.path.isdir(file_path):
    #            shutil.rmtree(file_path)
    #    except Exception as e:
    #        print("Failed to delete %s. Reason: %s" % (file_path, e))


def generate_notifications(new_trades):

    if not new_trades:
        print("No new signals for today!")
        #trigger_generic_email(msg=NO_NEW_SIGNALS_FOUND_MSG)
        post_telegram_message(message=NO_NEW_SIGNALS_FOUND_MSG)
        #cleanup_files()
        return

    new_trades_df = pd.DataFrame(data=new_trades)
    # here we are sorting based on BT signal type - column = "signal"
    new_trades_df = new_trades_df.sort_values("signal")
    updated_tradebook = pd.concat([tradebook, new_trades_df], axis=0)
    updated_tradebook.to_csv(TRADEBOOK_FILE_PATH, index=False)

    new_trades_file_path = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
    new_trades_df.to_csv(new_trades_file_path, index=False)

    #trigger_email_notification()
    time.sleep(1)
    trigger_telegram_notifications()

    #cleanup_files()
    #import cleanup


def main():
    new_trades = trigger_compilation()
    generate_notifications(new_trades)


while MAX_RETRIES:
    try:
        main()
        MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(10)
        print("Operation Failed! Retrying...")
        print(traceback.format_exc())
        print(exc)
        print("-" * 50)
        MAX_RETRIES -= 1
