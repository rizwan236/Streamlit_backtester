import os
import re
import shutil
import sys
import time
import traceback

import pandas as pd
import yfinance as yf

from symbol_copy import NSE_BSE_symbol_name_df
from telegram_bot import post_telegram_message


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


print("addCompany&Industry start")

"""
datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")
bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
# Print the columns of both DataFrames
print("Columns in datanse:")
print(datanse.columns)

print("\nColumns in bse:")
print(bse.columns)
"""


"""
def add_company_names_and_industry(input_file, output_file):
    # Read CSV file
    df = pd.read_csv(input_file)
    print("addCompany&Industry")

    # Function to clean company name
    def clean_company_name(name):
        name = name.replace(" Company Limited", "").replace(" Corporation Limited", "").replace(" (India) Limited", "").replace(" India Limited", " India").replace("", "").replace(" Pharmaceuticals Limited", " Pharma").replace("Pharmaceutical", "Pharma").replace(" (Delhi) Limited", "").replace(" (Maharashtra) Limited", "").replace(" Ltd.", "").replace(" Co. Ltd.", "").replace(" (India) Ltd.", "").replace(" Ltd", "").replace(" Co.", "").replace("ICICI Prudential ", "ICICI ").replace("Special Economic Zone", "Spl Eco Zone.").replace(" Limited", "").replace(" and ", " & ").replace(" (India)", "").replace(" Company", " Co.").replace(" Infrastructure", " Infra.").replace(" & " , " & ").replace(" Corporation ", "Corp. ").replace(" (Gujarat)", "").replace(" (S.A.)", "").replace(" And ", " & ").replace("Engineers", "Engrs.").replace(" (Chennai)", "").replace(" Infrastructures ", " Infra. ").replace(" limited", "").replace("Technologies", "Tech.").replace(" Infrastructure", " Infra.").replace(" Infrastructures", " Infra.").replace(" (Kalamandir)", "").replace(" (Madras)", "").replace("Nippon India Mutual Fund ", "").replace("Nippon India ", "").replace(" Financial ", " Fin. ").replace(" Engineering ", " Eng. ").replace(" Industries", " Ind.").replace(" Industries ", " Ind. ").replace(" International", " Intl.").replace(" Engineering", " Eng.").replace("(International)", "").replace(" Development ", " Dev. ").replace(" Development", " Dev.").replace(" International ", " Intl. ").replace(" Technology", " Tech.").replace(" Technology ", " Tech. ").replace(" Services", " Srvs.").replace(" Holding", " Hldg.").replace(" Agricultural ", " Agri. ").replace(" Management ", " Mgmt. ").replace(" Investment ", " Invest. ").replace(" Consolidated ", " Consol. ").replace(" Chemicals ", " Chem. ").replace(" Chemicals", " Chem.").replace(" Fertilizers ", " Fert. ").replace(" Fertilizers", " Fert.").replace(" Biochemicals", " Biochem.").replace(" Associated ", " Assoc. ").replace(" Associated", " Assoc.").replace(" Hospital", " Hosp.").replace(" Hospital ", " Hosp. ").replace(" Manufacturing", " Mfg.").replace(" Manufacturing ", " Mfg. ").replace("The ", "").replace("General ", " Gen. ").replace(" Ventures", " Vntrs.").replace(" Enterprises", " Ent.").replace(" Industrial ", " Ind. ").replace(" Industrial", " Ind.").replace(" International", " Int.").replace("(International)", "").replace(" Technologies", " Tech.").replace(" (Coimbatore)", "").replace(" Petrochemicals", " petrochem.").replace("Petrochemical", "Petrochem.").replace(" Petrochemicals ", " Petrochem.").replace(" Fertilisers ", " Fert. ").replace(" Institute ", " Inst. ").replace("Electricals", "Elect.").replace("Construction", "Constr.").replace("Systems", "Sys.").replace("Investments", "Invest.").replace("Management", "Mgmt.").replace("Exchange", "Exch.").replace(" Fertilisers", " Fert.").replace("Housing Finance", "Hsg. Fin.").replace("Housing", "Hsg.").replace("Motilal Oswal S&P", "Motilal Oswal").replace("Developers", "Develp.").replace(" Corporation", "")#  .replace("", "").replace("", "")  .replace("", "").replace("", "")    #Nippon India
        return name
    def clean_Industry_name(name):
        name = name.replace("Corporation of India", "Corp. of India").replace("Drug Manufacturers—General", "Pharma-General").replace("Engineering & Construction", "Engr./Constr").replace("Agricultural", "Agri.").replace("Chemicals", "Chem.").replace("Financial", "Fin.").replace("Estate", "Est.").replace(" - Regional", "").replace("Drug Manufacturers—Specialty & Generic", "Pharma-Specialty/Generic").replace("Regional", "").replace("Drug Manufacturers - Specialty & Generic", "Pharma-Specialty/Generic").replace("Drug Manufacturers - General", "Pharma-General").replace("Farm & Heavy Construction Machinery", "Farm/Heavy Mach.").replace("Information Technology ", "IT ").replace(" Equipment ", " Equip ").replace(" Equipment", " Equip").replace("Other Industrial Metals & Mining", "Other Metals/Mining").replace("Pharmaceutical ", "Pharma ").replace(" Infrastructure", " Infra").replace("Independent", "").replace("Infrastructure ", "Infra ").replace("Lodging", "Hotel").replace("Medical Care Facilities", "Hospital").replace("Integrated Freight & Logistics", "Freight/Logistics").replace(" & ", "/").replace(" - ", "-").replace(" — ", "-").replace(" and ", "/").replace("Manufacturing", "Mfg.").replace("Development", "Develp.").replace("Industrial", "Ind.").replace("Services", "Serv.").replace("Manufacturers", "Mfg.").replace("Electrical", "Elect.").replace("Manufacturing", "Mfg.").replace("Products", "prod.").replace("Machinery", "Mach.").replace("Communication", "Comm.").replace("Specialty", "Spl.").replace("Biotechnology", "Biotech").replace("Fabrication", "Fab.").replace("Production", "Prod.").replace("Conglomerates", "Conglo.").replace("Finance", "Fin.").replace("Management", "Mgmt.").replace("Packaged", "Pkg.").replace("Advertising", "Advert.").replace("Education", "Edu.").replace("", "").replace("", "").replace("", "").replace("", "")
        return name

    # Function to get company name from ticker
    def get_company_info(Symbol):
        try:
            stock = yf.Ticker(Symbol)
            company_name =stock.info['longName']
            company_name = clean_company_name(company_name)
            comparison_string = "Garden Reach Shipbuilders & Engineers"
            if len(company_name) >= len(comparison_string):
                company_name=Symbol
            industry = "Blank"
            YFindustry = "Blank"
            try:
                industry = stock.info['industry'] #industry sector
                YFindustry=industry
                industry = clean_Industry_name(industry)
            except:# Exception as e:
                #print(f"Error fetching Industry name for {Symbol}: {e}")
                industry = "Blank"
                YFindustry = "Blank"
            #print(industry)
            #print(company_name)
            return company_name,YFindustry,industry
        except:# Exception as e:
            industry = "Blank"
            YFindustry = "Blank"
            #print(f"Error fetching company name for {Symbol}: {e}")
            #print(Symbol,YFindustry,industry)
            return Symbol,YFindustry,industry


    # Add 'company' column to DataFrame
    #df['Company'] = df['Symbol'].apply(get_company_name)
    #df['Industry'] = df['Symbol'].apply(get_Industry_name)
    df['Company'],df['YFindustry'], df['Industry'] = zip(*df['Symbol'].apply(get_company_info))
    #print(df)

    result=list(df["Industry"].unique())
    result=pd.DataFrame(result)
    #print(result)

    # Save the DataFrame to a new CSV file
    df.to_csv(output_file, index=False)
    df.to_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv', index=False)
"""


def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df


def add_company_names_and_industry(input_file, output_file):
    # Read CSV file
    input_file_exclude_tickers = "/home/rizpython236/BT5/exclude_tickers.csv"
    df_exclude_tickers = pd.read_csv(input_file_exclude_tickers)
    df_input_file = pd.read_csv(input_file)
    df = pd.concat([df_input_file, df_exclude_tickers],
                   ignore_index=True).drop_duplicates()[:]
    # Sort by Symbol
    # df = df.sort_values('Symbol')
    # Reset index
    # df = df.reset_index(drop=True)
    # print(df)

    dflen = len(df)
    print(dflen)
    counter = 0

    def apply_replacements(name, replacements):
        """Robust text cleaner that handles order, overlaps, and spacing issues."""
        # Sort by length (longest first) to avoid partial matches overriding larger phrases
        for old, new in sorted(replacements.items(), key=lambda x: len(x[0]), reverse=True):
            # Use word boundaries only if old is alphanumeric
            if re.search(r"\w", old):
                pattern = r"(?i)\b" + re.escape(old.strip()) + r"\b"
            else:
                # Allow flexible matching for non-word items like " - " or "&"
                pattern = r"\s*" + re.escape(old.strip()) + r"\s*"
            name = re.sub(pattern, f" {new.strip()} ", name)

        # Remove duplicated punctuation and normalize spaces
        name = re.sub(r"\s{2,}", " ", name)      # collapse multiple spaces
        # remove space before punctuation
        name = re.sub(r"\s([,.\-:/&])", r"\1", name)
        # normalize space after punctuation
        name = re.sub(r"([,.\-:/&])\s+", r"\1 ", name)
        return name.strip()

    # Load replacement data once (from CSV)
    company_REPLACEMENTS_CSV = "/home/rizpython236/BT5/Company_replacements.csv"

    if os.path.exists(company_REPLACEMENTS_CSV):
        company_replacements = pd.read_csv(company_REPLACEMENTS_CSV)
        # Normalize column names
        # company_replacements.columns = [c.strip().lower() for c in company_replacements.columns]
        # if not {"old", "new"}.issubset(company_replacements.columns):
        #    raise ValueError(f"CSV must contain 'old' and 'new' columns. Found: {company_replacements.columns.tolist()}")

        company_replacements = company_replacements.dropna(
            subset=["old"])  # ensure valid rows
        company_replacements = dict(zip(company_replacements["old"].astype(str).str.strip(),
                                        company_replacements["new"].fillna("").astype(str)))
    else:
        print(
            f"⚠️ Warning: {company_REPLACEMENTS_CSV} not found. Using empty replacements.")
        company_replacements = {}

    # Load replacement data once (from CSV)
    Industry_REPLACEMENTS_CSV = "/home/rizpython236/BT5/Industry_replacements.csv"

    if os.path.exists(Industry_REPLACEMENTS_CSV):
        Industry_replacements = pd.read_csv(Industry_REPLACEMENTS_CSV)
        Industry_replacements = Industry_replacements.dropna(
            subset=["old"])  # ensure valid rows
        Industry_replacements = dict(zip(Industry_replacements["old"].astype(str).str.strip(),
                                         Industry_replacements["new"].fillna("").astype(str)))
    else:
        print(
            f"⚠️ Warning: {Industry_REPLACEMENTS_CSV} not found. Using empty replacements.")
        Industry_replacements = {}

    # print(company_replacements)
    # print(Industry_replacements)

    # --- Function remains same signature and output ---
    def clean_company_name(name, company_replacements):
        """Clean company name using external replacements CSV."""
        if not isinstance(name, str) or not name.strip():
            return name

        # for old, new in company_replacements.items():
        #    pattern = r"\s*" + re.escape(old.strip()) + r"\s*"
        #    name = re.sub(pattern, new, name, flags=re.IGNORECASE)

        # Optional cleanup: collapse extra spaces
        # name = re.sub(r"\s{2,}", " ", name).strip()
        # return name

        return apply_replacements(name, company_replacements)

    # Function to clean company name
    def clean_company_namexxxxxx(name):
        replacements = {
            " Company Limited": "", " Corporation Limited": "", " (India) Limited": "", " India Limited": " India",
            " Pharmaceuticals Limited": " Pharma", " (Delhi) Limited": "", " (Maharashtra) Limited": "",
            " Ltd.": "", " Co. Ltd.": "", " (India) Ltd.": "", " Ltd": "", " Co.": "", " Commercial ": " Comm.",
            " Advanced ": " Adv.", " Solutions ": " Solu.", " Appliances ": " App.", " Logistics ": " Logis.", " Insurance ": " Insur.", " Accessories ": " Accs.", " Specialities ": " Spcl.", " National ": " Nat.", " Software ": " Soft.", " Instrumental ": " Instr.", " System ": " Sys.", " Transformers ": " Transfor.",
            "ICICI Prudential ": "ICICI Pru", "Special Economic Zone": "Spl Eco Zone.", " Limited": "",
            " and ": " & ", " (India)": "", " Company": " Co.", " Infrastructure": " Infra.",
            " & ": " & ", " Corporation ": "Corp. ", " (Gujarat)": "", " (S.A.)": "",
            " And ": " & ", "Engineers": "Engrs.", " (Chennai)": "", " Infrastructures ": " Infra. ",
            " limited": "", "Technologies": "Tech.", " Infrastructure": " Infra.", " Infrastructures": " Infra.",
            " (Kalamandir)": "", " (Madras)": "", "Nippon India Mutual Fund ": "Nippon India ",
            "Nippon India ": "", " Financial ": " Fin. ", " Engineering ": " Eng. ",
            " Industries": " Ind.", " Industries ": " Ind. ", " International": " Intl.",
            " Engineering": " Eng.", "(International)": "", " Development ": " Dev. ",
            " Development": " Dev.", " International ": " Intl. ", " Technology": " Tech.",
            " Technology ": " Tech. ", " Services": " Srvs.", " Holding": " Hldg.", " E-Governance": " e-Gov.",
            " Agricultural ": " Agri. ", " Management ": " Mgmt. ", " Investment ": " Invest. ",
            " Consolidated ": " Consol. ", " Chemicals ": " Chem. ", " Chemicals": " Chem.",
            " Fertilizers ": " Fert. ", " Fertilizers": " Fert.", " Biochemicals": " Biochem.",
            " Associated ": " Assoc. ", " Associated": " Assoc.", " Hospital": " Hosp.",
            " Hospital ": " Hosp. ", " Manufacturing": " Mfg.", " Manufacturing ": " Mfg. ",
            "The ": "", "General ": " Gen. ", " Ventures": " Vntrs.", " Enterprises": " Entp.",
            " Industrial ": " Ind. ", " Industrial": " Ind.", " International": " Int.",
            "(International)": "", " Technologies": " Tech.", " (Coimbatore)": "",
            " Petrochemicals": " petrochem.", "Petrochemical": "Petrochem.",
            " Petrochemicals ": " Petrochem.", " Fertilisers ": " Fert. ", " -$ ": "", " MARKET": " MKT.", " Laboratory": " Lab.", " Automobile": " Auto.",
            " Infrastructure": " Infra. ", " Technologies": " Tech. ", " Pharmaceuticals": " Pharma. ", " Industries ": " Ind. ", " Immunologicals ": " Immunog. ", " Biologicals ": " Bio. ", " Petroleum ": " Petro. ", " Electronics ": " Electro. ", " Telecommunications ": " Telec. ", " Systems ": " Sys. ", " Petroleum ": " Petro. ", " Petroleum ": " Petro. ",
            " Institute ": " Inst. ", "Electricals": "Elect.", "Construction": "Constr.",
            "Systems": "Sys.", "Investments": "Invest.", "Management": "Mgmt.",
            "Exchange": "Exch.", " Fertilisers": " Fert.", "Housing Finance": "Hsg. Fin.", "Procter & Gamble": "P&G ",
            "Housing": "Hsg.", "Motilal Oswal S&P": "Motilal Oswal", "Developers": "Develp.",
            " Corporation": "", " Standard": " Std.", " Manufactures": " Mfg..", " Laboratories": " Lab.",
            " Industry": " Ind.", " Estates": " Est.", " Communications": " comm.", " Infrastructure": " Infra.",
            " Pharmaceutical": " Pharma.", " Development": " Develp.", " Equipment": " Equip.", " Specialty": " Spl.",
            " Education": " Edu.", " Chemicals": " Chem.", "Indian Railway Catering & Tourism": "IRCTC", "Renewable": "Renew", "Corporate": "Corp.",
            "Products": "Prod.", "Investment": "Invest.", "Consultancy": "Consult.", "Electrical": "Elect.", "Performance": "Perf.", "Consolidated": "Consol.",
            "Intermediaries": "intermeds.", "Automotive": "Auto.", "Entertainment": "Entmt.", "Institute": "Inst.", "Limited": "", "Company": "Compy.", "of India": "",
        }
        for old, new in replacements.items():
            # name = re.sub(re.escape(old), new, name, flags=re.IGNORECASE)
            pattern = r"\s*" + re.escape(old.strip()) + r"\s*"
            name = re.sub(pattern, new, name, flags=re.IGNORECASE)
            # name = name.replace(old, new)
        name = re.sub(r"\s{2,}", " ", name).strip()
        return name

    # Function to clean industry name
    def clean_Industry_name(name, Industry_replacements):
        replacements = {
            "Corporation of India": "Corp. of India", "Drug Manufacturers—General": "Pharma-General",
            "Engineering & Construction": "Engr./Constr", "Agricultural": "Agri.",
            "Chemicals": "Chem.", "Financial": "Fin.", "Estate": "Est.",
            " - Regional": "", "Drug Manufacturers—Specialty & Generic": "Pharma-Specialty/Generic",
            "Regional": "", "Drug Manufacturers - Specialty & Generic": "Pharma-Specialty/Generic",
            "Drug Manufacturers - General": "Pharma-General", "Farm & Heavy Construction Machinery": "Farm/Heavy Mach.",
            "Information Technology ": "IT ", " Equipment ": " Equip ", " Equipment": " Equip",
            "Other Industrial Metals & Mining": "Other Metals/Mining", "Pharmaceutical ": "Pharma ",
            " Infrastructure": " Infra", "Independent": "", "Infrastructure ": "Infra ",
            "Lodging": "Hotel", "Medical Care Facilities": "Hospital",
            "Integrated Freight & Logistics": "Freight/Logistics", " & ": "/",
            " - ": "-", " — ": "-", " and ": "/", "Manufacturing": "Mfg.",
            "Development": "Develp.", "Industrial": "Ind.", "Services": "Serv.",
            "Manufacturers": "Mfg.", "Electrical": "Elect.", "Manufacturing": "Mfg.",
            "Products": "prod.", "Machinery": "Mach.", "Communication": "Comm.",
            "Specialty": "Spl.", "Biotechnology": "Biotech", "Fabrication": "Fab.",
            "Production": "Prod.", "Conglomerates": "Conglo.", "Finance": "Fin.",
            "Management": "Mgmt.", "Packaged": "Pkg.", "Advertising": "Advert.",
            "Education": "Edu.",
        }
        # for old, new in Industry_replacements.items():
        #    pattern = r"\s*" + re.escape(old.strip()) + r"\s*"
        #    name = re.sub(pattern, new, name, flags=re.IGNORECASE)

        # name = re.sub(re.escape(old), new, name, flags=re.IGNORECASE)
        # name = name.replace(old, new)
        # name = re.sub(r"\s{2,}", " ", name).strip()
        # return name
        return apply_replacements(name, Industry_replacements)

    # Function to get company name from ticker
    def get_company_info(Symbol, symbol_to_name, company_replacements, Industry_replacements):
        try:
            # sym_name_df = NSE_BSE_symbol_name_df()
            # symbol_to_name = dict(zip(sym_name_df["SYMBOL"], sym_name_df["NAME OF COMPANY"]))
            stock = yf.Ticker(Symbol)
            company_name = symbol_to_name[Symbol]  # stock.info['longName']
            # print(company_name)
            company_name = clean_company_name(
                company_name, company_replacements)
            comparison_string = "Garden Reach Shipbuilders & Engineers"
            if len(company_name) >= len(comparison_string):
                company_name = Symbol
            industry = "Blank"
            YFindustry = "Blank"
            try:
                industry = stock.info["industry"]  # industry sector
                YFindustry = industry
                industry = clean_Industry_name(industry, Industry_replacements)

            except:
                industry = "Blank"
                YFindustry = "Blank"
            return company_name, YFindustry, industry
        except:
            industry = "Blank"
            YFindustry = "Blank"
            return Symbol, YFindustry, industry

    # Add 'company' column to DataFrame with a delay after every 100 symbols
    results = []
    bse_nse_common = pd.read_csv("/home/rizpython236/BT5/bse_nse_common.csv")
    bse_symbols = bse_nse_common["Symbol"].tolist()
    sym_name_df = NSE_BSE_symbol_name_df()
    symbol_to_name = dict(
        zip(sym_name_df["SYMBOL"], sym_name_df["NAME OF COMPANY"]))
    for idx, symbol in enumerate(df["Symbol"]):
        # info = get_company_info(symbol, symbol_to_name)   # run once
        company_name, YFindustry, industry = get_company_info(
            symbol, symbol_to_name, company_replacements, Industry_replacements)

        info_dict = {
            "Symbol": symbol,
            "Company": company_name,
            "YFindustry": YFindustry,
            "Industry": industry,
        }
        results.append(info_dict)

        # results.append(get_company_info(symbol,symbol_to_name))

        # If symbol ends with .NS, duplicate entry with .BO
        # if symbol.endswith(".NS"):
        #    bo_info = info.copy()   # make a shallow copy of dict (or DataFrame row)
        #    bo_info['Symbol'] = symbol.replace(".NS", ".BO")  # overwrite only Symbol
        #    results.append(bo_info)

        if symbol.endswith(".NS"):
            bo_symbol = symbol.replace(".NS", ".BO")
            if bo_symbol in bse_symbols:
                bo_info = info_dict.copy()
                bo_info["Symbol"] = bo_symbol
                results.append(bo_info)
                # print(bo_info)

        # Pause for 10 minutes after every 100 symbols
        if (idx + 1) % 500 == 0:
            print(f"Processed {idx + 1} symbols. Pausing for 5 minutes...")
            time.sleep(2 * 60)  # 600 seconds = 10 minutes

    # Unpack results into DataFrame columns
    # df['Company'], df['YFindustry'], df['Industry'] = zip(*results)
    # df_results = pd.DataFrame(results)
    df_results = pd.DataFrame(
        results, columns=["Symbol", "Company", "YFindustry", "Industry"])
    df = df_results[["Symbol", "Company", "YFindustry", "Industry"]]

    # Add 'company' column to DataFrame
    # df['Company'], df['YFindustry'], df['Industry'] = zip(*df['Symbol'].apply(get_company_info))

    # MYindustry.csv vlookup
    df.drop(columns=["Industry"], inplace=True)
    # print(df.head(30))
    Myind = pd.read_csv("/home/rizpython236/BT5/MYindustry.csv")
    merged_data = pd.merge(df, Myind, left_on="YFindustry",
                           right_on="Industry", how="left")
    # merged_data['MYindustry'] = merged_data['MYindustry'].fillna(merged_data['Symbol'])

    # Industry_to_myindustry_mapping = dict(zip(Myind['Industry'], Myind['MYindustry']))
    industries_with_no_match = merged_data[merged_data["MYindustry"].isna()]
    unique_values = industries_with_no_match["YFindustry"].unique().tolist()
    print(unique_values)
    post_telegram_message(unique_values)

    # merged_data["MYindustry"].fillna("Blank", inplace=True)
    merged_data.fillna({"MYindustry": "Blank"}, inplace=True)
    merged_data.drop(columns=["Industry"], inplace=True)
    merged_data = merged_data.rename(columns={"MYindustry": "Industry"})
    unique_industries = merged_data["Industry"].unique()
    # merged_data["Industry"].fillna("Blank", inplace=True)
    # Save the DataFrame to a new CSV file
    # print(unique_industries)
    try:
        datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")
        datanse.drop(
            columns=[
                " SERIES",
                " DATE OF LISTING",
                " PAID UP VALUE",
                " MARKET LOT",
                # " ISIN NUMBER",
                " FACE VALUE",
            ],
            inplace=True,
        )
        add_suffix_to_column(datanse, "SYMBOL", ".NS")

        bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
        bse.drop(
            columns=[
                # "Group",
                # "Face Value",
                # "ISIN No",
                "Industry",
                "Instrument",
                "Sector Name",
                "Industry New Name",
                "Igroup Name",
                "ISubgroup Name",
            ],
            inplace=True, errors="ignore",
        )
        bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
        bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
        bse = bse[bse["Status"] == "Active"]
        accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]
        bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF")]
        bse = bse[~bse["NAME OF COMPANY"].str.contains("EXCHANGE TRADED")]
        bse = bse[~bse["NAME OF COMPANY"].str.contains("FUND")]
        bse = bse[~bse["NAME OF COMPANY"].str.contains("Fund")]
        # bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
        condition = bse["SYMBOL"].str.endswith("*")
        bse.loc[condition, "SYMBOL"] = bse.loc[condition, "SYMBOL"].str[:-1]
        # Filter dataframe
        bse = bse[bse["Group"].isin(accepted_values)]
        add_suffix_to_column(bse, "SYMBOL", ".BO")

        bse = pd.concat([bse, datanse], axis=0, ignore_index=True)
        bse = bse.dropna(subset=["NAME OF COMPANY"])

        replacements = {
            " Company Limited": "", " Corporation Limited": "", " (India) Limited": "", " India Limited": " India",
            " Pharmaceuticals Limited": " Pharma", " (Delhi) Limited": "", " (Maharashtra) Limited": "",
            " Ltd.": "", " Co. Ltd.": "", " (India) Ltd.": "", " Ltd": "", " Co.": "", " Commercial ": " Comm.",
            " Advanced ": " Adv.", " Solutions ": " Solu.", " Appliances ": " App.", " Logistics ": " Logis.", " Insurance ": " Insur.", " Accessories ": " Accs.", " Specialities ": " Spcl.", " National ": " Nat.", " Software ": " Soft.", " Instrumental ": " Instr.", " System ": " Sys.", " Transformers ": " Transfor.",
            "ICICI Prudential ": "ICICI ", "Special Economic Zone": "Spl Eco Zone.", " Limited": "",
            " and ": " & ", " (India)": "", " Company": " Co.", " Infrastructure": " Infra.",
            " & ": " & ", " Corporation ": "Corp. ", " (Gujarat)": "", " (S.A.)": "",
            " And ": " & ", "Engineers": "Engrs.", " (Chennai)": "", " Infrastructures ": " Infra. ",
            " limited": "", "Technologies": "Tech.", " Infrastructure": " Infra.", " Infrastructures": " Infra.",
            " (Kalamandir)": "", " (Madras)": "", "Nippon India Mutual Fund ": "Nippon India ",
            "Nippon India ": "", " Financial ": " Fin. ", " Engineering ": " Eng. ",
            " Industries": " Ind.", " Industries ": " Ind. ", " International": " Intl.",
            " Engineering": " Eng.", "(International)": "", " Development ": " Dev. ",
            " Development": " Dev.", " International ": " Intl. ", " Technology": " Tech.",
            " Technology ": " Tech. ", " Services": " Srvs.", " Holding": " Hldg.",
            " Infrastructure": " Infra. ", " Technologies": " Tech. ", " Pharmaceuticals": " Pharma. ", " Industries ": " Ind. ", " Immunologicals ": " Immunog. ", " Biologicals ": " Bio. ", " Petroleum ": " Petro. ", " Electronics ": " Electro. ", " Telecommunications ": " Telec. ", " Systems ": " Sys. ", " Petroleum ": " Petro. ", " Petroleum ": " Petro. ",
            " Agricultural ": " Agri. ", " Management ": " Mgmt. ", " Investment ": " Invest. ",
            " Consolidated ": " Consol. ", " Chemicals ": " Chem. ", " Chemicals": " Chem.",
            " Fertilizers ": " Fert. ", " Fertilizers": " Fert.", " Biochemicals": " Biochem.",
            " Associated ": " Assoc. ", " Associated": " Assoc.", " Hospital": " Hosp.",
            " Hospital ": " Hosp. ", " Manufacturing": " Mfg.", " Manufacturing ": " Mfg. ",
            "The ": "", "General ": " Gen. ", " Ventures": " Vntrs.", " Enterprises": " Entp.",
            " Industrial ": " Ind. ", " Industrial": " Ind.", " International": " Int.",
            "(International)": "", " Technologies": " Tech.", " (Coimbatore)": "",
            " Petrochemicals": " petrochem.", "Petrochemical": "Petrochem.",
            " Petrochemicals ": " Petrochem.", " Fertilisers ": " Fert. ",
            " Institute ": " Inst. ", "Electricals": "Elect.", "Construction": "Constr.",
            "Systems": "Sys.", "Investments": "Invest.", "Management": "Mgmt.",
            "Exchange": "Exch.", " Fertilisers": " Fert.", "Housing Finance": "Hsg. Fin.", "Procter & Gamble": "P&G ",
            "Housing": "Hsg.", "Motilal Oswal S&P": "Motilal Oswal", "Developers": "Develp.",
            " Corporation": "", " Standard": " Std.", " Manufactures": " Mfg..", " Laboratories": " Lab.",
            " Industry": " Ind.", " Estates": " Est.", " Communications": " comm.", " Infrastructure": " Infra.",
            " Pharmaceutical": " Pharma.", " Development": " Develp.", " Equipment": " Equip.", " Specialty": " Spl.",
            " Education": " Edu.", " Chemicals": " Chem.", "Indian Railway Catering & Tourism": "IRCTC", "Renewable": "Renew", "Corporate": "Corp.",
            "Products": "Prod.", "Investment": "Invest.", "Consultancy": "Consult.", "Electrical": "Elect.", "Performance": "Perf.", "Consolidated": "Consol.",
            "Intermediaries": "intermeds.", "Automotive": "Auto.", "Entertainment": "Entmt.", "Institute": "Inst.", "Limited": "", "Company": "Compy.", "of India": "",
        }

        # bse['NAME OF COMPANY'] = bse['NAME OF COMPANY'].replace(replacements)

        # Replace based on contains
        # for key, value in replacements.items():
        #    #bse.loc[bse['NAME OF COMPANY'].str.contains(key, na=False), 'NAME OF COMPANY'] = bse['NAME OF COMPANY'].str.replace(key, value)
        #    bse.loc[bse['NAME OF COMPANY'].str.contains(key, na=False), 'NAME OF COMPANY'] = bse['NAME OF COMPANY'].str.replace(key, value, regex=False)

        # Assuming 'bse' is your DataFrame and 'replacements' is a dictionary with old-new pairs
        for old, new in company_replacements.items():
            # Update the 'NAME OF COMPANY' column using a regex pattern
            # bse["NAME OF COMPANY"] = bse["NAME OF COMPANY"].apply(
            #    lambda name: re.sub(r"\s*" + re.escape(old.strip()) + r"\s*", new, name, flags=re.IGNORECASE) if isinstance(name, str) else name)
            bse["NAME OF COMPANY"] = (bse["NAME OF COMPANY"].fillna("").apply(
                lambda name: apply_replacements(name, company_replacements)))

        # bse["NAME OF COMPANY"] = bse["NAME OF COMPANY"].apply(
        #    clean_company_name)
        # If company_replacements is defined elsewhere
        bse["NAME OF COMPANY"] = bse["NAME OF COMPANY"].apply(
            lambda x: clean_company_name(x, company_replacements),
        )
        mapping = dict(zip(bse["SYMBOL"], bse["NAME OF COMPANY"]))
        # merged_data['Company'] = merged_data['Company'].map(mapping)

        # Assuming 'mapping' is already created as shown previously
        merged_data["Company"] = merged_data["Company"].map(
            mapping).fillna(merged_data["Company"])

    except Exception as exc:
        print(f"add_company_names_and_industry error {exc}")
        traceback.print_exc()  # Print the full traceback

    TJI_index_file_path = "/home/rizpython236/BT5/trade-logs/TJI_index.csv"
    TJI_index_file = pd.read_csv(TJI_index_file_path)
    # merged_data = pd.concat([merged_data, TJI_index_file], ignore_index=True)
    merged_data = pd.concat([merged_data, TJI_index_file],
                            ignore_index=True).drop_duplicates(subset=["Symbol"])
    merged_data = merged_data.sort_values("Symbol").reset_index(drop=True)
    # print(merged_data)

    merged_data.to_csv(output_file, index=False)
    merged_data.to_csv(
        "/home/rizpython236/BT5/trade-logs/valid_tickers.csv", index=False)
    print("add_company_names_and_industry Completed")


"""
#__________________
bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
bse.drop(
    columns=[
        #"Group",
        #"Face Value",
        #"ISIN No",
        "Industry",
        "Instrument",
        "Sector Name",
        "Industry New Name",
        "Igroup Name",
        "ISubgroup Name",
    ],
    inplace=True,
)
bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Status"] == "Active"]
accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]
bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("FUND")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("Fund")]
#bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
condition = bse['SYMBOL'].str.endswith('*')
bse.loc[condition, 'SYMBOL'] = bse.loc[condition, 'SYMBOL'].str[:-1]
# Filter dataframe
bse = bse[bse["Group"].isin(accepted_values)]
add_suffix_to_column(bse, "SYMBOL", ".BO")
file_path = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
data = pd.read_csv(file_path)
blank_companies = data[data['Company'] == "Blank"]
print(bse)
"""


# output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
"""
def vlookup_and_merge(output_file):
    print("vlookup_and_merge")
    # Read the input files
    valid_tickers = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers.csv')
    trade_list = pd.read_csv('/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv')

    # Perform VLOOKUP and merge
    merged_data = pd.merge(trade_list, valid_tickers[['Symbol','Company', 'Industry']], left_on='ticker', right_on='Symbol', how='left')
    merged_data = merged_data.drop(columns=['Symbol'])
    merged_data.to_csv(output_file, index=False)
    print(f"Successfully merged data and saved to {output_file}")
"""


def vlookup_and_merge(output_file):
    print("vlookup_and_merge trade_list_BT_Screener")
    # Read the input files
    valid_tickers = pd.read_csv(
        "/home/rizpython236/BT5/trade-logs/valid_tickers.csv")
    # valid_tickers = pd.read_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers.csv')
    trade_list = pd.read_csv(
        "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv")

    # bse_nse_common = pd.read_csv('/home/rizpython236/BT5/bse_nse_common.csv')
    # df_combined = pd.concat([valid_tickers, bse_nse_common], ignore_index=True).drop_duplicates()
    # valid_tickers =df_combined

    # Sort dataframes before merging to improve performance
    valid_tickers.sort_values("Symbol", inplace=True)
    trade_list.sort_values("ticker", inplace=True)

    # print(trade_list)

    # Reduce dataframe size by selecting only necessary columns
    # valid_tickers = valid_tickers[['Symbol', 'Company', 'Industry']]  #Symbol,Company,YFindustry,Industry

    # Perform VLOOKUP and merge using the correct join type (left join in this case)
    merged_data = pd.merge(trade_list, valid_tickers,
                           left_on="ticker", right_on="Symbol", how="left")

    # Drop the redundant 'Symbol' column
    merged_data.drop(columns=["Symbol"], inplace=True)
    merged_data.drop(columns=["YFindustry"], inplace=True)
    merged_data["Company"].fillna("Blank", inplace=True)
    # merged_data["Industry"].fillna("Blank", inplace=True)

    # Save the merged data to a new CSV file
    merged_data.to_csv(output_file, index=False)
    # print(merged_data)
    print(f"Successfully merged data and saved to {output_file}")


# Example usage
# vlookup_and_merge(output_file)
# output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
# vlookup_and_merge(output_file)
# kk

'''
def update_output_file(input_file, output_file):
    """
    Updates the output file with VLOOKUP logic for Symbol, Company, YFindustry, and Industry columns.
    Fills in missing data for symbols without VLOOKUP matches.

    Args:
        input_file (str): Path to the input CSV file.
        output_file (str): Path to the output CSV file.
    """

    df_input = pd.read_csv(input_file)
    df_output = pd.read_csv(output_file)

    merged_data = pd.merge(df_output, df_input[['Symbol','Company', 'YFindustry', 'Industry']], left_on='Symbol', right_on='Symbol', how='left')
    #merged_data.fillna({'Company': merged_data['Symbol'], 'YFindustry': 'Blank', 'Industry': 'Blank'}, inplace=True)
    columns_to_drop = ['Company_x', 'YFindustry_x', 'Industry_x']
    #merged_data = merged_data.drop(columns_to_drop, axis=1)
    columns_to_rename = {'Company_y': 'Company', 'YFindustry_y': 'YFindustry', 'Industry_y': 'Industry'}
    # Rename columns using dictionary mapping
    #merged_data = merged_data.rename(columns=columns_to_rename)
      # Fill 'Company' with corresponding 'Symbol' if it's missing
    merged_data['Company'] = merged_data['Company'].fillna(merged_data['Symbol'])
    merged_data["YFindustry"].fillna("Blank", inplace=True)
    merged_data["Industry"].fillna("Blank", inplace=True)
    #print(merged_data)
    merged_data.to_csv(output_file, index=False)
'''


def update_output_file(input_file, output_file):
    """Updates the output file with VLOOKUP logic for Symbol, Company, YFindustry, and Industry columns.
    Fills in missing data for symbols without VLOOKUP matches.

    Args:
        input_file (str): Path to the input CSV file.
        output_file (str): Path to the output CSV file.

    """
    # input_file = '/home/rizpython236/BT5/Final.csv'
    # output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
    input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
    output_file = "/home/rizpython236/BT5/Final.csv"

    df_input = pd.read_csv(input_file)
    df_output = pd.read_csv(output_file)

    bse_nse_common = pd.read_csv("/home/rizpython236/BT5/bse_nse_common.csv")
    bse_symbols = bse_nse_common["Symbol"].tolist()

    df_bo = df_output.copy()
    df_bo["Symbol"] = df_bo["Symbol"].str.replace(".NS", ".BO", regex=False)
    df_bo = df_bo[df_bo["Symbol"].isin(bse_symbols)].reset_index(drop=True)

    df_combined = pd.concat(
        [df_input, df_bo], ignore_index=True).drop_duplicates()
    # df_combined = pd.merge(df_input, df_bo, on="Symbol", how="outer")
    # df_input =df_combined
    # print(df_input)

    df_combined2 = pd.concat(
        [df_output, df_bo], ignore_index=True).drop_duplicates()
    df_output = df_combined2
    # print(df_output)

    # Sort dataframes before merging to improve performance
    # df_input.sort_values('Symbol', inplace=True)
    # df_output.sort_values('Symbol', inplace=True)

    # Reduce dataframe size by selecting only necessary columns
    # df_input = df_input[['Symbol', 'Company', 'YFindustry', 'Industry']]
    # print(df_output)
    # Perform VLOOKUP and merge using the correct join type (left join in this case)
    merged_data = pd.merge(df_output, df_input, on="Symbol", how="left")
    # print(merged_data)
    # Fill 'Company' with corresponding 'Symbol' if it's missing
    merged_data["Company"] = merged_data["Company"].fillna(
        merged_data["Symbol"])
    # merged_data["YFindustry"].fillna("Blank", inplace=True)
    merged_data.fillna({"YFindustry": "Blank"}, inplace=True)
    # merged_data["Industry"].fillna("Blank", inplace=True)
    merged_data.fillna({"Industry": "Blank"}, inplace=True)
    merged_data.drop_duplicates(subset="Symbol", keep="first", inplace=True)
    merged_data.sort_values("Symbol", inplace=True)
    merged_data.reset_index(drop=True, inplace=True)
    # print(merged_data)
    # Save the merged data to a new CSV file
    output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
    merged_data.to_csv(output_file, index=False)
    print("vlookup valid_tickers file")


# Example usage
input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
# input_file = '/home/rizpython236/BT5/Final.csv'
output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"

# output_file = '/home/rizpython236/BT5/Final.csv'

# input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
# input_file = '/home/rizpython236/BT5/Final.csv'
# update_output_file(input_file, output_file)


input_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
output_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"


def copyfile1(input_file, output_file):
    try:
        shutil.copyfile(input_file, output_file)
        print(f"File copied successfully: {output_file}")
    except Exception as e:
        print(f"Error copying file: {e}")

# copyfile1(input_file, output_file)


# print("done1")
input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
# update_output_file(input_file, output_file)

output_file = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
# vlookup_and_merge(output_file)

# Example usage:
input_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
input_file = "/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv"
input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"

# input_file = '/home/rizpython236/BT5/Final.csv'
# input_file = '/home/rizpython236/BT5/exclude_tickers.csv'
input_file = "/home/rizpython236/BT5/Final.csv"
output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
# add_company_names_and_industry(input_file, output_file)

print("add_company_name done")
