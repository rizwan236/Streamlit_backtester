import os

import pandas as pd


#import pickle

# Function to read ticker files and add symbol column
def process_files(folder_path,limit=10):
    # Initialize an empty DataFrame to store all data
    combined_data = pd.DataFrame()
    # Counter for the number of processed files
    file_count = 0

    # Iterate through files in the folder
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.csv'):
            # Extract symbol from file name
            symbol = os.path.splitext(file_name)[0]
            #print(symbol)

            # Read the CSV file
            file_path = os.path.join(folder_path, file_name)
            data = pd.read_csv(file_path)

            # Add symbol column
            data.insert(0, 'Symbol', symbol)

            # Concatenate data to the combined DataFrame
            combined_data = pd.concat([combined_data, data], ignore_index=True)

            # Increment the file count
            file_count += 1

            # Break the loop if the limit is reached
            if limit is not None and file_count >= limit:
                break

    return combined_data

# Define folder path containing ticker CSV files
folder_path = '/home/rizpython236/BT5/ticker_daily1yr'

# Process files and get combined data
combined_data = process_files(folder_path,limit=None)

'''
# Print head of combined_data
print("Head of combined_data:")
print(combined_data.head())

# Print tail of combined_data
print("\nTail of combined_data:")
print(combined_data.tail())
'''

# Save combined data to a single CSV file
combined_data.to_csv('/home/rizpython236/BT5/trade-logs/combined_ticker_data.csv', index=False)
combined_data.to_pickle('/home/rizpython236/BT5/trade-logs/combined_ticker_data.pkl')


combined_data_from_pickle = pd.read_pickle('/home/rizpython236/BT5/trade-logs/combined_ticker_data.pkl')

# Print the DataFrame
print(combined_data_from_pickle)


print("DONE")
