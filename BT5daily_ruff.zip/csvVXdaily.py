import os
import sys
import time

import numpy as np
import pandas as pd
import pytz
from scipy import stats
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
import csv
from datetime import datetime
import traceback

import pandas_ta as ta
from PDFconvert import create_pdf


'''
input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv'  Replace with your CSV file   Pos1yrHighdaily  DDPCTdatadaily
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf'  Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf')
ggg
'''


Monday=True
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)


current_datetimeUTC = datetime.now()
weekdayUTC = datetime.now().strftime("%A")

formatted_datetimeUTC = current_datetimeUTC.strftime("%d %b %Y %I:%M %p")
formatted_datetimeIST = ISTnow.strftime("%d %b %Y %I:%M %p")

day=today.weekday() == 1



print("Start csv daily")


def is_range_bound(dataR, window=100, slope_threshold=0.02):
  """
  Checks if a stock is range-bound based on price slope and historical volatility.

  Args:
    data: A pandas DataFrame containing OHLC (Open, High, Low, Close) data.
    window: Lookback window for slope calculation (default: 20 days).
    slope_threshold: Absolute value threshold for low slope (default: 0.02).

  Returns:
    True if the stock is considered range-bound, False otherwise.
  """

  ## Calculate closing price slope
  data=dataR
  data["Slope"] = np.polyfit(range(window), data["Close"].iloc[-window:], 1)[0]

  ## Calculate Average True Range (ATR)
  atr = data["High"].max(axis=0) - data["Low"].min(axis=0) - np.abs(
      data["Close"].shift(1) - data["Open"]
  )
  atr = atr.ewm(alpha=1 / window, min_periods=window).mean()

  #print((data["Slope"].iloc[-1]))
  ## Check range-bound conditions
  return (data["Slope"].iloc[-1]) #<= slope_threshold #and np.mean(atr)*3 > 0.005


# Function to calculate adjusted R-squared
def adjusted_r_squared(y, x, slope, intercept,r_value):
    #y_pred = intercept + slope * x
    #ss_total = np.sum((y - np.mean(y)) ** 2)
    #ss_residual = np.sum((y - y_pred) ** 2)
    #r_squared = 1 - (ss_residual / ss_total)
    r_squared = r_value
    n = len(y)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    return adj_r_squared

def calculate_exponential_linear_regression(df,period=12):
    ## Download historical data from yfinance
    data  = df.iloc[-(period+5):] # yf.download(stock_symbol, period="1y")
    data=df
    #print(data)

    ## Calculate the natural logarithm of returns
    returns = np.log(data['Close'])
    #print(returns)
    x = np.arange(len(returns))
    #print(x)
    #window = x

    #slope, intercept, r_value, p_value, std_err = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x))  #stats.linregress(np.arange(len(window)), window)
    slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
    r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
    #annualized_slope = (np.power(np.exp(slope), 252) - 1) * 100
    annualized_slope = (np.power((1+slope), 252)) *100
    #slope, intercept, r_value, p_value, std_err = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x))
    r_squared = r_value
    n = len(x)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    annualized_slope_r_value = round(annualized_slope * (adj_r_squared ** 2), 2)

    #print(slope)
    #print(annualized_slope)

    ## Calculate linear regression
    #slope, _, r_value, _, _ = stats.linregress(x, returns)

    ## Calculate annualized slope
    #annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    ## Calculate annualized_slope_r_value
    #annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    ## Round the annualized slope and annualized_slope_r_value
    #rounded_annualized_slope = round(annualized_slope, 2)

    ## Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    higher_value = annualized_slope_r_value #np.maximum(annualized_slope_r_value, rounded_annualized_slope)

    return higher_value


# Specify the folder path containing CSV files
folder_path = '/home/rizpython236/BT5/ticker_daily1yr/'  ## Replace with the actual folder path
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()[:]
symbols = list(dict.fromkeys(symbols))  #list(set(symbols))
indices= ['^NSEI', 'BSE-500.BO', '^NSEMDCP50', 'NIFTYSMLCAP250.NS', 'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'BTC-USD', 'GOLDBEES.NS', '^NSEBANK', 'PSUBNKBEES.BO', '^CNXPSUBANK', 'NIFTYPVTBANK.NS', 'NIFTY_FIN_SERVICE.NS', '^CNXAUTO', '^CNXREALTY', '^CNXCMDT', '^CNXMETAL', '^CNXINFRA', 'ICICIINFRA.NS', 'PHARMABEES.NS', '^CNXPHARMA', '^CNXFMCG', '^CNXCONSUM', '^CNXIT', '^CNXENERGY', '^CRSLDX', 'MON100.NS', 'MAFANG.NS','HNGSNGBEES.NS', 'MAHKTECH.NS', 'SBIGETS.BO', 'AXISCETF.NS']

NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(NSE570_path)
NSE570symbols = NSE570ticker_df['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols))

selected_files = []

valid_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))


# Initialize counters for MRP13 and MRP25
CountBExp = 0
mrp13_count_more0 = 0
mrp25_count_less0 = 0
mrp25_count_more0 = 0
mrp13_countbothless0 = 0
mrp25_countbothmore0 = 0
CountS_DCH = 0
total_files = 0
file_names = []
Bullish = []
Bearish = []
Start_countmore0 = 0
mrp25_count_mores10 = 0
mrp25_mores10 = []
mrp25_count_M1L1 =[]
mrp25_count_M1L2 =[]
CountS_TTMSqueeze =0
CountS_fall =0
S_TTMSqueeze=[]
S_fall=[]
S_DCH =[]
CountS_EMA=0
S_EMS=[]
BExpShort=[]
CountBExplong=0
BExplong=[]
CountB52high =0
B52High=[]
CountBRSI = 0
BRSI =[]
CountBMRP = 0
BMRP =[]
CountBBTTM =0
BBBTTM = []
CountFinalSell=0
FinalSell=[]
CountFinalBUY=0
FinalBUY=[]
S_ROC =[]
S_DD_PCT_30 =[]
B_DD_PCT_30 =[]
expLonly =[]
expSonly =[]
indiceNOLONG=[]
indiceNOSHORT=[]
EFIU=[]
EFID=[]
SMA_V7SMA_V40=[]
_52wkL= []
_52wkH= []
_52wkrange=[]
SMAUP=[]
SMADWN=[]
RSIUP=[]
RSIDWN=[]
DDPCTlist=[]
MRPUP=[]
MRPDWN =[]
Pos1yrHigh=[]


# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            #total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)

            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                total_files += 1

                ### Read the CSV file into a DataFrame
                df = pd.read_csv(file_path)
                dfexp=df
                dataR=df

                #print(df)

                #df['CCI'] = df.ta.cci(df['High'], df['Low'], df['Close'], window=34)
                #df['CCI'] = tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34)
                #df['CCIavg'] = tb.SMA(df['CCI'], timeperiod=12)
                #df['ADX'] = tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['macd'], df['macdsignal'], df['macdhist'] = tb.MACD(df['Close'], fastperiod=12, slowperiod=26, signalperiod=9)
                #df['ATR'] = tb.ATR(df['High'], df['Low'], df['Close'], timeperiod=10)
                #df['SuperTrend_Upper_Band'] = df['High'] + (3 * df['ATR'])
                #df['SuperTrend_Lower_Band'] = df['Low'] - (3 * df['ATR'])
                #df['SuperTrend'] = (df['SuperTrend_Upper_Band'] + df['SuperTrend_Lower_Band']) / 2
                #df['VolumeSMA'] = tb.SMA(df['Volume'], timeperiod=14)

                ###############################
                df["CCI"]=tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34*5)
                df["CCImovavgL"] = tb.SMA(df["CCI"], timeperiod=14)
                df["CCImovavgS"] = tb.SMA(df["CCI"], timeperiod=7)
                df["macd"], df["macdsignal"], df["macdhist"] = tb.MACDEXT(df['Close'], fastperiod=12, fastmatype=0, slowperiod=26, slowmatype=0, signalperiod=9, signalmatype=0)
                df["ADX"]= tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=18*5)
                df["ADXavg"] = tb.SMA(df["ADX"], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                df["RSI"] = tb.RSI(df['Close'], timeperiod=24*5)
                df["RSIavg"] = tb.SMA(df["RSI"], timeperiod=14)
                df["OBV"] = tb.OBV(df['Close'], df['Volume'])
                df["obvmovavg"] = tb.SMA(df["OBV"], timeperiod=14)
                supertrend_values= ta.supertrend(high=df['High'], low=df['Low'], close=df['Close'], length=10, multiplier=4)#, offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
                df['ST'] = supertrend_values['SUPERT_10_4.0']
                df["SMA_20"] = tb.SMA(df['Close'], timeperiod=20)
                df["SMA_50"] = tb.SMA(df['Close'], timeperiod=50)
                df["SMA_200"] = tb.SMA(df['Close'], timeperiod=200)
                df["SMA_100"] = tb.SMA(df['Close'], timeperiod=100)
                df["EMA_200"] = tb.EMA(df['Close'], timeperiod=200)
                df["EMA_100"] = tb.SMA(df['Close'], timeperiod=100)
                #df["EMA_7W"] = tb.EMA(df['Close'], timeperiod=7)
                #df["EMA_5W"] = tb.EMA(df['Close'], timeperiod=5)
                #donchian_values=ta.donchian(df['High'], df['Low'], lower_length=20, upper_length=20, offset=None,)
                #df= pd.concat([df, donchian_values], axis=1)
                #df["DCH"]= ((df["DCU_20_20"] - df["DCL_20_20"]) / (df["DCU_20_20"] / 1)) * 100
                #df["DCHema"] = tb.SMA(df["DCH"], timeperiod=14)
                df['Exp_lin_reg']= exp12 = calculate_exponential_linear_regression(df,period=13*5)
                df['Exp_lin_regslow']= exp50 = calculate_exponential_linear_regression(df,period=26*5)
                #df["upperband"], df["middleband"], df["lowerband"] = tb.BBANDS(df['Close'], timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
                #squeeze_pro=ta.squeeze_pro(df['High'], df['Low'], df['Close'], bb_length=20, bb_std=2, kc_length=20, kc_scalar_wide=2, kc_scalar_normal=1.5, kc_scalar_narrow=1, mom_length=12, mom_smooth=6,)# use_tr=None, mamode=None,)
                ##print(squeeze_pro) //WIDE SQUEEZE: ORANGE , NORMAL SQUEEZE: RED ,NARROW SQUEEZE: YELLOW ,FIRED WIDE SQUEEZE: GREEN ,NO SQUEEZE: BLUE
                #df= pd.concat([df, squeeze_pro], axis=1)
                df['ROC_1']=tb.ROC(df['Close'], timeperiod=1)
                #df['ROC_2']=tb.ROC(df['Close'], timeperiod=2)
                df['ROC_4']=tb.ROC(df['Close'], timeperiod=4)
                #df['ROC_12']=tb.ROC(df['Close'], timeperiod=12)
                #df['ROC_24']=tb.ROC(df['Close'], timeperiod=24)
                #df['ROC_51']=tb.ROC(df['Close'], timeperiod=51)
                df["SMA_V200"] = tb.EMA(df['Volume'], timeperiod=200)
                #df["SMA_V200"] = tb.MAX(df['Volume'], timeperiod=51)
                df["SMA_30MRP"] = tb.EMA(df['MRP'], timeperiod=30)
                df["SMA_90MRP"] = tb.EMA(df['MRP'], timeperiod=200)
                df["SMA_V50"] = tb.SMA(df['Volume'], timeperiod=50)
                df["SMA_V40"] = tb.SMA(df['Volume'], timeperiod=20)
                df["SMA_V7"] = tb.SMA(df['Volume'], timeperiod=7)
                df["SMA_V4"] = tb.SMA(df['Volume'], timeperiod=4)
                df["52wkH"] = tb.MAX(df['Close'], timeperiod=252)
                df["52wkL"] = tb.MIN(df['Close'], timeperiod=252)
                df["MRPavg30"] = tb.EMA(df["MRP"], timeperiod=90)
                df["MRPavg90"] = tb.EMA(df["MRP"], timeperiod=200)
                #df["RangeBND"] = is_range_bound(dataR, window=200, slope_threshold=0.02)
                pos1yr= round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]),2)
                pos1yrStr =f"{int(pos1yr*100)}%"


                #Base_name=symbol_to_company.get(base_name, base_name)
                #symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))
                #d=df["RangeBND"].iloc[-100]
                #h=df["RangeBND"].iloc[-1]
                #print(Base_name,d,h)

                #if len(df) > 0 and df['ROC_1'].iloc[-1] > 4 and -3.0 < df["RangeBND"].iloc[-1] < 3.0 and df['Close'].iloc[-1] > 0000000000000:
                #    Base_name=symbol_to_company.get(base_name, base_name)
                #    VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V200"].iloc[-2],1)
                #    value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}"
                #    h=df["RangeBND"].iloc[-1]
                #    #print(value_to_append,h)

                ##########################
                if len(df) > 0 and df["SMA_200"].iloc[-1] < df["SMA_50"].iloc[-1] and df["SMA_V200"].iloc[-7]*1.5 < df['SMA_V7'].iloc[-1] and df["RSIavg"].iloc[-1] < df["RSI"].iloc[-1] > 70:
                    #CountBExp += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= int(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2])
                    RSI = df["RSI"].iloc[-1]
                    #print(Base_name)
                    value_to_append = f"{Base_name} | {int(df['CCI'].iloc[-1])} | {int(VX)} | {int(RSI)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                    RSIUP.append(value_to_append)
                    #BExpShort.append(value_to_append1)
                    #print(expSonly)
                    #FinalBUY.append(base_name)
                    #elif:
                if len(df) > 0 and df["RSIavg"].iloc[-1] > df["RSI"].iloc[-1] < 30:
                    #CountBExplong += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                    #print(Base_name)
                    RSI = int(df["RSI"].iloc[-1])
                    CCI= int(df['CCI'].iloc[-1])
                    value_to_append = f"{Base_name} | {int(df['CCI'].iloc[-1])} | {int(VX)} | {int(RSI)}"
                    RSIDWNdata = {
                            "UPCompany": Base_name,
                            "RSI": RSI,
                            "CCI": CCI,
                            #"ADX": ADX,
                            #"MACD":MACD,
                            #"ST":ST,
                            #"MRP13": MRP13,
                            #"MRP25": MRP25,
                            #"EX20":LNEXP20,
                            #"EX50":LNEXP50,
                            #"EMA200":SMA200UP,
                            #"OBV52wk":OBV52wk,
                            "VX": VX,
                            #"Ps1yr":pos1yr,
                            #"DD%": DD_PCT
                            }
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                    RSIDWN.append(value_to_append)
                    #BExplong.append(value_to_append1)
                    #FinalBUY.append(base_name)



                ##########################
                if len(df) > 0 and df["SMA_200"].iloc[-1] < df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] and df["SMA_50"].iloc[-1] < df["SMA_20"].iloc[-1] and df["RSI"].iloc[-1] > 55:
                    #CountBExp += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                    RSI = df["RSI"].iloc[-1]
                    #print(Base_name)
                    value_to_append = f"{Base_name} | {int(df['CCI'].iloc[-1])} | {int(VX)} | {int(RSI)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                    SMAUP.append(value_to_append)
                    #BExpShort.append(value_to_append1)
                    #print(expSonly)
                    #FinalBUY.append(base_name)
                #elif:
                if len(df) > 0 and df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] and df["SMA_50"].iloc[-1] > df["SMA_20"].iloc[-1]:
                    #CountBExplong += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                    #print(Base_name)
                    RSI = df["RSI"].iloc[-1]
                    value_to_append = f"{Base_name} | {int(df['CCI'].iloc[-1])} | {int(VX)} | {int(RSI)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                    SMADWN.append(value_to_append)
                    #BExplong.append(value_to_append1)
                    #FinalBUY.append(base_name)



                ####################
                if len(df) > 0 and df['ROC_1'].iloc[-1] > 4 and df["SMA_V200"].iloc[-2]*6 < df['Volume'].iloc[-1] :
                    #CountBExp += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['Volume'].iloc[-1]/df["SMA_V200"].iloc[-2],1)
                    #print(Base_name)
                    value_to_append = f"{Base_name} | {int(df['ROC_1'].iloc[-1])} | {int(df['CCI'].iloc[-1])} | {int(VX)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                    EFIU.append(value_to_append)
                    #BExpShort.append(value_to_append1)
                    #print(expSonly)
                    #FinalBUY.append(base_name)
                #elif:
                if len(df) > 0 and df['ROC_1'].iloc[-1] < -4 and df["SMA_V200"].iloc[-2]*4 < df['Volume'].iloc[-1] :
                    #CountBExplong += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['Volume'].iloc[-1]/df["SMA_V200"].iloc[-2],1)
                    #print(Base_name)
                    value_to_append = f"{Base_name} | {int(df['ROC_1'].iloc[-1])} | {int(df['CCI'].iloc[-1])} | {int(VX)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                    EFID.append(value_to_append)
                    #BExplong.append(value_to_append1)
                    #FinalBUY.append(base_name)
                if len(df) > 0 and df["SMA_V200"].iloc[-24]*3 < df['SMA_V40'].iloc[-1] and df["SMA_V40"].iloc[-8]*3 < df["SMA_V7"].iloc[-1] and df["SMA_V40"].iloc[-24]*4 < df['SMA_V4'].iloc[-1] and df["obvmovavg"].iloc[-2] < df["OBV"].iloc[-1] and df['ROC_4'].iloc[-1] > 12:
                    #CountBExplong += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],1)
                    value_to_append = f"{Base_name} | {int(df['ROC_1'].iloc[-1])} | {int(VX)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                    SMA_V7SMA_V40.append(value_to_append)
                    #BExplong.append(value_to_append1)
                    #FinalBUY.append(base_name)

                #########################
                if len(df) > 0 and df["52wkH"].iloc[-2] < df['Close'].iloc[-1] and df["SMA_V200"].iloc[-2]*5 < df['Volume'].iloc[-1] and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df["RSIavg"].iloc[-1] < df["RSI"].iloc[-1] > 60:
                    #CountBExp += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['Volume'].iloc[-1]/df["SMA_V50"].iloc[-2],1)
                    #print(Base_name)
                    value_to_append = f"{Base_name} | {int(df['RSI'].iloc[-1])} | {int(df['CCI'].iloc[-1])} | {int(VX)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                    _52wkH.append(value_to_append)
                    #BExpShort.append(value_to_append1)
                    #print(expSonly)
                    #FinalBUY.append(base_name)
                if len(df) > 0 and pos1yr < .5 and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df["RSIavg"].iloc[-1] < df["RSI"].iloc[-1] > 55:
                    #CountBExp += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['Volume'].iloc[-1]/df["SMA_V50"].iloc[-2],1)
                    #print(Base_name)
                    value_to_append = f"{Base_name} | {(pos1yrStr)} | {int(df['RSI'].iloc[-1])} | {int(df['CCI'].iloc[-1])} | {int(VX)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                    _52wkL.append(value_to_append)
                    #BExpShort.append(value_to_append1)
                    #print(value_to_append)
                    #FinalBUY.append(base_name)
                lower_bound = df["52wkL"].iloc[-1] * 1.0  ## Calculate 25% lower bound
                upper_bound = df["52wkL"].iloc[-1] * 1.30  ## Calculate 25% upper bound
                latest_close = df["Close"].iloc[-1]
                Rally = int(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100)
                Rally = f"{Rally}%"
                last_10_closes = df["Close"].iloc[-10:]  ## Get the last 10 closing prices
                latest_52wkL = df["52wkL"].iloc[-1]  ## Get the most recent 52-week low
                if len(df) > 0 and any(close == latest_52wkL for close in last_10_closes) and lower_bound <= latest_close <= upper_bound and df["SMA_V40"].iloc[-10] < df['SMA_V7'].iloc[-1] and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df["CCI"].iloc[-1] > df["CCImovavgS"].iloc[-1] > df["CCImovavgL"].iloc[-1] :
                    #CountBExp += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],1)
                    #print(Base_name)
                    value_to_append = f"{Base_name} | {Rally} | {int(VX)}"
                    #value_to_append1 = f"{Base_name} {round(df['Exp_lin_reg'].iloc[-1], 1)}"
                    _52wkrange.append(value_to_append)
                    #BExpShort.append(value_to_append1)
                    #print(expSonly)
                    #FinalBUY.append(base_name)

                    ######################
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["DD_PCT"].iloc[-1] > 5 and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df["MRPavg30"].iloc[-1] > df["MRPavg90"].iloc[-1]*1.05):
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #pos1yrStr =f"{int(pos1yr*100)}%"
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > -90000 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > -90000 else ""
                        ST ="UP" if df["ST"].iloc[-1] > df['Close'].iloc[-1] else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-30:] == df["52wkL"].iloc[-1]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        #print(OBV52wk)
                        MRPx= int(min(df["MRP13"].iloc[-1],df["MRP25"].iloc[-1]))
                        #MRP13= round(df["MRP13"].iloc[-1],2)
                        MRP25= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "NSE570":NSE570s,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "ST":ST,
                                    #"MRP13": MRP13,
                                    "MRP": MRP25,
                                    "EX20":LNEXP20,
                                    "EX50":LNEXP50,
                                    "EMA200":SMA200UP,
                                    "OBV52wk":OBV52wk,
                                    "VX": VX,
                                    "Ps1yr":pos1yrStr,
                                    "DD%": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        DDPCTlist.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and pos1yr >.70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df["MRPavg30"].iloc[-1] > df["MRPavg90"].iloc[-1]*1.05):
                        Base_name=symbol_to_company.get(base_name, base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > -90000 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > -90000 else ""
                        ST ="UP" if df["ST"].iloc[-1] > df['Close'].iloc[-1] else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-30:] == df["52wkH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        #print(OBV52wk)
                        MRPx= int(min(df["MRP13"].iloc[-1],df["MRP25"].iloc[-1]))
                        MRP13= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        #MRP25= round(df["MRP25"].iloc[-1],2)
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataPos1yrHigh = {
                                    "Company": Base_name,
                                    "NSE570":NSE570s,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "ST":ST,
                                    "MRP": MRP13,
                                    #"MRP25": MRP25,
                                    "EX20":LNEXP20,
                                    "EX50":LNEXP50,
                                    "EMA200":SMA200UP,
                                    "OBV52wk":OBV52wk,
                                    "VX": VX,
                                    "Ps1yr":pos1yrStr,
                                    "DD%": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        Pos1yrHigh.append(dataPos1yrHigh)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                ##########################
                if len(df) > 0 and (df["MRPavg30"].iloc[-1] > df["MRPavg90"].iloc[-1]*1.05) and  df["RSIavg"].iloc[-1] < df["RSI"].iloc[-1] > 55 and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df["CCI"].iloc[-1] > df["CCImovavgL"].iloc[-1] and df["SMA_V200"].iloc[-8]*1 < df['SMA_V7'].iloc[-1]:
                    #CountBExp += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    #VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],2)
                    VX= df['CCI'].iloc[-1]
                    RSI = df["RSI"].iloc[-1]
                    #print(Base_name)
                    MRPx= round(df["MRP13"].iloc[-1],2)
                    value_to_append = f"{Base_name} | {pos1yrStr} | {int(df['RSI'].iloc[-1])} | {int(VX)} | {float(MRPx)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                    MRPUP.append(value_to_append)
                    #BExpShort.append(value_to_append1)
                    #print(expSonly)
                    #FinalBUY.append(base_name)
                #elif:
                if len(df) > 0 and (df["MRPavg30"].iloc[-1]*1.05 < df["MRPavg90"].iloc[-1]) and  df["RSIavg"].iloc[-1] > df["RSI"].iloc[-1] < 45 and df["obvmovavg"].iloc[-1] > df["OBV"].iloc[-1] and df["CCI"].iloc[-1] < df["CCImovavgL"].iloc[-1]:
                    #CountBExplong += 1
                    Base_name=symbol_to_company.get(base_name, base_name)
                    #VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],2)
                    VX= df['CCI'].iloc[-1]
                    #print(Base_name)
                    RSI = df["RSI"].iloc[-1]
                    MRPx= round(df["MRP13"].iloc[-1],2)
                    value_to_append = f"{Base_name} | {pos1yrStr} | {int(df['RSI'].iloc[-1])} | {int(VX)} | {float(MRPx)}"
                    #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                    MRPDWN.append(value_to_append)
                    #BExplong.append(value_to_append1)
                    #FinalBUY.append(base_name)
    except Exception as e:
        print(f"csvVXdaily error: {e}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass

##########################



#expLonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
#expSonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
EFIU.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True)
EFID.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True)
SMA_V7SMA_V40.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True)
_52wkL.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True)
_52wkH.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True)
_52wkrange.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True)
SMAUP.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
SMADWN.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIUP.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIDWN.sort(key=lambda x: float(x.split(' | ')[-1]), reverse= False) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
#DDPCTlist.sort(key=lambda x: float(x.split('***')[-1]), reverse=True)
MRPUP.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
MRPDWN.sort(key=lambda x: float(x.split(' | ')[-1]), reverse=False) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)

'''
#indiceNOSHORT.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOSHORT[0] = 'Indices Exp lin Short-Long'

#indiceNOLONG.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOLONG[0] = 'Indices Exp lin Long'

for i in range(0, len(indiceNOSHORT), 35):
        block = indiceNOSHORT[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        ##post_telegram_message('\n'.join(block))

for i in range(0, len(indiceNOLONG), 35):
        block = indiceNOLONG[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        #post_telegram_message('\n'.join(block))
'''
# Calculate percentages
#Exp_percentage_mores40 = (S_TTMSqueeze / total_files) * 100
#print(Exp_percentage_mores40)

#mrp25_percentage_mores10 = (mrp25_count_mores10 / total_files) * 100
#mrp13_percentageless0 = (CountBExp / total_files) * 100
#mrp13_percentagemore0 = (mrp13_count_more0 / total_files) * 100
#mrp25_percentageless0 = (mrp25_count_less0 / total_files) * 100
#mrp25_percentagemore0 = (mrp25_count_more0 / total_files) * 100
#mrp25_percentagebothless0 = (mrp13_countbothless0 / total_files) * 100
#mrp25_percentagebothmore0 = (mrp25_countbothmore0 / total_files) * 100
#df = pd.DataFrame({'RP': file_names})
#df = pd.DataFrame({'BullCandle': Bullish})
#df = pd.DataFrame({'BearCandle': Bearish})
BUYmax_length = max(len(file_names), len(BExpShort), len(BExplong), len(B52High) , len(BRSI),len(BMRP),len(BBBTTM),len(B_DD_PCT_30) )
SELLmax_length = max(len(file_names), len(S_TTMSqueeze),len(S_ROC), len(S_fall), len(S_DCH) , len(S_EMS),len(S_DD_PCT_30),)

expmax_length = max(len(file_names), len(expSonly),len(expLonly),len(BExpShort),len(BExplong),len(EFIU),len(EFID))#,len(indiceNO))
VXmax_length = max(len(file_names), len(EFIU),len(EFID),len(SMA_V7SMA_V40))
_52wk_length = max(len(file_names), len(_52wkH),len(_52wkL),len(_52wkrange))
SMA_length = max(len(file_names), len(SMAUP),len(SMADWN),len(SMADWN))
RSI_length = max(len(file_names), len(RSIUP),len(RSIDWN),len(RSIDWN))
#DDPCTlist_length = max(len(file_names), len(DDPCTlist),len(DDPCTlist),len(DDPCTlist))
MRP_length = max(len(file_names), len(MRPUP),len(MRPUP),len(MRPDWN))

MRPlist_data = {
    'MRPUP | Ps1yr | RSI | CCI | MRP': MRPUP + [' '] * (MRP_length - len(MRPUP)),
    'MRPDWN | Ps1yr | RSI | CCI | MRP': MRPDWN + [' '] * (MRP_length - len(MRPDWN))
}


#DDPCTlist_data = {
#    'DD*RSI*VX*CCI*MRP***DDPCT': DDPCTlist + ['--'] * (DDPCTlist_length - len(DDPCTlist))
#}

RSI_data = {
    'RSIUP | CCI | Vx | RSI': RSIUP + [' '] * (RSI_length - len(RSIUP)),
    'RSIDWN | CCI | Vx | RSI': RSIDWN + [' '] * (RSI_length - len(RSIDWN))
    #'52wkrange-Rally--Vx': _52wkrange + [' '] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}


SMA_data = {
    'SMAUP | CCI | Vx | RSI': SMAUP + [' '] * (SMA_length - len(SMAUP)),
    'SMADWN | CCI | Vx | RSI': SMADWN + [' '] * (SMA_length - len(SMADWN))
    #'52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

_52wkdata = {
    '52wkH | RSI | CCI | UP': _52wkH + [' '] * (_52wk_length - len(_52wkH)),
    '52wkL | pos1yr | RSI | CCI | DWN': _52wkL + [' '] * (_52wk_length - len(_52wkL)),
    '52wkrange | Rally | Vx': _52wkrange + [' '] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

expdata = {
    'ExpShort | L | S': expSonly + [' '] * (expmax_length - len(expSonly)),
    'ExpLong | S | L': expLonly + [' '] * (expmax_length - len(expLonly))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

VXdata = {
    #'ExpShort-L--S': expSonly + ['--'] * (expmax_length - len(expSonly)),
    #'ExpLong-S--L': expLonly + ['--'] * (expmax_length - len(expLonly))
    'EFIUP | ROC | CCI | UP': EFIU + [' '] * (VXmax_length - len(EFIU)),
    'EFIDWN | ROC | CCI | DWN': EFID + [' '] * (VXmax_length - len(EFID)),
    'SMA_V7/V40 | ROC | V': SMA_V7SMA_V40 + [' '] * (VXmax_length - len(SMA_V7SMA_V40))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

BUYdata = {
    'TTM': BBBTTM + ['--'] * (BUYmax_length - len(BBBTTM)),
    #'ExpShort': BExpShort + ['--'] * (BUYmax_length - len(BExpShort)),
    #'Explong': BExplong + ['--'] * (BUYmax_length - len(BExplong)),
    'RSI': BRSI + [' '] * (BUYmax_length - len(BRSI)),
    'DD_PCT_25': B_DD_PCT_30 + [' '] * (BUYmax_length - len(B_DD_PCT_30)),
    '52High': B52High + [' '] * (BUYmax_length - len(B52High)),
    'MRP': BMRP + [' '] * (BUYmax_length - len(BMRP))
}

SELLdata = {
    'TTM': S_TTMSqueeze + [' '] * (SELLmax_length - len(S_TTMSqueeze)),
    'ROC': S_ROC + [' '] * (SELLmax_length - len(S_ROC)),
    'Fall': S_fall + [' '] * (SELLmax_length - len(S_fall)),
    'DD_PCT_25': S_DD_PCT_30 + [' '] * (SELLmax_length - len(S_DD_PCT_30)),
    'DCH': S_DCH + [' '] * (SELLmax_length - len(S_DCH)),
    'SEMA200': S_EMS + [' '] * (SELLmax_length - len(S_EMS))
}



dfBUY = pd.DataFrame(BUYdata)
dfSELL = pd.DataFrame(SELLdata)
dfexpdata = pd.DataFrame(expdata)
dfVXdata = pd.DataFrame(VXdata)
df52wkdata = pd.DataFrame(_52wkdata)
dfSMA_data = pd.DataFrame(SMA_data)
dfRSI_data = pd.DataFrame(RSI_data)
#dfDDPCTlist_data =pd.DataFrame(DDPCTlist_data)
dfMRPlist_data =pd.DataFrame(MRPlist_data)

#print(dfBUY)
#print(dfSELL)
#print(dfexpdata)


old52wkdataWkly_path = '/home/rizpython236/BT5/trade-logs/52wkdatadaily.csv'
old52wkdataWklydf = pd.read_csv(old52wkdataWkly_path)


#dfBUY.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv', index=False)
#dfSELL.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv', index=False)
#dfexpdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv', index=False)
dfVXdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv', index=False)
dfSMA_data.to_csv('/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/trade-logs/52wkdatadaily.csv', index=False)
dfRSI_data.to_csv('/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv', index=False)
#dfDDPCTlist_data.to_csv('/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv', index=False)
dfMRPlist_data.to_csv('/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv', index=False)


try:
    #print(DDPCTlist)
    if len(DDPCTlist) > 0:  # Check if DDPCTlist has entries before writing
      # Define the folder path (replace 'your_folder_path' with your desired location)
      folder_path = '/home/rizpython236/BT5/screener-outputs/'
      DDPCTlist.sort(key=lambda row: row["ADX"], reverse=True)

      # Create the folder if it doesn't exist
      #import os
      os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

      # Open the CSV file in write mode and write headers
      with open(os.path.join(folder_path, "DDPCTdatadaily.csv"), "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=data.keys())
        writer.writeheader()

        # Write rows from DDPCTlist to the CSV file
        for row in DDPCTlist:
            writer.writerow(row)

        print(f"DDPCTlist.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4 =False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf')
    else:
      print("No data found to write to DDPCTlist.csv")
except Exception as e:
    print(f"Error in pdf DDPCTlist- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass


try:
    #print(DDPCTlist)
    if len(Pos1yrHigh) > 0:  # Check if DDPCTlist has entries before writing
      # Define the folder path (replace 'your_folder_path' with your desired location)
      folder_path = '/home/rizpython236/BT5/screener-outputs/'
      Pos1yrHigh.sort(key=lambda row: row["ADX"], reverse=True)

      # Create the folder if it doesn't exist
      #import os
      os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

      # Open the CSV file in write mode and write headers
      with open(os.path.join(folder_path, "Pos1yrHighdaily.csv"), "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=data.keys())
        writer.writeheader()

        # Write rows from DDPCTlist to the CSV file
        for row in Pos1yrHigh:
            writer.writerow(row)

        print(f"Pos1yrHighdaily.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4 =False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.pdf')
    else:
      print("No data found to write to Pos1yrHighdaily.csv")
except Exception as e:
    print(f"Error in pdf Pos1yrHighdaily- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

# Example usage:
#sector_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#valid_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#replace_values(sector_file, valid_file, output_file)

if weekday != "Tuesday":
    #dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
    #dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
    #dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
    print("Made copy of Old file")


input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/52wkdatadaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/RSIdatadaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)


input_csv_file = '/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MRPdatadaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf')
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.pdf')
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/52wkdatadaily.pdf')

time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/MRPdatadaily.pdf')
time.sleep(2)

if dfRSI_data.empty:
    print("RSI_data is empty")
else:
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/RSIdatadaily.pdf')
time.sleep(2)
if dfSMA_data.empty:
    print("SMA_data is empty")
else:
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.pdf')


try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf'
    if os.path.exists(output_pdf_file):
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf')
except Exception as e:
    print(f"Error in ruuning DDPCTdatadaily pdf- {e}")
    pass

try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.pdf'
    if os.path.exists(output_pdf_file):
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/Pos1yrHighdaily.pdf')
except Exception as e:
    print(f"Error in ruuning Pos1yrHighdaily pdf- {e}")
    pass

##########
new =df52wkdata
old = old52wkdataWklydf
change = pd.DataFrame()

new['52wkH | RSI | CCI | UP'] = new['52wkH | RSI | CCI | UP'].apply(lambda x: x.split(' | ')[0])
old['52wkH | RSI | CCI | UP'] = old['52wkH | RSI | CCI | UP'].apply(lambda x: x.split(' | ')[0])

old['52wkL | pos1yr | RSI | CCI | DWN'] = old['52wkL | pos1yr | RSI | CCI | DWN'].apply(lambda x: x.split(' | ')[0])
new['52wkL | pos1yr | RSI | CCI | DWN'] = new['52wkL | pos1yr | RSI | CCI | DWN'].apply(lambda x: x.split(' | ')[0])

for column in old.columns:
    change[column] = new[column][~new[column].isin(old[column])]
change.to_csv('/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv', index=False)
#print(change)
time.sleep(2)
input_csv_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.pdf')

#print(df)
#print(Start_countmore0)
#df.to_csv('/home/rizpython236/BT5/screener-outputs/Relative_perf.csv', index=False)

#time.sleep(2)

#input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  Replace with your CSV file
#output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  Replace with desired output PDF file

#create_pdf(input_csv_file, output_pdf_file)

##post_telegram_file('/home/rizpython236/BT5/screener-outputs/Relative_perf.pdf')


'''

#######################

if 1==1:
#try:
    if weekday == "Wednesday":
        print("Running Chgwatchlist")
        try:
            Buyfile_path = '/home/rizpython236/BT5/OldwatchlistBUY.csv'
            Bolddf = pd.read_csv(Buyfile_path)

            Sellfile_path = '/home/rizpython236/BT5/OldwatchlistSELL.csv'
            Solddf = pd.read_csv(Sellfile_path)

            expfile_path = '/home/rizpython236/BT5/OldwatchlistExpLinR.csv'
            expdf = pd.read_csv(expfile_path)
        except Exception as e:
            print(f"file not found Oldgwatchlist- {e}")
            pass


        dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
        dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
        dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
        print("Made copy of Old file")


        new =dfBUY
        old = Bolddf
        change = pd.DataFrame()
        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])
        #new['DD_PCT_25'] = new['DD_PCT_25'].applymap(lambda x: x.rsplit('-', 1)[-1])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])


        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv'  Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf'  Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf')



        ####

        new =dfSELL
        old = Solddf
        change = pd.DataFrame()

        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv'  Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf'  Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf')


        ####

        new =dfexpdata
        old = expdf
        change = pd.DataFrame()

        new['ExpLong-S--L'] = new['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])
        old['ExpLong-S--L'] = old['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        old['ExpShort-L--S'] = old['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])
        new['ExpShort-L--S'] = new['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv'  Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf'  Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf')

    else:
        1+1
#except Exception as e:
#    print(f"Error in ruuning Chgwatchlist- {e}")
#    pass
'''


print("done")



























