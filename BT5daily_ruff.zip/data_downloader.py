import os
import sys
import time

import numpy as np

#sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python39/site-packages/")
#sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages')
import pandas as pd
import pytz


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
from custum_index import (
    calculate_custom_index,
    load_index_constituents_from_csv,
    plot_index_close_prices,
)
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from telegram_bot import post_telegram_file, post_telegram_message
import yfinance as yf


print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")
#import asyncio
#import cleanup
#import logging
#logger = logging.getLogger('yfinance')
#logger.setLevel(logging.ERROR)  # default: only print errors
#logger.setLevel(logging.CRITICAL)  # disable printing
#logger.setLevel(logging.DEBUG)  # verbose: print errors & debug info
from datetime import date, datetime, timedelta
import traceback

from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    NIFTY_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    SYMBOLS_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    VALID_TICKERS_CSV,
)

#from scipy.stats import gmean
#from concurrent.futures import ThreadPoolExecutor, as_completed
#from tqdm import tqdm
import talib as tb


def download_ticker_data(symbol):
    try:
        # Check if ticker is valid
        ticker = yf.Ticker(symbol)
        # Your validation logic here
        last_price = 1000  # Your actual validation code
        reg_mp = last_price > 15

        if not reg_mp:
            return symbol, None  # Return None for invalid tickers

        # Download data
        data = yf.download(
            symbol,
            start=START_DATE,
            end=END_DATE,
            interval="1wk",
            rounding=True,
            threads=True,
            multi_level_index=False,
            progress=False,
            back_adjust=True,
            repair=False,
            keepna=False,
            actions=False,
            auto_adjust=True
        )

        if len(data) > 55:
            data.index = data.index.date
            data.rename_axis("Date", inplace=True)
            return symbol, data
        return symbol, None

    except Exception as e:
        return symbol, None


print("Initiating weekly pybroker Data Downloader!")
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

#today = datetime.now(IST_TIMEZONE).date()
#yesterday = today - timedelta(days=1)
#end_date = yesterday



end_date = datetime.now(IST_TIMEZONE).date() #- timedelta(weeks=2)

#end_date = date.today()
# start_date = end_date - timedelta(days=365)
start_date = end_date - timedelta(weeks=77) #77 weekly  52+12 64
END_DATE = str(end_date)
START_DATE = str(start_date)
#print(START_DATE)
#post_telegram_message(START_DATE)
print(f"start date {START_DATE} ,end date {END_DATE}.")
time.sleep(1)
#post_telegram_message(END_DATE)
post_telegram_message(f"The start date is {START_DATE} and the end date is {END_DATE}.")


# ticker_symbols_file = "symbol.csv"
tickers_df = pd.read_csv(SYMBOLS_CSV)
tickers_list = list(tickers_df["Symbol"].unique())[:]

#tickers_list= ["^NSEI","^NSEBANK","RELIANCE.NS","INFY"]
additional_tickers = ["^NSEI", "^NSEBANK", "RELIANCE.NS", "INFY"]
#tickers_list.extend(additional_tickers)
#tickers_list = additional_tickers + tickers_list

'''
path=  TICKER_CSV_DATA_FOLDER_PATH  #'/home/rizpython236/BT5/ticker_15yr'
TJI_IC_path = '/home/rizpython236/BT5/trade-logs/TJI_index.csv'
TJI_IC_path = pd.read_csv(TJI_IC_path)
TJI_IC_path = TJI_IC_path['Symbol'].tolist()[:]
#TJI_IC_path = list(set(TJI_IC_path))
index_csv_file = "/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv"

#path=  '/home/rizpython236/BT5/ticker_15yr'
#Plot the Close Prices of the indices
plot_index_close_prices(path, TJI_IC_path[:33],index_csv_file,Frequency='Wk') # Wk Daily All52wk All200daily Allfull
plot_index_close_prices(path, TJI_IC_path[33:],index_csv_file,Frequency='Wk') # Wk Daily All52wk All200daily Allfull
plot_index_close_prices(path, TJI_IC_path[:],index_csv_file,Frequency='All52wk') # Wk Daily All52wk All200daily Allfull
ll
'''

# # Downloading data
print("-" * 100)
print("Starting download for data from {} to {}.".format(start_date, end_date))
print("-" * 100)

invalid_tickers = []
incomplete_data_tickers = []
valid_tickers = []

print("Total number of symbols: ", len(tickers_list))
count=0
total_symbols = len(tickers_list)


for symbol in tickers_list:
    #break
    count +=1
    if count % 300 == 0:
        print(f"Processed {count} symbols. Pausing for 5 minutes...")
        time.sleep(4*60)  # 600 seconds = 10 minutes


    #print(count)
    #print("Total number of processed symbols: ", count, "({:.2f}%)".format(count / total_symbols * 100))
    remaining_symbols = total_symbols - count
    #print("Total number of remaining symbols: ", remaining_symbols, "({:.2f}%)".format(remaining_symbols / total_symbols * 100))
    # detecting invalid tickers

    ticker = yf.Ticker(symbol) #line77

    #ticker = yf.Ticker(symbol).info  #line80
    ticker_info = None
    try:
        #ticker_info = ticker.info
        #reg_mp =ticker_info.get("regularMarketPrice")
        #reg_mp=ticker

        #####history = ticker.history(period='1d',auto_adjust=True)
        #history = ticker.history(start=start_date, end=start_date + timedelta(days=1),interval="1wk", auto_adjust=True)
        #######last_price = history['Close'].iloc[-1]
        #volume = history['Volume'].iloc[-1]
        #marketCap =ticker.info['marketCap']
        last_price =1000
        reg_mp=last_price>15 #and marketCap > 500000000
        #reg_volume=volume>50
        #print(last_price)

        #stock_data = yf.Ticker(stock_symbol)
        # Get the income statement
        #income_statement = ticker.financials

        # Get the balance sheet
        #balance_sheet = ticker.balance_sheet

        # Extract Gross Profit from the income statement
        #gross_profit = income_statement.loc['Gross Profit'].values[0]

        # Extract Shareholder's Equity from the balance sheet
        #shareholders_equity = balance_sheet.loc["Total Stockholder Equity"].values[0]

        #gross_profit=gross_profit>1
        #shareholders_equity=shareholders_equity>1
        #print(reg_mp)
        #print(gross_profit)
        #print(shareholders_equity)

        #reg_mp=last_price = ticker['regularMarketPrice']

        #reg_mp=ticker_info = ticker.fast_info.get('last_price')#ticker.info
        #reg_mp =ticker_info.get("regularMarketPrice")


        #print(reg_mp)
        if not reg_mp:
            invalid_tickers.append(symbol)
            #print("Invalid ticker - {}".format(symbol))
            continue
    except:# yf.exceptions.TickerSymbolError: #
        invalid_tickers.append(symbol)
        #print("Invalid ticker - {}".format(symbol))
        continue

    #print("Downloading data for => {}".format(symbol))
    data = yf.download(
        symbol,
        start=START_DATE,
        end=END_DATE,
        interval="1wk", #1wk
        rounding=True,
        threads=True,
        multi_level_index=False,
        progress=False,
        back_adjust=True,
        repair=False,  # Data repair is used to fill in missing or corrupted data
        keepna=False,  # removes any rows with missing data.
        actions=False,  #excludes dividend and stock split events from the dat
        auto_adjust=True  #adjusted for corporate actions like stock splits and dividends
        #ignore_tz=True
    )


    ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
    if len(data) > 55:
        #print(data.column)
        # Strip spaces from column names
        #data.columns = data.columns.str.strip()
        #Convert the 'Date' column to datetime and remove the time part
        #data[0] = pd.to_datetime(data[0]).dt.date
        data.index = data.index.date
        data.rename_axis("Date", inplace=True)
        data.to_csv(ticker_csv_file_path)
        #print(data)
    time.sleep(0.10)

'''
# Using ThreadPoolExecutor to parallelize downloads
with ThreadPoolExecutor(max_workers=10) as executor:  # Adjust max_workers as needed
    pass
    # Submit all download tasks
    future_to_symbol = {
        executor.submit(download_ticker_data, symbol): symbol
        for symbol in tickers_list
    }

    # Use tqdm to show progress
    for future in tqdm(as_completed(future_to_symbol), total=len(tickers_list), desc="Downloading"):
        symbol = future_to_symbol[future]
        try:
            result_symbol, data = future.result()
            if data is None:
                invalid_tickers.append(symbol)
            else:
                # Save the data to CSV
                ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
                data.to_csv(ticker_csv_file_path)
                valid_data[symbol] = data
        except Exception as e:
            invalid_tickers.append(symbol)
        time.sleep(0.10)  # Small delay to avoid rate limiting

print(f"\nData download task completed. {len(valid_tickers)} valid tickers, {len(invalid_tickers)} invalid tickers.")
'''

print("Data download task completed.")
print("Validating data and removing incomplete ticker-data files.")


def get_filepaths(directory):
    """
    This function lists all the file names present in directory.
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)  # Add it to the list.

    return file_paths


def check_data_continuity(df, interval=7):
    """
    input - df with datetime index and interval to check gaps for
    output - this func will return False if there are gaps present
    otherwise return True
    """
    deltas = df['Date'].diff()[1:]
    datetime_gaps = deltas[deltas > timedelta(days=interval)]
    return datetime_gaps.empty

def check_num_rows(df1, df2):
    return df1.shape[0] == df2.shape[0]



files_to_process = get_filepaths(TICKER_CSV_DATA_FOLDER_PATH)
nifty_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + NIFTY_CSV
nifty_df = pd.read_csv(nifty_file_path)
nifty_df.dropna(inplace=True)
nifty_rows = len(nifty_df)
# print(nifty_rows)

nifty_start_date, nifty_end_date = nifty_df["Date"][0], nifty_df["Date"][nifty_rows - 1]

if len(nifty_start_date) == 10:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date,"%Y-%m-%d").date()
elif len(nifty_start_date) == 25:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d %H:%M:%S%z").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d %H:%M:%S%z").date()
else:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()


#nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
#nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()

#nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d %H:%M:%S%z").date()
#nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d %H:%M:%S%z").date()

#incomplete_data_tickers = []
#valid_tickers = []


for file in files_to_process:
    """folder\\BHARTIAIRTEL.NS.csv"""
    ticker_name = file.split("/")[-1:][0]     #file.split("\\")[1]
    ticker_name = ticker_name.split(".csv")[0]

    #print("Validating {} file".format(ticker_name))
    ticker_df = pd.read_csv(file)
    # print(len(ticker_df))

    # Drops rows where OHLC = 0 or value = NA
    ticker_df.dropna(inplace=True)
    ticker_df = ticker_df[ticker_df.Open != 0]
    ticker_df = ticker_df[ticker_df.High != 0]
    ticker_df = ticker_df[ticker_df.Low != 0]
    ticker_df = ticker_df[ticker_df.Close != 0]
    #ticker_df = ticker_df[ticker_df.Volume != 0] #
    #ticker_df = ticker_df[ticker_df.Close != ticker_df.Open] #
    ticker_df['Volume'] = ticker_df['Volume'].replace(0, 1)
    ticker_df['Volume'] = ticker_df['Volume'].fillna(1)

    ticker_df.reset_index(drop=True, inplace=True)
    Ticker_rows = len(ticker_df)
    # print(len(ticker_df))
    ticker_df["Date"] = pd.to_datetime(ticker_df["Date"]).dt.date

    ## Delete rows earlier than nifty start-date
    # ticker_df = ticker_df[ticker_df["Date"] >= nifty_start_date_obj]
    ## Delete rows if any present after nifty end date
    ticker_df = ticker_df[ticker_df["Date"] <= nifty_end_date_obj]


    # CHECK IF DATA IS CONTINUOUS - PROPER WEEKLY GAPS
    is_data_rows_equals_nifty = check_num_rows(ticker_df,nifty_df)  #for daily
    is_data_continuous = check_data_continuity(ticker_df)   #weekly

    if not check_data_continuity:  #is_data_rows_equals_nifty use for daily data
        print("Weekly gaps found in {}".format(ticker_name))
    else:
        #print("Data is consistent in weekly TF for {}".format(ticker_name))
        1+1

    # DECIDE - HOW TO FILTER

    # Only check if the total rows are atleast 52 and data cont in weekly TF
    if len(ticker_df) >= 53*0  and is_data_rows_equals_nifty == True:  #check_data_continuity

        # Check if either rows are atleast 52 or atleast >= nifty-rows
        # if len(ticker_df) >= 52 or len(ticker_df) >= nifty_rows:
        #print(
        #    "Complete Data Ticker => {} with total rows => {} vs Nifty {} rows".format(
        #        ticker_name, Ticker_rows,nifty_rows
        #    )
        #)
        valid_tickers.append(ticker_name)
        ticker_df.to_csv(file, index=False)
    else:
        incomplete_data_tickers.append(ticker_name)
        # deleting the incomplete ticker data file
        '''
        print(
            "Incomplete Data Ticker => {} with total rows => {} vs Nifty {} rows".format(
                ticker_name, len(file),nifty_rows
            )
        )
        '''
        if os.path.exists(file):
            os.remove(file)

try:
    # Load index constituents from a CSV file
    csv_path = '/home/rizpython236/BT5/trade-logs/index_constituents.csv'
    index_constituents = load_index_constituents_from_csv(csv_path)
    path=  TICKER_CSV_DATA_FOLDER_PATH  #'/home/rizpython236/BT5/ticker_15yr'
    # Calculate indices
    #valid_tickers = []
    calculate_custom_index(path, index_constituents, weighting_method='return_equal', valid_tickers=valid_tickers) #Choose 'price', 'Price_equal', return_equal or 'custom'." RSI  ATR

    #index_names = ['TJI_RTGAGY', 'TJI_alkCHE']
    # Define the index names to plot
    TJI_IC_path = '/home/rizpython236/BT5/trade-logs/TJI_index.csv'
    TJI_IC_path = pd.read_csv(TJI_IC_path)
    TJI_IC_path = TJI_IC_path['Symbol'].tolist()[:]
    #TJI_IC_path = list(set(TJI_IC_path))
    index_csv_file = "/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv"

    #path=  '/home/rizpython236/BT5/ticker_15yr'
    #Plot the Close Prices of the indices
    plot_index_close_prices(path, TJI_IC_path[:33],index_csv_file,Frequency='Wk') # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(path, TJI_IC_path[33:],index_csv_file,Frequency='Wk') # Wk Daily All52wk All200daily Allfull
    plot_index_close_prices(path, TJI_IC_path[:],index_csv_file,Frequency='All52wk') # Wk Daily All52wk All200daily Allfull

except Exception as e:
    print(f"Error occurred: {str(e)}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    #print("Error type:", e.__class__.__name__)
    #print("Error message:", str(e))
    #print("Traceback:\n", traceback_str)
    pass

#_____________________-

invalid_tickers_df = pd.DataFrame()

invalid_tickers_df["invalid_ticker"] = invalid_tickers
INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
invalid_tickers_df.to_csv(INVALID_TICKERS_FILE_PATH, index=False)

valid_tickers_df = pd.DataFrame()
valid_tickers_df["Symbol"] = valid_tickers
from telegram_bot import post_telegram_message


print("Total number of valid weekly symbols: {}".format(len(valid_tickers)))
post_telegram_message("Total valid weekly symbols: {}".format(len(valid_tickers)))
vt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + VALID_TICKERS_CSV
valid_tickers_df.to_csv(vt_file_path, index=False)
valid_tickers_df.to_csv('/home/rizpython236/BT5/screener-outputs/valid_tickers_stock-pattern.csv', index=False)


incomplete_data_tickers_df = pd.DataFrame()
incomplete_data_tickers_df["Symbol"] = incomplete_data_tickers
idt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV
incomplete_data_tickers_df.to_csv(idt_file_path, index=False)

'''
import relative_performance

from add_company_name import add_company_names_and_industry,vlookup_and_merge,update_output_file,copyfile1
input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
update_output_file(input_file, output_file)

import csv_file2copy
'''

