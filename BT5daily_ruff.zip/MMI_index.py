# from datetime import datetime, timedelta
import csv
import datetime
from datetime import datetime as dt, timedelta
import os
import sys
import time
import traceback

from matplotlib.dates import DateFormatter, MonthLocator
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pandas_ta as ta
import pytz
import yfinance as yf

from settings import SCREENER_OUTPUT_FOLDER_PATH
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")

# post_telegram_message("Scan started!")


folder_path = SCREENER_OUTPUT_FOLDER_PATH
text = None
index = text
latest_index = 0

"""
#/html/body/div[1]/div[3]/div/div[2]/div[1]/div/div[2]/span
<span class="jsx-3654585993 jsx-2307192908 number">58.35</span>
#app-container > div > div.jsx-3800193825.first-fold-root.text-center > div.jsx-3654585993.jsx-2307192908.mood-indicator-root > div > div.jsx-3654585993.jsx-2307192908.mmi-value > span
document.querySelector("#app-container > div > div.jsx-3800193825.first-fold-root.text-center > div.jsx-3654585993.jsx-2307192908.mood-indicator-root > div > div.jsx-3654585993.jsx-2307192908.mmi-value > span")
//*[@id="app-container"]/div/div[2]/div[1]/div/div[2]/span
<span class="jsx-3654585993 jsx-2307192908 number">58.35</span>
<span class="jsx-3654585993 jsx-2307192908 number">58.35</span>
"""


try:
    """
    url = "https://www.tickertape.in/market-mood-index"
    response = requests.get(url)

    soup = BeautifulSoup(response.text, "html.parser")
    #element = soup.select_one(
    #    "#app-container > div > div:nth-of-type(1) > div:nth-of-type(1) > div > div:nth-of-type(2) > span"
    #)

    element = soup.select_one(
        '//*[@id="app-container"]/div/div[2]/div[1]/div/div[2]/span'
    )

    print(element)

    text = float(element.text) # Convert the text to a float
    """

    """
    url = "https://www.tickertape.in"
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    time.sleep(20)

    url = "https://www.tickertape.in/market-mood-index"
    response = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    time.sleep(10)

    tree = html.fromstring(response.content)
    print(tree)
    #//*[@id="app-container"]/div/div[2]/div[1]/div/div[2]/span
    #/html/body/div[1]/div[3]/div/div[2]/div[1]/div/div[2]/span
    element = tree.xpath("/html/body/div[1]/div[3]/div/div[2]/div[1]/div/div[2]/span")
    print(element)
    text_content = element[0].text_content().strip()
    value = float(text_content)
    print(f"Found value: {value}")

    """

    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")

    chrome_options.add_argument(
        "--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option(
        "excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")
    chrome_options.add_experimental_option("prefs", {
        # "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })

    attempt = 0
    max_attempts = 2
    success = False

    while attempt < max_attempts and not success:
        try:

            # Step 1: Initialize browser and navigate to the URL
            browser = webdriver.Chrome(options=chrome_options)

            browser.get("https://www.tickertape.in")
            time.sleep(15)

            # WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.TAG_NAME, "body")))

            url = "https://www.tickertape.in/market-mood-index"

            browser.execute_cdp_cmd("Network.setExtraHTTPHeaders", {
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
                },
            })
            browser.get(url)
            # print(browser.page_source)

            time.sleep(10)

            # Step 2: Wait until the dropdown is present and select "Equity T+1"
            wait = WebDriverWait(browser, 30)
            # text=wait.find_element(By.XPATH,get_xpath(driver,'7SqcnWPGomxhUBf')).text
            # driver.get('https://www.nseindia.com/companies-listing/raising-capital-public-issues-emerge-selecting-a-migration-to-main-board')

            # to fetch the text of element
            # text=browser.find_element(By.XPATH,get_xpath(browser,'7SqcnWPGomxhUBf')).text
            # Wait for the table to be present
            xpath = "/html/body/div[1]/div[3]/div/div[2]/div[1]/div/div[2]/span"
            # table = WebDriverWait(browser, 20).until(EC.presence_of_element_located((By.XPATH, table_xpath)))
            # css_selector  = 'body > div.main.static_content > div > section > div > div > div > div > div > div > div:nth-child(1) > div.col-md-12.midContainer.staticConetnt > div > div > table'
            element = WebDriverWait(browser, 30).until(
                EC.presence_of_element_located((By.XPATH, xpath)))

            # Wait for container first
            # WebDriverWait(browser, 30).until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.midContainer")))
            # Instead of hardcoded CSS, use XPath for any table present in the section
            # table = WebDriverWait(browser, 30).until(EC.presence_of_element_located((By.XPATH, "//table[contains(@class, 'table')]")))

            # table = wait.until(lambda d: d.find_element(By.XPATH, table_xpath))
            # print(table)

            text_content = element.text.strip()
            value = float(text_content)
            print(f"Found value: {value}")

            success = True

        except Exception as e:
            attempt += 1
            print(f"Attempt {attempt} failed with error: {e!s}")
            print(f"⚠️Error occurred: {e!s}")
            traceback_str = traceback.format_exc()
            print(traceback_str)
            # post_telegram_message("Download from bse_ticker_download failed!...")

            if attempt == max_attempts:
                print("Max attempts reached. Failed to download data.")
        finally:
            browser.quit()

    text = value  # float(element.text) # Convert the text to a float
    # text=2
    if text < 20:
        print(f"{text}: MMI Index-ExtremeFear")
        post_telegram_message(f"{text}: MMI Index-ExtremeFear")
    elif text < 30:
        print(f"{text}: MMI Index-HighFear")
        post_telegram_message(f"{text}:MMI Index-HighFear")
    elif 30 <= text <= 50:
        print(f"{text}: MMI Index-Fear")
        post_telegram_message(f"{text}:MMI Index-Fear")
    elif 50 < text <= 70:
        print(f"{text}: MMI Index-Greed")
        post_telegram_message(f"{text}:MMI Index-Greed")
    elif 70 < text <= 80:
        print(f"{text}: MMI Index-HighGreed")
        post_telegram_message(f"{text}:MMI Index-HighGreed")
    else:
        print(f"{text}:MMI Index-ExtremeGreed")
        post_telegram_message(f"{text}:MMI Index-ExtremeGreed")
    print("Extreme Fear  <20\nHigh Fear  <30\nFear  30 to 50\nGreed 50 to 70\nHigh Greed >70\nExtreme Greed >80")
    time.sleep(2)
    post_telegram_message(
        "Extreme Fear  <20\nHigh Fear  <30\nFear  30 to 50\nGreed 50 to 70\nHigh Greed >70\nExtreme Greed >80")

    if text != None:

        # Define the text and marker positions
        labels = [
            "0",
            "20",
            "30-HFear",
            "50-Fear",
            "70-HGreed",
            "80",
            "100",
        ]
        marker_positions = [0, 20, 30, 50, 70, 80, 100]

        # Define the colors for each range
        colors = ["#006400", "#228B22", "#9ACD32",
                  "#FFA07A", "#FF4500", "#8B0000"]

        # Set the value for the text variable
        # text = 56.76

        # Create a figure and axis
        fig, ax = plt.subplots()

        # Set the limits and ticks for the axis
        ax.set_xlim(0, 100)
        ax.set_ylim(0, 1)
        ax.set_xticks(marker_positions)
        ax.set_xticklabels(labels)

        # Remove the y-axis and spines
        ax.yaxis.set_visible(False)
        ax.spines["left"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["top"].set_visible(False)

        # Plot the colored ranges as rectangles
        for i in range(len(marker_positions) - 1):
            ax.axvspan(
                marker_positions[i], marker_positions[i +
                                                      1], color=colors[i], alpha=0.5,
            )

        # Add a vertical line at the text position (56 in this case) and a legend
        ax.axvline(x=text, color="r", linestyle="--",
                   label=f"Sentiment Value: {text}")
        ax.legend()

        # Add a title and show the chart
        ax.set_title("Investor Sentiment")
        # plt.show()
        # Set the file path to include the folder path
        file_path = os.path.join(folder_path, "MMI_Index.png")
        plt.savefig(file_path, dpi=300, bbox_inches="tight")
        time.sleep(1)
        post_telegram_file(file_path)
        # Check if the file exists

        if os.path.exists(file_path):
            # Delete the file if it exists
            os.remove(file_path)


except Exception as e:
    print(f"⚠️Error: Failed to get MMI index Value {e!s}")
    traceback_str = traceback.format_exc()
    print(traceback_str)
    post_telegram_message("Error: Failed to get MMI index Value")
    # Skip the remaining code if there's an error
    print("Extreme Fear  <20\nHigh Fear  <30\nFear  30 to 50\nGreed 50 to 70\nHigh Greed >70\nExtreme Greed >80")
    # post_telegram_message("Extreme Fear  <20\nHigh Fear  <30\nFear  30 to 50\nGreed 50 to 70\nHigh Greed >70\nExtreme Greed >80")


# Check if today is a weekend day
today = datetime.datetime.today() - datetime.timedelta(days=0)
if (today.weekday() == 5 or today.weekday() == 6):  # 5 is Saturday and 6 is Sunday
    print(today.strftime("Today is %A, a weekend day!"))

else:
    # Set the file path to the xxx.csv file in a specified folder
    folder_path = (r"/home/rizpython236/BT5/trade-logs")
    file_path = os.path.join(folder_path, "MMI.csv")
    index = text

    # Read the CSV file and get the latest index value
    if os.path.isfile(file_path) and os.stat(file_path).st_size > 0:
        df = pd.read_csv(file_path)
        if not df.empty:
            latest_index = df["Index"].iloc[-1]
            latest_date = df["Date"].iloc[-1]
            print("The latest index value in MMI file: " + str(latest_index))
        else:
            latest_index = 0
            latest_date = today.strftime("%Y-%m-%d")

folder_path = (r"/home/rizpython236/BT5/trade-logs")
file_path = os.path.join(folder_path, "MMI.csv")


# Get the NIFTY index value
# Replace "^NSEI" with the appropriate symbol if needed
nifty = yf.Ticker("^NSEI")
nifty_info = nifty.history(period="1d")
# print(nifty_info)
# nifty_value = nifty_info["Close"].iloc[-1]
today_close = nifty_info["Close"].iloc[-1]
# previous_close = nifty_info['Close'].iloc[-2]
# print(previous_close)
# Nifty_daily_change = ((today_close - previous_close)/previous_close)*100
nifty_value = round(today_close, 2)
# print(Nifty_daily_change)

# Replace "^NSEI" with the appropriate symbol if needed ^CNXSC , NIFTY_MICROCAP250.NS ,^CRSLDX
SMLCAP = yf.Ticker("^CNXSC")
NIFTY_MICROCAP250 = yf.Ticker("NIFTY_MICROCAP250.NS")
Nifty500 = yf.Ticker("^CRSLDX")
SMLCAP_info = SMLCAP.history(period="1d")
NIFTY_MICROCAP250_info = NIFTY_MICROCAP250.history(period="1d")
Nifty500_info = Nifty500.history(period="1d")
# SMLCAP_value = SMLCAP_info["Close"].iloc[-1]
today_close = SMLCAP_info["Close"].iloc[-1]
NIFTY_MICROCAP250_close = NIFTY_MICROCAP250_info["Close"].iloc[-1]
Nifty500_close = Nifty500_info["Close"].iloc[-1]
# previous_close = SMLCAP_info['Close'].iloc[-2]
# SMLCAP_daily_change = ((today_close - previous_close)/previous_close)*100
# SMLCAP_daily_change = ((SMLCAP_info['Close'] - SMLCAP_info['Open'])/SMLCAP_info['Open'])*100
SMLCAP_price = round(today_close, 2)
NIFTY_MICROCAP250_price = round(NIFTY_MICROCAP250_close, 2)
Nifty500_price = round(Nifty500_close, 2)

SMLCAP_value = SMLCAP_price + 7361.15
NIFTY_MICROCAP250_value = NIFTY_MICROCAP250_price + 4229.3
Nifty500_value = Nifty500_price + 2576.35


SMLCAPtoNifty = round(SMLCAP_value / nifty_value, 3)
NIFTY_MICROCAP250toNifty = round(NIFTY_MICROCAP250_value / nifty_value, 3)
Nifty500toNifty = round(Nifty500_value / nifty_value, 3)


print(nifty_value)
print(SMLCAP_price)
print(SMLCAPtoNifty)

print(NIFTY_MICROCAP250_price)
print(NIFTY_MICROCAP250toNifty)

print(Nifty500_price)
print(Nifty500toNifty)


# Write to the CSV file if the index value is different from the latest index value
if index != latest_index:  # and latest_date !=today.strftime("%Y-%m-%d"):
    # Open the CSV file for appending
    with open(file_path, "a", newline="") as csvfile:
        writer = csv.writer(csvfile)
        # Write the current date and index value to the file
        writer.writerow([today.strftime("%Y-%m-%d"), index, nifty_value, SMLCAP_price, SMLCAPtoNifty,
                        Nifty500_price, Nifty500toNifty, NIFTY_MICROCAP250_price, NIFTY_MICROCAP250toNifty])
        print(today.strftime("Today is %A, a weekday & csv file updated."))
        # time.sleep(2)
        # post_telegram_message(today.strftime("Today is %A, a weekday & csv file updated."))
else:
    print("Index value already exists in the CSV file.")

"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
"""
folder_path_csv = "/home/rizpython236/BT5/trade-logs"
file_path_csv = os.path.join(folder_path_csv, "MMI.csv")

df = pd.read_csv(file_path_csv).drop_duplicates()
df = df.sort_values(by="Date", ascending=True)
# print(df)

df["Date"] = pd.to_datetime(df["Date"])

# Set the figure size and orientation
fig = plt.figure(figsize=(11.7, 8.3))

# Adjust the subplot parameters for narrower margins
fig.subplots_adjust(left=0.08, right=0.95, top=0.92, bottom=0.08)


# Create the plot
ax = fig.add_subplot(111)

# Create the plot
# fig, ax = plt.subplots()

# Plot the index values
ax.plot(df["Date"], df["Index"], color="black", label="MMI Index")

# Create a twin axis
ax2 = ax.twinx()

# Plot the 'nifty' values on the secondary axis without displaying values
ax2.plot(df["Date"], df["nifty"], color="gray", label="Nifty")
ax2.set_yticklabels([])  # Hide tick labels on the secondary axis

# Calculate and plot the trend line for 'nifty'
nifty_trend = np.polyfit(df["Date"].index, df["nifty"], 1)
# nifty_trend_line = np.poly1d(nifty_trend)
# ax2.plot(df['Date'], nifty_trend_line(df['Date'].index), color='gray', linestyle='--', label='Nifty Trend')

# Set major lines for the primary axis
ax.yaxis.set_major_locator(plt.FixedLocator([20, 30, 50, 70, 80]))
# Set y-axis ticks from 0 to 150
ax.set_yticks(range(10, 110, 10))

# Add horizontal lines
ax.axhline(y=20.0, color="green", linestyle="--")
ax.axhline(y=30.0, color="blue", linestyle="--")
ax.axhline(y=50.0, color="yellow", linestyle="--")
ax.axhline(y=70.0, color="orange", linestyle="--")
ax.axhline(y=80.0, color="red", linestyle="--")

months = MonthLocator()
# ax.xaxis.set_major_locator(months)
# ax.xaxis.set_major_formatter(DateFormatter('%b %Y'))

ax.xaxis.set_major_locator(MonthLocator(interval=3))  # Set ticks at each month
ax.xaxis.set_major_formatter(DateFormatter("%b %y"))

# Set labels and legend
ax.set_xlabel("Date")
ax.set_ylabel("Index")
ax2.set_ylabel("Nifty")
ax.legend(loc="upper left")


"""
###
# Create the plot
fig, ax = plt.subplots()
ax.plot(df['Date'], df['Index'])

# Set major lines
ax.yaxis.set_major_locator(plt.FixedLocator([20, 30, 50, 70, 80]))
# Set y-axis ticks from 0 to 150
ax.set_yticks(range(10, 110, 10))

ax.axhline(y=20.0, color='green', linestyle='--')
ax.axhline(y=30.0, color='blue', linestyle='--')
ax.axhline(y=50.0, color='yellow', linestyle='--')
ax.axhline(y=70.0, color='orange', linestyle='--')
ax.axhline(y=80.0, color='red', linestyle='--')
####
"""
"""
# Shade the graph based on the conditions
colors = ['darkgreen', 'green', 'yellowgreen', 'gold', 'orange', 'red']
conditions = [df['Value'] <= 20, df['Value'] <= 30, df['Value'] <= 50, df['Value'] <= 70, df['Value'] < 80, df['Value'] >= 80]
for i in range(len(colors)):
    ax.fill_between(df['Date'], np.where(conditions[i], df['Value'], np.nan), np.where(conditions[i+1], df['Value'], np.nan), color=colors[i])
"""

# Save the plot
file_path = os.path.join(folder_path)
chart_path = os.path.join(folder_path, "MMI_Index_History.png")
fig.savefig(chart_path)
post_telegram_file(chart_path)

if os.path.exists(chart_path):
    # Delete the file if it exists
    os.remove(chart_path)


first_value = df["nifty"].iloc[0]  # Get the first value of the 'Close' column
df["Nifty_50"] = round((df["nifty"] / first_value) * 1, 2)


months = MonthLocator()
# ax.xaxis.set_major_formatter(DateFormatter('%b %Y'))

ax.xaxis.set_major_locator(MonthLocator(interval=3))  # Set ticks at each month
ax.xaxis.set_major_formatter(DateFormatter("%b %y"))

# Plot the data
plt.figure(figsize=(14, 8))
plt.plot(df["Date"], df["Nifty500toNifty"],
         label="Nifty500toNifty", color="green")
plt.plot(df["Date"], df["SMLCAPtoNifty"], label="SMLCAPtoNifty", color="blue")
plt.plot(df["Date"], df["NIFTY_MICROCAP250toNifty"],
         label="NIFTY_MICROCAP250toNifty", color="red")
plt.plot(df["Date"], df["Nifty_50"], label="Nifty_50", color="black")
# Add labels at the end of each line
last_date = df["Date"].iloc[-1]  # Last date in the DataFrame

# Label for Nifty500toNifty
last_nifty50 = df["Nifty_50"].iloc[-1]
plt.text(last_date, last_nifty50, "Nifty_50", fontsize=10, color="black",
         va="baseline", ha="left", backgroundcolor="white")

# Label for Nifty500toNifty
last_nifty500 = df["Nifty500toNifty"].iloc[-1]
plt.text(last_date, last_nifty500, "Nifty500toNifty", fontsize=10, color="green",
         va="baseline", ha="left", backgroundcolor="white")

# Label for SMLCAPtoNifty
last_smlcap = df["SMLCAPtoNifty"].iloc[-1]
plt.text(last_date, last_smlcap, "SMLCAPtoNifty", fontsize=10, color="blue",
         va="baseline", ha="left", backgroundcolor="white")

# Label for NIFTY_MICROCAP250toNifty
last_microcap = df["NIFTY_MICROCAP250toNifty"].iloc[-1]
plt.text(last_date, last_microcap, "NIFTY_MICROCAP250toNifty", fontsize=10, color="red",
         va="baseline", ha="left", backgroundcolor="white")
plt.title("SMLCAPtoNifty Over Time")
plt.xlabel("Date")
plt.ylabel("SMLCAPtoNifty Value")
plt.grid(True)
plt.legend(loc="upper left")
plt.tight_layout()

# Display the plot (optional)
# plt.show()

# Save the plot
file_path = os.path.join(folder_path)
chart_path = os.path.join(folder_path, "SMLCAPNiftyratio.png")
plt.savefig(chart_path)
post_telegram_file(chart_path)

if os.path.exists(chart_path):
    # Delete the file if it exists
    os.remove(chart_path)

# Show the plot (optional)
# plt.show()


# Define date range
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
# today = datetime.now(IST_TIMEZONE).date()
today = dt.now(IST_TIMEZONE).date()
ISTnow = dt.now(IST_TIMEZONE)
weekday = dt.now(IST_TIMEZONE).strftime("%A")

end_date = ISTnow  # datetime.now()
start_date = end_date - timedelta(days=252 * 3)  # 10 years ago

# Downloading data
midcap_data = yf.download("^CRSMID", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
nsei_data = yf.download("^NSEI", start=start_date,
                        end=end_date, multi_level_index=False)["Close"]
nifty500_data = yf.download(
    "^CRSLDX", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXCONSUM_data = yf.download(
    "^CNXCONSUM", start=start_date, end=end_date, multi_level_index=False)["Close"]
NSEBANK_data = yf.download(
    "^NSEBANK", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXIT_data = yf.download("^CNXIT", start=start_date,
                         end=end_date, multi_level_index=False)["Close"]
CNXAUTO_data = yf.download(
    "^CNXAUTO", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXMETAL_data = yf.download(
    "^CNXMETAL", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXPHARMA_data = yf.download(
    "^CNXPHARMA", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXREALTY_data = yf.download(
    "^CNXREALTY", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXINFRA_data = yf.download(
    "^CNXINFRA", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXMEDIA_data = yf.download(
    "^CNXMEDIA", start=start_date, end=end_date, multi_level_index=False)["Close"]
# BSECG_data = yf.download('BSE-CG.BO', start=start_date, end=end_date)['Close']
CNXFMCG_data = yf.download(
    "^CNXFMCG", start=start_date, end=end_date, multi_level_index=False)["Close"]


# Calculate returns
midcap_returns = midcap_data / midcap_data.iloc[0] * 100
nsei_returns = nsei_data / nsei_data.iloc[0] * 100
nifty500_returns = nifty500_data / nifty500_data.iloc[0] * 100
CNXCONSUM_returns = CNXCONSUM_data / CNXCONSUM_data.iloc[0] * 100
NSEBANK_returns = NSEBANK_data / NSEBANK_data.iloc[0] * 100
CNXIT_returns = CNXIT_data / CNXIT_data.iloc[0] * 100
CNXAUTO_returns = CNXAUTO_data / CNXAUTO_data.iloc[0] * 100
CNXMETAL_returns = CNXMETAL_data / CNXMETAL_data.iloc[0] * 100
# CNXPHARMA_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
CNXREALTY_returns = CNXREALTY_data / CNXREALTY_data.iloc[0] * 100
CNXINFRA_returns = CNXINFRA_data / CNXINFRA_data.iloc[0] * 100
CNXMEDIA_returns = CNXMEDIA_data / CNXMEDIA_data.iloc[0] * 100
# BSECG_data_returns = BSECG_data / BSECG_data.iloc[0] * 100
CNXFMCG_returns = CNXFMCG_data / CNXFMCG_data.iloc[0] * 100
# CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100


# Plotting
folder_path = "/home/rizpython236/BT5/screener-outputs/"

# colors = ['red', 'blue', 'green', 'purple', 'orange', 'brown', 'teal', 'fuchsia', 'gold', 'darkcyan', 'limegreen', 'magenta','pink','grey']

fig, ax = plt.subplots(figsize=(16, 10))
ax.plot(nsei_returns.index, nsei_returns,
        label="Nifty50", color="black", linestyle="--")
ax.plot(midcap_returns.index, midcap_returns, label="MidCap", color="blue")
ax.plot(nifty500_returns.index, nifty500_returns,
        label="Nifty500", color="red")
ax.plot(CNXIT_returns.index, CNXIT_returns, label="NiftyIT", color="green")
ax.plot(NSEBANK_returns.index, NSEBANK_returns,
        label="NiftyBank", color="purple")
ax.plot(CNXAUTO_returns.index, CNXAUTO_returns,
        label="NiftyAuto", color="brown")
ax.plot(CNXREALTY_returns.index, CNXREALTY_returns,
        label="NiftyReality", color="teal")
# ax.plot(CNXPHARMA_returns.index, CNXPHARMA_returns, label='NiftyPharma',color='limegreen')
ax.plot(CNXMETAL_returns.index, CNXMETAL_returns,
        label="NiftyMetal", color="grey")
ax.plot(CNXINFRA_returns.index, CNXINFRA_returns,
        label="NiftyInfra", color="magenta")
ax.plot(CNXMEDIA_returns.index, CNXMEDIA_returns,
        label="NiftyMedia", color="pink")
ax.plot(CNXCONSUM_returns.index, CNXCONSUM_returns,
        label="Nifty Consumption", color="orange")
ax.plot(CNXFMCG_returns.index, CNXFMCG_returns,
        label="Nifty FMCG", color="yellow")

# Add labels at the end of each line
last_date = nsei_returns.index[-1]  # Last date in the data

# Label for Nifty50
ax.text(last_date, nsei_returns.iloc[-1], "Nifty50", fontsize=10, color="black",
        va="baseline", ha="left", backgroundcolor="white")

# Label for MidCap
ax.text(last_date, midcap_returns.iloc[-1], "MidCap", fontsize=10, color="blue",
        va="baseline", ha="left", backgroundcolor="white")

# Label for Nifty500
ax.text(last_date, nifty500_returns.iloc[-1], "Nifty500", fontsize=10, color="red",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyIT
ax.text(last_date, CNXIT_returns.iloc[-1], "NiftyIT", fontsize=10, color="green",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyBank
ax.text(last_date, NSEBANK_returns.iloc[-1], "NiftyBank", fontsize=10, color="purple",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyAuto
ax.text(last_date, CNXAUTO_returns.iloc[-1], "NiftyAuto", fontsize=10, color="brown",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyReality
ax.text(last_date, CNXREALTY_returns.iloc[-1], "NiftyReality", fontsize=10, color="teal",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyMetal
ax.text(last_date, CNXMETAL_returns.iloc[-1], "NiftyMetal", fontsize=10, color="grey",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyInfra
ax.text(last_date, CNXINFRA_returns.iloc[-1], "NiftyInfra", fontsize=10, color="magenta",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyMedia
ax.text(last_date, CNXMEDIA_returns.iloc[-1], "NiftyMedia", fontsize=10, color="pink",
        va="baseline", ha="left", backgroundcolor="white")

# Label for Nifty Consumption
ax.text(last_date, CNXCONSUM_returns.iloc[-1], "Nifty Consumption", fontsize=10, color="orange",
        va="baseline", ha="left", backgroundcolor="white")

# Label for Nifty FMCG
ax.text(last_date, CNXFMCG_returns.iloc[-1], "Nifty FMCG", fontsize=10, color="yellow",
        va="baseline", ha="left", backgroundcolor="white")


ax.set_title("3 Year Index Performance Comparison")
ax.set_xlabel("Date")
ax.set_ylabel("Index Value (Indexed to 100)")
ax.legend(loc="upper left")
ax.grid(True)
# Set ticks at each 3 months
ax.xaxis.set_major_locator(MonthLocator(interval=3))
# Format date as abbreviated month and year
ax.xaxis.set_major_formatter(DateFormatter("%b %y"))
plt.xticks(rotation=90)
plt.tight_layout()

file_path = os.path.join(folder_path)
chart_path = os.path.join(folder_path, "INDIAIndiceschart.png")
plt.savefig(chart_path)
time.sleep(3)
post_telegram_file(chart_path)
# plt.show()


#########################
"""
midcap_returns = midcap_data / midcap_data.iloc[0] * 100
nsei_returns = nsei_data / nsei_data.iloc[0] * 100
nifty500_returns = nifty500_data / nifty500_data.iloc[0] * 100
CNXCONSUM_returns = CNXCONSUM_data / CNXCONSUM_data.iloc[0] * 100
NSEBANK_returns = NSEBANK_data / NSEBANK_data.iloc[0] * 100
CNXIT_returns = CNXIT_data / CNXIT_data.iloc[0] * 100
CNXAUTO_returns = CNXAUTO_data / CNXAUTO_data.iloc[0] * 100
CNXMETAL_returns = CNXMETAL_data / CNXMETAL_data.iloc[0] * 100
#CNXPHARMA_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
CNXREALTY_returns = CNXREALTY_data / CNXREALTY_data.iloc[0] * 100
CNXINFRA_returns = CNXINFRA_data / CNXINFRA_data.iloc[0] * 100
CNXMEDIA_returns = CNXMEDIA_data / CNXMEDIA_data.iloc[0] * 100
#BSECG_data_returns = BSECG_data / BSECG_data.iloc[0] * 100
CNXFMCG_returns = CNXFMCG_data / CNXFMCG_data.iloc[0] * 100
#CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
"""

# Combine all data into a single DataFrame
data = pd.DataFrame({
    "Midcap": midcap_returns,
    "NSEI": nsei_returns,
    "Nifty500": nifty500_returns,
    "CNXCONSUM": CNXCONSUM_returns,
    "NSEBANK": NSEBANK_returns,
    "CNXIT": CNXIT_returns,
    "CNXAUTO": CNXAUTO_returns,
    "CNXMETAL": CNXMETAL_returns,
    # 'CNXPHARMA': CNXPHARMA_data,
    "CNXREALTY": CNXREALTY_returns,
    "CNXINFRA": CNXINFRA_returns,
    "CNXMEDIA": CNXMEDIA_returns,
    "CNXFMCG": CNXFMCG_returns,
})

# Function to calculate drawdown using pandas_ta


def calculate_drawdown(series):
    drawdown_result = ta.drawdown(series)
    return drawdown_result


# Calculate drawdown for each column in the DataFrame
drawdown_results = {}
for column in data.columns:
    drawdown_results[column] = calculate_drawdown(data[column])

# Extract the latest drawdown values for DD_PCT
latest_drawdowns = {}
for key, value in drawdown_results.items():
    # Get the latest DD_PCT value
    latest_drawdowns[key] = value["DD_PCT"].iloc[-1]

# Convert to a DataFrame and sort by DD_PCT (high to low)
latest_drawdowns_df = pd.DataFrame(
    latest_drawdowns.items(), columns=["Ticker", "DD_PCT"])
latest_drawdowns_df = latest_drawdowns_df.sort_values(
    by="DD_PCT", ascending=False)

# Round the values to 6 decimal places
latest_drawdowns_df["DD_PCT"] = (latest_drawdowns_df["DD_PCT"] * 100).round(2)

# Print the sorted drawdown table
# print(latest_drawdowns_df)
# latest_drawdowns_json = latest_drawdowns_df.to_json(orient='records', indent=2)
# post_telegram_message(latest_drawdowns_json)


# Convert each row to a string and join with newline characters
message = "\n".join([f"{row['Ticker']}: {row['DD_PCT']}%" for _,
                    row in latest_drawdowns_df.iterrows()])

post_telegram_message("3yr drawdown")
time.sleep(3)
# Post the formatted message to Telegram
post_telegram_message(message)

###################
end_date = ISTnow  # datetime.now()
start_date = end_date - timedelta(days=252 * 1)  # 10 years ago

# Downloading data
midcap_data = yf.download("^CRSMID", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
nsei_data = yf.download("^NSEI", start=start_date,
                        end=end_date, multi_level_index=False)["Close"]
nifty500_data = yf.download(
    "^CRSLDX", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXCONSUM_data = yf.download(
    "^CNXCONSUM", start=start_date, end=end_date, multi_level_index=False)["Close"]
NSEBANK_data = yf.download(
    "^NSEBANK", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXIT_data = yf.download("^CNXIT", start=start_date,
                         end=end_date, multi_level_index=False)["Close"]
CNXAUTO_data = yf.download(
    "^CNXAUTO", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXMETAL_data = yf.download(
    "^CNXMETAL", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXPHARMA_data = yf.download(
    "^CNXPHARMA", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXREALTY_data = yf.download(
    "^CNXREALTY", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXINFRA_data = yf.download(
    "^CNXINFRA", start=start_date, end=end_date, multi_level_index=False)["Close"]
CNXMEDIA_data = yf.download(
    "^CNXMEDIA", start=start_date, end=end_date, multi_level_index=False)["Close"]
# BSECG_data = yf.download('BSE-CG.BO', start=start_date, end=end_date)['Close']
CNXFMCG_data = yf.download(
    "^CNXFMCG", start=start_date, end=end_date, multi_level_index=False)["Close"]


# Calculate returns
midcap_returns = midcap_data / midcap_data.iloc[0] * 100
nsei_returns = nsei_data / nsei_data.iloc[0] * 100
nifty500_returns = nifty500_data / nifty500_data.iloc[0] * 100
CNXCONSUM_returns = CNXCONSUM_data / CNXCONSUM_data.iloc[0] * 100
NSEBANK_returns = NSEBANK_data / NSEBANK_data.iloc[0] * 100
CNXIT_returns = CNXIT_data / CNXIT_data.iloc[0] * 100
CNXAUTO_returns = CNXAUTO_data / CNXAUTO_data.iloc[0] * 100
CNXMETAL_returns = CNXMETAL_data / CNXMETAL_data.iloc[0] * 100
# CNXPHARMA_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
CNXREALTY_returns = CNXREALTY_data / CNXREALTY_data.iloc[0] * 100
CNXINFRA_returns = CNXINFRA_data / CNXINFRA_data.iloc[0] * 100
CNXMEDIA_returns = CNXMEDIA_data / CNXMEDIA_data.iloc[0] * 100
# BSECG_data_returns = BSECG_data / BSECG_data.iloc[0] * 100
CNXFMCG_returns = CNXFMCG_data / CNXFMCG_data.iloc[0] * 100
# CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100


# Plotting
folder_path = "/home/rizpython236/BT5/screener-outputs/"

# colors = ['red', 'blue', 'green', 'purple', 'orange', 'brown', 'teal', 'fuchsia', 'gold', 'darkcyan', 'limegreen', 'magenta','pink','grey']

fig, ax = plt.subplots(figsize=(16, 10))
ax.plot(nsei_returns.index, nsei_returns,
        label="Nifty50", color="black", linestyle="--")
ax.plot(midcap_returns.index, midcap_returns, label="MidCap", color="blue")
ax.plot(nifty500_returns.index, nifty500_returns,
        label="Nifty500", color="red")
ax.plot(CNXIT_returns.index, CNXIT_returns, label="NiftyIT", color="green")
ax.plot(NSEBANK_returns.index, NSEBANK_returns,
        label="NiftyBank", color="purple")
ax.plot(CNXAUTO_returns.index, CNXAUTO_returns,
        label="NiftyAuto", color="brown")
ax.plot(CNXREALTY_returns.index, CNXREALTY_returns,
        label="NiftyReality", color="teal")
# ax.plot(CNXPHARMA_returns.index, CNXPHARMA_returns, label='NiftyPharma',color='limegreen')
ax.plot(CNXMETAL_returns.index, CNXMETAL_returns,
        label="NiftyMetal", color="grey")
ax.plot(CNXINFRA_returns.index, CNXINFRA_returns,
        label="NiftyInfra", color="magenta")
ax.plot(CNXMEDIA_returns.index, CNXMEDIA_returns,
        label="NiftyMedia", color="pink")
ax.plot(CNXCONSUM_returns.index, CNXCONSUM_returns,
        label="Nifty Consumption", color="orange")
ax.plot(CNXFMCG_returns.index, CNXFMCG_returns,
        label="Nifty FMCG", color="yellow")

# Add labels at the end of each line
last_date = nsei_returns.index[-1]  # Last date in the data

# Label for Nifty50
ax.text(last_date, nsei_returns.iloc[-1], "Nifty50", fontsize=10, color="black",
        va="baseline", ha="left", backgroundcolor="white")

# Label for MidCap
ax.text(last_date, midcap_returns.iloc[-1], "MidCap", fontsize=10, color="blue",
        va="baseline", ha="left", backgroundcolor="white")

# Label for Nifty500
ax.text(last_date, nifty500_returns.iloc[-1], "Nifty500", fontsize=10, color="red",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyIT
ax.text(last_date, CNXIT_returns.iloc[-1], "NiftyIT", fontsize=10, color="green",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyBank
ax.text(last_date, NSEBANK_returns.iloc[-1], "NiftyBank", fontsize=10, color="purple",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyAuto
ax.text(last_date, CNXAUTO_returns.iloc[-1], "NiftyAuto", fontsize=10, color="brown",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyReality
ax.text(last_date, CNXREALTY_returns.iloc[-1], "NiftyReality", fontsize=10, color="teal",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyMetal
ax.text(last_date, CNXMETAL_returns.iloc[-1], "NiftyMetal", fontsize=10, color="grey",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyInfra
ax.text(last_date, CNXINFRA_returns.iloc[-1], "NiftyInfra", fontsize=10, color="magenta",
        va="baseline", ha="left", backgroundcolor="white")

# Label for NiftyMedia
ax.text(last_date, CNXMEDIA_returns.iloc[-1], "NiftyMedia", fontsize=10, color="pink",
        va="baseline", ha="left", backgroundcolor="white")

# Label for Nifty Consumption
ax.text(last_date, CNXCONSUM_returns.iloc[-1], "Nifty Consumption", fontsize=10, color="orange",
        va="baseline", ha="left", backgroundcolor="white")

# Label for Nifty FMCG
ax.text(last_date, CNXFMCG_returns.iloc[-1], "Nifty FMCG", fontsize=10, color="yellow",
        va="baseline", ha="left", backgroundcolor="white")

ax.set_title("1 Year Index Performance Comparison")
ax.set_xlabel("Date")
ax.set_ylabel("Index Value (Indexed to 100)")
ax.legend(loc="upper left")
ax.grid(True)
# Set ticks at each 3 months
ax.xaxis.set_major_locator(MonthLocator(interval=1))
# Format date as abbreviated month and year
ax.xaxis.set_major_formatter(DateFormatter("%b %y"))
plt.xticks(rotation=90)
plt.tight_layout()

file_path = os.path.join(folder_path)
chart_path = os.path.join(folder_path, "1yrINDIAIndiceschart.png")
plt.savefig(chart_path)
time.sleep(3)
post_telegram_file(chart_path)
# plt.show()


#########################
"""
midcap_returns = midcap_data / midcap_data.iloc[0] * 100
nsei_returns = nsei_data / nsei_data.iloc[0] * 100
nifty500_returns = nifty500_data / nifty500_data.iloc[0] * 100
CNXCONSUM_returns = CNXCONSUM_data / CNXCONSUM_data.iloc[0] * 100
NSEBANK_returns = NSEBANK_data / NSEBANK_data.iloc[0] * 100
CNXIT_returns = CNXIT_data / CNXIT_data.iloc[0] * 100
CNXAUTO_returns = CNXAUTO_data / CNXAUTO_data.iloc[0] * 100
CNXMETAL_returns = CNXMETAL_data / CNXMETAL_data.iloc[0] * 100
#CNXPHARMA_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
CNXREALTY_returns = CNXREALTY_data / CNXREALTY_data.iloc[0] * 100
CNXINFRA_returns = CNXINFRA_data / CNXINFRA_data.iloc[0] * 100
CNXMEDIA_returns = CNXMEDIA_data / CNXMEDIA_data.iloc[0] * 100
#BSECG_data_returns = BSECG_data / BSECG_data.iloc[0] * 100
CNXFMCG_returns = CNXFMCG_data / CNXFMCG_data.iloc[0] * 100
#CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
"""

# Combine all data into a single DataFrame
data = pd.DataFrame({
    "Midcap": midcap_returns,
    "NSEI": nsei_returns,
    "Nifty500": nifty500_returns,
    "CNXCONSUM": CNXCONSUM_returns,
    "NSEBANK": NSEBANK_returns,
    "CNXIT": CNXIT_returns,
    "CNXAUTO": CNXAUTO_returns,
    "CNXMETAL": CNXMETAL_returns,
    # 'CNXPHARMA': CNXPHARMA_data,
    "CNXREALTY": CNXREALTY_returns,
    "CNXINFRA": CNXINFRA_returns,
    "CNXMEDIA": CNXMEDIA_returns,
    "CNXFMCG": CNXFMCG_returns,
})

# Function to calculate drawdown using pandas_ta


def calculate_drawdown(series):
    drawdown_result = ta.drawdown(series)
    return drawdown_result


# Calculate drawdown for each column in the DataFrame
drawdown_results = {}
for column in data.columns:
    drawdown_results[column] = calculate_drawdown(data[column])

# Extract the latest drawdown values for DD_PCT
latest_drawdowns = {}
for key, value in drawdown_results.items():
    # Get the latest DD_PCT value
    latest_drawdowns[key] = value["DD_PCT"].iloc[-1]

# Convert to a DataFrame and sort by DD_PCT (high to low)
latest_drawdowns_df = pd.DataFrame(
    latest_drawdowns.items(), columns=["Ticker", "DD_PCT"])
latest_drawdowns_df = latest_drawdowns_df.sort_values(
    by="DD_PCT", ascending=False)

# Round the values to 6 decimal places
latest_drawdowns_df["DD_PCT"] = (latest_drawdowns_df["DD_PCT"] * 100).round(2)

# Print the sorted drawdown table
# print(latest_drawdowns_df)
# post_telegram_message(latest_drawdowns_df)
# latest_drawdowns_json = latest_drawdowns_df.to_json(orient='records', indent=2)
# post_telegram_message(latest_drawdowns_json)

message = "\n".join([f"{row['Ticker']}: {row['DD_PCT']}%" for _,
                    row in latest_drawdowns_df.iterrows()])

post_telegram_message("1yr drawdown")
time.sleep(3)
# Post the formatted message to Telegram
post_telegram_message(message)


###################
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today = dt.now(IST_TIMEZONE).date()
ISTnow = dt.now(IST_TIMEZONE)
weekday = dt.now(IST_TIMEZONE).strftime("%A")

end_date = ISTnow  # datetime.now()
start_date = end_date - timedelta(days=252 * 3)  # 10 years ago

# Downloading data
Nifty_data = yf.download("^NSEI", start=start_date,
                         end=end_date, multi_level_index=False)["Close"]
Nasdaq_data = yf.download("^IXIC", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
DowJones_data = yf.download(
    "^DJI", start=start_date, end=end_date, multi_level_index=False)["Close"]
nikkie_data = yf.download("^N225", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
SSEComposite_data = yf.download(
    "000001.SS", start=start_date, end=end_date, multi_level_index=False)["Close"]
hangseng_data = yf.download(
    "^HSI", start=start_date, end=end_date, multi_level_index=False)["Close"]
FTSE100_data = yf.download("^FTSE", start=start_date,
                           end=end_date, multi_level_index=False)["Close"]
MSCIWORLD_data = yf.download("^990100-USD-STRD", start=start_date,
                             end=end_date, multi_level_index=False)["Close"]  # XWD.TO
RUI_data = yf.download("^RUI", start=start_date,
                       end=end_date, multi_level_index=False)["Close"]
RUTdata = yf.download("^RUT", start=start_date,
                      end=end_date, multi_level_index=False)["Close"]
BTC_USD_data = yf.download("BTC-USD", start=start_date,
                           end=end_date, multi_level_index=False)["Close"]
NYFANG_data = yf.download("^NYFANG", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
IVZINGOLD_data = yf.download(
    "IVZINGOLD.NS", start=start_date, end=end_date, multi_level_index=False)["Close"]
ESILVER_data = yf.download(
    "ESILVER.NS", start=start_date, end=end_date, multi_level_index=False)["Close"]
USDollar_data = yf.download(
    "DX-Y.NYB", start=start_date, end=end_date, multi_level_index=False)["Close"]


# print(FTSE100_data)

# Calculate returns
Nifty_returns = Nifty_data / Nifty_data.iloc[0] * 100
Nasdaq_returns = Nasdaq_data / Nasdaq_data.iloc[0] * 100
DowJones_returns = DowJones_data / DowJones_data.iloc[0] * 100
nikkie_returns = nikkie_data / nikkie_data.iloc[0] * 100
SSEComposite_returns = SSEComposite_data / SSEComposite_data.iloc[0] * 100
hangseng_returns = hangseng_data / hangseng_data.iloc[0] * 100
FTSE100_returns = FTSE100_data / FTSE100_data.iloc[0] * 100
MSCIWORLD_returns = MSCIWORLD_data / MSCIWORLD_data.iloc[0] * 100
RUI_data_returns = RUI_data / RUI_data.iloc[0] * 100
RUTdata_returns = RUTdata / RUTdata.iloc[0] * 100
BTC_USD_returns = BTC_USD_data / BTC_USD_data.iloc[0] * 100
NYFANG_returns = NYFANG_data / NYFANG_data.iloc[0] * 100
IVZINGOLD_returns = IVZINGOLD_data / IVZINGOLD_data.iloc[0] * 100
ESILVER_returns = ESILVER_data / ESILVER_data.iloc[0] * 100
USDollar_returns = USDollar_data / USDollar_data.iloc[0] * 100
# CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
# CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100


# Plotting
folder_path = "/home/rizpython236/BT5/screener-outputs/"

fig, ax = plt.subplots(figsize=(12, 8))

# colors = ['red', 'blue', 'green', 'purple', 'orange', 'brown', 'teal', 'fuchsia', 'gold', 'darkcyan', 'limegreen', 'magenta','pink','grey']

ax.plot(Nifty_returns.index, Nifty_returns,
        label="IND: Nifty50", color="black", linestyle="--")
ax.plot(Nasdaq_returns.index, Nasdaq_returns, label="US: Nasdaq", color="blue")
ax.plot(DowJones_returns.index, DowJones_returns,
        label="US: DowJones", color="green")
ax.plot(RUI_data_returns.index, RUI_data_returns,
        label="US: Russell 1000 ", color="orange")
# ax.plot(RUTdata_returns.index, RUTdata_returns, label='US: Russell 2000',color='grey')
ax.plot(NYFANG_returns.index, NYFANG_returns,
        label="US: FANG+", color="purple")
# ax.plot(nikkie_returns.index, nikkie_returns, label='JPN: Nikkei 225',color='teal')
ax.plot(SSEComposite_returns.index, SSEComposite_returns,
        label="China: SSEComposite", color="red")
ax.plot(hangseng_returns.index, hangseng_returns,
        label="HK: Hang Seng", color="pink")
# ax.plot(FTSE100_returns.index, FTSE100_returns, label='Euro: FTSE100',color='brown')
# ax.plot(MSCIWORLD_returns.index, MSCIWORLD_returns, label='MSCI WORLD')
# ax.plot(BTC_USD_returns.index, BTC_USD_returns, label='BitcoinUSD')
ax.plot(IVZINGOLD_returns.index, IVZINGOLD_returns,
        label="IND: GOLD", color="gold")

ax.plot(ESILVER_returns.index, ESILVER_returns,
        label="IND: Silver", color="silver")
ax.plot(USDollar_returns.index, USDollar_returns,
        label="US: US$$$ Idx", color="teal")


# Add labels at the end of each line
last_date = Nifty_returns.index[-1]  # Last date in the data

# Label for IND: Nifty50
ax.text(last_date, Nifty_returns.iloc[-1], "IND: Nifty50", fontsize=10, color="black",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: Nasdaq
ax.text(last_date, Nasdaq_returns.iloc[-1], "US: Nasdaq", fontsize=10, color="blue",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: DowJones
ax.text(last_date, DowJones_returns.iloc[-1], "US: DowJones", fontsize=10, color="green",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: Russell 1000
ax.text(last_date, RUI_data_returns.iloc[-1], "US: Russell 1000", fontsize=10, color="orange",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: FANG+
ax.text(last_date, NYFANG_returns.iloc[-1], "US: FANG+", fontsize=10, color="purple",
        va="baseline", ha="left", backgroundcolor="white")

# Label for China: SSEComposite
ax.text(last_date, SSEComposite_returns.iloc[-1], "China: SSEComposite", fontsize=10, color="red",
        va="baseline", ha="left", backgroundcolor="white")

# Label for HK: Hang Seng
ax.text(last_date, hangseng_returns.iloc[-1], "HK: Hang Seng", fontsize=10, color="pink",
        va="baseline", ha="left", backgroundcolor="white")

# Label for IND: GOLD
ax.text(last_date, IVZINGOLD_returns.iloc[-1], "IND: GOLD", fontsize=10, color="gold",
        va="baseline", ha="left", backgroundcolor="white")


ax.text(last_date, ESILVER_returns.iloc[-1], "IND: Silver", fontsize=10, color="silver",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: US$$$ Idx
ax.text(last_date, USDollar_returns.iloc[-1], "US: US$$$ Idx", fontsize=10, color="teal",
        va="baseline", ha="left", backgroundcolor="white")

ax.set_title("3 Year Index Performance Comparison")
ax.set_xlabel("Date")
ax.set_ylabel("Index Value (Indexed to 100)")
ax.legend(loc="upper left")
ax.grid(True)
# Set ticks at each 3 months
ax.xaxis.set_major_locator(MonthLocator(interval=3))
# Format date as abbreviated month and year
ax.xaxis.set_major_formatter(DateFormatter("%b %y"))
plt.xticks(rotation=90)
plt.tight_layout()

file_path = os.path.join(folder_path)
chart_path = os.path.join(folder_path, "GlobalIndiceschart.png")
plt.savefig(chart_path)
time.sleep(3)
post_telegram_file(chart_path)
# plt.show()


######################################

end_date = ISTnow  # datetime.now()
start_date = end_date - timedelta(days=252 * 1)  # 10 years ago

# Downloading data
Nifty_data = yf.download("^NSEI", start=start_date,
                         end=end_date, multi_level_index=False)["Close"]
Nasdaq_data = yf.download("^IXIC", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
DowJones_data = yf.download(
    "^DJI", start=start_date, end=end_date, multi_level_index=False)["Close"]
nikkie_data = yf.download("^N225", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
SSEComposite_data = yf.download(
    "000001.SS", start=start_date, end=end_date, multi_level_index=False)["Close"]
hangseng_data = yf.download(
    "^HSI", start=start_date, end=end_date, multi_level_index=False)["Close"]
FTSE100_data = yf.download("^FTSE", start=start_date,
                           end=end_date, multi_level_index=False)["Close"]
MSCIWORLD_data = yf.download("^990100-USD-STRD", start=start_date,
                             end=end_date, multi_level_index=False)["Close"]  # XWD.TO
RUI_data = yf.download("^RUI", start=start_date,
                       end=end_date, multi_level_index=False)["Close"]
RUTdata = yf.download("^RUT", start=start_date,
                      end=end_date, multi_level_index=False)["Close"]
BTC_USD_data = yf.download("BTC-USD", start=start_date,
                           end=end_date, multi_level_index=False)["Close"]
NYFANG_data = yf.download("^NYFANG", start=start_date,
                          end=end_date, multi_level_index=False)["Close"]
IVZINGOLD_data = yf.download(
    "IVZINGOLD.NS", start=start_date, end=end_date, multi_level_index=False)["Close"]
ESILVER_data = yf.download(
    "ESILVER.NS", start=start_date, end=end_date, multi_level_index=False)["Close"]
USDollar_data = yf.download(
    "DX-Y.NYB", start=start_date, end=end_date, multi_level_index=False)["Close"]


# print(FTSE100_data)

# Calculate returns
Nifty_returns = Nifty_data / Nifty_data.iloc[0] * 100
Nasdaq_returns = Nasdaq_data / Nasdaq_data.iloc[0] * 100
DowJones_returns = DowJones_data / DowJones_data.iloc[0] * 100
nikkie_returns = nikkie_data / nikkie_data.iloc[0] * 100
SSEComposite_returns = SSEComposite_data / SSEComposite_data.iloc[0] * 100
hangseng_returns = hangseng_data / hangseng_data.iloc[0] * 100
FTSE100_returns = FTSE100_data / FTSE100_data.iloc[0] * 100
MSCIWORLD_returns = MSCIWORLD_data / MSCIWORLD_data.iloc[0] * 100
RUI_data_returns = RUI_data / RUI_data.iloc[0] * 100
RUTdata_returns = RUTdata / RUTdata.iloc[0] * 100
BTC_USD_returns = BTC_USD_data / BTC_USD_data.iloc[0] * 100
NYFANG_returns = NYFANG_data / NYFANG_data.iloc[0] * 100
IVZINGOLD_returns = IVZINGOLD_data / IVZINGOLD_data.iloc[0] * 100
ESILVER_returns = ESILVER_data / ESILVER_data.iloc[0] * 100
USDollar_returns = USDollar_data / USDollar_data.iloc[0] * 100
# CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100
# CNXCMDT_returns = CNXPHARMA_data / CNXPHARMA_data.iloc[0] * 100


# Plotting
folder_path = "/home/rizpython236/BT5/screener-outputs/"

fig, ax = plt.subplots(figsize=(12, 8))

# colors = ['red', 'blue', 'green', 'purple', 'orange', 'brown', 'teal', 'fuchsia', 'gold', 'darkcyan', 'limegreen', 'magenta','pink','grey']

ax.plot(Nifty_returns.index, Nifty_returns,
        label="IND: Nifty50", color="black", linestyle="--")
ax.plot(Nasdaq_returns.index, Nasdaq_returns, label="US: Nasdaq", color="blue")
ax.plot(DowJones_returns.index, DowJones_returns,
        label="US: DowJones", color="green")
ax.plot(RUI_data_returns.index, RUI_data_returns,
        label="US: Russell 1000 ", color="orange")
# ax.plot(RUTdata_returns.index, RUTdata_returns, label='US: Russell 2000',color='grey')
ax.plot(NYFANG_returns.index, NYFANG_returns,
        label="US: FANG+", color="purple")
# ax.plot(nikkie_returns.index, nikkie_returns, label='JPN: Nikkei 225',color='teal')
ax.plot(SSEComposite_returns.index, SSEComposite_returns,
        label="China: SSEComposite", color="red")
ax.plot(hangseng_returns.index, hangseng_returns,
        label="HK: Hang Seng", color="pink")
# ax.plot(FTSE100_returns.index, FTSE100_returns, label='Euro: FTSE100',color='brown')
# ax.plot(MSCIWORLD_returns.index, MSCIWORLD_returns, label='MSCI WORLD')
# ax.plot(BTC_USD_returns.index, BTC_USD_returns, label='BitcoinUSD')
ax.plot(IVZINGOLD_returns.index, IVZINGOLD_returns,
        label="IND: GOLD", color="gold")
ax.plot(ESILVER_returns.index, ESILVER_returns,
        label="IND: Silver", color="silver")
ax.plot(USDollar_returns.index, USDollar_returns,
        label="US: US$$$ Idx", color="teal")

# Add labels at the end of each line
last_date = Nifty_returns.index[-1]  # Last date in the data

# Label for IND: Nifty50
ax.text(last_date, Nifty_returns.iloc[-1], "IND: Nifty50", fontsize=10, color="black",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: Nasdaq
ax.text(last_date, Nasdaq_returns.iloc[-1], "US: Nasdaq", fontsize=10, color="blue",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: DowJones
ax.text(last_date, DowJones_returns.iloc[-1], "US: DowJones", fontsize=10, color="green",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: Russell 1000
ax.text(last_date, RUI_data_returns.iloc[-1], "US: Russell 1000", fontsize=10, color="orange",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: FANG+
ax.text(last_date, NYFANG_returns.iloc[-1], "US: FANG+", fontsize=10, color="purple",
        va="baseline", ha="left", backgroundcolor="white")

# Label for China: SSEComposite
ax.text(last_date, SSEComposite_returns.iloc[-1], "China: SSEComposite", fontsize=10, color="red",
        va="baseline", ha="left", backgroundcolor="white")

# Label for HK: Hang Seng
ax.text(last_date, hangseng_returns.iloc[-1], "HK: Hang Seng", fontsize=10, color="pink",
        va="baseline", ha="left", backgroundcolor="white")

# Label for IND: GOLD
ax.text(last_date, IVZINGOLD_returns.iloc[-1], "IND: GOLD", fontsize=10, color="gold",
        va="baseline", ha="left", backgroundcolor="white")

ax.text(last_date, ESILVER_returns.iloc[-1], "IND: Silver", fontsize=10, color="silver",
        va="baseline", ha="left", backgroundcolor="white")

# Label for US: US$$$ Idx
ax.text(last_date, USDollar_returns.iloc[-1], "US: US$$$ Idx", fontsize=10, color="teal",
        va="baseline", ha="left", backgroundcolor="white")

ax.set_title("1 Year Index Performance Comparison")
ax.set_xlabel("Date")
ax.set_ylabel("Index Value (Indexed to 100)")
ax.legend(loc="upper left")
ax.grid(True)
# Set ticks at each 3 months
ax.xaxis.set_major_locator(MonthLocator(interval=1))
# Format date as abbreviated month and year
ax.xaxis.set_major_formatter(DateFormatter("%b %y"))
plt.xticks(rotation=90)
plt.tight_layout()

file_path = os.path.join(folder_path)
chart_path = os.path.join(folder_path, "1yrGlobalIndiceschart.png")
plt.savefig(chart_path)
time.sleep(3)
post_telegram_file(chart_path)
# plt.show()


print("completed MMI_Index_History")
