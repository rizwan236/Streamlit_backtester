from datetime import date, datetime, timedelta
import os
import sys

import numpy as np
import pandas as pd
import pytz


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
import riskfolio as rp
from riskfolio import Portfolio
import xlsxwriter
import yfinance as yf


IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
end_date = datetime.now(IST_TIMEZONE).date()
#end_date = date.today()
# start_date = end_date - timedelta(days=365)
start_date = end_date - timedelta(weeks=52*14) #77 weekly
END_DATE = str(end_date)
START_DATE = str(start_date)

def download_data(symbol, start_date, end_date):
    data = yf.download(symbol, start=start_date, end=end_date)
    return data

def load_data_from_csv(folder_path, symbol):
    try:
        file_path = os.path.join(folder_path, f"{symbol}.csv")
        data = pd.read_csv(file_path, parse_dates=True, index_col='Date')
    except:
        pass
    return data

def calculate_optimal_portfolio(data, freq, target_volatility):
    # Assuming monthly returns for simplicity
    returns = data['Close'].pct_change().dropna()  #.resample(freq).ffill()

    port = rp.Portfolio(returns)
    method_mu='hist' # Method to estimate expected returns based on historical data.
    method_cov='hist' # Method to estimate covariance matrix based on historical data.
    port.assets_stats(method_mu=method_mu, method_cov=method_cov, d=0.94)
    model='Classic' # Could be Classic (historical), BL (Black Litterman) or FM (Factor Model)
    rm = 'MV' # Risk measure used, this time will be variance
    obj = 'Sharpe' # Objective function, could be MinRisk, MaxRet, Utility or Sharpe
    hist = True # Use historical scenarios for risk measures that depend on scenarios
    rf = 0 # Risk free rate
    l = 0 # Risk aversion factor, only useful when obj is 'Utility'
    w = port.optimization(model=model, rm=rm, obj=obj, rf=rf, l=l, hist=hist)
    stats = port.portfolio_statistics()
    display(w.T)
    '''
    sigma = np.cov(returns, rowvar=False)#returns.cov().values.astype(float)

    # Define the portfolio
    port = Portfolio(returns)

    # Set the objective function to maximize the Sharpe ratio
    objective = 'Sharpe'

    # Set the risk measure to 'MV' (mean-variance optimization)
    rm = 'MV'

    # Set constraints for the optimization
    constraints = {'Disabled short sales': 1, 'Leverage limit': 1}

    # Estimate the optimal portfolio weights
    #w = port.optimization(objective, rm, constraints)
    w = port.optimization(objective, rm, constraints)# covar_matrix=sigma)

    # Calculate the portfolio statistics
    stats = port.portfolio_statistics()
    '''
    return w, stats

def create_excel_report(output_path, stock_symbols, optimal_weights, portfolio_stats):
    workbook = xlsxwriter.Workbook(output_path)
    worksheet = workbook.add_worksheet()

    # Write header
    worksheet.write(0, 0, 'Stock Symbol')
    worksheet.write(0, 1, 'Optimal Weights')
    worksheet.write(0, 2, 'Portfolio Statistics')

    # Write data
    row = 1
    for symbol in stock_symbols:
        worksheet.write(row, 0, symbol)
        worksheet.write(row, 1, str(optimal_weights[symbol]))
        worksheet.write(row, 2, str(portfolio_stats[symbol]))
        row += 1

    workbook.close()


if __name__ == "__main__":
    # List of stock symbols
    stock_symbols = ["AAPL", "GOOGL", "MSFT", "AMZN", "FB"]

    ticker_path = '/home/rizpython236/BT5/Finalnse.csv'
    ticker_df = pd.read_csv(ticker_path)
    symbols = ticker_df['Symbol'].tolist()[:]
    stock_symbols = list(dict.fromkeys(symbols))

    # Folder path where OHLCV data is saved in CSV format
    data_folder = '/home/rizpython236/BT5/ticker_15yr/'

    # Date range for historical data
    start_date = START_DATE # "2020-01-01" #
    end_date = END_DATE #"2021-12-31"  #

    # Frequency of returns (e.g., 'M' for monthly)
    returns_frequency = 'W'

    # Target volatility for the portfolio
    target_volatility = 0.1  # Adjust as needed

    optimal_weights = {}
    portfolio_stats = {}

    for symbol in stock_symbols:
        # Download or load historical data
        #data = download_data(symbol, start_date, end_date)
        # Alternatively, load data from CSV if already downloaded
        data = load_data_from_csv(data_folder, symbol)

        # Calculate optimal portfolio weights and statistics
        weights, stats = calculate_optimal_portfolio(data, returns_frequency, target_volatility)

        optimal_weights[symbol] = weights
        portfolio_stats[symbol] = stats

    # Display results
    for symbol in stock_symbols:
        print(f"\nOptimal weights for {symbol}:\n{optimal_weights[symbol]}")
        print(f"\nPortfolio statistics for {symbol}:\n{portfolio_stats[symbol]}")

# Output Excel report
excel_report_path = "portfolio_report.xlsx"
create_excel_report(excel_report_path, stock_symbols, optimal_weights, portfolio_stats)
