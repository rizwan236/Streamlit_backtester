import os

import pandas as pd
import talib as ta


#import yfinance as yf

print("MRP")
'''
def add_relative_performance_folder(folder_path, lookback):
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            add_relative_performance(file_path, lookback)

def add_relative_performance(filename, lookback):
    # Load the CSV file into a DataFrame
    df = pd.read_csv(filename)

    # Retrieve data for Nifty and Bank Nifty
    nifty_df = pd.read_csv("/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv",parse_dates=['Date'])
    banknifty_df = pd.read_csv("/home/rizpython236/BT5/ticker-csv-files/^NSEBANK.csv",parse_dates=['Date'])

    # Calculate daily returns for Nifty and Bank Nifty
    nifty_df['Return'] = (nifty_df['Close'] - nifty_df['Close'].shift(1)) / nifty_df['Close'].shift(1) * 100
    banknifty_df['Return'] = (banknifty_df['Close'] - banknifty_df['Close'].shift(1)) / banknifty_df['Close'].shift(1) * 100

    # Calculate average returns for Nifty and Bank Nifty
    nifty_df['Avg_Return'] = nifty_df['Return'].rolling(lookback).mean()
    banknifty_df['Avg_Return'] = banknifty_df['Return'].rolling(lookback).mean()

    # Fill missing values in 'Avg_Return' column with 0
    nifty_df['Avg_Return'].fillna(0, inplace=True)
    banknifty_df['Avg_Return'].fillna(0, inplace=True)

    # Convert 'Avg_Return' column to numeric type
    #nifty_df['Avg_Return'] = pd.to_numeric(nifty_df['Avg_Return'], errors='coerce')
    #banknifty_df['Avg_Return'] = pd.to_numeric(banknifty_df['Avg_Return'], errors='coerce')

    print(nifty_df)

    print(df['Date'].isnull().sum())
    print(nifty_df['Date'].isnull().sum())
    df['Date'] = pd.to_datetime(df['Date'])
    print(df['Date'].dtype)
    print(nifty_df['Date'].dtype)

    # Merge Nifty and Bank Nifty data with the original DataFrame
    merged_df = pd.merge(df, nifty_df[['Date', 'Avg_Return']], left_on='Date', right_on='Date', how='left', sort=False)
    merged_df = pd.merge(merged_df, banknifty_df[['Date', 'Avg_Return']], on='Date', how='left', sort=False)

    # Calculate relative performance
    merged_df['Relative_Performance'] = (merged_df['Close'] - merged_df['Close'].rolling(lookback).mean()) / merged_df['Close'].rolling(lookback).mean() * 100 - (merged_df['Avg_Return_x'] + merged_df['Avg_Return_y']) / 2

    # Save the updated DataFrame back to the CSV file
    merged_df.to_csv(filename, index=False)

# Example usage
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
lookback = 55
add_relative_performance_folder(folder_path, lookback)
'''

import os

import pandas as pd


def get_stock_csv_files(folder_path):
    csv_files = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            csv_files.append(os.path.join(folder_path, file))

    return csv_files

def calculate_mrp(stock_csv_file, index_csv_file):
    # Load stock and index data from CSV files
    stock_data = pd.read_csv(stock_csv_file)
    index_data = pd.read_csv(index_csv_file)

    # Calculate Relative Performance (RP)
    RP = (stock_data["Close"] / index_data["Close"]) * 100

    # Calculate RP52W (Simple Moving Average over 52 weeks)
    RP13W = RP.rolling(window=3).mean()
    RP25W = RP.rolling(window=6).mean()

    # Calculate Mansfield Relative Performance (MRP)
    MRP13 = ((RP / RP13W) - 1) * 10
    MRP25 = ((RP / RP25W) - 1) * 10

    # Add MRP values to the stock data
    stock_data["MRP13"] = MRP13
    stock_data["MRP25"] = MRP25

    # Save the updated stock data to a new CSV file
    stock_data.to_csv(stock_csv_file, index=False)

# Provide the folder path where the stock CSV files are located
stock_folder_path = '/home/rizpython236/BT5/ticker-csv-files-mhtly'

# Get the list of stock CSV files in the folder
stock_csv_files = get_stock_csv_files(stock_folder_path)

# Provide the file path for the index CSV file
index_csv_file = "/home/rizpython236/BT5/ticker-csv-files-mhtly/^NSEI.csv"

# Calculate MRP and update each stock CSV file
for stock_csv_file in stock_csv_files:
    calculate_mrp(stock_csv_file, index_csv_file)



def delete_mrp_column(stock_csv_file):
    # Load stock data from CSV file
    stock_data = pd.read_csv(stock_csv_file)

    # Check if MRP column exists in the stock data
    if 'MRP' in stock_data.columns:
        # Remove the MRP column
        stock_data.drop('MRP', axis=1, inplace=True)

        # Save the updated stock data to the same CSV file
        stock_data.to_csv(stock_csv_file, index=False)
        print(f"MRP column removed from {stock_csv_file}")
    else:
        print(f"No MRP column found in {stock_csv_file}")

# Provide the folder path where the stock CSV files are located
stock_folder_path = '/home/rizpython236/BT5/ticker-csv-files/'

# Get the list of stock CSV files in the folder
stock_csv_files = [os.path.join(stock_folder_path, file) for file in os.listdir(stock_folder_path) if file.endswith('.csv')]

# Delete the MRP column from each stock CSV file
#for stock_csv_file in stock_csv_files:
#    delete_mrp_column(stock_csv_file)


print("done")