from datetime import datetime, timedelta
import os
import sys
import time
import traceback

from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pytz
import talib as tb
import yfinance as yf

from settings import (
    TICKER_CSV_DATA_FOLDER_PATH,
)
from symbol_copy import manage_zip
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.insert(
    0, "/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.13/site-packages")


print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")
# from scipy.stats import gmean


# import sys
sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.13/site-packages/")


TICKER_CSV_DATA_FOLDER_PATH = "/home/rizpython236/BT5/ticker_15yr"

'''

def plot_index_close_prices(folder_path, index_names,index_csv_file=None,Frequency=None):
    """
    Plot the Close Price of multiple indices in a single chart for comparison.
    - x-axis labels are displayed on a quarterly basis.
    - Different colors and line styles are used for each index line.
    - Line styles change after every 16 indices.

    Parameters:
    - folder_path: Path to the folder containing the index CSV files.
    - index_names: List of index names (e.g., ['Autoindex', 'FMCGindex']).
    """
    def calculate_rolling_mrp(stock_csv_file, window=252,index_csv_file=None,Frequency=None):
        """
        Calculates the rolling Market Relative Performance (MRP) for a given stock over a specified window.

        Args:
            stock_csv_file (str): Path to the CSV file containing stock data.
            window (int): Rolling window size in trading days (default is 252).

        Returns:
            pandas.Series: Series containing the rolling MRP values for the stock.
        """

        # Path to the index data file
        #index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

        # Load stock and index data
        stock_data = pd.read_csv(stock_csv_file, usecols=['Date', 'Close'])
        nifty_data = pd.read_csv(index_csv_file, usecols=['Date', 'Close'])
        if Frequency == 'Wk':
            stock_data =stock_data[-52:]
            nifty_data =nifty_data[-52:]
        elif Frequency == 'Daily':
            stock_data =stock_data[-200:]
            nifty_data =nifty_data[-200:]
        elif Frequency == 'All':
            stock_data =stock_data[:]
            nifty_data =nifty_data[:]
        else:
            1+1
            #Frequency == 'All'
            #stock_data =stock_data[:]
            #nifty_data =nifty_data[:]

        stock_data = stock_data.reset_index(drop=True)
        nifty_data = nifty_data.reset_index(drop=True)
        window =  min(len(stock_data),len(nifty_data))-10

        # Ensure the data is sorted by date
        stock_data['Date'] = pd.to_datetime(stock_data['Date'])
        nifty_data['Date'] = pd.to_datetime(nifty_data['Date'])
        #stock_data = stock_data.sort_values('Date')
        #nifty_data = nifty_data.sort_values('Date')

        # Merge stock and index data on the 'Date' column
        merged_data = pd.merge(stock_data, nifty_data, on='Date', suffixes=('_stock', '_nifty'))

        # Find the row with the minimum Close price
        min_close_row = merged_data['Close_nifty'].idxmin()

        # Slice the DataFrame from the row with the minimum Close price to the end
        merged_data = merged_data.loc[min_close_row:]

        # Reset the index (optional)
        merged_data = merged_data.reset_index(drop=True)

        # Calculate daily returns
        merged_data['stock_returns'] = merged_data['Close_stock'].pct_change()
        merged_data['nifty_returns'] = merged_data['Close_nifty'].pct_change()

        # Calculate rolling cumulative returns for stock and index
        merged_data['stock_cumreturns'] =  (1 + merged_data['stock_returns']).cumprod() #(1 + merged_data['stock_returns']).rolling(window=window, min_periods=1).apply(np.prod, raw=True) - 1
        merged_data['nifty_cumreturns'] = (1 + merged_data['nifty_returns']).cumprod() #(1 + merged_data['nifty_returns']).rolling(window=window, min_periods=1).apply(np.prod, raw=True) - 1

        # Calculate rolling MRP (Market Relative Performance)
        merged_data['MRP'] = (1 + merged_data['stock_cumreturns']*100) / (1 + merged_data['nifty_cumreturns']*100)

        # Round MRP to 3 decimal places
        merged_data['MRP'] = merged_data['MRP'].round(3).ffill()
        stock_data['MRP'] = merged_data['MRP'].fillna(method='ffill')
        stock_data['Nifty50'] =merged_data['nifty_cumreturns'].round(3).ffill()


        first_value = merged_data['Close_nifty'].iloc[0]  # Get the first value of the 'Close' column
        merged_data['Nifty50'] = round((merged_data['Close_nifty'] / first_value) * 1, 3)
        stock_data['Nifty50'] =merged_data['Nifty50'].round(3).ffill()

        #print(stock_data)
        # Return the MRP series
        return stock_data[['Date', 'MRP','Nifty50']]


    #index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
    nifty_data = pd.read_csv(index_csv_file, usecols=['Date', 'Close'])
    if Frequency == 'Wk':
        file_label = "52wk"
        nifty_data =nifty_data[-52:]
    elif Frequency == 'Daily':
        file_label = "200day"
        nifty_data =nifty_data[-200:]
    elif Frequency == 'All':
        file_label = "All"
        nifty_data =nifty_data[:]
    else:
        1+1
        #Frequency == 'All'
        #nifty_data =nifty_data[:]

    nifty_data['Date'] = pd.to_datetime(nifty_data['Date'])

    first_value = nifty_data['Close'].iloc[0]  # Get the first value of the 'Close' column
    nifty_data['Close'] = round((nifty_data['Close'] / first_value) * 1, 3)
    nifty_data['Nifty50'] =nifty_data['Close'].round(3).ffill()


    index_constituents = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
    index_constituents = pd.read_csv(index_constituents)
    Index_to_Longname = dict(zip(index_constituents['Symbol'], index_constituents['Company']))

    plt.figure(figsize=(22, 18))  # Set the figure size
    plt.title("Comparison of Index MRP levels. start date wis when nifty is lowest")
    plt.xlabel("Date", fontsize=12)
    plt.ylabel("Close MRP (Indexed to 1)", fontsize=10)
    plt.grid(True)  # Add a grid for better readability

    def niftyplot(file_path=None,window=252,index_csv_file=index_csv_file,Frequency=Frequency):
        nifty_data1  =calculate_rolling_mrp(file_path, window=252,index_csv_file=index_csv_file,Frequency=Frequency)
        Long_Name = f"Nifty50_{nifty_data1['Nifty50'].iloc[-1]}"
        #print(Long_Name)
        plt.plot(nifty_data1['Date'], nifty_data1['Nifty50'], label=Long_Name, linestyle=':', color= 'black')
        plt.text(nifty_data1['Date'].iloc[-1],nifty_data1['Nifty50'].iloc[-1], Long_Name, fontsize=11, color='black',
                va='baseline', ha='left', backgroundcolor='white')
        # Find the date and value of the maximum Nifty price
        max_nifty_price = nifty_data1['Nifty50'].max()
        max_nifty_date = nifty_data1.loc[nifty_data1['Nifty50'].idxmax(), 'Date']
        return max_nifty_date

    # Define a list of colors for the lines
    colors = ['yellow', 'red', 'blue', 'green', 'purple', 'orange', 'brown', 'teal',
              'fuchsia', 'gold', 'darkcyan', 'limegreen', 'magenta', 'pink', 'grey', ]

    # Define a list of line styles
    line_styles = ['-', '--', '-.', ':']

    no=0
    run = False
    for i, index_name in enumerate(index_names):
        Long_Name1 = Index_to_Longname.get(index_name)
        # Construct the file name
        file_name = f"{index_name}.csv"
        file_path = os.path.join(folder_path, file_name)

        # Check if the file exists
        if not os.path.exists(file_path):
            print(f"File {file_path} not found. Skipping.")
            continue

        if run == False:
            niftyplot(file_path=file_path,window=252,index_csv_file=index_csv_file,Frequency=Frequency)
            run = True

        # Read the index data
        #index_data = pd.read_csv(file_path)
        index_data  =calculate_rolling_mrp(file_path, window=252,index_csv_file=index_csv_file,Frequency=Frequency)


        # Convert the 'Date' column to datetime format
        index_data['Date'] = pd.to_datetime(index_data['Date'])
        index_data['MRP'] = index_data['MRP'].fillna(method='ffill')


        #print(index_data.tail())

        # Determine the line style based on the index number
        line_style = line_styles[no  % len(line_styles)]



        if index_data['MRP'].iloc[-1] > 2 or index_data['MRP'].iloc[-1] < nifty_data['Nifty50'].iloc[-1] :
            #line_style = line_styles[(no // 16) % len(line_styles)]
            Long_Name = f"{Long_Name1}_{index_data['MRP'].iloc[-1]}"
            if Long_Name1 ==None:
                print(Long_Name,index_name)
            #print(Long_Name)
            # Plot the Close_Index column with a unique color and line style
            plt.plot(index_data['Date'], index_data['MRP'],
                     label=Long_Name, linestyle=line_style, color=colors[no % len(colors)])

            last_date = index_data['Date'].iloc[-1]
            last_mrp = index_data['MRP'].iloc[-1]
            plt.text(last_date,last_mrp, Long_Name, fontsize=11, color=colors[no % len(colors)],
                     va='baseline', ha='left', backgroundcolor='white')
            no +=1
        else:
            Long_Name = f"{Long_Name1}_{index_data['MRP'].iloc[-1]}"
            print(f"Index is betwwen {index_data['Nifty50'].iloc[-1]} & 2 {Long_Name},{index_name}")


    # Add a legend
    #plt.legend(loc='upper left', fontsize=9)
    plt.legend(ncol=2, loc='upper left',fontsize=16)

    # Format x-axis to show labels on a quarterly basis
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))  # Quarterly labels
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format as 'YYYY-MM'

    # Rotate x-axis labels for better readability
    plt.xticks(rotation=90)

    # Show the plot
    plt.tight_layout()
    #plt.show()
    folder_path='/home/rizpython236/BT5/screener-outputs/'
    file_path = os.path.join(folder_path)
    chart_path = os.path.join(folder_path, f'TJI_Indices_{file_label}.png')
    plt.savefig(chart_path)
    time.sleep(3)
    post_telegram_file(chart_path)
    os.remove(chart_path)


# Example usage:
# Define the index names to plot
TJI_IC_path = '/home/rizpython236/BT5/trade-logs/TJI_index.csv'
TJI_IC_path = pd.read_csv(TJI_IC_path)
TJI_IC_path = TJI_IC_path['Symbol'].tolist()[:]
#TJI_IC_path = list(set(TJI_IC_path))
index_names = []
TJI_IC_path.extend(index_names)

#index_names = ['TJI_AVTN', 'TJI_RTGAGY']
path=  '/home/rizpython236/BT5/ticker_15yr'
index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

# Plot the Close Prices of the indices
#plot_index_close_prices(path, TJI_IC_path[:33],index_csv_file,Frequency=None) #'Wk''Daily''All'
#plot_index_close_prices(path, TJI_IC_path[33:],index_csv_file,Frequency=None)
#plot_index_close_prices(path, TJI_IC_path[:],index_csv_file,Frequency='All') #'Wk''Daily''All'

'''

# _____________________________________________________

# Index,Stock1,Stock1 weight,Stock2,Stock2 weight,Stock3,Stock3 weight,Default Stock
# Autoindex,Tatamotors,0.6,bajajauto,0.4,,,Nifty


# ____________________________


def load_index_constituents_from_csv(csv_path):
    """Load index constituents and their weights from a CSV file.

    Parameters
    ----------
    - csv_path: Path to the CSV file containing index constituents and weights.

    Returns
    -------
    - A dictionary where keys are index names and values are dictionaries of constituents and their weights.

    """
    # Read the CSV file
    df = pd.read_csv(csv_path)
    df.drop("Long_Name", axis=1, inplace=True)

    # Initialize the index_constituents dictionary
    index_constituents = {}

    # Iterate over each row in the CSV
    for _, row in df.iterrows():
        index_name = row["Index"]
        constituents = {}

        # Extract stock and weight pairs dynamically
        total_weight = 0
        i = 1
        while True:
            stock_col = f"Stock{i}"
            weight_col = f"Stock{i} weight"
            if stock_col not in row or weight_col not in row:
                break  # Exit if no more stocks are found
            if pd.notna(row[stock_col]) and pd.notna(row[weight_col]):
                constituents[row[stock_col]] = row[weight_col]
                total_weight += row[weight_col]
            i += 1

        # If the total weight is less than 100%, assign the remainder to the default stock
        # Assuming weights are in decimal form (e.g., 0.6 for 60%)
        if total_weight < 1.0:
            default_stock = row["Default Stock"]
            if pd.notna(default_stock):
                constituents[default_stock] = 1.0 - total_weight
            else:
                # raise ValueError(f"Default stock not specified for index {index_name}.")
                print(f"Default stock not specified for index {index_name}.")
        else:
            print(f"total_weight > 1 {index_name}.")

        # Add the index and its constituents to the dictionary
        index_constituents[index_name] = constituents

    # print(index_constituents)
    return index_constituents


def calculate_custom_index(folder_path, index_constituents, weighting_method="price", valid_tickers=None):
    """Calculate custom indices based on the stock data in the specified folder.
    The index starts at 1000 and scales proportionally.

    Parameters
    ----------
    - folder_path: Path to the folder containing the stock CSV files.
    - index_constituents: Dictionary where keys are index names and values are dictionaries of constituents and their weights.
    - weighting_method: 'price' for price-weighted index, 'equal' for equal-weighted index, 'custom' for user-specified weights.
    - valid_tickers: List to store valid tickers.

    """
    errorlist = []

    def change_stock_suffix(stock):
        if stock.endswith(".NS"):
            # Replace .NS with .BO
            return stock[:-3] + ".BO"
        if stock.endswith(".BO"):
            # Replace .BO with .NS
            return stock[:-3] + ".NS"
        # If it doesn't end with .NS or .BO, return the original stock symbol
        return stock

    # Loop through each index and its constituents
    for index_name, constituents in index_constituents.items():
        # Initialize an empty DataFrame to store the combined stock data
        combined_data = pd.DataFrame()

        for stock, weight in constituents.items():
            # Construct the file name
            file_name = f"{stock}.csv"
            file_path = os.path.join(folder_path, file_name)

            # Check if the file exists
            if not os.path.exists(file_path):
                # print(f"File {file_path} not found.")
                # else:
                chgstock = change_stock_suffix(stock)
                file_name = f"{chgstock}.csv"
                file_path = os.path.join(folder_path, file_name)
                # print(chgstock)
                if not os.path.exists(file_path):
                    errorlist.append(stock)
                    print(f"File1 {file_path} not found. Skipping.")
                    continue
                    # break

            # Read the stock data
            stock_data = pd.read_csv(file_path)
            # print(stock_data)
            stock_data["Stock"] = stock  # Add a column to identify the stock

            # Append the stock data to the combined data
            combined_data = pd.concat([combined_data, stock_data], axis=0)

        if combined_data.empty or stock_data.empty:
            continue
        # combined_data = combined_data[['Date', 'Open', 'High', 'Low', 'Close', 'Volume', 'Stock']]
        for col in ["Open", "High", "Low", "Close", "Volume"]:
            if col in combined_data.columns:  # check if the columns are present.
                combined_data[col] = pd.to_numeric(
                    combined_data[col], errors="coerce")
            else:
                print(f"Column '{col}' not found in DataFrame.")

        # print(combined_data.head())
        # print(combined_data.dtypes)
        # print(combined_data['Close'].isnull().sum())

        try:
            # Group by date and calculate the index values
            if weighting_method == "price":
                # Price-weighted index: weight based on price as a percentage of total price
                def calculate_price_weighted_index(group, price_column):
                    total_price = group[price_column].sum()
                    weights = group[price_column] / total_price
                    return (group[price_column] * weights).sum()

                # index_data = combined_data.groupby('Date').apply(
                #    lambda group: pd.Series({
                #        'Open': calculate_price_weighted_index(group, 'Open'),
                #        'High': calculate_price_weighted_index(group, 'High'),
                #        'Low': calculate_price_weighted_index(group, 'Low'),
                #        'Close': calculate_price_weighted_index(group, 'Close'),
                #        'Volume': group['Volume'].sum()
                #    })
                # ).reset_index()

                # print(combined_data.columns)
                index_data = combined_data.groupby("Date").agg({
                    "Close": lambda x: calculate_price_weighted_index(x, "Close"),
                    "High": lambda x: calculate_price_weighted_index(x, "High"),
                    "Low": lambda x: calculate_price_weighted_index(x, "Low"),
                    "Open": lambda x: calculate_price_weighted_index(x, "Open"),
                    "Volume": "sum",
                }).reset_index()

                # Calculate weights and weighted values for each group
                # combined_data['Weight'] = combined_data.groupby('Date')['Close'].transform(lambda x: x / x.sum())

                # Calculate weighted index for each column
                # index_data = combined_data.groupby('Date').apply(
                #    lambda group: pd.Series({
                #        'Open': (group['Open'] * group['Weight']).sum(),
                #        'High': (group['High'] * group['Weight']).sum(),
                #        'Low': (group['Low'] * group['Weight']).sum(),
                #        'Close': (group['Close'] * group['Weight']).sum(),
                #        'Volume': group['Volume'].sum()
                #    })
                # ).reset_index()

            elif weighting_method == "Price_equal":
                def normalize_group(group):
                    for column in ["Open", "High", "Low", "Close"]:
                        # Get the first value of the column in the group
                        base_value = group[column].iloc[0]
                        group[f"{column}"] = (
                            group[column] / base_value) * 1000
                    return group

                combined_data = combined_data[~combined_data["Stock"].str.startswith(
                    "^NSEI")]
                combined_data = combined_data.groupby(
                    "Stock").apply(normalize_group)
                # print(combined_data)

                # Equal-weighted index: simple average of prices
                index_data = combined_data.groupby("Date").agg({
                    "Open": "mean",
                    "High": "mean",
                    "Low": "mean",
                    "Close": "mean",
                    "Volume": "sum",
                }).reset_index()

            elif weighting_method == "return_equal":
                # Calculate daily returns for each price column (Open, High, Low, Close)
                for column in ["Open", "High", "Low", "Close"]:
                    combined_data[f"{column}_Return"] = combined_data.groupby("Stock")[
                        column].pct_change()

                # Drop rows with NaN returns (first row for each stock)
                # combined_data = combined_data.dropna(subset=['Open_Return', 'High_Return', 'Low_Return', 'Close_Return'])

                # Fill NaN returns with 0 (e.g., first row for each stock)
                combined_data[["Open_Return", "High_Return", "Low_Return", "Close_Return"]] = combined_data[[
                    "Open_Return", "High_Return", "Low_Return", "Close_Return"]].fillna(0.0001)

                # Exclude the index component (e.g., "^NSEI")
                combined_data = combined_data[~combined_data["Stock"].str.startswith(
                    "^NSEI")]

                # Number of stocks in the index
                num_stocks = combined_data["Stock"].nunique()

                if num_stocks == 0:
                    # raise ValueError("No valid stocks found after filtering")
                    print(f"No valid stocks {stock} found after filtering")
                    continue

                # Assign equal weights to each stock
                combined_data["Weight"] = 1 / num_stocks

                # Calculate weighted returns for each price column
                for column in ["Open", "High", "Low", "Close"]:
                    combined_data[f"{column}_Weighted_Return"] = combined_data[f"{column}_Return"] * \
                        combined_data["Weight"]

                # Aggregate weighted returns and volume by date
                index_data = combined_data.groupby("Date").agg({
                    "Open_Weighted_Return": "sum",
                    "High_Weighted_Return": "sum",
                    "Low_Weighted_Return": "sum",
                    "Close_Weighted_Return": "sum",
                    "Volume": "sum",
                }).reset_index()

                # Rename columns
                index_data = index_data.rename(columns={
                    "Open_Weighted_Return": "Open",
                    "High_Weighted_Return": "High",
                    "Low_Weighted_Return": "Low",
                    "Close_Weighted_Return": "Close",
                })

                # Set the initial index value
                initial_index_value = 1000

                # Calculate the index value over time for each price column
                for column in ["Open", "High", "Low", "Close"]:
                    index_data[column] = initial_index_value * \
                        (1 + index_data[column]).cumprod()

            elif weighting_method == "custom":
                # Custom-weighted index: use weights from index_constituents
                def calculate_custom_weighted_index(group, price_column):
                    weighted_sum = 0
                    for stock, weight in constituents.items():
                        stock_data = group[group["Stock"] == stock]
                        if not stock_data.empty:
                            weighted_sum += stock_data[price_column].iloc[0] * weight
                    return weighted_sum

                index_data = combined_data.groupby("Date").apply(
                    lambda group: pd.Series({
                        "Open": calculate_custom_weighted_index(group, "Open"),
                        "High": calculate_custom_weighted_index(group, "High"),
                        "Low": calculate_custom_weighted_index(group, "Low"),
                        "Close": calculate_custom_weighted_index(group, "Close"),
                        "Volume": group["Volume"].sum(),
                    }),
                ).reset_index()

            elif weighting_method == "ATR":
                def calculate_standard_deviation(data, period=14, column="Close"):
                    """Calculate the Standard Deviation (SD) of returns for a given dataset.

                    Parameters
                    ----------
                        data (pd.DataFrame): The dataset containing price data.
                        period (int): The rolling window period for SD calculation.
                        column (str): The column to use for calculating returns (default is 'Close').

                    Returns
                    -------
                        pd.Series: A series containing the Standard Deviation values.

                    """
                    # Calculate daily returns
                    returns = data[column].pct_change()

                    # Calculate Standard Deviation of returns
                    std_dev = returns.rolling(
                        window=period, min_periods=1).std()

                    return std_dev
                    # calculate_standard_deviation(data, period=14, column='Close')

                def calculate_atr(data, period=14):
                    """Calculate the Average True Range (ATR) for a given dataset.
                    """
                    high = data["High"]
                    low = data["Low"]
                    close = data["Close"]

                    # Calculate True Range (TR)
                    tr1 = abs(high - low)
                    tr2 = abs(high - close.shift())
                    tr3 = abs(low - close.shift())
                    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

                    # Calculate ATR
                    atr = tr.rolling(window=period, min_periods=1).mean()

                    return atr

                def create_atr_weighted_index(data, atr_period=14):
                    """Create an index where weights are based on ATR.
                    """
                    # Filter out the index data (e.g., ^NSEI)
                    data = data[~data["Stock"].str.startswith("^NSEI")]

                    # Calculate ATR for each stock
                    data["ATR"] = data.groupby("Stock").apply(lambda x: calculate_atr(
                        x, period=atr_period)).reset_index(level=0, drop=True)
                    # calculate_standard_deviation(x, period=14, column='Close')

                    # Calculate weights as the inverse of ATR for higher weight to  lower volatily
                    # data['Weight'] = 1 / data['ATR']
                    # Calculate weights as the ATR for higher weight to highter volatily
                    # data['Weight'] = data['ATR']
                    # Calculate weights as the hybrid of ATR
                    data["Weight"] = 0.6 * data["ATR"] + \
                        0.4 * (1 / data["ATR"])

                    # Handle cases where ATR is zero or near-zero (to avoid infinite weights)
                    data["Weight"] = data["Weight"].replace(
                        [float("inf"), -float("inf")], 0)

                    # Normalize weights so they sum to 1 for each date
                    data["Weight"] = data.groupby(
                        "Date")["Weight"].apply(lambda x: x / x.sum())

                    # Calculate the weighted index
                    index_data = data.groupby("Date").apply(
                        lambda x: pd.Series({
                            "Open": (x["Open"] * x["Weight"]).sum(),
                            "High": (x["High"] * x["Weight"]).sum(),
                            "Low": (x["Low"] * x["Weight"]).sum(),
                            "Close": (x["Close"] * x["Weight"]).sum(),
                            "Volume": x["Volume"].sum(),
                        }),
                    ).reset_index()

                    return index_data

                index_data = create_atr_weighted_index(
                    combined_data, atr_period=14)

            elif weighting_method == "RSI":
                def calculate_rsi(data, period=21, column="Close"):
                    """Calculate the Relative Strength Index (RSI) for a given dataset.
                    """
                    delta = data[column].diff()
                    gain = (delta.where(delta > 0, 0)).rolling(
                        window=period, min_periods=1).mean()
                    loss = (-delta.where(delta < 0, 0)
                            ).rolling(window=period, min_periods=1).mean()

                    rs = gain / loss
                    rsi = 100 - (100 / (1 + rs))

                    return rsi

                def create_rsi_weighted_index(data, rsi_period=21):
                    """Create an index where weights are based on RSI.
                    """
                    # Filter out the index data (e.g., ^NSEI)
                    data = data[~data["Stock"].str.startswith("^NSEI")]

                    # Calculate RSI for each stock
                    data["RSI"] = data.groupby("Stock")[["Close"]].apply(
                        lambda x: calculate_rsi(x, period=rsi_period),
                    ).reset_index(level=0, drop=True)

                    # Assign weights based on RSI
                    # Higher weights for RSI in the range 30-70, lower weights outside this range
                    data["Weight"] = data["RSI"].apply(
                        lambda x: 1 -
                        abs((x - 50) / 50) if 30 <= x <= 70 else 0.1,
                    )

                    # Normalize weights so they sum to 1 for each date
                    data["Weight"] = data.groupby(
                        "Date")["Weight"].apply(lambda x: x / x.sum())

                    # Calculate the weighted index
                    index_data = data.groupby("Date").apply(
                        lambda x: pd.Series({
                            "Open": (x["Open"] * x["Weight"]).sum(),
                            "High": (x["High"] * x["Weight"]).sum(),
                            "Low": (x["Low"] * x["Weight"]).sum(),
                            "Close": (x["Close"] * x["Weight"]).sum(),
                            "Volume": x["Volume"].sum(),
                        }),
                    ).reset_index()

                    return index_data

                index_data = create_rsi_weighted_index(
                    combined_data, rsi_period=21)

            else:
                raise ValueError(
                    "Invalid weighting method. Choose 'price', 'equal', or 'custom'.")
            # print(index_data.columns)
            # print(type(index_data.columns))
            # Convert all column names to strings
            index_data.columns = [str(col) for col in index_data.columns]
            # index_data.rename(columns={invalid_column_name: 'Valid_Column_Name'}, inplace=True)
            # print(index_data.columns.hasnans)
            # print(index_data[['Open', 'High', 'Low', 'Close', 'Volume']].dtypes)

            # index_data[['Open', 'High', 'Low', 'Close', 'Volume']] = index_data[['Open', 'High', 'Low', 'Close', 'Volume']].fillna(method='ffill')
            # Normalize the index to start at 1000
            for column in ["Open", "High", "Low", "Close"]:
                first_value = index_data[column].iloc[0]
                index_data[column] = round(
                    (index_data[column] / first_value) * 1000, 2)

            # print(index_name)
            # print(index_data)
            # Save the index to a CSV file
            if valid_tickers is not None:
                valid_tickers.append(index_name)
            output_file = os.path.join(folder_path, f"{index_name}.csv")
            index_data.to_csv(output_file, index=False)
            print(f"Index saved to {output_file}")
        except Exception as e:
            print(f"Error occurred for custum_index: {e!s}")
            traceback_str = traceback.format_exc()
            # Print detailed error information
            # print("Error type:", e.__class__.__name__)
            # print("Error message:", str(e))
            # print("Traceback:\n", traceback_str)
            continue

    print(errorlist)
    post_telegram_message(f"Missing TJI Tickers: {', '.join(errorlist)}")


"""
# Example usage:
# Load index constituents from a CSV file
csv_path = '/home/rizpython236/BT5/trade-logs/index_constituents.csv'
index_constituents = load_index_constituents_from_csv(csv_path)
path=  '/home/rizpython236/BT5/ticker_15yr'
# Calculate indices
valid_tickers = []
calculate_custom_index(path, index_constituents, weighting_method='return_equal', valid_tickers=valid_tickers) #Choose 'price', 'Price_equal', return_equal or 'custom'." RSI  ATR
"""
# ______________________________


# import os
# import pandas as pd


def plot_index_close_prices(folder_path, index_names, index_csv_file=None, Frequency=None):
    """Plot the Close Price of multiple indices in a single chart for comparison.
    - x-axis labels are displayed on a quarterly basis.
    - Different colors and line styles are used for each index line.
    - Line styles change after every 16 indices.

    Parameters
    ----------
    - folder_path: Path to the folder containing the index CSV files.
    - index_names: List of index names (e.g., ['Autoindex', 'FMCGindex']).

    """
    def calculate_rolling_mrp(stock_csv_file, window=252, index_csv_file=None, Frequency=None):
        """Calculates the rolling Market Relative Performance (MRP) for a given stock over a specified window.

        Args:
            stock_csv_file (str): Path to the CSV file containing stock data.
            window (int): Rolling window size in trading days (default is 252).

        Returns:
            pandas.Series: Series containing the rolling MRP values for the stock.

        """
        # Path to the index data file
        # index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

        # Load stock and index data
        # usecols=['Date','High', 'Low', 'Close']) usecols=['Date','High', 'Low', 'Close'])
        stock_data = pd.read_csv(stock_csv_file)
        nifty_data = pd.read_csv(index_csv_file)  # usecols=['Date', 'Close'])
        if Frequency == "Wk":
            stock_data = stock_data[-52:]
            nifty_data = nifty_data[-52:]
        elif Frequency == "Daily":
            stock_data = stock_data[-252:]
            nifty_data = nifty_data[-252:]
        elif Frequency == "All52wk":
            stock_data = stock_data[-52:]
            nifty_data = nifty_data[-52:]
        elif Frequency == "All200daily":
            stock_data = stock_data[-252:]
            nifty_data = nifty_data[-252:]
        else:
            # Frequency == 'Allfull'
            stock_data = stock_data[:]
            nifty_data = nifty_data[:]

        stock_data = stock_data.reset_index(drop=True)
        nifty_data = nifty_data.reset_index(drop=True)
        window = min(len(stock_data), len(nifty_data)) - 10

        # Ensure the data is sorted by date
        stock_data["Date"] = pd.to_datetime(stock_data["Date"])
        nifty_data["Date"] = pd.to_datetime(nifty_data["Date"])
        # stock_data = stock_data.sort_values('Date')
        # nifty_data = nifty_data.sort_values('Date')

        # Merge stock and index data on the 'Date' column
        merged_data = pd.merge(stock_data, nifty_data,
                               on="Date", suffixes=("_stock", "_nifty"))
        # print(merged_data)

        # Find the row with the minimum Close price
        # min_close_row = merged_data['Close_nifty'].idxmin()

        # Slice the DataFrame from the row with the minimum Close price to the end
        # merged_data = merged_data.loc[min_close_row:]

        # Reset the index (optional)
        # merged_data = merged_data.reset_index(drop=True)

        # Calculate daily returns
        merged_data["stock_returns"] = merged_data["Close_stock"].pct_change()
        merged_data["nifty_returns"] = merged_data["Close_nifty"].pct_change()

        # Calculate rolling cumulative returns for stock and index
        # (1 + merged_data['stock_returns']).rolling(window=window, min_periods=1).apply(np.prod, raw=True) - 1
        merged_data["stock_cumreturns"] = (
            1 + merged_data["stock_returns"]).cumprod()
        # (1 + merged_data['nifty_returns']).rolling(window=window, min_periods=1).apply(np.prod, raw=True) - 1
        merged_data["nifty_cumreturns"] = (
            1 + merged_data["nifty_returns"]).cumprod()

        # Calculate rolling MRP (Market Relative Performance)
        merged_data["MRP"] = (1 + merged_data["stock_cumreturns"]
                              * 100) / (1 + merged_data["nifty_cumreturns"] * 100)
        if Frequency == "Daily" or Frequency == "All200daily":
            merged_data["RSI"] = tb.RSI(
                merged_data["Close_stock"], timeperiod=14)
        else:
            merged_data["RSI"] = tb.RSI(
                merged_data["Close_stock"], timeperiod=14)

        if Frequency == "Daily" or Frequency == "All200daily" or Frequency == "Wk" or Frequency == "All52wk":
            merged_data["CCI"] = tb.CCI(
                merged_data["High_stock"], merged_data["Low_stock"], merged_data["Close_stock"], timeperiod=34)
        else:
            merged_data["CCI"] = tb.CCI(
                merged_data["High_stock"], merged_data["Low_stock"], merged_data["Close_stock"], timeperiod=34)

        # Round MRP to 3 decimal places
        merged_data["MRP"] = merged_data["MRP"].round(3).ffill()
        # stock_data['MRP'] = merged_data['MRP'].fillna(method='ffill')
        stock_data["MRP"] = merged_data["MRP"].ffill()
        # stock_data['Nifty50'] =merged_data['nifty_cumreturns'].round(3).ffill()

        # Get the first value of the 'Close' column
        first_value = merged_data["Close_nifty"].iloc[0]
        merged_data["Nifty50"] = round(
            (merged_data["Close_nifty"] / first_value) * 1, 3)
        merged_data["Nifty50"] = merged_data["Nifty50"].round(3).ffill()
        merged_data["Close_nifty"] = merged_data["Close_nifty"].round(2)
        stock_data["Nifty50"] = merged_data["Nifty50"].round(3).ffill()

        # print(merged_data)
        # Return the MRP series
        # return stock_data[['Date', 'MRP','Nifty50']]
        return merged_data

    # index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
    nifty_data = pd.read_csv(index_csv_file, usecols=["Date", "Close"])
    if Frequency == "Wk":
        file_label = "52wk"
        nifty_data = nifty_data[-52:]
    elif Frequency == "Daily":
        file_label = "200day"
        nifty_data = nifty_data[-252:]
    elif Frequency == "All52wk":
        file_label = "All52wk"
        nifty_data = nifty_data[-52:]
    elif Frequency == "All200daily":
        file_label = "All200daily"
        nifty_data = nifty_data[-252:]
    else:
        # Frequency == 'Allfull'
        file_label = "Allfull"
        nifty_data = nifty_data[:]

    nifty_data["Date"] = pd.to_datetime(nifty_data["Date"])

    # Get the first value of the 'Close' column
    first_value = nifty_data["Close"].iloc[0]
    nifty_data["Close"] = round((nifty_data["Close"] / first_value) * 1, 3)
    nifty_data["Nifty50"] = nifty_data["Close"].round(3).ffill()

    index_constituents = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
    index_constituents = pd.read_csv(index_constituents)
    Index_to_Longname = dict(
        zip(index_constituents["Symbol"], index_constituents["Company"]))

    plt.figure(figsize=(22, 18))  # Set the figure size
    plt.title("Comparison of Index MRP levels.")
    plt.xlabel("Date", fontsize=12)
    plt.ylabel("Close MRP (Indexed to 1)", fontsize=10)
    plt.grid(True)  # Add a grid for better readability

    def niftyplot(file_path=None, window=252, index_csv_file=index_csv_file, Frequency=Frequency):
        nifty_data1 = calculate_rolling_mrp(
            file_path, window=252, index_csv_file=index_csv_file, Frequency=Frequency)
        Long_Name = f"Nifty50_{nifty_data1['Nifty50'].iloc[-1]}"
        # print(Long_Name)
        plt.plot(nifty_data1["Date"], nifty_data1["Nifty50"],
                 label=Long_Name, linestyle="--", color="black")
        plt.text(nifty_data1["Date"].iloc[-1], nifty_data1["Nifty50"].iloc[-1], Long_Name, fontsize=11, color="black",
                 va="baseline", ha="left", backgroundcolor="white")
        # Find the date and value of the Min Nifty price
        min_nifty_price = nifty_data1["Close_nifty"].min()
        min_nifty_date = nifty_data1.loc[nifty_data1["Close_nifty"].idxmin(
        ), "Date"]
        min_nifty_date_str = min_nifty_date.strftime("%Y-%m-%d")
        # Find the date and value of the maximum Nifty price
        max_nifty_price = nifty_data1["Close_nifty"].max()
        max_nifty_date = nifty_data1.loc[nifty_data1["Close_nifty"].idxmax(
        ), "Date"]
        # Format the date as a string without the time
        max_nifty_date_str = max_nifty_date.strftime("%Y-%m-%d")

        # Add a vertical line at the date of maximum Nifty price
        plt.axvline(x=max_nifty_date, color="red", linestyle="-", linewidth=1,
                    label=f"Nifty Max: {max_nifty_price}-{max_nifty_date_str}")
        # Add a vertical line at the date of min Nifty price
        plt.axvline(x=min_nifty_date, color="green", linestyle="-", linewidth=1,
                    label=f"Nifty Min: {min_nifty_price}-{min_nifty_date_str}")

        return min_nifty_date, max_nifty_date

    # Define a list of colors for the lines
    colors = ["yellow", "red", "blue", "green", "purple", "orange", "brown", "teal",
              "fuchsia", "gold", "darkcyan", "limegreen", "magenta", "pink", "grey"]

    # Define a list of line styles
    line_styles = ["-", "--", "-.", ":"]

    no = 0
    run = False
    for i, index_name in enumerate(index_names):
        Long_Name1 = Index_to_Longname.get(index_name)
        # Construct the file name
        file_name = f"{index_name}.csv"
        file_path = os.path.join(folder_path, file_name)

        # Check if the file exists
        if not os.path.exists(file_path):
            print(f"File {file_path} not found. Skipping.")
            continue

        if run == False:
            niftyplot(file_path=file_path, window=252,
                      index_csv_file=index_csv_file, Frequency=Frequency)
            run = True

        # Read the index data
        # index_data = pd.read_csv(file_path)
        index_data = calculate_rolling_mrp(
            file_path, window=252, index_csv_file=index_csv_file, Frequency=Frequency)

        # Convert the 'Date' column to datetime format
        index_data["Date"] = pd.to_datetime(index_data["Date"])
        # index_data['MRP'] = index_data['MRP'].fillna(method='ffill')
        index_data["MRP"] = index_data["MRP"].ffill()
        # index_data["RSI"] = tb.RSI(index_data['Close'], timeperiod=34)

        # print(index_data.tail())

        # Determine the line style based on the index number
        line_style = line_styles[no % len(line_styles)]

        if (index_data["MRP"].iloc[-1] > nifty_data["Nifty50"].iloc[-1] * 1.1 and index_data["RSI"].iloc[-1] > 55 and index_data["CCI"].iloc[-1] > 10) or (index_data["MRP"].iloc[-1] < nifty_data["Nifty50"].iloc[-1]* .9 and index_data["RSI"].iloc[-1] < 45 and index_data["CCI"].iloc[-1] < -10):
            # line_style = line_styles[(no // 16) % len(line_styles)]
            Long_Name = f"{Long_Name1}_{index_data['MRP'].iloc[-1]}"
            if Long_Name1 == None:
                print(Long_Name, index_name)
            # print(f" Plot Index {Long_Name} & {index_name}")
            # print(Long_Name)
            # Plot the Close_Index column with a unique color and line style
            plt.plot(index_data["Date"], index_data["MRP"],
                     label=Long_Name, linestyle=line_style, color=colors[no % len(colors)])

            last_date = index_data["Date"].iloc[-1]
            last_mrp = index_data["MRP"].iloc[-1]
            plt.text(last_date, last_mrp, Long_Name, fontsize=11, color=colors[no % len(colors)],
                     va="baseline", ha="left", backgroundcolor="white")
            no += 1
        else:
            Long_Name = f"{Long_Name1}_{index_data['MRP'].iloc[-1]}"
            # print(f"Index is betwwen {index_data['Nifty50'].iloc[-1]} & 2 {Long_Name},{index_name}")

    # Add a legend
    # plt.legend(loc='upper left', fontsize=9)
    plt.legend(ncol=2, loc="upper left", fontsize=16)

    # Format x-axis to show labels on a quarterly basis
    plt.gca().xaxis.set_major_locator(
        mdates.MonthLocator(interval=1))  # Quarterly labels  3
    plt.gca().xaxis.set_major_formatter(
        mdates.DateFormatter("%Y-%m"))  # Format as 'YYYY-MM'

    # Rotate x-axis labels for better readability
    # plt.xticks(rotation=25)
    plt.xticks(rotation=90, ha="right")

    # Show the plot
    plt.tight_layout()

    # plt.show()
    folder_path = "/home/rizpython236/BT5/screener-outputs/"
    file_path = os.path.join(folder_path)
    chart_path = os.path.join(folder_path, f"TJI_Indices_{file_label}.png")
    plt.savefig(chart_path)
    time.sleep(3)
    post_telegram_file(chart_path)
    os.remove(chart_path)


# Example usage:
# Define the index names to plot
TJI_IC_path = "/home/rizpython236/BT5/trade-logs/TJI_index.csv"
TJI_IC_path = pd.read_csv(TJI_IC_path)
TJI_IC_path = TJI_IC_path["Symbol"].tolist()[:]
# TJI_IC_path = list(set(TJI_IC_path))
index_names = []
TJI_IC_path.extend(index_names)

# index_names = ['TJI_AVTN', 'TJI_RTGAGY']
path = "/home/rizpython236/BT5/ticker_15yr"
index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

# Plot the Close Prices of the indices

# plot_index_close_prices(path, TJI_IC_path[:33],index_csv_file,Frequency='Daily') # Wk Daily All52wk All200daily Allfull
# plot_index_close_prices(path, TJI_IC_path[33:],index_csv_file,Frequency='Daily') # Wk Daily All52wk All200daily Allfull
# plot_index_close_prices(path, TJI_IC_path[:],index_csv_file,Frequency='All200daily') # Wk Daily All52wk All200daily Allfull


def calculate_momentum(data, lookback_period=12, column="Close"):
    """Calculate momentum as the percentage change in price over a lookback period.
    """
    momentum = data[column].pct_change(periods=lookback_period)
    return momentum


def download_ticker_data(tickers_list=None, TICKER_CSV_DATA_FOLDER_PATH=None):

    try:
        count = 0
        IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
        end_date = datetime.now(IST_TIMEZONE).date()  # - timedelta(weeks=2)
        # start_date = end_date - timedelta(weeks=77) #77 weekly  52+12 64
        start_date = end_date - timedelta(weeks=52 + 1)
        END_DATE = str(end_date)
        START_DATE = str(start_date)
        print(f"start date {START_DATE} ,end date {END_DATE}.")
        additional_tickers = []
        tickers_list.extend(additional_tickers)
        # tickers_list = additional_tickers + tickers_list
        for symbol in tickers_list:
            count += 1
            if count % 200 == 0:
                print(f"Processed {count} symbols. Pausing for 5 minutes...")
                time.sleep(4 * 60)  # 600 seconds = 10 minutes

            # print("Downloading data for => {}".format(symbol))
            data = yf.download(
                symbol,
                start=START_DATE,
                end=END_DATE,
                interval="1d",  # 1wk "1d"
                rounding=True,
                threads=True,
                multi_level_index=False,
                progress=False,
                back_adjust=True,
                repair=True,  # Data repair is used to fill in missing or corrupted data
                keepna=False,  # removes any rows with missing data.
                actions=False,  # excludes dividend and stock split events from the dat
                auto_adjust=True,  # adjusted for corporate actions like stock splits and dividends
                # ignore_tz=True
            )

            ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
            if len(data) > 250:
                # print(data.column)
                # print(data)
                # Strip spaces from column names
                # data.columns = data.columns.str.strip()
                # Convert the 'Date' column to datetime and remove the time part
                # data[0] = pd.to_datetime(data[0]).dt.date
                data.index = data.index.date
                data.rename_axis("Date", inplace=True)
                data = data.reset_index()
                data = data.drop(columns=["Repaired?"], errors="ignore")
                # data["Date"] = pd.to_datetime(data["Date"]).dt.date
                data.to_csv(ticker_csv_file_path, index=False)
                # print(data)
            time.sleep(1.5)

    except Exception as e:
        print(f"Error processing download_ticker_data: {e!s}")
        traceback_str = traceback.format_exc()
        print(traceback_str)


def addchartspdf(screenercsv_path=None, folder_path=None, filepathpdf=None):
    try:
        screener_BTouputtickers = []
        if screenercsv_path == "/home/rizpython236/BT5/trade-logs/screener-output.csv":
            data = pd.read_csv(screenercsv_path)
            screener_BTouputtickers = data["ticker"].tolist()
            # screener_BTouputtickers =["INFY","LOTUSEYE.NS","MARUTI.NS"]
            # screener_BTouputtickers =  data[data['dir'] == 'BUY']['ticker'].tolist()
            # Sort the DataFrame by 'dir' (BUY first) and then by 'ticker'
            # screener_BTouputtickers = data.sort_values(by=['signal', 'ticker'])
            screener_BTouputtickers = data.sort_values(
                "signal", ascending=True)["ticker"].tolist()
            # Extract all tickers in order (BUY followed by SELL)
            # screener_BTouputtickers = screener_BTouputtickers['ticker'].tolist()
        elif screenercsv_path == "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv":
            data = pd.read_csv(screenercsv_path)
            screener_BTouputtickers = data[data["dir"]
                                           == "BUY"]["ticker"].tolist()
        elif screenercsv_path == "/home/rizpython236/BT5/trade-logs/Opentradebook.csv":
            data = pd.read_csv(screenercsv_path)
            screener_BTouputtickers = data[data["signal"]
                                           == "BUY"]["ticker"].tolist()
            # screener_buy_tickers_date = [
            #    (row['date'], row['ticker'])
            #    for _, row in data[data["signal"] == "BUY"].iterrows()
            # ]
            buy_data = data[data["signal"] == "BUY"]
            buy_dates = buy_data["date"].tolist()
            buy_tickers = buy_data["ticker"].tolist()
            buy_pairs = list(zip(buy_dates, buy_tickers))
            # target_ticker = "AAPL"
            # buy_dates_for_ticker = [date for date, ticker in buy_pairs if ticker == target_ticker]

            # for date, ticker in zip(buy_dates, buy_tickers):
            # print(f"{date}: {ticker}")

            # screener_BTouputtickers = data['ticker'].tolist()
        else:
            raise ValueError("Invalid screener CSV path provided.")

        print(screener_BTouputtickers)
        if len(screener_BTouputtickers) == 0:
            return

        # print(screenercsv_path)
        # print(folder_path)
        # print(filepathpdf)
        manage_zip("unzip")

        for ticker in screener_BTouputtickers:
            file_path = os.path.join(folder_path, f"{ticker}.csv")

            if os.path.exists(file_path):
                1 + 1
                # File already exists
                # print(f"✅ Found: {ticker}.csv")
            else:
                # File missing → download
                print(f"⬇️ Downloading missing ticker: {ticker}")
                download_ticker_data(
                    tickers_list=[ticker],
                    TICKER_CSV_DATA_FOLDER_PATH=TICKER_CSV_DATA_FOLDER_PATH,
                )

        # for file_name in os.listdir(folder_path):
        #    #if file_name.endswith('.csv'):
        #    file_path = os.path.join(folder_path, file_name)
        #    base_name = os.path.splitext(file_name)[0]
        #    if base_name in screener_BTouputtickers:
        #        continue
        #    else:
        #        base_list = [base_name]
        #        download_ticker_data(tickers_list=base_list,TICKER_CSV_DATA_FOLDER_PATH=TICKER_CSV_DATA_FOLDER_PATH)
        #        #download_ticker_data(tickers_list=screener_BTouputtickers,TICKER_CSV_DATA_FOLDER_PATH=TICKER_CSV_DATA_FOLDER_PATH)

        valid_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
        valid_df = pd.read_csv(valid_file)
        symbol_to_company = dict(zip(valid_df["Symbol"], valid_df["Company"]))

        with PdfPages(filepathpdf) as pdf:
            # Loop through all files in the folder
            cleaned_tickers = []
            # cleaned_tickers_all = []

            for ticker in screener_BTouputtickers:
                file_name = f"{ticker}.csv"  # construct filename from ticker
                if file_name in os.listdir(folder_path):

                    # for file_name in os.listdir(folder_path):
                    #    if file_name.endswith('.csv'):
                    file_path = os.path.join(folder_path, file_name)
                    # total_files += 1
                    base_name = os.path.splitext(file_name)[0]
                    # file_names.append(base_name)
                    # print(file_name,base_name)
                    clean_ticker = ticker.replace(".NS", "").replace(".BO", "")
                    if clean_ticker in cleaned_tickers:
                        print(f"Skipping {clean_ticker} - already processed")
                        continue

                    cleaned_tickers.append(clean_ticker)

                    try:

                        if base_name in screener_BTouputtickers:  # if base_name in minervinitickers:
                            file_path = os.path.join(folder_path, file_name)
                            # total_files += 1
                            # print(file_name,file_path)
                            Base_name = symbol_to_company.get(
                                base_name, base_name)
                            # Read the CSV file into a DataFrame
                            dfM = pd.read_csv(file_path, usecols=[
                                              "Date", "Open", "High", "Low", "Close", "Volume"])
                            dfM["Date"] = pd.to_datetime(dfM["Date"]).dt.date
                            # Convert index to datetime
                            dfM["Date"] = pd.to_datetime(dfM["Date"])

                            dfM["CCI"] = tb.CCI(
                                dfM["High"], dfM["Low"], dfM["Close"], timeperiod=34)
                            # dfM["CCImovavgL"] = tb.EMA(dfM["CCI"], timeperiod=14)
                            dfM["RSI14"] = tb.RSI(dfM["Close"], timeperiod=14)
                            dfM["SMA_50"] = tb.EMA(
                                dfM["Close"], timeperiod=10 * 5)
                            dfM["SMA_200"] = tb.SMA(
                                dfM["Close"], timeperiod=40 * 5)
                            # df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                            dfM["SMA_150"] = tb.EMA(
                                dfM["Close"], timeperiod=25 * 5)  # 25
                            # df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                            # df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                            dfM["SMA_200_15"] = tb.SMA(
                                dfM["SMA_200"], timeperiod=10 * 5)
                            dfM["OBV"] = tb.OBV(dfM["Close"], dfM["Volume"])
                            # dfM["AD"] = talib.AD(dfM['High'],dfM['Low'],dfM['Close'],dfM['Volume'])
                            # print(dfM)
                            # print(f"minervini_Charts for {Base_name}")

                            if screenercsv_path == "/home/rizpython236/BT5/trade-logs/Opentradebook.csv" and (dfM["Close"].iloc[-1] < dfM["SMA_200"].iloc[-1] and dfM["CCI"].iloc[-1] < 1000):
                                print(
                                    f"Skipping {clean_ticker} - not in Up mumentum")
                                continue

                            # 1. Combined Price, Volume, RSI Chart
                            fig_combined = plt.figure(figsize=(11, 8.5))
                            # gs = fig_combined.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                            # gs = fig_combined.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])
                            # Custom GridSpec for 60% Price, 10% Volume, 15% RSI, 15% CCI
                            gs = fig_combined.add_gridspec(
                                4, 1, height_ratios=[6, 1, 1.5, 1.5])

                            # Price chart (line plot)
                            ax1 = fig_combined.add_subplot(gs[0])
                            ax1.plot(dfM["Date"], dfM["Close"],
                                     label="Price", color="black", linewidth=1)

                            # Plot SMAs on top of line chart
                            ax1.plot(dfM["Date"], dfM["SMA_50"],
                                     label="EMA 10", color="blue", linewidth=1.5)
                            ax1.plot(
                                dfM["Date"], dfM["SMA_150"], label="EMA 25", color="orange", linewidth=1.5)
                            ax1.plot(dfM["Date"], dfM["SMA_200"],
                                     label="SMA 40", color="red", linewidth=1.5)
                            ax1.plot(dfM["Date"], dfM["SMA_200_15"],
                                     label="SMA 40(1)", color="purple", linewidth=1.5)

                            if screenercsv_path == "/home/rizpython236/BT5/trade-logs/Opentradebook.csv":
                                target_ticker = ticker
                                buy_dates_for_ticker = [
                                    date for date, ticker in buy_pairs if ticker == target_ticker]
                                # Convert string dates to datetime if needed
                                buy_dates_dt = [pd.to_datetime(
                                    date) for date in buy_dates_for_ticker]
                                buy_dates_dt = buy_dates_dt[0]

                                # Calculate business days from today
                                today = pd.Timestamp.today().normalize()  # Remove time component)
                                bdays = pd.bdate_range(
                                    start=buy_dates_dt, end=today, inclusive="neither")
                                weekday_count = len(bdays)

                                if weekday_count < 252:
                                    ax1.axvline(x=buy_dates_dt, color='orange', linestyle='--', linewidth=2,
                                               alpha=0.7, label=f'Buy Date: {buy_dates_dt.strftime("%Y-%m-%d")}')

                                ax1.set_title(
                                    f"{buy_dates_for_ticker} {weekday_count} business days ago-{clean_ticker} {Base_name} Price & Moving Averages", fontsize=14)
                            else:
                                ax1.set_title(
                                    f"{clean_ticker} {Base_name} Price and Moving Averages", fontsize=14)

                            ax1.legend()

                            """
                            # Volume chart
                            ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                            ax2.bar(dfM['Date'], dfM['Volume']/ 1000, color='blue', width=0.5, alpha=0.5)
                            #ax2.set_title('Volume', fontsize=12)
                            #ax2.set_ylabel('Volume')
                            #ax2.set_title('Volume (in thousands)', fontsize=12)  # Update title to reflect units
                            ax2.set_ylabel('Volume (K)')  # Change y-axis label to indicate thousands
                            """

                            # Volume chart with OBV
                            ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                            # Plot volume bars
                            ax2.bar(dfM["Date"], dfM["Volume"] / 1000,
                                    color="blue", width=0.5, alpha=0.5, label="Volume")
                            # Plot OBV line on secondary y-axis
                            ax2b = ax2.twinx()
                            ax2b.plot(dfM["Date"], dfM["OBV"] / 1000,
                                      color="black", linewidth=1.5, label="OBV")
                            # Set labels and title
                            ax2.set_ylabel("Volume (K)", color="blue")
                            ax2b.set_ylabel("OBV (K)", color="black")
                            # Set colors for y-axes to match their respective data
                            ax2.tick_params(axis="y", colors="blue")
                            ax2b.tick_params(axis="y", colors="black")
                            # Add legend
                            lines, labels = ax2.get_legend_handles_labels()
                            lines2, labels2 = ax2b.get_legend_handles_labels()
                            ax2.legend(lines + lines2, labels +
                                       labels2, loc="upper left")

                            # RSI chart
                            ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                            ax3.plot(dfM["Date"], dfM["RSI14"],
                                     color="purple", label="RSI")
                            ax3.axhline(70, color="red",
                                        linestyle="--", alpha=0.5)
                            ax3.axhline(30, color="green",
                                        linestyle="--", alpha=0.5)
                            ax3.fill_between(dfM["Date"], 70, dfM["RSI14"],
                                             where=(dfM["RSI14"] >= 70), color="red", alpha=0.3)
                            ax3.fill_between(dfM["Date"], 30, dfM["RSI14"],
                                             where=(dfM["RSI14"] <= 30), color="green", alpha=0.3)
                            ax3.set_title("RSI (24)", fontsize=12)
                            ax3.set_ylim(0, 100)
                            ax3.legend()

                            # CCI chart
                            ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                            ax4.plot(dfM["Date"], dfM["CCI"],
                                     color="purple", label="CCI")
                            ax4.axhline(0, color="red",
                                        linestyle="--", alpha=0.5)
                            ax4.axhline(50, color="green",
                                        linestyle="--", alpha=0.5)
                            ax4.fill_between(dfM["Date"], 0, dfM["CCI"],
                                             where=(dfM["CCI"] <= 0), color="red", alpha=0.3)
                            ax4.fill_between(dfM["Date"], 50, dfM["CCI"],
                                             where=(dfM["CCI"] >= 50), color="green", alpha=0.3)
                            ax4.set_title("CCI (34)", fontsize=12)
                            ax4.set_ylim(-100, 150)
                            ax4.legend()

                            # Format x-axis to show labels on a quarterly basis
                            plt.gca().xaxis.set_major_locator(
                                mdates.MonthLocator(interval=3))  # Quarterly labels  6
                            plt.gca().xaxis.set_major_formatter(
                                mdates.DateFormatter("%Y-%m"))  # Format as 'YYYY-MM'
                            # plt.xticks(rotation=25)
                            plt.xticks(rotation=90, ha="right")
                            plt.tight_layout()
                            # Reduce margins using tight_layout with padding adjustments
                            # plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)  # Adjust padding as needed
                            # pdf.savefig(fig_combined)
                            pdf.savefig(fig_combined, bbox_inches="tight")

                            folder_pathf = "/home/rizpython236/BT5/screener-outputs/"
                            file_path = os.path.join(folder_pathf)
                            chart_path = os.path.join(
                                folder_pathf, f"screener_output_Charts_{Base_name}.png")
                            # plt.savefig(chart_path)
                            # time.sleep(3)
                            # post_telegram_file(chart_path)
                            # os.remove(chart_path)
                            # if total_files == symNo:
                            plt.close(fig_combined)

                            # Add metadata
                            d = pdf.infodict()
                            d["Title"] = f"{Base_name} Technical Analysis Report"
                            d["Author"] = "Automated Report Generator"

                            print(
                                f"Generated report for {Base_name} at: {filepathpdf}")
                    except Exception as e:
                        print(
                            f"Error processing screener_output_Charts {Base_name}: {e!s}")
                        traceback_str = traceback.format_exc()
                        print(traceback_str)
                        plt.close("all")

        time.sleep(3)
        print(f"Send telegrame report: {filepathpdf}")
        if len(screener_BTouputtickers) != 0:
            post_telegram_file(filepathpdf)
            1 + 1
    except Exception as e:
        print(f"Error processing screener_output_Charts: {e!s}")
        traceback_str = traceback.format_exc()
        print(traceback_str)
        # plt.close('all')


# folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
folder_path = "/home/rizpython236/BT5/ticker_15yr/"
filepathpdf = "/home/rizpython236/BT5/screener-outputs/screener_output_Charts.pdf"
screenercsv_path = "/home/rizpython236/BT5/trade-logs/screener-output.csv"


filepathBTpdf = "/home/rizpython236/BT5/screener-outputs/BTbuy_Charts.pdf"
screenercsvBT_path = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"


# addchartspdf(screenercsv_path=screenercsv_path, folder_path=folder_path, filepathpdf=filepathpdf)
# addchartspdf(screenercsv_path=screenercsvBT_path, folder_path=folder_path, filepathpdf=filepathBTpdf)


# addchartspdf(screenercsv_path=screenercsv_path, folder_path=folder_path, filepathpdf=filepathpdf)
