import pandas as pd


def calculate_future_value(investment, cagr, years):
  """
  Calculates the future value of an investment based on initial investment, CAGR, and number of years.

  Args:
      investment (float): Initial investment amount.
      cagr (float): Compound annual growth rate (as a percentage).
      years (int): Number of years for investment.

  Returns:
      float: Future value of the investment.
  """
  return round(investment * (1 + cagr/100) ** years,0)

def process_csv_data(filename):
  """
  Reads data from a CSV file and calculates future values for each stock.

  Args:
      filename (str): Path to the CSV file.

  Returns:
      pandas.DataFrame: DataFrame containing stock information and future values for various years.
  """
  # Read data from CSV file
  data = pd.read_csv(filename)

  # Add a new column to store future values
  data["Future Value"] = None

  # Calculate future values for each year and stock
  years_list = [1, 3, 5, 10, 15, 20, 25]

  for year in years_list:
    data["Future Value Year " + str(year)] = data.apply(lambda row: calculate_future_value(row["investment amt"], row["CAGR"], year), axis=1)

  # Drop the original "Future Value" column (if it exists)
  data.drop("Future Value", axis=1, inplace=True)

  return data

# Specify the CSV file path
csv_file = "your_stock_data.csv"
output = "your_stock_data.csv"

# Process and display the data
processed_data = process_csv_data(csv_file)
print(processed_data.to_string())

processed_data.to_csv(output)

############################

gggggggggggggggggggg

def calculate_cagr(initial_value, final_value, years):
  """
  Calculates the Compound Annual Growth Rate (CAGR) for a given initial value, final value, and number of years.

  Args:
      initial_value (float): Initial value of the investment.
      final_value (float): Final value of the investment after 'years'.
      years (int): Number of years for which the CAGR is calculated.

  Returns:
      float: The calculated CAGR as a percentage.
  """
  if final_value == initial_value:
    return 0  # Handle case where initial and final values are the same
  return ((final_value / initial_value) ** (1 / years) - 1) * 100

def process_csv_data(filename):
  """
  Reads data from a CSV file, calculates sum of investment and future value, and returns CAGR.

  Args:
      filename (str): Path to the CSV file.

  Returns:
      float: The calculated CAGR for the sum of investment and future value after 1 year.
  """
  # Read data from CSV file
  data = pd.read_csv(filename)

  # Calculate sum of investment and future value after 1 year
  total_investment = data["Investment amt"].sum()
  total_future_value = data["future value"].sum()

  # Calculate CAGR
  cagr = calculate_cagr(total_investment, total_future_value, 1)

  return cagr

# Specify the CSV file path
csv_file = "your_stock_data.csv"

# Process and display the CAGR
cagr = process_csv_data(csv_file)
print(f"CAGR of the sum of investment and future value after 1 year: {cagr:.2f}%")


