import importlib


# Define the packages to check
packages = ["backtrader", "python-telegram-bot", "yfinance", "TA-Lib", "pandas-ta"]

# Check compatibility for Python 3.10
for package in packages:
    try:
        # Attempt to import the package
        importlib.import_module(package)
        print(f"{package}: Compatible with Python 3.10")
    except ModuleNotFoundError:
        print(f"{package}: Not found or may not be compatible with Python 3.10")
