import backtrader as bt


class SmaCross(bt.Strategy):
    params = dict(
        pfast=10,               # period for the fast moving average
        pslow=30,               # period for the slow moving average
        last_day_signals=False, # flag: only signals for last bar if True
        stake=1,                # number of shares/contracts to trade
    )

    def __init__(self):
        sma1 = bt.indicators.SMA(self.data.close, period=self.p.pfast)
        sma2 = bt.indicators.SMA(self.data.close, period=self.p.pslow)
        self.crossover = bt.indicators.CrossOver(sma1, sma2)  # crossover signal

    def next(self):
        # Mode 1: Generate signals only for the last bar
        if self.p.last_day_signals:
            if len(self.data) == len(self.data.data):  # last bar
                if self.crossover > 0:
                    print(f"{self.data.datetime.date(0)}: BUY Signal (SMA Cross Up)")
                elif self.crossover < 0:
                    print(f"{self.data.datetime.date(0)}: SELL Signal (SMA Cross Down)")
            return  # do not trade in this mode

        # Mode 2: Full backtest with trading logic
        if not self.position:  # not in the market
            if self.crossover > 0:
                self.buy(size=self.p.stake)
        elif self.crossover < 0:
            self.close()


def run_backtest(
    datafile,
    last_day_signals=False,
    initial_cash=100000.0,
    commission=0.001,       # e.g. 0.1%
    stake=100,              # default trade size
    slippage=0.0            # e.g. 0.001 = 0.1% slippage
):
    cerebro = bt.Cerebro()
    cerebro.addstrategy(SmaCross, last_day_signals=last_day_signals, stake=stake)

    # Load data (replace with your feed type if not CSV)
    data = bt.feeds.YahooFinanceCSVData(dataname=datafile)
    cerebro.adddata(data)

    if last_day_signals:
        # Just run for signals, no broker simulation
        cerebro.run()
    else:
        # Broker settings
        cerebro.broker.setcash(initial_cash)
        cerebro.broker.setcommission(commission=commission)

        if slippage > 0:
            cerebro.broker.set_slippage_perc(slippage)

        print(f"Starting Portfolio Value: {cerebro.broker.getvalue():.2f}")
        cerebro.run()
        print(f"Final Portfolio Value: {cerebro.broker.getvalue():.2f}")

        cerebro.plot()


if __name__ == '__main__':
    # Full backtest mode
    run_backtest(
        "your_data.csv",
        last_day_signals=False,
        initial_cash=200000.0,
        commission=0.0005,  # 0.05%
        stake=50,
        slippage=0.0002     # 0.02% slippage
    )

    # Signals-only mode
    # run_backtest("your_data.csv", last_day_signals=True)
