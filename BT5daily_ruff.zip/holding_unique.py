

import pandas as pd


# Clear the console
# os.system('cls' if os.name == 'nt' else 'clear')

csv_path = "/home/rizpython236/BT5/myholding.csv"
csv_path1 = "/home/rizpython236/BT5/trade-logs/new_tickers.csv"
csv_path2 = "/home/rizpython236/BT5/exclude_tickers.csv"
csv_path3 = "/home/rizpython236/BT5/myholding.csv"
csv_path4 = "/home/rizpython236/BT5/Final.csv"
csv_path5 = "/home/rizpython236/BT5/include_tickers.csv"


# Define the CSV file paths
csv_paths = [csv_path, csv_path1, csv_path2, csv_path3, csv_path4, csv_path5]

# Function to process each CSV file


def process_csv(csv_path):
    # Load the CSV file into a DataFrame
    df = pd.read_csv(csv_path)

    # Initialize dictionaries to hold duplicates and unique items for each column
    duplicates_dict = {}
    unique_dict = {}

    # Iterate over each column in the DataFrame
    for column in df.columns:
        # Identify duplicates in the current column
        duplicates = df[column][df[column].duplicated()].unique()

        # Store duplicates in the dictionary if any exist
        if len(duplicates) > 0:
            duplicates_dict[column] = duplicates.tolist()

        # Identify unique items in the current column
        unique_items = df[column].unique()

        # Store unique items in the dictionary
        unique_dict[column] = unique_items.tolist()

    # Create DataFrames from the duplicates and unique items dictionaries
    duplicates_df = pd.DataFrame.from_dict(
        duplicates_dict, orient="index").transpose()
    unique_df = pd.DataFrame.from_dict(unique_dict, orient="index").transpose()

    # Print the DataFrames of duplicates and unique items
    print(f"Duplicates for {csv_path}:")
    print(duplicates_df)
    print("\nUnique Items for {csv_path}:")
    # print(unique_df)
    print("\n" + "-" * 40 + "\n")
    # Save the DataFrame with unique entries to a new CSV file
    unique_df.to_csv(csv_path, index=False)


# Process each CSV file
for path in csv_paths:
    process_csv(path)
