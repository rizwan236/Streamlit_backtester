import os
import time

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from telegram_bot import post_telegram_file, post_telegram_message


print("drawdown")


# Specify the folder path containing CSV files
# Replace with the actual folder path
folder_path = "/home/rizpython236/BT5/ticker-csv-files/"
folder_path = "/home/rizpython236/BT5/ticker_15yr"
ticker_path = "/home/rizpython236/BT5/myholding.csv"
ticker_path = "/home/rizpython236/BT5/Finalnse.csv"
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df["Symbol"].tolist()[:]
symbols = list(dict.fromkeys(symbols))
selected_files = []

valid_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
valid_df = pd.read_csv(valid_file)
Symbol_to_YFindustry_mapping = dict(
    zip(valid_df["Symbol"], valid_df["YFindustry"]))

# Base_name=symbol_to_company.get(base_name, base_name)
# symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

change_df = pd.read_csv("/home/rizpython236/BT5/MYindustry.csv")
YFindustry_to_MYindustry_mapping = dict(
    zip(change_df["Industry"], change_df["MYindustry"]))


# Create an empty DataFrame for storing the latest close prices
latest_DD = pd.DataFrame(columns=["Symbol", "Latest_DDWN"])

# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    if file_name.endswith(".csv"):
        file_path = os.path.join(folder_path, file_name)
        # total_files += 1
        base_name = os.path.splitext(file_name)[0]
        # file_names.append(base_name)
        # print(base_name)
        if base_name in symbols:
            file_path = os.path.join(folder_path, file_name)
            selected_files.append(file_path)

            # Read the CSV file into a DataFrame
            df = pd.read_csv(file_path)

            # Get the latest close price
            latest_DDWN = round(df["DD_PCT"].iloc[-1], 1)  # DD_PCT

            if latest_DDWN <= 80:
                # Append the data to the DataFrame
                new_row = pd.DataFrame(
                    {"Symbol": [base_name], "Latest_DDWN": [latest_DDWN]})
                latest_DD = pd.concat([latest_DD, new_row], ignore_index=True)
                # latest_DD = latest_DD.append({'Symbol': base_name, 'Latest_DDWN': latest_DDWN}, ignore_index=True)
                # print(latest_DD)

                # Convert the 'Latest_DDWN' column to numeric
                #
                latest_DD["Latest_DDWN"].fillna(.1, inplace=True)
                latest_DD["Latest_DDWN"] = pd.to_numeric(
                    latest_DD["Latest_DDWN"], errors="coerce")
                # latest_DD['Latest_DDWN'].fillna(0.1, inplace=True)
                # latest_DD['Latest_DDWN'] = latest_DD['Latest_DDWN'].dropna()
                # latest_DD = latest_DD.sort_values(by='Latest_DDWN')
                # print(latest_DD)

                # Map 'Symbol' to 'YFindustry'
                latest_DD["YFindustry"] = latest_DD["Symbol"].map(
                    Symbol_to_YFindustry_mapping)

                # Map 'YFindustry' to 'MYindustry'
                latest_DD["MYindustry"] = latest_DD["YFindustry"].map(
                    YFindustry_to_MYindustry_mapping)

                # Append the count to 'MYindustry'
                latest_DD["Count"] = latest_DD.groupby(
                    "MYindustry").cumcount().add(1)

                # Modify 'MYindustry' to append the count
                # latest_DD['MYindustry'] = latest_DD['MYindustry'] + '-' + latest_DD['Count'].astype(str)
                latest_DD["Latest_DDWN"] = latest_DD["Latest_DDWN"].dropna()

                # Calculate the median 'Latest_DDWN' and count separately
                median_by_MYindustry = latest_DD.groupby(
                    "MYindustry")["Latest_DDWN"].median().reset_index()  # .sort_values()
                count_by_MYindustry = latest_DD.groupby("MYindustry")[
                    "Count"].max()
                min_max_df = latest_DD.groupby("MYindustry")["Latest_DDWN"].agg([
                    "min", "max"]).reset_index()
                # MaxDD_by_MYindustry  = latest_DD.groupby('MYindustry')['Latest_DDWN'].max().reset_index()
                # MinDD_by_MYindustry  = latest_DD.groupby('MYindustry')['Latest_DDWN'].min().reset_index()
                # Modify 'MYindustry' to append the count
                # latest_DD['MYindustry'] = latest_DD['MYindustry'] + '-' + latest_DD['Count'].astype(str)

                # print(median_by_MYindustry)
                # print(count_by_MYindustry)

                # Combine the results into a DataFrame
                # summary_df = pd.DataFrame({'Median_Latest_DDWN': median_by_MYindustry, 'Count': count_by_MYindustry})
                summary_df = pd.merge(
                    median_by_MYindustry, count_by_MYindustry, on="MYindustry")
                summary_df = pd.merge(summary_df, min_max_df, on="MYindustry")
                # summary_df = pd.merge(summary_df, MaxDD_by_MYindustry, on='MYindustry')  # Merge the result with the third DataFrame
                # summary_df = pd.merge(summary_df, MinDD_by_MYindustry, on='MYindustry')  # Merge the result with the fourth DataFrame
                # Append the count to 'MYindustry'
                summary_df["MYindustry"] = summary_df["MYindustry"] + \
                    "-" + summary_df["Count"].astype(str)

                # summary_df = summary_df[summary_df['Count'] >= 1]
                # Drop the 'Count' column if you no longer need it
                # summary_df = summary_df.drop('Count', axis=1)

                # Sort the DataFrame by the median values
                # summary_df = summary_df.sort_values(by='Count')

                # median_by_MYindustry = latest_DD.groupby('MYindustry')['Latest_DDWN'].median().sort_values()

                # print(latest_DD)
                invalid_rows = latest_DD[pd.to_numeric(
                    latest_DD["Latest_DDWN"], errors="coerce").isna()]

                # print(invalid_rows)
                # valid_values = latest_DD['Latest_DDWN'].dropna()
                # print(valid_values)

# print(summary_df)

summary_df["min"].fillna(.1, inplace=True)
summary_df["min"] = pd.to_numeric(summary_df["min"], errors="coerce")

summary_df["max"].fillna(.1, inplace=True)
summary_df["max"] = pd.to_numeric(summary_df["max"], errors="coerce")

summary_df["Latest_DDWN"].fillna(.1, inplace=True)
summary_df["Latest_DDWN"] = pd.to_numeric(
    summary_df["Latest_DDWN"], errors="coerce")

summary_df["Count"].fillna(.1, inplace=True)
summary_df["Count"] = pd.to_numeric(summary_df["Count"], errors="coerce")

latest_DD["Count"].fillna(.1, inplace=True)
latest_DD["Count"] = pd.to_numeric(latest_DD["Count"], errors="coerce")

latest_DD["Latest_DDWN"].fillna(.1, inplace=True)
latest_DD["Latest_DDWN"] = pd.to_numeric(
    latest_DD["Latest_DDWN"], errors="coerce")
latest_DD["Latest_DDWN"].fillna(.1, inplace=True)
latest_DD["Latest_DDWN"] = latest_DD["Latest_DDWN"].dropna()

latest_DD = latest_DD.sort_values(by="Latest_DDWN")
summary_df = summary_df[summary_df["Count"] >= 2]
summary_df = summary_df.sort_values(by="Count")
# latest_DD.to_csv('/home/rizpython236/BT5/delete.csv')
# print(median_by_MYindustry)
# print(count_by_MYindustry)
# print(latest_DD)
# print(latest_DD)
# print(invalid_rows)

# print(summary_df)
# print(latest_DD['Latest_DDWN'].dropna().unique())
print(latest_DD["Latest_DDWN"].isnull().sum())

# print(latest_DD)
industries_with_no_match = latest_DD[latest_DD["MYindustry"].isna()]
unique_values = industries_with_no_match["MYindustry"].unique().tolist()
post_telegram_message(unique_values)
print(unique_values)
"""
print(latest_DD[latest_DD['MYindustry'].isnull()])
print(latest_DD[latest_DD['Latest_DDWN'].isnull()])
print(latest_DD[latest_DD['YFindustry'].isnull()])
print(latest_DD[latest_DD['Count'].isnull()])
print(latest_DD.info())
"""

# bin_edges = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
# Calculate histogram values and bin edges
hist_values, bin_edges, _ = plt.hist(latest_DD["Latest_DDWN"].dropna(
), bins=range(0, 101, 10), density=True, edgecolor="black", alpha=0.7)

# Convert counts to percentages
percentage_values = hist_values / sum(hist_values)


"""
# Create bins for drawdown values
bins = range(0, 101, 10)
# Create a new column in the DataFrame to represent the bins
latest_DD['Drawdown_Bins'] = pd.cut(latest_DD['Latest_DDWN'], bins=bins, right=False)
# Calculate the percentage frequency
percentage_frequency = latest_DD['Drawdown_Bins'].value_counts(normalize=True) * 100
print(latest_DD)
plt.figure(figsize=(10, 6))
ax=sns.countplot(x='Drawdown_Bins',data=latest_DD, color='skyblue',)#
plt.xlabel('Drawdown % bins of 10')
plt.ylabel('Latest_DDWN %')
from matplotlib.ticker import PercentFormatter
ax.yaxis.set_major_formatter(PercentFormatter())
plt.grid(axis='y', linestyle='--', alpha=0.7)
#plt.gca().yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
plt.tight_layout()
chart_path = '/home/rizpython236/BT5/screener-outputs/Drawdown.png'
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)
"""
# Create histogram
plt.figure(figsize=(10, 6))  # Create a new figure
# sns.histplot(latest_DD['Latest_DDWN'].dropna(), bins=range(0, 101, 10), kde=False ,label='Drawdown bins of 10',density=True)
bar = plt.bar(bin_edges[:-1], percentage_values, width=10,
              edgecolor="black", alpha=0.7, label="Drawdown % bins of 10")
# plt.hist(latest_DD['Latest_DDWN'], bins=range(0, 101, 10), edgecolor='black', alpha=0.7)
# Add frequency labels on each bar
for bar, freq in zip(bar, percentage_values):
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width() / 2, height,
             f"{freq:.0%}", ha="center", va="bottom")
plt.title("Histogram of Drawdown for NSE500 & MICROCAP_250")
plt.xlabel("Latest_DDWN %")
plt.ylabel("Frequency %")
plt.xticks(range(0, 101, 10))  # Optional: Set custom x-axis ticks
# Show y-axis in percentage format


plt.gca().yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
plt.grid(axis="y", linestyle="--", alpha=0.7)
# Adjust margins for the first chart
plt.subplots_adjust(wspace=0.3, hspace=0.5)
plt.tight_layout()
chart_path = "/home/rizpython236/BT5/screener-outputs/Drawdown1yr.png"
plt.savefig(chart_path)
# plt.show()
time.sleep(2)
post_telegram_file(chart_path)
########################
"""
# Plot the histogram
plt.figure(figsize=(18, 8))  # Create a new figure
sns.barplot(x=summary_df['MYindustry'], y=summary_df['Latest_DDWN'], color='blue', edgecolor='black',label='Median Drawdown % by Industry',palette='Set3')
# Scatter plot for minimum and maximum
sns.scatterplot(x=summary_df['MYindustry'], y=summary_df['min'], color='White', marker='_',s=100,linewidth=3, label='Min Drawdown % by Industry')
sns.scatterplot(x=summary_df['MYindustry'], y=summary_df['max'], color='red', marker='_',s=100,linewidth=2, label='Max Drawdown % by Industry')
#sns.pointplot(x=summary_df['MYindustry'], y=summary_df['min'].min(), color='green', markers="_", scale=0.5, label='Min Drawdown % by Industry')
#sns.pointplot(x=summary_df['MYindustry'], y=summary_df['max'].max(), color='red', markers="_", scale=0.5, label='Max Drawdown % by Industry')
#plt.bar(summary_df['MYindustry'], summary_df['Latest_DDWN'], color='blue', edgecolor='black', alpha=0.7)
#plt.bar(median_by_MYindustry.index, median_by_MYindustry.values, color='blue', edgecolor='black', alpha=0.7)
plt.title('Median Drawdown by Industry for NSE500 & MICROCAP_250')
plt.xlabel('Industry with Count')
plt.ylabel('Median Latest_DDWN %')
plt.xticks(rotation=90, ha='right')  # Adjust rotation for better readability
# Adjust margins for the first chart
plt.subplots_adjust(wspace=0.1, hspace=0.1)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

# Show the plot or save it to a file
# plt.show()
chart_path = '/home/rizpython236/BT5/screener-outputs/IndustryDrawdown.png'
plt.savefig(chart_path)
time.sleep(2)
#post_telegram_file(chart_path)
"""
##############
# box plot
# print(latest_DD)

summary_df["Left_Part"] = summary_df["MYindustry"].str.rsplit("-", n=1).str[0]
summary_df = summary_df.rename(columns={"MYindustry": "MYindustrySummary"})
summary_df = summary_df.rename(columns={"Count": "CountSummary"})
# print(summary_df)
merged_df = pd.merge(latest_DD, summary_df[["Left_Part", "MYindustrySummary", "CountSummary"]],
                     left_on="MYindustry", right_on="Left_Part", how="left", suffixes=("_latest_DD", "_summary_df"))
merged_df = merged_df[merged_df["CountSummary"] >= 2.5]
merged_df = merged_df.sort_values(by="CountSummary")
# print(latest_DD)
# print(summary_df)
# print(merged_df)

# latest_DD = latest_DD[latest_DD['Count'] >= 2]
# latest_DD = latest_DD.sort_values(by='Count')
plt.figure(figsize=(18, 8))
# sns.set(style='darkgrid', palette='dark')
sns.boxplot(x=merged_df["MYindustrySummary"],
            y=merged_df["Latest_DDWN"], palette="Set3")
# sns.boxplot(x=latest_DD['MYindustry'], y=latest_DD['Latest_DDWN'],palette='Set3')#, data=latest_DD ,flierprops=dict(marker='o', markersize=8, markerfacecolor='red'
plt.title("Industry-wise Drawdown Summary for NSE500 & MICROCAP_250")
plt.xlabel("Industry with count")
plt.ylabel("Drawdown%")
plt.xticks(rotation=90, ha="right")
plt.subplots_adjust(wspace=0.1, hspace=0.1)
plt.grid(axis="y", linestyle="--", alpha=0.7)
plt.tight_layout()
# plt.show()
chart_path = "/home/rizpython236/BT5/screener-outputs/IndustryDrawdownBoxplot1yr.png"
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)

print("done")
