"""
portfolio_analysis_robust.py

Features:
- Reads transactions.csv and optional tickers.csv (cache)
- Fetches company metadata (name, sector, industry, latest price) from yfinance with caching & retries
- Processes transactions with FIFO lot accounting (accurate realized P/L)
- Handles splits (adjust lot sizes by ratio), dividends (cash inflow), buys, sells
- Produces per-symbol and portfolio IRR (xirr) - lifetime and current-holdings
- Exports CSV reports (full, realized, unrealized, sector_summary) and allocation pie charts
- Logs warnings and handles edge cases gracefully

Robust parsing & validation of input CSVs (required columns, date parsing, numeric coercion).
FIFO lot accounting for buys/sells (accurate realized P/L & remaining cost basis).
Accurate splits handling (adjusts existing lots by split ratio).
Dividends support (treats 'Dividend' txns as cash inflows).
Safe yfinance fetching with retries & caching (avoids repeated downloads).
Complete cashflow tracking per symbol for correct XIRR computation.
Portfolio-level IRRs: lifetime (all transactions) and current-holdings only.
Graceful handling of sells larger than holdings (logs warning, caps).
Clear logging & summaries, and final CSV + PNG outputs.
Defensive programming for missing/NaNs, divide-by-zero, and numpy_financial fallback.

Notes / Behavior & Edge-case decisions
FIFO realized P/L: sells consume oldest lots first. If a sell exceeds current holdings, the excess is ignored and a warning is emitted. (You can change behavior to allow short positions or to track negative lots; I chose to warn + ignore to keep accounting sane.)
Splits: ratio should be the multiplier (e.g., a 1:2 split → ratio = 2). All lots have units multiplied by ratio and cost per unit divided by ratio.
Dividends: Accepts either units × price (price as per-unit dividend) or price as total dividend if units = 0. Dividends count as realized cashflows and increase the realized P/L.
XIRR: Uses numpy_financial.xirr if available; otherwise uses a Newton-Raphson fallback. Requires at least 2 cashflows to compute.
Ticker caching: data/tickers.csv is updated/created. Set refresh_prices=True in build_ticker_master(...) if you want to force re-fetch prices.
Transaction CSV format: Required columns: date,type,symbol,units,price. Optional: ratio for splits. type should be one of buy,sell,split,dividend (case-insensitive).
Charting: Uses matplotlib; does not set explicit colors (per your earlier preference).

numpy_financial
fv(rate, nper, pmt, pv[, when])	Compute the future value.
pv(rate, nper, pmt[, fv, when])	Compute the present value.
npv(rate, values)	Returns the NPV (Net Present Value) of a cash flow series.
pmt(rate, nper, pv[, fv, when])	Compute the payment against loan principal plus interest.
ppmt(rate, per, nper, pv[, fv, when])	Compute the payment against loan principal.
ipmt(rate, per, nper, pv[, fv, when])	Compute the interest portion of a payment.
irr(values)	Return the Internal Rate of Return (IRR).
mirr(values, finance_rate, reinvest_rate)	Modified internal rate of return.
nper(rate, pmt, pv[, fv, when])	Compute the number of periodic payments.
rate(nper, pmt, pv, fv[, when, guess, tol, …])	Compute the rate of interest per period.
"""

import os
import pandas as pd
import numpy as np
import yfinance as yf
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import numpy_financial as npf
import warnings

warnings.filterwarnings("ignore")

# --------------------------------------
# 1️⃣  PATHS & DIRECTORIES
# --------------------------------------
BASE_DIR = "data"
OUTPUT_DIR = "output"
CHART_DIR = os.path.join(OUTPUT_DIR, "charts")

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(CHART_DIR, exist_ok=True)

TICKER_FILE = os.path.join(BASE_DIR, "tickers.csv")
TXN_FILE = os.path.join(BASE_DIR, "transactions.xlsx")  # <-- Excel file
TXN_SHEET = "Trans"

# --------------------------------------
# 2️⃣  HELPER FUNCTIONS
# --------------------------------------
def safe_xirr(values, dates):
    """Compute XIRR safely, return np.nan if not feasible."""
    if len(values) < 2 or all(v == 0 for v in values):
        return np.nan
    try:
        irr = npf.xirr(values, dates)
        if np.isfinite(irr):
            return irr * 100
        return np.nan
    except Exception:
        return np.nan


def safe_price(symbol):
    """Fetch latest price with fallback."""
    try:
        hist = yf.Ticker(symbol).history(period="1d")
        if not hist.empty:
            return hist["Close"].iloc[-1]
    except Exception:
        pass
    return np.nan


# --- 2️⃣ Fetch Metadata from Yahoo Finance ---
def fetch_yf_metadata(symbol):
    """Fetch company info from Yahoo Finance."""
    try:
        info = yf.Ticker(symbol).info
        return {
            "symbol": symbol,
            "company name": info.get("longName", symbol),
            "sector": info.get("sector", "Unknown"),
            "industry": info.get("industry", "Unknown"),
            "latest price": info.get("currentPrice", np.nan),
        }
    except Exception:
        return {
            "symbol": symbol,
            "company name": symbol,
            "sector": "Unknown",
            "industry": "Unknown",
            "latest price": np.nan,
        }


def pie_chart(data, group_col, value_col, title, file_name):
    """Generate and save pie chart safely."""
    try:
        plt.figure(figsize=(6, 6))
        grp = data.groupby(group_col)[value_col].sum().sort_values(ascending=False)
        grp = grp[grp > 0]
        plt.pie(grp, labels=grp.index, autopct="%1.1f%%", startangle=140)
        plt.title(title)
        plt.tight_layout()
        plt.savefig(os.path.join(CHART_DIR, file_name))
        plt.close()
    except Exception as e:
        print(f"⚠️ Chart error ({file_name}): {e}")

# --------------------------------------
# 3️⃣  LOAD TRANSACTIONS
# --------------------------------------
if not os.path.exists(TXN_FILE):
    raise FileNotFoundError(f"Transaction file not found: {TXN_FILE}")

try:
    txns = pd.read_excel(TXN_FILE, sheet_name=TXN_SHEET)
except Exception as e:
    raise RuntimeError(f"Failed to read sheet '{TXN_SHEET}' from {TXN_FILE}: {e}")

txns.columns = txns.columns.str.strip().str.lower()

required_cols = {"date", "type", "symbol", "units", "price"}
missing = required_cols - set(txns.columns)
if missing:
    raise ValueError(f"Missing columns in transaction file: {missing}")

if "ratio" not in txns.columns:
    txns["ratio"] = 1

txns["date"] = pd.to_datetime(txns["date"], errors="coerce")
txns = txns.dropna(subset=["date", "symbol"])
txns["symbol"] = txns["symbol"].astype(str).str.strip().str.upper()
txns["type"] = txns["type"].str.lower().str.strip()


# --- 1️⃣ Load Existing Tickers (if available) ---
if os.path.exists(TICKER_FILE):
    existing_tickers = pd.read_csv(TICKER_FILE)
    existing_tickers.columns = existing_tickers.columns.str.lower().str.strip()
else:
    existing_tickers = pd.DataFrame(columns=["symbol", "company name", "sector", "industry", "latest price"])

# --------------------------------------
# 4️⃣  BUILD TICKER MASTER FROM YFINANCE
# --------------------------------------
symbols = sorted(txns["symbol"].unique())
ticker_data = [fetch_yf_metadata(sym) for sym in symbols]
tickers_df = pd.DataFrame(ticker_data)

# --- 4️⃣ Backfill Missing Info from Existing Tickers ---
tickers_df = tickers_df.merge(
    existing_tickers[["symbol", "latest price"]],
    on="symbol",
    how="left",
    suffixes=("", "_old")
)

# Prefer Yahoo price if available; otherwise keep existing
tickers_df["latest price"] = tickers_df.apply(
    lambda r: r["latest price"]
    if not pd.isna(r["latest price"])
    else r["latest price_old"],
    axis=1,
)

tickers_df.drop(columns=["latest price_old"], inplace=True)


# Backfill missing latest prices
tickers_df["latest price"] = tickers_df.apply(
    lambda r: safe_price(r["symbol"]) if pd.isna(r["latest price"]) else r["latest price"], axis=1
)


# --- 6️⃣ Save Updated Tickers File ---
tickers_df.to_csv(TICKER_FILE, index=False)
print(f"✅ Updated ticker metadata saved to: {TICKER_FILE}")

# --------------------------------------
# 5️⃣  PROCESS TRANSACTIONS
# --------------------------------------
holdings = {}
cashflows = {}

for _, row in txns.iterrows():
    sym = row["symbol"]
    qty = row["units"]
    price = row["price"]
    txn_type = str(row["type"]).lower()
    ratio = row.get("ratio", 1)
    date = row["date"]

    if sym not in holdings:
        holdings[sym] = {"units": 0, "cost": 0.0, "realized_pnl": 0.0, "first_buy_date": None}
        cashflows[sym] = []

    h = holdings[sym]

    if txn_type == "buy":
        total_cost = h["units"] * h["cost"] + qty * price
        total_units = h["units"] + qty
        h["cost"] = total_cost / total_units if total_units > 0 else 0
        h["units"] = total_units
        if not h["first_buy_date"]:
            h["first_buy_date"] = date
        cashflows[sym].append({"date": date, "value": -qty * price})

    elif txn_type == "sell":
        sell_value = qty * price
        buy_cost = qty * h["cost"]
        h["realized_pnl"] += sell_value - buy_cost
        h["units"] = max(0, h["units"] - qty)
        cashflows[sym].append({"date": date, "value": sell_value})

    #elif txn_type == "split":
    #    try:
    #        ratio = float(ratio)
    #        if ratio > 0:
    #            h["units"] *= ratio
    #    except Exception:
    #        print(f"⚠️ Invalid split ratio for {sym} on {date}")


    elif txn_type == "split":
        ratio = float(ratio)
        if h["units"] > 0:
            h["units"] *= ratio
            h["cost"] /= ratio
        else:
            print(f"⚠️ Split ignored for {sym}: no holdings at time of split.")

# --------------------------------------
# 6️⃣  BUILD HOLDINGS DATAFRAME
# --------------------------------------
records = []
today = datetime.now()

for sym, h in holdings.items():
    tinfo = tickers_df[tickers_df["symbol"] == sym].iloc[0]
    mv = h["units"] * (tinfo["latest price"] or 0)
    total_cost = h["units"] * h["cost"]
    unrealized = mv - total_cost
    holding_period = (
        (today - pd.to_datetime(h["first_buy_date"])).days / 365
        if h["first_buy_date"] is not None
        else np.nan
    )

    # Add current value as inflow if holding exists
    if h["units"] > 0:
        cashflows[sym].append({"date": today, "value": mv})

    irr = safe_xirr([c["value"] for c in cashflows[sym]], [c["date"] for c in cashflows[sym]])

    records.append({
        "Symbol": sym,
        "Company": tinfo["company name"],
        "Sector": tinfo["sector"],
        "Industry": tinfo["industry"],
        "Units": round(h["units"], 2),
        "Avg Cost": round(h["cost"], 2),
        "Total Cost": round(total_cost, 2),
        "Latest Price": round(tinfo["latest price"], 2),
        "Market Value": round(mv, 2),
        "Unrealized P/L": round(unrealized, 2),
        "Realized P/L": round(h["realized_pnl"], 2),
        "Holding Period (Yrs)": round(holding_period, 2),
        "IRR %": round(irr, 2),
    })

pf_df = pd.DataFrame(records)

# --------------------------------------
# 7️⃣  PORTFOLIO IRRs (Lifetime & Current)
# --------------------------------------
def aggregate_cashflows(cf_dict, only_active=False):
    all_cf = []
    for sym, cfs in cf_dict.items():
        if only_active and holdings[sym]["units"] <= 0:
            continue
        all_cf.extend(cfs)
    if not all_cf:
        return np.nan
    df = pd.DataFrame(all_cf).groupby("date")["value"].sum().reset_index().sort_values("date")
    return safe_xirr(df["value"].tolist(), df["date"].tolist())

lifetime_irr = aggregate_cashflows(cashflows, only_active=False)
current_irr = aggregate_cashflows(cashflows, only_active=True)

# --------------------------------------
# 8️⃣  FINAL METRICS
# --------------------------------------
pf_df["Abs P/L"] = pf_df["Unrealized P/L"] + pf_df["Realized P/L"]
pf_df["% P/L"] = (pf_df["Abs P/L"] / pf_df["Total Cost"].replace(0, np.nan)) * 100

total_cost = pf_df["Total Cost"].sum()
total_mv = pf_df["Market Value"].sum()
pf_df["Alloc @ Cost %"] = (pf_df["Total Cost"] / total_cost) * 100
pf_df["Alloc @ MV %"] = (pf_df["Market Value"] / total_mv) * 100

# Append summary row
pf_df.loc[len(pf_df)] = {
    "Symbol": "TOTAL",
    "Company": "Portfolio Total",
    "Total Cost": total_cost,
    "Market Value": total_mv,
    "Abs P/L": pf_df["Abs P/L"].sum(),
    "% P/L": (pf_df["Abs P/L"].sum() / total_cost) * 100,
    "IRR %": np.nan,
}

# --------------------------------------
# 9️⃣  GROUP & SAVE
# --------------------------------------
realized_df = pf_df[pf_df["Realized P/L"] != 0].copy()
unrealized_df = pf_df[pf_df["Units"] > 0].copy().sort_values("Market Value", ascending=False)

sector_summary = (
    pf_df.groupby("Sector")[["Total Cost", "Market Value", "Abs P/L"]]
    .sum()
    .sort_values("Market Value", ascending=False)
)
sector_summary["% P/L"] = (sector_summary["Abs P/L"] / sector_summary["Total Cost"]) * 100

pf_df.to_csv(os.path.join(OUTPUT_DIR, "portfolio_full_report.csv"), index=False)
realized_df.to_csv(os.path.join(OUTPUT_DIR, "portfolio_realized.csv"), index=False)
unrealized_df.to_csv(os.path.join(OUTPUT_DIR, "portfolio_unrealized.csv"), index=False)
sector_summary.to_csv(os.path.join(OUTPUT_DIR, "sector_summary.csv"))

# --------------------------------------
# 🔟  CHARTS
# --------------------------------------
pie_chart(unrealized_df, "Sector", "Market Value", "Sector Allocation", "sector_allocation.png")
pie_chart(unrealized_df, "Industry", "Market Value", "Industry Allocation", "industry_allocation.png")
pie_chart(unrealized_df, "Company", "Market Value", "Company Allocation", "company_allocation.png")

# --------------------------------------
# ✅  SUMMARY
# --------------------------------------
print("\n✅ Portfolio Analysis Complete")
print(f"📈 Lifetime IRR: {lifetime_irr:.2f}%")
print(f"💼 Current Holdings IRR: {current_irr:.2f}%")
print(f"📁 Reports saved in: {OUTPUT_DIR}")
print(f"📊 Charts saved in: {CHART_DIR}")
