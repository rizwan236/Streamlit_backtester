
import numpy as np
import pandas as pd

from settings import (
    EXCLUDE_TICKERS_CSV,
    INCLUDE_TICKERS_CSV,
)


include_tickers = pd.read_csv(INCLUDE_TICKERS_CSV)
include_tickers = list(include_tickers["Symbol"].unique())
exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)
exclude_tickers = list(exclude_tickers["Symbol"].unique())

print("ISINbsense")


def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df


# Load BSE file
bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")  # bse.csv")
# https://www.bseindia.com/corporates/List_Scrips.html

# print(bse)


download_successful = False
"""
while MAX_RETRIES:
    try:
        time.sleep(1)
        print("Downloading NSE symbol list from NSE Website.")
        url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
        response = requests.get(url)
        datanse = pd.read_csv(url)
        #print(datanse)
        print("Found {} tickers in NSE symbol list".format(len(datanse)))
        download_successful = True
        MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(1)
        print("Download from NSE failed! Retrying...")
        #post_telegram_message("Download from NSE failed! Retrying...")
        print(exc)
        print("-" * 50)
        MAX_RETRIES -= 1

"""

if not download_successful:
    # post_telegram_message(message="Download data from NSE Failed")
    # sys.exit()
    datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")


# Rename Security Id column to SYMBOL
bse.drop(
    columns=[
        # "Group",
        "Face Value",
        # "ISIN No",
        "Industry",
        "Instrument",
        "Sector Name",
        "Industry New Name",
        "Igroup Name",
        "ISubgroup Name",
    ],
    inplace=True,
)


bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
bse.rename(columns={"Issuer Name": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Status"] == "Active"]
accepted_values = ["A ", "B ", "T ", "X ", "XT",
                   "R ", "M ", "MT", "XD", "Z", "P", "ZP", "IP"]
bse = bse[~bse["Security Name"].str.contains("ETF")]
bse = bse[~bse["Security Name"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["Security Name"].str.contains("FUND")]
bse = bse[~bse["Security Name"].str.contains("Fund")]
# bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
condition = bse["SYMBOL"].str.endswith("*")
bse.loc[condition, "SYMBOL"] = bse.loc[condition, "SYMBOL"].str[:-1]
# Filter dataframe

bse = bse[bse["Group"].isin(accepted_values)]
# print(bse)


"""
#url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
#response = requests.get(url)
#datanse = pd.read_csv(url)
"""

# lower_bound = datetime.datetime.today() - datetime.timedelta(days=370)
# print(lower_bound)
# upper_bound = datetime.datetime.today()
"""
datanse[" DATE OF LISTING"] = pd.to_datetime(
    datanse[" DATE OF LISTING"], format="%d-%b-%Y"
)
datanse1 = datanse[(datanse[" DATE OF LISTING"] <= lower_bound)]
"""

datanse.drop(
    columns=[
        " SERIES",
        " DATE OF LISTING",
        " PAID UP VALUE",
        " MARKET LOT",
        # " ISIN NUMBER",
        " FACE VALUE",
    ],
    inplace=True,
)

# bse=bse['Igroup Name'].fillna("Zero", inplace=True)
print(len(bse))
print(len(datanse))
print(len(datanse) + len(bse))

datansebse = pd.merge(datanse, bse, left_on=[
                      " ISIN NUMBER"], right_on=["ISIN No"], how="left")
common_symbols = bse[bse["ISIN No"].isin(
    datanse[" ISIN NUMBER"])]  # common isin
print(len(common_symbols))
# bse = bse[~bse["Face Value"].isin(common_symbols["Face Value"])]

"""
datansebse1 = pd.merge(datanse, bse, left_on=[' ISIN NUMBER'], right_on=['Face Value'], how='right')
print(datansebse1)
common_symbols1 = datanse[datanse[" ISIN NUMBER"].isin(bse)["Face Value"]]  #common isin
print(len(common_symbols1))
datanse1 = datanse[~datanse[" ISIN NUMBER"].isin(common_symbols1[" ISIN NUMBER"])]

print(datansebse1)
#datansebse.to_csv("/home/rizpython236/BT5/screener-outputs/xxFinal.csv", index=False)
"""
# fffffffffff

# print(datansebse)

# datansebse = pd.merge(datanse, bse, on=' ISIN NUMBER', how='left')
# print(datansebse)
# datanse.to_csv('/home/rizpython236/BT5/screener-outputs/datanse.csv', index=False)
# bse.to_csv('/home/rizpython236/BT5/screener-outputs/databse.csv', index=False)


# common_symbols = bse[bse["SYMBOL"].isin(datanse["SYMBOL"])]


# Deleting the rows with common symbols in the bse file
# bse = bse[~bse["SYMBOL"].isin(common_symbols["SYMBOL"])]

bse["BSE"] = bse.apply(lambda row: row["SYMBOL"]
                       if row["ISIN No"].startswith("IN") else None, axis=1)
datanse["NSE"] = datanse.apply(
    lambda row: row["SYMBOL"] if row[" ISIN NUMBER"].startswith("IN") else None, axis=1)
datanse["BSE"] = datanse.apply(
    lambda row: row["SYMBOL"] if row[" ISIN NUMBER"].startswith("IN") else None, axis=1)
# df['BSE'] = df.apply(lambda row: row['Symbol'] if row['Face Value'].startswith('IN') else None, axis=1)

add_suffix_to_column(bse, "SYMBOL", ".BO")
add_suffix_to_column(datanse, "SYMBOL", ".NS")

# Merging the two files
result = pd.concat([bse, datanse], axis=0, ignore_index=True)


# datanse = result[~result["Security Id"]astype(str).str.contains("ETF", na=False)]
result.rename(columns={"SYMBOL": "Symbol"}, inplace=True)
# result.insert(0, "^NSEI")
# result.insert(1, "^NSEBANK")
# result.insert(2, "^CRSLDX")
# result.insert(3, "^NSEMDCP50")
result.drop(
    columns=[
        "NAME OF COMPANY",
        # "Security Id",
        # "Security Name",
        "Status",
        # "Security Code",
        # " ISIN NUMBER",
        # " FACE VALUE",
    ],
    inplace=True,
)


# print(result)


result.rename(columns={"ISIN No": "ISIN NUMBER BSE"}, inplace=True)
result.rename(columns={" ISIN NUMBER": "ISIN NUMBER NSE"}, inplace=True)
result.rename(columns={"Security Name": "COMPANY"}, inplace=True)
result = result.fillna("")
result = result.astype(str)

# print(result)

desired_order = ["ISIN NUMBER BSE", "ISIN NUMBER NSE", "NSE",
                 "BSE", "Group", "Security Code", "Symbol", "COMPANY"]
# desired_order = ['ISIN NUMBER BSE','ISIN NUMBER NSE','NSE','BSE','Group','Security Code','Symbol','COMPANY']
result = result[desired_order]

valid_tickers = pd.read_csv(
    "/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv")
result = pd.merge(result, valid_tickers, left_on="Symbol",
                  right_on="Symbol", how="left")

desired_order = ["ISIN NUMBER BSE", "ISIN NUMBER NSE", "NSE", "BSE", "Group", "Security Code",
                 "Symbol", "COMPANY", "LongName", "Industry", "MarketCapCr", "Price", "Volume"]
# desired_order = ['ISIN NUMBER BSE','ISIN NUMBER NSE','NSE','BSE','Group','Security Code','Symbol','COMPANY']
result = result[desired_order]
result["MarketCapCr"] = result["MarketCapCr"].replace("Blank", np.nan)
# result= result.sort_values(by='MarketCapCr', ascending=False,na_position='last')

# result = result[result['ISIN NUMBER BSE'].notna()].sort_values(by='MarketCapCr')
# result = result[result['ISIN NUMBER NSE'].notna()].sort_values(by='MarketCapCr')


nse_result = result[result["Symbol"].str.endswith(".NS")].sort_values(
    by="MarketCapCr", ascending=False, na_position="last")
bse_result = result[result["Symbol"].str.endswith(".BO")].sort_values(
    by="MarketCapCr", ascending=False, na_position="last")
result = pd.concat([nse_result, bse_result])


# Get unique ISINs from both columns
unique_bse = result["ISIN NUMBER BSE"].dropna().unique()
unique_nse = result["ISIN NUMBER NSE"].dropna().unique()

# Combine and get unique ISINs
unique_isins = pd.Series(np.concatenate((unique_bse, unique_nse))).unique()

# Create a new DataFrame with only unique ISINs
# result = result[result['ISIN NUMBER BSE'].isin(unique_isins) | result['ISIN NUMBER NSE'].isin(unique_isins)]


print(result)

result.to_csv("/home/rizpython236/BT5/trade-logs/FinalISIN.csv", index=False)

"""

hhhhhhhhhhhhhhhhhhhhh

new_df = pd.DataFrame()
new_df['ISIN'] = ORGdataframe['ISIN NUMBER BSE'].fillna('') + ORGdataframe['ISIN NUMBER NSE'].fillna('')
new_df = new_df.drop_duplicates()

# Step 2: Add Symbol column based on ISIN
new_df['Symbol'] = new_df['ISIN'].apply(lambda x: x + '.NS' if x.endswith('IN') else x + '.BO')

# Step 3: Add NSE, BSE, NAME OF COMPANY columns based on ISIN using a VLOOKUP-like operation
def vlookup(isin, column_name):
    matching_row = ORGdataframe.loc[ORGdataframe['ISIN NUMBER BSE'] == isin, column_name].iloc[0]
    return matching_row

new_df['NSE'] = new_df['ISIN'].apply(lambda x: vlookup(x, 'NSE'))
new_df['BSE'] = new_df['ISIN'].apply(lambda x: vlookup(x, 'BSE'))
new_df['NAME OF COMPANY'] = new_df['ISIN'].apply(lambda x: vlookup(x, 'NAME OF COMPANY'))

# Display the final dataframe
print(new_df)

result.to_csv("/home/rizpython236/BT5/FinalISIN.csv", index=False)

hhhhhhhhhhhhhhhhhhhhhh

include_tickers_df = pd.DataFrame(include_tickers, columns=['Symbol'])
#result=result['Symbol']
#print(include_tickers_df)
#print(result)
#result = result.append(include_tickers_df['Symbol'], ignore_index=True)

###########
result = pd.concat([result, include_tickers_df], ignore_index=True)
#result=list(result["Symbol"].unique())
result=pd.DataFrame(result)
result = result.rename(columns={result.columns[0]: "Symbol"})
#result.to_csv("/home/rizpython236/BT5/screener-outputs/xxFinal.csv", index=False)
###########



common_symbols = include_tickers_df[~include_tickers_df["Symbol"].isin(result["Symbol"])] #common isin
common_symbols=common_symbols["Symbol"]
#print(common_symbols)
#print((len(common_symbols)))
#common_symbols.to_csv("common.csv", index=False)


result = pd.concat([result, include_tickers_df], ignore_index=True)
#result = result.append(include_tickers[['Symbol']], ignore_index=True)

result=list(result["Symbol"].unique())
result=pd.DataFrame(result)
result = result.rename(columns={result.columns[0]: "Symbol"})
result.to_csv("/home/rizpython236/BT5/Final.csv", index=False)

"""
