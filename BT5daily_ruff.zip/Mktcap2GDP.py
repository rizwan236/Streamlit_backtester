import csv
import datetime
import os
import time
import traceback

from lxml import html
from matplotlib.dates import DateFormatter, MonthLocator
import matplotlib.pyplot as plt
import pandas as pd
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# post_telegram_message("Scan started!")
from settings import SCREENER_OUTPUT_FOLDER_PATH
from telegram_bot import post_telegram_file, post_telegram_message


folder_path = SCREENER_OUTPUT_FOLDER_PATH


# __________________________________________chart


# Set up Chrome options
chrome_options = Options()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
# chrome_options.add_argument("--window-size=1920,1080")
chrome_options.add_argument("--disable-blink-features=AutomationControlled")
chrome_options.add_experimental_option(
    "excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option("useAutomationExtension", False)
chrome_options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")
chrome_options.add_experimental_option("prefs", {
    # "download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True,
})

# Initialize WebDriver
driver = webdriver.Chrome(options=chrome_options)


def download_chart(url, xpath, folder_path):
    """Downloads a chart by clicking the 'Save' button located by the given XPath.

    Args:
      url: The URL of the webpage containing the chart.
      xpath: The XPath expression to locate the 'Save' button.
      folder_path: The path to the folder where the downloaded chart should be saved.

    """
    try:
        # Set up the webdriver (replace with your preferred browser)
        driver = webdriver.Chrome(options=chrome_options)
        driver.get("https://www.gurufocus.com")
        # driver = webdriver.Chrome()  # Use webdriver.Firefox() for Firefox, etc.
        time.sleep(30)
        driver.get(url)
        # print(driver.page_source)

        # tenyear_button = WebDriverWait(driver, 10).until(
        #    EC.element_to_be_clickable((By.XPATH, '/html/body/div[2]/div[1]/div/div[2]/div[3]/div[4]/div/div[2]/div/svg/g[15]/text')))
        #
        # tenyear_button.click()

        # time.sleep(4)

        # Wait for the 'Save' button to be clickable
        save_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, xpath)),
        )

        # Click the 'Save' button
        save_button.click()

        time.sleep(5)
        post_telegram_file("/home/rizpython236/BT5/chart.png")

        print(
            f"Chart downloaded and telegramed initiated. Saved to: {folder_path}")

    except Exception as e:
        print(f"Error downloading chart: {e}")
        traceback_str = traceback.format_exc()
    finally:
        driver.quit()


# Example usage
# Replace with the actual URL
url = "https://www.gurufocus.com/global-market-valuation.php?country=IND"
xpath = "/html/body/div[2]/div[1]/div/div[2]/div[3]/div[4]/div/div[1]/a[1]"
# Replace with your desired folder path
folder_path = "/home/rizpython236/BT5/chart.png"

download_chart(url, xpath, folder_path)


# ________________________________________________________


headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"}


url = "https://www.gurufocus.com/global-market-valuation.php?country=IND"
value = None

try:
    # response = requests.get(url)
    response = requests.get(url, headers=headers)
    response.raise_for_status()
except requests.exceptions.HTTPError as errh:
    print(f"HTTP Error: {errh}")
except requests.exceptions.ConnectionError as errc:
    print(f"Connection Error: {errc}")
except requests.exceptions.Timeout as errt:
    print(f"Timeout Error: {errt}")
except requests.exceptions.RequestException as err:
    print(f"Something went wrong: {err}")


try:
    content = response.content
    tree = html.fromstring(content)
    font_element = tree.xpath('//*[@id="content1"]/div[3]/p[2]/font')[0]
    text = font_element.text.strip()
    text1 = tree.xpath('//*[@id="content1"]/div[3]/p[2]/b[1]/text()')[0]
    text2 = "  "
    value = text1
    concatenated_text = "".join([text, text2, text1])
    # print(concatenated_text)
    print(
        f"{concatenated_text}\n"
        "Ratio = Total Market Cap / GDP\tValuation\n"
        "Ratio ≤ 62%\tSignificantly Undervalued\n"
        "62% < Ratio ≤ 80%\tModestly Undervalued\n"
        "80% < Ratio ≤ 98%\tFair Valued\n"
        "98% < Ratio ≤ 115%\tModestly Overvalued\n"
        "Ratio > 115%\tSignificantly Overvalued",
    )
    post_telegram_message(
        f"{concatenated_text}\n"
        "https://www.gurufocus.com/global-market-valuation.php?country=IND\n"
        "Ratio = Total Market Cap / GDP\tValuation\n"
        "Ratio ≤ 62%\tSignificantly Undervalued\n"
        "62% < Ratio ≤ 80%\tModestly Undervalued\n"
        "80% < Ratio ≤ 98%\tFair Valued\n"
        "98% < Ratio ≤ 115%\tModestly Overvalued\n"
        "Ratio > 115%\tSignificantly Overvalued",
    )

except IndexError as err:
    print(f"Index Error: {err}")


# get the current date in yyyy-mm-dd format
date_today = datetime.datetime.today().strftime("%Y-%m-%d")

# set the value to 99
if value is None:
    value = 0
else:
    pass


# specify the folder path for the CSV file
folder_path = (r"/home/rizpython236/BT5/trade-logs/")

# specify the filename for the CSV file
filename = "GDP.csv"


# read the last row of the CSV file
with open(folder_path + filename, newline="") as csvfile:
    reader = csv.reader(csvfile)
    last_row = list(reader)[-1]

# get the date from the last row of the CSV file
date_last = last_row[0]

# compare the current date with the date from the last row
if date_today > date_last:
    # open the CSV file in append mode
    with open(folder_path + filename, "a", newline="") as csvfile:
        writer = csv.writer(csvfile)

        # write the new row to the CSV file
        # writer.writerow(["DATE", "Value"])
        writer.writerow([date_today, value])
        print("GDP file updated")
else:
    print("Today's date is not greater than the latest date in the CSV file.")


folder_path_csv = "/home/rizpython236/BT5/trade-logs"
file_path_csv = os.path.join(folder_path_csv, "GDP.csv")

df = pd.read_csv(file_path_csv).drop_duplicates()
df["DATE"] = pd.to_datetime(df["DATE"])
df["Value"] = df["Value"].str.replace("%", "").astype(float)
df = df.sort_values(by="DATE", ascending=True)


# print(df)

# Set the figure size and orientation
# A4 size landscape (width: 11.7 inches, height: 8.3 inches)
fig = plt.figure(figsize=(11.7, 8.3))

# Adjust the subplot parameters for narrower margins
fig.subplots_adjust(left=0.08, right=0.95, top=0.92, bottom=0.08)

# Create the plot
ax = fig.add_subplot(111)


# Create the plot
# fig, ax = plt.subplots()
ax.plot(df["DATE"], df["Value"])

# Set major lines
ax.yaxis.set_major_locator(plt.FixedLocator([62.0, 80.0, 98.0, 115.0]))

# Set y-axis ticks from 0 to 150
ax.set_yticks(range(50, 130, 10))

# Draw horizontal lines at 62.0, 80.0, 98.0, and 115.0
ax.axhline(y=62.0, color="green", linestyle="--")
ax.axhline(y=80.0, color="blue", linestyle="--")
ax.axhline(y=98.0, color="orange", linestyle="--")
ax.axhline(y=115.0, color="red", linestyle="--")


# Set axis label and title
ax.set_ylabel("GDP")
ax.set_xlabel("Date")
ax.set_title("GDP Index History")

months = MonthLocator()
# ax.xaxis.set_major_locator(months)
# ax.xaxis.set_major_formatter(DateFormatter('%b %Y'))

ax.xaxis.set_major_locator(MonthLocator(interval=3))  # Set ticks at each month
ax.xaxis.set_major_formatter(DateFormatter("%b %y"))

# Save the plot
file_path = os.path.join(folder_path)
chart_path = os.path.join(folder_path, "GDP_Index_History.png")
fig.savefig(chart_path)
post_telegram_file(chart_path)
if os.path.exists(chart_path):
    # Delete the file if it exists
    os.remove(chart_path)

# Show the plot (optional)
# plt.show()
print("completed GDP_Index_History")
