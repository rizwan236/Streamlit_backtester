
import datetime
import os
import sys
import time

import pandas as pd
import pytz

from add_company_name import (
    add_company_names_and_industry,
)
from symbol_copy import (
    update_exclude_list,
)
from telegram_bot import (
    post_telegram_message,
    shutdown_bot,
)


print("Starting the scheduler2 script...")
# pandas-1.3.5
# source /home/rizpython236/.virtualenvs/Pybroker39/bin/activate && python /home/rizpython236/BT5/scheduler2.py


# source virtualenvwrapper.sh && workon my-env && python /home/yourusername/something/script.py
# source /home/yourusername/my-env/bin/activate && python /home/yourusername/something/script.py

#   source virtualenvwrapper.sh && workon Pybroker39 && python /home/rizpython236/BT5/scheduler2.py
#   source virtualenvwrapper.sh && workon Pybroker39r && python /home/rizpython236/BT5/scheduler2.py
# source virtualenvwrapper.sh && workon Pybroker39 && python /home/rizpython236/BT5/trade_compiler.py


# import pkg_resources


# time.sleep(5)

# Define the path to the specific folder
# folder_path = "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/"
# folder_path = "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/pandas_ta/__init__.py"
# sys.path.append(folder_path)


# pybroker39_python = "/home/rizpython236/.virtualenvs/Pybroker39zz/bin/python3.9"
# sys.path.append(pybroker39_python)
# pybroker39_python = "/home/rizpython236/.virtualenvs/Pybroker39/bin/activate/python"

# Function to restart the script


def restart_script():
    print("Restarting the script...")
    try:
        python = sys.executable
        os.execl(python, python, *sys.argv)
        # os.execl(pybroker39_python, pybroker39_python, *sys.argv)
    except Exception as e:
        print(f"Failed to restart the script: {e}")
        sys.exit(1)


"""
# Function to restart the script
def restart_script():
    print("Restarting the script...")
    os.execv(sys.executable, ['python'] + sys.argv)
"""
"""
# Try importing pandas_ta and handle the DistributionNotFound error
try:
    folder_path = "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/"
    #folder_path = "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/pandas_ta/__init__.py"
    sys.path.append(folder_path)
    #import pandas_ta as ta
    # Verify that pandas_ta has been imported successfully
    #print(ta)
    #print("pandas_ta imported successfully.")
    #except pkg_resources.DistributionNotFound as e:
    #print(f"Error: {e}")
    #traceback.print_exc()
    #time.sleep(5)
    #restart_script()
    #sys.exit(1)  # Exit the script with a non-zero status indicating an error
except Exception as e:
    print("An unexpected error occurred:")
    traceback.print_exc()  # Print the full traceback
    #restart_script()
    sys.exit(1)
"""

"""
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

# Get current date and time in IST
ISTnow = datetime.datetime.now(IST_TIMEZONE)
weekday = ISTnow.strftime("%A")
print(weekday)

# Create time bounds -- program should run between RUN_LB and RUN_UB
RUN_LB = IST_TIMEZONE.localize(datetime.datetime.strptime('01:00', '%H:%M')).time()  # 1:30 AM IST
RUN_UB = IST_TIMEZONE.localize(datetime.datetime.strptime('01:30', '%H:%M')).time()  # 2:00 AM IST
#RUN_LB = datetime.time(hour=20-0, minute=30)     #1:30am ist  2:30amUTC is 8am IST
#RUN_UB = datetime.time(hour=21-0)     # 1am ist   2amUTC 7:30am IST

# Helper function to determine whether we should be currently running
def should_run():
    # Get the current time
    #ct = datetime.datetime.now().time()
    ct = datetime.datetime.now(IST_TIMEZONE).time()
    # Compare current time to run bounds
    lbok = RUN_LB <= ct
    ubok = RUN_UB >= ct
    # If the bounds wrap the 24-hour day, use a different check logic
    if RUN_LB > RUN_UB:
        return lbok or ubok
    else:
        return lbok and ubok


# Helper function to determine how far from now RUN_LB is
def get_wait_secs():
    # Get the current datetime
    #cd = datetime.datetime.now()
    cd = datetime.datetime.now(IST_TIMEZONE)
    # Create a datetime with *today's* RUN_LB
    #ld = datetime.datetime.combine(datetime.date.today(), RUN_LB)
    ld = datetime.datetime.combine(cd.date(), RUN_LB)
    # If the current time is after RUN_UB, move to next day
    if cd.time() > RUN_UB:
        ld += datetime.timedelta(days=1)
    # Create a timedelta for the time until *today's* RUN_LB
    ld = IST_TIMEZONE.localize(ld)
    td = ld - cd
    # Ignore td days (may be negative), return td.seconds (always positive)
    return (td.seconds+0)


while True:
    if should_run():
        print("Running the Trade Compiler")
        Start=datetime.datetime.now(IST_TIMEZONE)
        print(datetime.datetime.now(IST_TIMEZONE))
        #print(datetime.utcnow())
        print("-"*50)
        os.system("python /home/rizpython236/BT5/trade_compiler.py")
        End=datetime.datetime.now(IST_TIMEZONE)
        Gap=End-Start
        minutes = Gap.seconds / 60
        print(datetime.datetime.now(IST_TIMEZONE))
        print('Difference in minutes: ', minutes)
    else:
        wait_secs = get_wait_secs()
        wait_secs1111 = get_wait_secs()/(60*60)
        Start=datetime.datetime.now(IST_TIMEZONE)
        print(datetime.datetime.now(IST_TIMEZONE))
        print("Sleeping for %d Hr..." % wait_secs1111)
        time.sleep(wait_secs)


import time
import datetime
import pytz

        print("Running the Trade Compiler")
        start_time = datetime.datetime.now(IST_TIMEZONE)
        print(start_time)
        # Your trade compiler execution here
        os.system("python /home/rizpython236/BT5/trade_compiler.py")
        end_time = datetime.datetime.now(IST_TIMEZONE)
        gap = end_time - start_time
        minutes = gap.total_seconds() / 60
        print(end_time)
        print('Difference in minutes:', minutes)

"""
"""

IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

# Combine RUN_LB and RUN_UB into a single structure for easier comparison
run_window = (IST_TIMEZONE.localize(datetime.datetime.strptime("01:00", "%H:%M")).time(),
              IST_TIMEZONE.localize(datetime.datetime.strptime("01:30", "%H:%M")).time())


def should_run():
    now = datetime.datetime.now(IST_TIMEZONE).time()
    return (run_window[0] <= now <= run_window[1]) or (run_window[0] > run_window[1] and (now <= run_window[0] or now >= run_window[1]))


def get_wait_secs():
    now = datetime.datetime.now(IST_TIMEZONE)
    next_run = IST_TIMEZONE.localize(
        datetime.datetime.combine(now.date(), run_window[0]))

    if now.time() > run_window[1]:
        next_run += datetime.timedelta(days=1)

    wait_secs = (next_run - now).total_seconds()

    # Calculate hours and minutes (consider potential rounding errors)
    hours, remainder = divmod(wait_secs, 3600)
    minutes = int(remainder / 60)

    return hours, minutes


while True:
    if should_run():
        print("Running the Trade Compiler")
        start_time = datetime.datetime.now(IST_TIMEZONE)
        time.sleep(1)
        print(start_time)
        # Your trade compiler execution here
        os.system("python /home/rizpython236/BT5/trade_compiler.py")
        end_time = datetime.datetime.now(IST_TIMEZONE)
        gap = end_time - start_time
        minutes = gap.total_seconds() / 60
        print(end_time)
        print("Code running time in minutes:", minutes)
        # sys.exit(1)
        time.sleep(10*60)
    else:
        hours, minutes = get_wait_secs()
        print(datetime.datetime.now(IST_TIMEZONE))
        print(f"Sleeping for {hours} hours and {minutes} minutes...")
        time.sleep(1)
        # Call time.sleep() within the else block to use the calculated wait_secs
        # Convert to seconds for time.sleep()
        time.sleep(hours * 3600 + minutes * 60)

"""


IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

# Run window: Sunday between 1:00 PM and 1:30 PM IST
run_window = (
    datetime.time(hour=13, minute=0),   # 1:00 PM
    datetime.time(hour=13, minute=30),   # 1:30 PM
)


def should_run():
    """Return True only if today is Sunday and current time is within the run window."""
    now = datetime.datetime.now(IST_TIMEZONE)
    is_sunday = now.weekday() == 6  # Monday=0, Sunday=6
    return is_sunday and (run_window[0] <= now.time() <= run_window[1])


def get_wait_secs():
    """Calculate seconds to wait until next Sunday 1:00 PM IST."""
    now = datetime.datetime.now(IST_TIMEZONE)
    # Days until next Sunday (0 if today is Sunday)
    days_ahead = (6 - now.weekday()) % 7

    next_run_date = now.date() + datetime.timedelta(days=days_ahead)
    next_run = datetime.datetime.combine(next_run_date, run_window[0])
    next_run = IST_TIMEZONE.localize(next_run)

    # If already past this Sunday's window, move to next Sunday
    if now >= next_run:
        next_run += datetime.timedelta(days=7)

    wait_secs = (next_run - now).total_seconds()

    hours, remainder = divmod(wait_secs, 3600)
    minutes = int(remainder / 60)
    return wait_secs, int(hours), minutes


while True:
    if should_run():
        print("Running the Trade Compiler...")
        start_time = datetime.datetime.now(IST_TIMEZONE)
        print(f"Start time: {start_time}")
        post_telegram_message(f"Sunday 1pm Start time: {start_time}")

        file_path = "/home/rizpython236/BT5/trade-logs/exclude_tickersmanual.csv"

        # Read only the headers
        df = pd.read_csv(file_path)

        # Create an empty DataFrame with same columns
        empty_df = pd.DataFrame(columns=df.columns)

        # Overwrite the CSV keeping only headers
        empty_df.to_csv(file_path, index=False)

        print(
            f"Cleared all rows from {file_path}, kept only headers: {list(df.columns)}")

        # Run your script
        # os.system("python /home/rizpython236/BT5/trade_compiler.py")
        # Run your script
        os.system("python /home/rizpython236/BT5/BSENSEtickerdownloader.py")
        # Run your script
        os.system("python /home/rizpython236/BT5/symbol_copy.py")
        # Run your script
        # os.system("python /home/rizpython236/BT5/trade_compiler.py")
        # Run your script
        # os.system("python /home/rizpython236/BT5/trade_compiler.py")
        update_exclude_list(
            exclude_file="/home/rizpython236/BT5/exclude_tickers.csv")

        time.sleep(1*60)

        os.system("python /home/rizpython236/BT5/BSENSEtickerdownloader.py")
        os.system("python /home/rizpython236/BT5/symbol_copy.py")

        input_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
        output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
        # add_company_names_and_industry(input_file, output_file)

        input_file = "/home/rizpython236/BT5/Final.csv"
        output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
        add_company_names_and_industry(input_file, output_file)

        # Run your script
        # os.system("python /home/rizpython236/BT5/BTmombroker.py")

        end_time = datetime.datetime.now(IST_TIMEZONE)
        run_duration = (end_time - start_time).total_seconds() / 60
        print(f"End time: {end_time}")
        print(f"Code running time: {run_duration:.2f} minutes")
        post_telegram_message(
            f"Sunday 1pm End time: {end_time}, Code running time: {run_duration:.2f} minutes")
        time.sleep(.5*60)
        shutdown_bot()
        sys.exit(1)

        # Sleep 30 minutes before checking again (to avoid rerun in same window)
        time.sleep(30 * 60)
    else:
        wait_secs, hours, minutes = get_wait_secs()
        now = datetime.datetime.now(IST_TIMEZONE)
        print(
            f"[{now}] Not Sunday 1 PM yet. Sleeping for {hours} hours and {minutes} minutes...")
        time.sleep(wait_secs)
