#4a0810c1944b4a43a2538042e01f0b3a

import sys


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
from newsapi import NewsApiClient
import yfinance as yf


newsapi = NewsApiClient(api_key='4a0810c1944b4a43a2538042e01f0b3a')


# /v2/top-headlines
top_headlines = newsapi.get_top_headlines(q='bitcoin',
                                          sources='bbc-news,the-verge',
                                          category='business',
                                          language='en',
                                          country='us')

# /v2/everything
all_articles = newsapi.get_everything(q='bitcoin',
                                      sources='bbc-news,the-verge',
                                      domains='bbc.co.uk,techcrunch.com',
                                      from_param='2017-12-01',
                                      to='2017-12-12',
                                      language='en',
                                      sort_by='relevancy',
                                      page=2)

# /v2/top-headlines/sources
sources = newsapi.get_sources()
fffffffffff

import requests


def get_stock_news(api_key, symbol):
    #base_url = "https://newsapi.org/v2/everything"
    base_url = "https://newsapi.org/v2/top-headlines"
    params = {
        'q': f'{symbol} stock',
        'language': 'en',
        'country': 'in',  # India
        'apiKey': api_key
    }

    response = requests.get(base_url, params=params)
    news_data = response.json()

    if response.status_code == 200:
        articles = news_data.get('articles', [])
        return articles
    else:
        print(f"Error fetching news: {news_data.get('message', 'Unknown error')}")
        return []

if __name__ == "__main__":
    # Replace 'YOUR_API_KEY' with your actual News API key
    news_api_key = '4a0810c1944b4a43a2538042e01f0b3a'

    stock_symbol = "Tata Consultancy Services"  # Replace with the desired stock symbol

    stock_news = get_stock_news(news_api_key, stock_symbol)

    for article in stock_news:
        print(f"Title: {article['title']}")
        print(f"Description: {article['description']}")
        print(f"URL: {article['url']}")
        print("\n")
