import os
import sys
import time

import numpy as np
import pandas as pd
import pytz
from scipy import stats
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
import csv
from datetime import datetime, timedelta
import traceback

from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates

#import mplfinance as mpf
import matplotlib.pyplot as plt
import pandas_ta as ta

#import tulipy as ti
from PDFconvert import create_pdf, delete_file


pd.options.mode.chained_assignment = None  # Default is 'warn'



#import subprocess
# Upgrade pandas-market-calendars using pip
#subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pandas-market-calendars"])

import pandas_market_calendars as mcal


nse_calendar = mcal.get_calendar('NSE')



'''
input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf')
ggg

'''
Monday=True
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
yesterday = today - timedelta(days=1)
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)


# Fetch NSE holidays for the current year
schedule = nse_calendar.schedule(start_date=f'{yesterday.year}-01-01', end_date=f'{today.year}-12-31')
#holidays = schedule[~schedule['market_open'].notna()].index.date
market_days = schedule['market_open'].notna().index.date

#print(holidays)
print(yesterday)

# Check if today is an NSE holiday
if yesterday not in market_days:
    print("Today is an NSE holiday.")
else:
    print("Today is NOTTT an NSE holiday.")


current_datetimeUTC = datetime.now()
weekdayUTC = datetime.now().strftime("%A")

formatted_datetimeUTC = current_datetimeUTC.strftime("%d %b %Y %I:%M %p")
formatted_datetimeIST = ISTnow.strftime("%d %b %Y %I:%M %p")

day=today.weekday() == 1



print("Start wkly_candle")

def get_roc30_2yrH_index(df):
    """
    Function to find the first row index within the last 90 rows of the DataFrame where:
    - The 'Close' price equals the last value in the '2yrL' column.
    - The last value of 'obvmovavg' is less than the last value of 'OBV'.

    Parameters:
    df (pandas.DataFrame): The DataFrame containing 'Close', '2yrL', 'obvmovavg', and 'OBV' columns.

    Returns:
    int or str: The index (relative to the entire DataFrame) of the first row where the condition is met.
                Returns an empty string if no rows meet the condition or if the second condition is not met.
    """
    # Get the boolean mask where the condition is true within the last 90 rows
    mask = df["Close"].iloc[-7:] < df["2yrH"].iloc[-1]*1.0
    mask90 = df["Close"].iloc[-22:-6] == df["2yrH"].iloc[-1]

    # Find the row indices where the condition is true
    row_indices = mask[mask].index if mask.all() else []  # for mask90 (check if any True before indexing)
    row_indices90 = mask90[mask90].index if mask90.any() else []  # for mask90 (check if any True before indexing)

    # Check the second condition
    #if len(row_indices) > 0 and len(row_indices90) > 0:
    if len(row_indices) > 0 and len(row_indices90) > 0 and df["OBV"].loc[row_indices90[0]]*.95 > df["OBV"].iloc[-1] and mask90.any() and mask.all(): # if and df["OBV"].loc[row_indices90[0]] < df["OBV"].iloc[-1]  and mask.all():
        # Return the first row number relative to the entire DataFrame or an empty string
        #return df.index.get_loc(row_indices[0]) if not row_indices.empty else ""
        #return df.index.get_loc(row_indices90[0]) if not row_indices90.empty else ""  #df.index.get_loc(row_indices[-1])
        roc = int(((df["Close"].iloc[-1] - df["2yrH"].iloc[-1] ) / df["2yrH"].iloc[-1])*100)
        obv_condition_met = round( df["OBV"].iloc[-1]/df["OBV"].loc[row_indices90[0]],2)
        return roc,obv_condition_met
    else:
        return 0,0

def get_roc30_2yrL_index(df):
    """
    Function to find the first row index within the last 90 rows of the DataFrame where:
    - The 'Close' price equals the last value in the '2yrL' column.
    - The last value of 'obvmovavg' is less than the last value of 'OBV'.

    Parameters:
    df (pandas.DataFrame): The DataFrame containing 'Close', '2yrL', 'obvmovavg', and 'OBV' columns.

    Returns:
    int or str: The index (relative to the entire DataFrame) of the first row where the condition is met.
                Returns an empty string if no rows meet the condition or if the second condition is not met.
    """
    # Get the boolean mask where the condition is true within the last 90 rows
    mask = df["Close"].iloc[-7:] > df["2yrL"].iloc[-1]*1.0
    mask90 = df["Close"].iloc[-22:-6] == df["2yrL"].iloc[-1]

    # Find the row indices where the condition is true
    row_indices = mask[mask].index if mask.all() else []  # for mask90 (check if any True before indexing)
    row_indices90 = mask90[mask90].index if mask90.any() else []  # for mask90 (check if any True before indexing)

    # Check the second condition
    #if len(row_indices) > 0 and len(row_indices90) > 0:
    if len(row_indices) > 0 and len(row_indices90) > 0 and df["OBV"].loc[row_indices90[0]]*1.05 < df["OBV"].iloc[-1] and mask90.any() and mask.all(): # if and df["OBV"].loc[row_indices90[0]] < df["OBV"].iloc[-1]  and mask.all():
        # Return the first row number relative to the entire DataFrame or an empty string
        #return df.index.get_loc(row_indices[0]) if not row_indices.empty else ""
        #return df.index.get_loc(row_indices90[0]) if not row_indices90.empty else ""  #df.index.get_loc(row_indices[-1])
        roc = int(((df["Close"].iloc[-1] - df["2yrL"].iloc[-1] ) / df["2yrL"].iloc[-1])*100)
        obv_condition_met = round( df["OBV"].iloc[-1]/df["OBV"].loc[row_indices90[0]],2)
        return roc,obv_condition_met
    else:
        return 0,0


    # Check if mask90 is False and mask is True
    #if not mask90.any() and mask.any():
    #    if df["obvmovavg"].iloc[-20] < df["OBV"].iloc[-1]:
    #        return df.index.get_loc(mask.idxmax())  # Get the index of the first True value in mask
    #    else:
    #        return ""
    #else:
    #    return ""


def is_range_bound(dataR, window=100, slope_threshold=0.02):
  """
  Checks if a stock is range-bound based on price slope and historical volatility.

  Args:
    data: A pandas DataFrame containing OHLC (Open, High, Low, Close) data.
    window: Lookback window for slope calculation (default: 20 days).
    slope_threshold: Absolute value threshold for low slope (default: 0.02).

  Returns:
    True if the stock is considered range-bound, False otherwise.
  """

  # Calculate closing price slope
  data=dataR
  data["Slope"] = np.polyfit(range(window), data["Close"].iloc[-window:], 1)[0]

  # Calculate Average True Range (ATR)
  atr = data["High"].max(axis=0) - data["Low"].min(axis=0) - np.abs(
      data["Close"].shift(1) - data["Open"]
  )
  atr = atr.ewm(alpha=1 / window, min_periods=window).mean()

  #print((data["Slope"].iloc[-1]))
  # Check range-bound conditions
  return (data["Slope"].iloc[-1]) #<= slope_threshold #and np.mean(atr)*3 > 0.005

# Function to calculate adjusted R-squared
def adjusted_r_squared(y, x, slope, intercept,r_value):
    #y_pred = intercept + slope * x
    #ss_total = np.sum((y - np.mean(y)) ** 2)
    #ss_residual = np.sum((y - y_pred) ** 2)
    #r_squared = 1 - (ss_residual / ss_total)
    r_squared = r_value
    n = len(y)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    return adj_r_squared

def calculate_exponential_linear_regression(df,period=12):
    # Download historical data from yfinance
    data  = df.iloc[-(period+5):] # yf.download(stock_symbol, period="1y")
    data=df
    #print(data)

    # Calculate the natural logarithm of returns
    returns = np.log(data['Close'])
    #print(returns)
    x = np.arange(len(returns))
    #print(x)

    #slope, intercept, r_value, p_value, std_err = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x))
    #print(slope, intercept, r_value, p_value, std_err )
    slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
    #annualized_slope = (np.power(np.exp(slope), 252) - 1) * 100
    annualized_slope = (np.power((1+slope), 252)) *100
    r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
    r_squared = r_value
    n = len(x)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    annualized_slope_r_value = round(annualized_slope * (adj_r_squared ** 2), 2)

    #print(slope)
    #print(annualized_slope)

    # Calculate linear regression
    #slope, _, r_value, _, _ = stats.linregress(x, returns)

    # Calculate annualized slope
    #annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    # Calculate annualized_slope_r_value
    #annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Round the annualized slope and annualized_slope_r_value
    #rounded_annualized_slope = round(annualized_slope, 2)

    # Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    higher_value = annualized_slope_r_value #np.maximum(annualized_slope_r_value, rounded_annualized_slope)

    return higher_value


def calculate_mrp1(stock_csv_file):
    # Load stock and index data from CSV files using chunksize for large files
    chunksize = 10 ** 6 # Adjust based on available memory
    #stock_data = pd.concat(pd.read_csv(stock_csv_file, chunksize=chunksize))
    #index_data = pd.concat(pd.read_csv(index_csv_file, chunksize=chunksize))
    #print(stock_csv_file)

    index_csv_file = "/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv"
    stock_data = pd.read_csv(stock_csv_file)
    index_data = pd.read_csv(index_csv_file)
    stock_data = stock_data.iloc[-252:]
    index_data = index_data.iloc[-252:]

    MDD_df = stock_data.copy()

    stock_data1 = pd.DataFrame()
    index_data1 = pd.DataFrame()
    stock_data1['Close'] = stock_data['Close'].pct_change()
    index_data1['Close'] = index_data['Close'].pct_change()

    # Calculate cumulative returns
    stock_data['Stock_Cumulative_Return'] = round(100*(1 + stock_data1['Close']).cumprod(),5)
    index_data['Dow_Cumulative_Return'] = round(100*(1 + index_data1['Close']).cumprod(),5)

    # Adjust initial value calculation
    initial_value = 1
    stock_data1['Close'] = initial_value * stock_data['Stock_Cumulative_Return']
    index_data1['Close'] = initial_value * index_data['Dow_Cumulative_Return']

    # Calculate Relative Performance (RP)
    RP = stock_data1['Close'] / index_data1['Close']
    RP =round(RP,4)

    # Add MRP values to the stock data
    stock_data['MRP'] = RP.round(3) #round(RP, 3)

    # Assuming MDD_df1 is a DataFrame with relevant columns
    #stock_data = pd.concat([stock_data, MDD_df1], axis=1)
    # Save the updated stock data to a new CSV file
    print(stock_data['MRP'])

    return stock_data['MRP']

    #stock_data.to_csv(stock_csv_file, index=False)


def calculate_mrp(stock_csv_file):
    """
    Calculates the Market Relative Performance (MRP) for a given stock.

    Args:
        stock_csv_file (str): Path to the CSV file containing stock data.

    Returns:
        pandas.Series: Series containing the MRP values for the stock.
    """

    index_csv_file = "/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv"

    # Load stock and index data efficiently
    stock_data = pd.read_csv(stock_csv_file, usecols=['Close'])
    index_data = pd.read_csv(index_csv_file, usecols=['Close'])

    # Select the last 252 trading days
    #stock_data = stock_data.tail(270)
    #index_data = index_data.tail(270)

    # Calculate daily returns
    stock_returns = stock_data['Close'].pct_change()
    index_returns = index_data['Close'].pct_change()

    # Calculate cumulative returns
    #stock_cumulative_returns = (1 + stock_returns).cumprod()
    #index_cumulative_returns = (1 + index_returns).cumprod()

    # Calculate MRP
    #mrp = stock_cumulative_returns / index_cumulative_returns
    stock_cumreturns =(1+stock_returns).rolling(window=252).apply(np.prod)-1
    index_cumreturns=(1+index_returns).rolling(window=252).apply(np.prod)-1
    mrp=stock_data['MRPcsv15yrs']=((1+stock_cumreturns)/(1+index_cumreturns)).ffill()

    stock_data['MRPcsv15yrs'] = mrp.round(3)

    #print(stock_data['MRP'])
    return stock_data['MRPcsv15yrs']



#calculate_mrp("/home/rizpython236/BT5/ticker_15yr/SHAKTIPUMP.NS.csv")



TJI_IC_path = '/home/rizpython236/BT5/trade-logs/TJI_index.csv'
TJI_IC_path = pd.read_csv(TJI_IC_path)
TJI_IC_path = TJI_IC_path['Symbol'].tolist()[:]
TJI_IC_path = list(set(TJI_IC_path))



# Specify the folder path containing CSV files
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'  # Replace with the actual folder path
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
#ticker_path = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()[:]
symbols.extend(TJI_IC_path)
symbols = list(dict.fromkeys(symbols))  #list(set(symbols))
indices= ['^NSEI', 'BSE-500.BO', '^NSEMDCP50', 'NIFTYSMLCAP250.NS', 'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'BTC-USD', 'GOLDBEES.NS', '^NSEBANK', 'PSUBNKBEES.BO', '^CNXPSUBANK', 'NIFTYPVTBANK.NS', 'NIFTY_FIN_SERVICE.NS', '^CNXAUTO', '^CNXREALTY', '^CNXCMDT', '^CNXMETAL', '^CNXINFRA', 'ICICIINFRA.NS', 'PHARMABEES.NS', '^CNXPHARMA', '^CNXFMCG', '^CNXCONSUM', '^CNXIT', '^CNXENERGY', '^CRSLDX', 'MON100.NS', 'MAFANG.NS','HNGSNGBEES.NS', 'MAHKTECH.NS', 'SBIGETS.BO', 'AXISCETF.NS']

NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(NSE570_path)
NSE570symbols = NSE570ticker_df['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols))
#print(len(NSE570symbols))



symNo= len(symbols)



selected_files = []

valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))


# Initialize counters for MRP13 and MRP25
CountBExp = 0
mrp13_count_more0 = 0
mrp25_count_less0 = 0
mrp25_count_more0 = 0
mrp13_countbothless0 = 0
mrp25_countbothmore0 = 0
CountS_DCH = 0
total_files = 0
file_names = []
Bullish = []
Bearish = []
Start_countmore0 = 0
mrp25_count_mores10 = 0
mrp25_mores10 = []
mrp25_count_M1L1 =[]
mrp25_count_M1L2 =[]
CountS_TTMSqueeze =0
CountS_fall =0
S_TTMSqueeze=[]
S_fall=[]
S_DCH =[]
CountS_EMA=0
S_EMS=[]
BExpShort=[]
CountBExplong=0
BExplong=[]
CountB52high =0
B52High=[]
CountBRSI = 0
BRSI =[]
CountBMRP = 0
BMRP =[]
CountBBTTM =0
BBBTTM = []
CountFinalSell=0
FinalSell=[]
CountFinalBUY=0
FinalBUY=[]
S_ROC =[]
S_DD_PCT_30 =[]
B_DD_PCT_30 =[]
expLonly =[]
expSonly =[]
indiceNOLONG=[]
indiceNOSHORT=[]
EFIU=[]
EFID=[]
SMA_V7SMA_V40=[]
_52wkL= []
_52wkH= []
_52wkrange=[]
SMAUP=[]
SMADWN=[]
RSIUP=[]
RSIDWN=[]
DDPCTlist=[]
MRPUP=[]
MRPDWN =[]
Pos1yrHigh=[]
Pos1yrlow =[]
maxVx=[]
MRPcross=[]
SMAcross=[]
L2yr30_ROC=[]
HigerHigh=[]
MRHigerHigh=[]
results_listGreater=[]
results_listLower=[]
results_listget_roc30_2yrL_index=[]
results_listget_roc30_2yrH_index=[]
minervini=[]
TJI=[]
Candleslist =[]
minervinitickers=[]



def Candles(Candleslist =None,symbol_to_company=None,df=None,base_name=None,cal252_mrp=None,NSE570symbols=None):
    try:
        INDdf =df[:]
        df=df[-6:]
        #Bullish
        df['CDLMARUBOZU'] = tb.CDLMARUBOZU(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish-Marubozu"
        df['CDLCLOSINGMARUBOZU'] =tb.CDLCLOSINGMARUBOZU(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish-Closing Marubozu"
        df['CDLKICKINGBYLENGTH'] = tb.CDLKICKINGBYLENGTH(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish-Kicking longer Marubozu"
        df['CDLTASUKIGAP'] =tb.CDLTASUKIGAP(df['Open'], df['High'], df['Low'], df['Close'])  #"Bullish Cont-Tasuki Gap"
        df['CDLINNECK'] =tb.CDLINNECK(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Cont-In-Neck Pattern"
        df['CDLHAMMER'] =tb.CDLHAMMER(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Hammer"
        df['CDLENGULFING'] = tb.CDLENGULFING(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Engulfing Pattern"
        df['CDLDRAGONFLYDOJI'] = tb.CDLDRAGONFLYDOJI(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Dragonfly Doji"
        df['CDLINVERTEDHAMMER'] =tb.CDLINVERTEDHAMMER(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Inverted Hammer"
        df['CDLPIERCING'] =tb.CDLPIERCING(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Piercing Pattern"
        df['CDLMORNINGSTAR'] =tb.CDLMORNINGSTAR(df['Open'], df['High'], df['Low'], df['Close'], penetration=0) #"Bullish Reversal-Morning Star"
        df['CDLHARAMI'] = tb.CDLHARAMI(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Harami Pattern"
        df['CDLHARAMICROSS'] = tb.CDLHARAMICROSS(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Harami Cross Pattern"
        df['CDL3WHITESOLDIERS'] =tb.CDL3WHITESOLDIERS(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Three Advancing White Soldiers"
        df['CDLHANGINGMAN'] =tb.CDLHANGINGMAN(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal-Hanging Man"
        df['CDLSHOOTINGSTAR'] =tb.CDLSHOOTINGSTAR(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal-Shooting Star"
        df['CDLIDENTICAL3CROWS'] =tb.CDLIDENTICAL3CROWS(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal- Identical Three Crows"
        df['CDLGRAVESTONEDOJI'] =tb.CDLGRAVESTONEDOJI(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal-Gravestone Doji"
        df['CDLDARKCLOUDCOVER'] = tb.CDLDARKCLOUDCOVER(df['Open'], df['High'], df['Low'], df['Close'], penetration=0) #"Brearish Reversal-Dark Cloud Cover"
        df['CDLABANDONEDBABY'] =tb.CDLABANDONEDBABY(df['Open'], df['High'], df['Low'], df['Close'], penetration=0)  #"Brearish Reversal-Abandoned Baby"


        if df['CDLMARUBOZU'].iloc[-1] > 0:
            cand = "Bullish-Marubozu"
        elif df['CDLCLOSINGMARUBOZU'].iloc[-1] > 0:
            cand = "Bullish-Closing Marubozu"
        elif df['CDLKICKINGBYLENGTH'].iloc[-1] > 0:
            cand = "Bullish-Kicking longer Marubozu"
        #Bullish Contin..
        elif df['CDLTASUKIGAP'].iloc[-1] > 0:
            cand = "Bullish Cont-Tasuki Gap"
        elif df['CDLINNECK'].iloc[-1] > 0:
            cand = "Bullish Cont-In-Neck Pattern"
        #Bullish Reversal
        elif df['CDLHAMMER'].iloc[-1]  > 0:
            cand = "Bullish Reversal-Hammer"
        elif df['CDLENGULFING'].iloc[-1] > 0:
            cand = "Bullish Reversal-Engulfing Pattern"
        elif df['CDLDRAGONFLYDOJI'].iloc[-1] > 0:
            cand = "Bullish Reversal-Dragonfly Doji"
        elif df['CDLINVERTEDHAMMER'].iloc[-1] > 0:
            cand = "Bullish Reversal-Inverted Hammer"
        elif df['CDLPIERCING'].iloc[-1]  > 0:
            cand = "Bullish Reversal-Piercing Pattern"
        elif df['CDLMORNINGSTAR'].iloc[-1]  > 0:
            cand = "Bullish Reversal-Morning Star"
        elif df['CDLHARAMI'].iloc[-1] > 0:
            cand = "Bullish Reversal-Harami Pattern"
        elif df['CDLHARAMICROSS'].iloc[-1] > 0:
            cand = "Bullish Reversal-Harami Cross Pattern"
        elif df['CDL3WHITESOLDIERS'].iloc[-1]  > 0:
            cand = "Bullish Reversal-Three Advancing White Soldiers"

        #Brearish
        elif df['CDLMARUBOZU'].iloc[-1]  < 0:
            cand = "Brearish-Marubozu"
        #Bearish cont..
        elif df['CDLTASUKIGAP'].iloc[-1]  < 0:
            cand = "Brearish Cont-Tasuki"
        #bearish Reversal
        elif df['CDLHANGINGMAN'].iloc[-1] < 0:
            cand = "Brearish Reversal-Hanging Man"
        elif df['CDLSHOOTINGSTAR'].iloc[-1]  < 0:
            cand = "Brearish Reversal-Shooting Star"
        elif df['CDLIDENTICAL3CROWS'].iloc[-1] < 0:
            cand = "Brearish Reversal- Identical Three Crows"
        elif df['CDLGRAVESTONEDOJI'].iloc[-1]  < 0:
            cand = "Brearish Reversal-Gravestone Doji"
        elif df['CDLDARKCLOUDCOVER'].iloc[-1] < 0:
            cand = "Brearish Reversal-Dark Cloud Cover"
        elif df['CDLHARAMI'].iloc[-1]  < 0:
            cand = "Brearish Reversal-Harami"
        elif df['CDLHARAMICROSS'].iloc[-1] < 0:
            cand = "Brearish Reversal-Harami Cross Pattern"
        elif df['CDLENGULFING'].iloc[-1] < 0:
            cand = "Brearish Reversal-Engulfing Pattern"
        elif df['CDLABANDONEDBABY'].iloc[-1]  < 0:
            cand = "Brearish Reversal-Abandoned Baby"
        else:
            1+1
            #cand = ""

        df["SMA_V7"] = tb.SMA(INDdf['Volume'], timeperiod=7)
        df["SMA_V40"] = tb.SMA(INDdf['Volume'], timeperiod=20)
        #df["RSI"] = tb.RSI(data52['Close'], timeperiod=34)
        df["CCI"]=tb.CCI(INDdf['High'], INDdf['Low'], INDdf['Close'], timeperiod=34)
        supertrend_values= ta.supertrend(high=INDdf['High'], low=INDdf['Low'], close=INDdf['Close'], length=10, multiplier=4)#, offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
        df['ST'] = supertrend_values['SUPERT_10_4.0']
        df["52wkH"] = tb.MAX(INDdf['Close'], timeperiod=52)
        df["52wkL"] = tb.MIN(INDdf['Close'], timeperiod=52)

        df["SMA_50"] = tb.SMA(INDdf['Close'], timeperiod=10)
        df["SMA_200"] = tb.SMA(INDdf['Close'], timeperiod=40)
        df["SMA_100"] = tb.SMA(INDdf['Close'], timeperiod=20)
        df["SMA_150"] = tb.SMA(INDdf['Close'], timeperiod=30)
        df["EMA_100"] = tb.SMA(INDdf['Close'], timeperiod=20)
        df["EMA_200"] = tb.EMA(INDdf['Close'], timeperiod=40)
        df["SMA_200_15"] = tb.SMA(INDdf['SMA_200'], timeperiod=12)
        df["RSI14"] = tb.RSI(INDdf['Close'], timeperiod=14)
        df["RSI14avg"] = tb.EMA(INDdf["RSI14"], timeperiod=7)
        #print(df)


        Base_name=symbol_to_company.get(base_name, base_name)
        DD_PCT=int(df["DD_PCT"].iloc[-1])
        DD_PCT=f"{int(DD_PCT)}%"
        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-6],2)
        RSI = int(df["RSI"].iloc[-1])
        #ADX = int(df["ADX"].iloc[-1])
        CCI = int(df["CCI"].iloc[-1])
        #MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
        NSE570s = "Y" if base_name in NSE570symbols  else ""
        #ROC_14= int(df['ROC_30'].iloc[-1])
        #OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
        #OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2)
        #OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
        #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
        #ROC30_2yrL = get_roc30_2yrL_index(df)
        #LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
        #LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
        #MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
        #MRP= f"{round(df['MRP'].iloc[-1], 2)}"
        #MRP= cal252_mrp.iloc[-1]
        #MRPD ="UP" if (df["EMA_14cal252_mrp"].iloc[-1] < cal252_mrp.iloc[-1] and nifty_data['EMA_200'].iloc[-1] < nifty_data['EMA_50'].iloc[-1] < nifty_data["Close"].iloc[-1] and RSI > 40) else ""
        #MRP = MRP.iloc[-1] if MRP.iloc[-1] is not Nan else MRP.iloc[-2]
        #print(Base_name,cal252_mrp)
        #UD= "UP" if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else ""
        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
        CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,1)
        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""   # and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
        if len(df) > 0 and df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1] and df["SMA_200"].iloc[-1] > df["SMA_200_15"].iloc[-1] and df["Close"].iloc[-1] > df["52wkL"].iloc[-1]*1.25 and df["Close"].iloc[-1] > df["52wkH"].iloc[-1]*.75 and df["RSI14avg"].iloc[-5] < df["RSI14"].iloc[-1] > 60  :
            M = "Y"
        else:
            M =""
        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
        pos1yr= round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]),2)

        data = {
                "Company": Base_name,
                "Candle": cand,
                "MV" : M,
                "N570":NSE570s,
                #"ROC_30": ROC_14,
                #"MRP1yr": MRP,
                #"MRPS":MRPD,
                #"MRPL": UD,
                "RSI": RSI,
                "CCI": CCI,
                #"ADX": ADX,
                #"MACD":MACD,
                #"ROC_2": ROC_2,
                "ST":ST,
                #"EXP20":LNEXP20,
                #"EXP50":LNEXP50,
                "MA200UP":SMA200UP,
                #"OBVchg":OBVchg,
                "VX": VX,
                "CH52wk%":CH52wk,
                "Ps1yr":pos1yr,
                "DD%3yr": DD_PCT
                }
                # Append the dictionary to DDPCTlist
        #Candleslist.append(data)
        return data
    except Exception as e:
        1+1
        #print(f"Error processing Candle {Base_name}: {str(e)}")
        traceback_str = traceback.format_exc()


def rolling_two_largest(x):
  # Convert window to pandas Series (recommended from previous solution)
  window_series = pd.Series(x)
  # Sort the window in descending order
  sorted_window = window_series.sort_values(ascending=False)
  # Fill with NaNs and replace top 2 with actual values
  result = pd.Series(np.nan * len(x))
  result.iloc[0:2] = sorted_window.head(2)
  #print(result)
  return result


nifty_csv_file = "/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv"
nifty_data = pd.read_csv(nifty_csv_file)
#nifty_data = nifty_data.iloc[:]
nifty_data["EMA_200"] = tb.EMA(nifty_data['Close'], timeperiod=200)
nifty_data["EMA_50"] = tb.EMA(nifty_data['Close'], timeperiod=50)
#nifty_data["SMA_200"] = tb.SMA(nifty_data['Close'], timeperiod=200)


# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)


            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                #total_files += 1

                # Read the CSV file into a DataFrame
                df = pd.read_csv(file_path)
                dfexp=df
                dataR=df
                data52 =df[:]
                df["SMA_V40"] = tb.SMA(data52['Volume'], timeperiod=10)
                if df["SMA_V40"].iloc[-1]  <=500:
                    1+1
                    continue

                #print(df)

                #df['CCI'] = df.ta.cci(df['High'], df['Low'], df['Close'], window=34)
                #df['CCI'] = tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34)
                #df['CCIavg'] = tb.SMA(df['CCI'], timeperiod=12)
                #df['ADX'] = tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['macd'], df['macdsignal'], df['macdhist'] = tb.MACD(df['Close'], fastperiod=12, slowperiod=26, signalperiod=9)
                #df['ATR'] = tb.ATR(df['High'], df['Low'], df['Close'], timeperiod=10)
                #df['SuperTrend_Upper_Band'] = df['High'] + (3 * df['ATR'])
                #df['SuperTrend_Lower_Band'] = df['Low'] - (3 * df['ATR'])
                #df['SuperTrend'] = (df['SuperTrend_Upper_Band'] + df['SuperTrend_Lower_Band']) / 2
                #df['VolumeSMA'] = tb.SMA(df['Volume'], timeperiod=14)

                ###############################
                #cal252_mrp  =calculate_mrp(file_path)
                #df["EMA_14cal252_mrp"] = tb.EMA(cal252_mrp, timeperiod=22)
                #df["CCI"]=tb.CCI(data52['High'], data52['Low'], data52['Close'], timeperiod=120)
                #df["CCImovavgL"] = tb.EMA(df["CCI"], timeperiod=14)
                #df["CCImovavgS"] = tb.EMA(df["CCI"], timeperiod=7)
                #df["macd"], df["macdsignal"], df["macdhist"] = tb.MACDEXT(data52['Close'], fastperiod=12, fastmatype=0, slowperiod=26, slowmatype=0, signalperiod=9, signalmatype=0)
                #df["ADX"]= tb.ADX(data52['High'], data52['Low'], data52['Close'], timeperiod=34)
                #df["ADXavg"] = tb.EMA(df["ADX"], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df["RSI"] = tb.RSI(data52['Close'], timeperiod=34)
                #df["RSIavg"] = tb.EMA(df["RSI"], timeperiod=7)
                #df["RSI14"] = tb.RSI(data52['Close'], timeperiod=24)
                #df["RSI14avg"] = tb.EMA(df["RSI14"], timeperiod=7)
                #df["OBV"] = tb.OBV(data52['Close'], data52['Volume'])
                #df["obvmovavg"] = tb.EMA(df["OBV"], timeperiod=14)
                #df["MaxOBV30"] = tb.MAX(df['OBV'], timeperiod=22)
                #df["MinOBV30"] = tb.MIN(df['OBV'], timeperiod=22)

                #supertrend_values= ta.supertrend(high=df['High'], low=df['Low'], close=df['Close'], length=10, multiplier=4)#, offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
                #df['ST'] = supertrend_values['SUPERT_10_4.0']
                #df["SMA_20"] = tb.SMA(df['Close'], timeperiod=20)
                #df["SMA_50"] = tb.SMA(data52['Close'], timeperiod=50)
                #df["SMA_200"] = tb.SMA(data52['Close'], timeperiod=200)
                #df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                #df["SMA_150"] = tb.SMA(data52['Close'], timeperiod=150)
                #df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                #df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                #df["SMA_200_15"] = tb.SMA(df['SMA_200'], timeperiod=60)

                #df["EMA_30"] = tb.EMA(data52['Close'], timeperiod=30)
                #df["EMA_7W"] = tb.EMA(df['Close'], timeperiod=7)
                #df["EMA_5W"] = tb.EMA(df['Close'], timeperiod=5)
                #donchian_values=ta.donchian(df['High'], df['Low'], lower_length=20, upper_length=20, offset=None,)
                #df= pd.concat([df, donchian_values], axis=1)
                #df["DCH"]= ((df["DCU_20_20"] - df["DCL_20_20"]) / (df["DCU_20_20"] / 1)) * 100
                #df["DCHema"] = tb.SMA(df["DCH"], timeperiod=14)
                #df['Exp_lin_reg']= exp12 = calculate_exponential_linear_regression(data52,period=120)
                #df['Exp_lin_regslow']= exp50 = calculate_exponential_linear_regression(data52,period=180)
                #df["upperband"], df["middleband"], df["lowerband"] = tb.BBANDS(df['Close'], timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
                #squeeze_pro=ta.squeeze_pro(df['High'], df['Low'], df['Close'], bb_length=20, bb_std=2, kc_length=20, kc_scalar_wide=2, kc_scalar_normal=1.5, kc_scalar_narrow=1, mom_length=12, mom_smooth=6,)# use_tr=None, mamode=None,)
                ##print(squeeze_pro) # //WIDE SQUEEZE: ORANGE , NORMAL SQUEEZE: RED ,NARROW SQUEEZE: YELLOW ,FIRED WIDE SQUEEZE: GREEN ,NO SQUEEZE: BLUE
                #df= pd.concat([df, squeeze_pro], axis=1)
                #df['ROC_1']=tb.ROC(df['Close'], timeperiod=1)
                #df['ROC_2'] = tb.ROCP(data52['Close'], timeperiod=1)*100
                #df['ROC_30']=tb.ROCP(data52['Close'], timeperiod=22)*100
                #df['ROC_5']=tb.ROCP(data52['Close'], timeperiod=5)*100
                #df["ROC_2movavg"] = tb.SMA(df["ROC_2"], timeperiod=5)
                #df["ROC_22movavg"] = tb.SMA(df["ROC_2"], timeperiod=22)
                #df['ROC_4']=tb.ROC(df['Close'], timeperiod=4)
                #df['ROC_12']=tb.ROC(df['Close'], timeperiod=12)
                #df['ROC_24']=tb.ROC(df['Close'], timeperiod=24)
                #df['ROC_51']=tb.ROC(df['Close'], timeperiod=51)
                #df["SMA_V200"] = tb.EMA(df['Volume'], timeperiod=200)
                #df["SMA_V200"] = tb.MAX(df['Volume'], timeperiod=51)
                #df["SMA_V50"] = tb.SMA(df['Volume'], timeperiod=50)
                ###df["SMA_V40"] = tb.SMA(data52['Volume'], timeperiod=20)
                #df["SMA_V7"] = tb.SMA(data52['Volume'], timeperiod=7)
                #df["SMA_V4"] = tb.SMA(df['Volume'], timeperiod=4)

                #df["High_higher12"] = df['High'].iloc[-3:].shift(0) > df['High'].iloc[-3:].shift(1)
                #df["High_higher"] = df['Close'].iloc[-3:].shift(0) > df['Close'].iloc[-3:].shift(1) #close is highter than prev close
                #df["Low_higher"] = df['Low'].iloc[-3:].shift(0) > df['Low'].iloc[-3:].shift(1)   #low is highter than prev close


                #df["High_Lower"] = df['Close'].iloc[-3:].shift(0) < df['Close'].iloc[-3:].shift(1)    #high is lower than prev close
                #df["Low_lower"] = df['Low'].iloc[-3:].shift(0) < df['Low'].iloc[-3:].shift(1)   #low is lower than prev close
                #df["High_lower12"] = df['High'].iloc[-3:].shift(0) < df['High'].iloc[-3:].shift(1)



                #df["High_higher"] =df['Close'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] > max(x[:-1]),raw=True)
                #df["Low_higher"] =df['Low'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] > max(x[:-1]),raw=True)

                #df["High_Lower"] =df['High'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] < min(x[:-1]),raw=True)
                #df["Low_lower"] =df['Close'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] < min(x[:-1]),raw=True)

                try:
                    1+1
                    #df["SMA_91MRP"] =df["SMA_30MRP"] = tb.EMA(data52['MRP'], timeperiod=30) #------------------
                    #df["SMA_200MRP"] = df["SMA_90MRP"] = tb.EMA(data52['MRP'], timeperiod=200)
                    #df["EMA_14MRP"] = tb.EMA(data52['MRP'], timeperiod=14)  #-------------
                    #df["EMA_30MRP"] = tb.EMA(data52['MRP'], timeperiod=30)
                except Exception as e:
                    1+1
                #df["MaxcloseH"] = tb.MAX(df['Close'], timeperiod=252*2)
                #df["MaxcloseL"] = tb.MIN(df['Close'])# timeperiod=252)
                #df["52wkH"] = tb.MAX(data52['Close'], timeperiod=252)
                #df["52wkL"] = tb.MIN(data52['Close'], timeperiod=252)
                #df["2yrL"] = tb.MIN(data52['Close'], timeperiod=252+(252*0))
                #df["2yrH"] = tb.MAX(data52['Close'], timeperiod=252+(252*0))
                #df["MaxVx22"] = tb.MAX(df['Volume'], timeperiod=958) #252*3.5)
                #quantile= ta.quantile(close=df['Volume'], length=958, q=.7, offset=None)#,
                #df['quantile'] = quantile# ['QTL_958_0.75']
                #df["SMA_V3yr"] = tb.SMA(df['Volume'], timeperiod=958) #252*3.5)
                #MaxVx =round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-7]*.6),2)
                #MaxVxM =round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-10]),2)
                #pos1yr= round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]),2)
                #df["RangeBND"] = is_range_bound(dataR, window=200, slope_threshold=0.02)
                #print(df['Volume'].iloc[-1])
                #df["MaxVx"] = df['Volume'].rolling(window=25*3).apply(rolling_two_largest, raw=True).mean(axis=1)
                #try:
                #    df["MaxVx1"] = df['Volume'].rolling(window=252*3).max() #tb.MAX(df['Volume'], timeperiod=252*3)
                #    MaxVxmax = df["MaxVx1"].iloc[-7]*.70
                #    df["MaxVx"] = df['Volume'].rolling(window=(252*3)).apply(lambda x: x.nlargest(2).mean(), raw=True)
                #    MaxVx1 = round(df['Volume'].iloc[-1]/df["MaxVx"].iloc[-3],2)
                #    #print(df["MaxVx"].iloc[-1])
                #    print(df["MaxVx22"])
                #except Exception as e:
                #    MaxVx1 = 0
                #    #print(f"csvVXdaily error: {e}")
                #print(df['Volume'].iloc[-1])
                #print(df["MaxVx"]==df["MaxVx1"])

                DD_PCT=int(df["DD_PCT"].iloc[-1])
                DD15yr= f"{int(DD_PCT)}%"
                NSE570s = "Y" if base_name in NSE570symbols  else ""
                Base_name=symbol_to_company.get(base_name, base_name)
                #print(df)

                #Candles = Candles(Candleslist =Candleslist,symbol_to_company=symbol_to_company,df=df,base_name=base_name,cal252_mrp=None,NSE570symbols=NSE570symbols)
                #Candleslist.append(Candles)

                INDdf =df[:]
                df=df[-6:]
                #Bullish
                df['CDLMARUBOZU'] = tb.CDLMARUBOZU(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish-Marubozu"
                df['CDLCLOSINGMARUBOZU'] =tb.CDLCLOSINGMARUBOZU(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish-Closing Marubozu"
                df['CDLKICKINGBYLENGTH'] = tb.CDLKICKINGBYLENGTH(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish-Kicking longer Marubozu"
                df['CDLTASUKIGAP'] =tb.CDLTASUKIGAP(df['Open'], df['High'], df['Low'], df['Close'])  #"Bullish Cont-Tasuki Gap"
                df['CDLINNECK'] =tb.CDLINNECK(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Cont-In-Neck Pattern"
                df['CDLHAMMER'] =tb.CDLHAMMER(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Hammer"
                df['CDLENGULFING'] = tb.CDLENGULFING(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Engulfing Pattern"
                df['CDLDRAGONFLYDOJI'] = tb.CDLDRAGONFLYDOJI(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Dragonfly Doji"
                df['CDLINVERTEDHAMMER'] =tb.CDLINVERTEDHAMMER(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Inverted Hammer"
                df['CDLPIERCING'] =tb.CDLPIERCING(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Piercing Pattern"
                df['CDLMORNINGSTAR'] =tb.CDLMORNINGSTAR(df['Open'], df['High'], df['Low'], df['Close'], penetration=0) #"Bullish Reversal-Morning Star"
                df['CDLHARAMI'] = tb.CDLHARAMI(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Harami Pattern"
                df['CDLHARAMICROSS'] = tb.CDLHARAMICROSS(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Harami Cross Pattern"
                df['CDL3WHITESOLDIERS'] =tb.CDL3WHITESOLDIERS(df['Open'], df['High'], df['Low'], df['Close']) #"Bullish Reversal-Three Advancing White Soldiers"
                df['CDLHANGINGMAN'] =tb.CDLHANGINGMAN(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal-Hanging Man"
                df['CDLSHOOTINGSTAR'] =tb.CDLSHOOTINGSTAR(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal-Shooting Star"
                df['CDLIDENTICAL3CROWS'] =tb.CDLIDENTICAL3CROWS(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal- Identical Three Crows"
                df['CDLGRAVESTONEDOJI'] =tb.CDLGRAVESTONEDOJI(df['Open'], df['High'], df['Low'], df['Close']) #"Brearish Reversal-Gravestone Doji"
                df['CDLDARKCLOUDCOVER'] = tb.CDLDARKCLOUDCOVER(df['Open'], df['High'], df['Low'], df['Close'], penetration=0) #"Brearish Reversal-Dark Cloud Cover"
                df['CDLABANDONEDBABY'] =tb.CDLABANDONEDBABY(df['Open'], df['High'], df['Low'], df['Close'], penetration=0)  #"Brearish Reversal-Abandoned Baby"
                #print(df['CDLMARUBOZU'])

                cand = None
                if df['CDLMARUBOZU'].iloc[-1] > 0:
                    cand = "Bullish-Marubozu"
                elif df['CDLCLOSINGMARUBOZU'].iloc[-1] > 0:
                    cand = "Bullish-Closing Marubozu"
                elif df['CDLKICKINGBYLENGTH'].iloc[-1] > 0:
                    cand = "Bullish-Kicking longer Marubozu"
                #Bullish Contin..
                elif df['CDLTASUKIGAP'].iloc[-1] > 0:
                    cand = "Bullish Cont-Tasuki Gap"
                elif df['CDLINNECK'].iloc[-1] > 0:
                    cand = "Bullish Cont-In-Neck Pattern"
                #Bullish Reversal
                elif df['CDLHAMMER'].iloc[-1]  > 0:
                    cand = "Bullish Reversal-Hammer"
                elif df['CDLENGULFING'].iloc[-1] > 0:
                    cand = "Bullish Reversal-Engulfing Pattern"
                elif df['CDLDRAGONFLYDOJI'].iloc[-1] > 0:
                    cand = "Bullish Reversal-Dragonfly Doji"
                elif df['CDLINVERTEDHAMMER'].iloc[-1] > 0:
                    cand = "Bullish Reversal-Inverted Hammer"
                elif df['CDLPIERCING'].iloc[-1]  > 0:
                    cand = "Bullish Reversal-Piercing Pattern"
                elif df['CDLMORNINGSTAR'].iloc[-1]  > 0:
                    cand = "Bullish Reversal-Morning Star"
                elif df['CDLHARAMI'].iloc[-1] > 0:
                    cand = "Bullish Reversal-Harami Pattern"
                elif df['CDLHARAMICROSS'].iloc[-1] > 0:
                    cand = "Bullish Reversal-Harami Cross Pattern"
                elif df['CDL3WHITESOLDIERS'].iloc[-1]  > 0:
                    cand = "Bullish Reversal-Three Advancing White Soldiers"

                #Brearish
                elif df['CDLMARUBOZU'].iloc[-1]  < 0:
                    cand = "Brearish-Marubozu"
                #Bearish cont..
                elif df['CDLTASUKIGAP'].iloc[-1]  < 0:
                    cand = "Brearish Cont-Tasuki"
                #bearish Reversal
                elif df['CDLHANGINGMAN'].iloc[-1] < 0:
                    cand = "Brearish Reversal-Hanging Man"
                elif df['CDLSHOOTINGSTAR'].iloc[-1]  < 0:
                    cand = "Brearish Reversal-Shooting Star"
                elif df['CDLIDENTICAL3CROWS'].iloc[-1] < 0:
                    cand = "Brearish Reversal- Identical Three Crows"
                elif df['CDLGRAVESTONEDOJI'].iloc[-1]  < 0:
                    cand = "Brearish Reversal-Gravestone Doji"
                elif df['CDLDARKCLOUDCOVER'].iloc[-1] < 0:
                    cand = "Brearish Reversal-Dark Cloud Cover"
                elif df['CDLHARAMI'].iloc[-1]  < 0:
                    cand = "Brearish Reversal-Harami"
                elif df['CDLHARAMICROSS'].iloc[-1] < 0:
                    cand = "Brearish Reversal-Harami Cross Pattern"
                elif df['CDLENGULFING'].iloc[-1] < 0:
                    cand = "Brearish Reversal-Engulfing Pattern"
                elif df['CDLABANDONEDBABY'].iloc[-1]  < 0:
                    cand = "Brearish Reversal-Abandoned Baby"
                else:
                    #1+1
                    cand = None

                if cand ==None:
                    continue
                else:
                    print(f'Company: {Base_name}, {cand}')

                df["SMA_V7"] = tb.SMA(INDdf['Volume'], timeperiod=7)
                df["SMA_V40"] = tb.SMA(INDdf['Volume'], timeperiod=20)
                #df["RSI"] = tb.RSI(data52['Close'], timeperiod=34)
                df["CCI"]=tb.CCI(INDdf['High'], INDdf['Low'], INDdf['Close'], timeperiod=34)
                supertrend_values= ta.supertrend(high=INDdf['High'], low=INDdf['Low'], close=INDdf['Close'], length=10, multiplier=4)#, offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
                df['ST'] = supertrend_values['SUPERT_10_4.0']
                df["52wkH"] = tb.MAX(INDdf['Close'], timeperiod=52)
                df["52wkL"] = tb.MIN(INDdf['Close'], timeperiod=52)

                df["SMA_50"] = tb.SMA(INDdf['Close'], timeperiod=10)
                df["SMA_200"] = tb.SMA(INDdf['Close'], timeperiod=40)
                df["SMA_100"] = tb.SMA(INDdf['Close'], timeperiod=20)
                df["SMA_150"] = tb.SMA(INDdf['Close'], timeperiod=30)
                df["EMA_100"] = tb.SMA(INDdf['Close'], timeperiod=20)
                df["EMA_200"] = tb.EMA(INDdf['Close'], timeperiod=40)
                df["SMA_200_15"] = tb.SMA(df['SMA_200'], timeperiod=12)
                df["RSI14"] = tb.RSI(INDdf['Close'], timeperiod=14)
                df["RSI14avg"] = tb.EMA(df["RSI14"], timeperiod=7)
                #print(df)


                Base_name=symbol_to_company.get(base_name, base_name)
                DD_PCT=int(df["DD_PCT"].iloc[-1])
                DD_PCT=f"{int(DD_PCT)}%"
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-6],2)
                RSI = int(df["RSI14"].iloc[-1])
                #ADX = int(df["ADX"].iloc[-1])
                CCI = int(df["CCI"].iloc[-1])
                #MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                NSE570s = "Y" if base_name in NSE570symbols  else ""
                #ROC_14= int(df['ROC_30'].iloc[-1])
                #OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
                #OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2)
                #OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
                #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
                #ROC30_2yrL = get_roc30_2yrL_index(df)
                #LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                #LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                #MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                #MRP= f"{round(df['MRP'].iloc[-1], 2)}"
                #MRP= cal252_mrp.iloc[-1]
                #MRPD ="UP" if (df["EMA_14cal252_mrp"].iloc[-1] < cal252_mrp.iloc[-1] and nifty_data['EMA_200'].iloc[-1] < nifty_data['EMA_50'].iloc[-1] < nifty_data["Close"].iloc[-1] and RSI > 40) else ""
                #MRP = MRP.iloc[-1] if MRP.iloc[-1] is not Nan else MRP.iloc[-2]
                #print(Base_name,cal252_mrp)
                #UD= "UP" if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else ""
                ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,1)
                SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""   # and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                if len(df) > 0 and df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1] and df["SMA_200"].iloc[-1] > df["SMA_200_15"].iloc[-1] and df["Close"].iloc[-1] > df["52wkL"].iloc[-1]*1.25 and df["Close"].iloc[-1] > df["52wkH"].iloc[-1]*.75 and df["RSI14avg"].iloc[-5] < df["RSI14"].iloc[-1] > 60  :
                    M = "Y"
                else:
                    M =""
                #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                pos1yr= round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]),2)

                data = {
                        "Company": Base_name,
                        "Candle": cand,
                        "MV" : M,
                        "N570":NSE570s,
                        #"ROC_30": ROC_14,
                        #"MRP1yr": MRP,
                        #"MRPS":MRPD,
                        #"MRPL": UD,
                        "RSI": RSI,
                        "CCI": CCI,
                        #"ADX": ADX,
                        #"MACD":MACD,
                        #"ROC_2": ROC_2,
                        "ST":ST,
                        #"EXP20":LNEXP20,
                        #"EXP50":LNEXP50,
                        "MA200UP":SMA200UP,
                        #"OBVchg":OBVchg,
                        "VX": VX,
                        "CH52wk%":CH52wk,
                        "Ps1yr":pos1yr,
                        "DD%3yr": DD_PCT
                        }
                        # Append the dictionary to DDPCTlist
                Candleslist.append(data)


                ##########################
    except Exception as e:
        print(f"csvVXdaily {Base_name} error: {e}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass


#print(results_dfget_roc30_2yrL_index)
if len(Candleslist) > 0:
    Candleslist = pd.DataFrame(Candleslist)
    Candleslist = Candleslist.sort_values(by="Candle", ascending=False)
    #Candleslist = Candleslist.dropna(subset=['Candle '])
    Candleslist.fillna("", inplace=True)
    Candleslist.to_csv('/home/rizpython236/BT5/screener-outputs/wklyCandleslist.csv', index=False)
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/wklyCandleslist.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/wklyCandleslist.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
    time.sleep(5)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/wklyCandleslist.pdf')


print("wkly_candle done")



























