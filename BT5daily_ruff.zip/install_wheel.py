from glob import glob
import os
import subprocess
import sys


def install_wheel_from_folder(folder_path, wheel_name=None, upgrade=False):
    """
    Install a wheel file from a specific folder.
    
    Args:
        folder_path (str): Path to the folder containing the wheel file
        wheel_name (str, optional): Specific wheel filename to install. 
                                    If None, installs the first wheel found.
        upgrade (bool): Whether to use the --upgrade flag with pip
    """
    # Check if folder exists
    if not os.path.isdir(folder_path):
        print(f"Error: Folder '{folder_path}' does not exist.")
        return False
    
    # Find wheel files in the folder
    wheel_files = glob(os.path.join(folder_path, "*.whl"))
    
    if not wheel_files:
        print(f"No wheel files found in '{folder_path}'")
        return False
    
    # Select wheel file
    if wheel_name:
        wheel_path = os.path.join(folder_path, wheel_name)
        if not os.path.isfile(wheel_path):
            print(f"Error: Wheel file '{wheel_name}' not found in '{folder_path}'")
            return False
    else:
        wheel_path = wheel_files[0]
        if len(wheel_files) > 1:
            print(f"Multiple wheel files found. Installing the first one: '{os.path.basename(wheel_path)}'")
    
    # Prepare pip command
    pip_cmd = [sys.executable, "-m", "pip", "install"]
    
    if upgrade:
        pip_cmd.append("--upgrade")
    
    pip_cmd.append(wheel_path)
    
    # Run pip install
    print(f"Installing wheel file: '{wheel_path}'")
    try:
        subprocess.check_call(pip_cmd)
        print("Installation completed successfully.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Installation failed with error: {e}")
        return False

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Install a wheel file from a specific folder")
    parser.add_argument("folder", help="Path to the folder containing the wheel file")
    parser.add_argument("--wheel", help="Specific wheel filename to install")
    parser.add_argument("--upgrade", action="store_true", help="Upgrade the package if already installed")
    
    parser = argparse.ArgumentParser(description="Install a wheel file from a specific folder")
    parser.add_argument("folder", help="/home/rizpython236/BT5/")
    parser.add_argument("--wheel", help="Specific wheel filename to install")
    parser.add_argument("--upgrade", action="store_true", help="Upgrade the package if already installed")    
    
    
    args = parser.parse_args()
    
    install_wheel_from_folder(args.folder, args.wheel, args.upgrade)