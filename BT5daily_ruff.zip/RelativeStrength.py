
import backtrader as bt
import talib as ta


class NiftyBankNiftyRelativePerformance(bt.Indicator):
    lines = ('relative_performance', 'moving_avg', 'rsi')
    params = (
        ('lookback', 55),
        ('interval', 10),
        ('nifty', None),
        ('banknifty', None),
    )

    def __init__(self):
        self.addminperiod(self.params.lookback)
        self.addminperiod(self.params.interval)

    def next(self):
        nifty = self.p.nifty.close[0]
        banknifty = self.p.banknifty.close[0]

        nifty_return = (nifty - self.p.nifty.close[-1]) / self.p.nifty.close[-1] * 100
        banknifty_return = (banknifty - self.p.banknifty.close[-1]) / self.p.banknifty.close[-1] * 100

        nifty_avg_return = ta.SMA(nifty_return, self.params.lookback)
        banknifty_avg_return = ta.SMA(banknifty_return, self.params.lookback)

        relative_performance = (self.data[0] - ta.SMA(self.data[0], self.params.lookback)) / ta.SMA(self.data[0], self.params.lookback) * 100 - (nifty_avg_return + banknifty_avg_return) / 2

        self.lines.relative_performance[0] = relative_performance
        self.lines.moving_avg[0] = ta.SMA(relative_performance, self.params.interval)
        self.lines.rsi[0] = ta.RSI(self.data.close, timeperiod=14)