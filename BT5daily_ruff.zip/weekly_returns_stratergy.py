import sys


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
from datetime import datetime

import matplotlib.pyplot as plt
import numpy as np
from numpy_financial import npv
import pandas as pd
from scipy.optimize import newton
import yfinance as yf


def calculate_drawdown(data):
    max_value = data['Close'].cummax()
    drawdown = (data['Close'] - max_value) / max_value
    return round(drawdown*100,2)

def calculate_cagr(initial_value, final_value, years):
    cagr = ((final_value / initial_value) ** (1 / years)) - 1
    return cagr

def calculate_xirr(df):
    cashflows = df['Cashflows'].tolist()
    dates = [datetime.strptime(date, '%Y-%m-%d') for date in df['Date']]

    # Define the XIRR calculation function
    def xirr_function(rate):
        result = 0.0
        for i in range(len(cashflows)):
            result += cashflows[i] / ((1 + rate) ** ((dates[i] - dates[0]).days / 365.0))
        return result

    # Initial guess for XIRR
    guess = 0.1

    # Calculate XIRR using Newton's method
    xirr = newton(xirr_function, guess)

    return xirr

# Download S&P 500 data from Yahoo Finance
spx = yf.Ticker('^NSEI')
spx_data = spx.history(period='15y', interval='1mo')#1wk 1mo


# Calculate drawdown
spx_data['Drawdown'] = calculate_drawdown(spx_data)

# Define the drawdown threshold
drawdown_threshold = -15


drawdown_low = spx_data[spx_data['Drawdown'] < 0]
print(drawdown_low)

# Calculate quartiles, mean, median, max
quartiles = drawdown_low['Drawdown'].quantile([0.25, 0.5, 0.75])
mean = drawdown_low['Drawdown'].mean()
Minimum = drawdown_low['Drawdown'].min()

print("Drawdown 1st Quartile:", quartiles[0.25])
print("Drawdown 2nd Quartile (Median):", quartiles[0.5])
print("Drawdown 3rd Quartile:", quartiles[0.75])
print("Drawdown Mean:", mean)
print("Drawdown 4th Quartile:", quartiles[0.75])  # Same as 3rd quartile in this case since all values are below 0%
print("Drawdown Minimum:", Minimum)




# Calculate weekly returns
spx_data['Weekly_Return'] = round(spx_data['Close'].pct_change() * 100,2)

negative_returns = spx_data[spx_data['Weekly_Return'] < 0]

# Calculate quartiles, mean, median, max
quartiles = negative_returns['Weekly_Return'].quantile([0.25, 0.5, 0.75])
mean = negative_returns['Weekly_Return'].mean()
Minimum = negative_returns['Weekly_Return'].min()

print("Negative_returns 1st Quartile:", quartiles[0.25])
print("Negative_returns 2nd Quartile (Median):", quartiles[0.5])
print("Negative_returns 3rd Quartile:", quartiles[0.75])
print("Negative_returns Mean:", mean)
print("Negative_returns 4th Quartile:", quartiles[0.75])  # Same as 3rd quartile in this case since all values are below 0%
print("Negative_returns Minimum:", Minimum)

initial_value = spx_data['Close'].iloc[0]
final_value = spx_data['Close'].iloc[-1]
years = len(spx_data) / 12  # 12 Assuming monthly data , 12 monthly

cagr = calculate_cagr(initial_value, final_value, years)
#print(f'CAGR: {cagr * 100:.2f}%')


# Initialize variables
investment = 50000
investment_log = []
portfolio_value = []
initial_units = 0
cumulative_value = 0
MKTcumulative_value=0
portfolio_value1=0

cashflows_df = pd.DataFrame(columns=['Date', 'Cashflows'])

for index, row in spx_data.iterrows():
     if 1==1: #if row['Weekly_Return'] < -5:
        units_purchased = investment / row['Close']
        value_of_units_purchased = units_purchased * row['Close']
        portfolio_value1 = initial_units* row['Close']
        if row['Drawdown'] < drawdown_threshold: # if row['Drawdown'] < drawdown_threshold:   row['Weekly_Return'] < -6:
            cumulative_value += value_of_units_purchased
            initial_units += units_purchased
            portfolio_value1 = initial_units* row['Close']
            investment_log.append({'Date': index.strftime('%Y-%m-%d'),'Total_units':initial_units, 'Units_Purchased': units_purchased, 'Value_of_Units_Purchased': value_of_units_purchased, 'Cumulative_Value': cumulative_value, 'MktCumulative_Value': round(portfolio_value1,0),'INDICE': round(row['Close'],2)  })
            cashflows_df = cashflows_df.append({'Date': index.strftime('%Y-%m-%d'), 'Cashflows': -value_of_units_purchased}, ignore_index=True)
        else:
            cumulative_value = cumulative_value
            investment_log.append({'Date': index.strftime('%Y-%m-%d'),'Total_units':initial_units, 'Units_Purchased': 0, 'Value_of_Units_Purchased': 0, 'Cumulative_Value': cumulative_value, 'MktCumulative_Value': round(portfolio_value1,0),'INDICE': round(row['Close'],2)  })

portfolio_value1=initial_units * spx_data['Close'][-1]
#portfolio_value.append(initial_units * row['Close'])

current_date = datetime.now().strftime('%Y-%m-%d')
cashflows_df = cashflows_df.append({'Date': current_date, 'Cashflows': portfolio_value1}, ignore_index=True)


#print(investment_log)
print(cashflows_df)
print(portfolio_value)



xirr = calculate_xirr(cashflows_df)

print(f'CAGR: {cagr * 100:.2f}%')
print(f'XIRR: {xirr:.2%}')



#investment_log['Date'] = pd.to_datetime(investment_log['Date'])
for entry in investment_log:
    entry['Date'] = pd.to_datetime(entry['Date'])

# Create a DataFrame from the investment_log list
df = pd.DataFrame(investment_log)

cashflows_df.to_csv('/home/rizpython236/BT5/screener-outputs/cashflows_df.csv', index=False)
df.to_csv('/home/rizpython236/BT5/screener-outputs/investment_log.csv', index=False)
spx_data.to_csv('/home/rizpython236/BT5/screener-outputs/Draw_neg_data.csv', index=False)


# Load the CSV file into a Pandas DataFrame
data = pd.read_csv('/home/rizpython236/BT5/screener-outputs/investment_log.csv')

# Convert the "Date" column to datetime
data['Date'] = pd.to_datetime(data['Date'], format='%Y-%m-%d')

# Replace missing or invalid values in numeric columns with NaN
numeric_columns = ['Total_units', 'Cumulative_Value', 'MktCumulative_Value', 'INDICE']
data[numeric_columns] = data[numeric_columns].apply(pd.to_numeric)#, errors='coerce')

start_value = 50000  # The initial value for scaling
#data['Cumulative_Scaled'] = (data['Cumulative_Value'] / data['Cumulative_Value'].iloc[0]) * start_value
data['INDICE_Scaled'] = (data['INDICE'] / data['INDICE'].iloc[0]) * start_value
data.to_csv('/home/rizpython236/BT5/screener-outputs/investment_log.csv', index=False)

print(data)
# Sort the DataFrame by Date if date values are valid
#if 'Date' in data:
#    data.sort_values(by='Date', inplace=True)

# Plot the chart
plt.figure(figsize=(12, 6))
plt.plot(data['Date'], data['Total_units'], label='Total Units', marker='o')
plt.plot(data['Date'], data['Cumulative_Value'], label='Cumulative Value', marker='o')
plt.plot(data['Date'], data['MktCumulative_Value'], label='MktCumulative Value', marker='o')
plt.plot(data['Date'], data['INDICE'], label='INDICE', marker='o')

plt.xlabel('Date')
plt.ylabel('Value')
plt.legend()
plt.grid()
plt.title('Investment Performance')
plt.xticks(rotation=45)
plt.tight_layout()

#plt.show()

plt.savefig('/home/rizpython236/BT5/screener-outputs/equity_curve.png')

Print("done")

