import os
import time

import pandas as pd
import telebot  # pip install pyTelegramBotAPI

from PDFconvert import create_pdf
from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
)


INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
invalid_tickers_df = pd.read_csv(INVALID_TICKERS_FILE_PATH)
invalid_tickers = list(invalid_tickers_df["invalid_ticker"].unique())

INCOMPLETE_TICKERS_FILE_PATH = (
    SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV)
incomplete_tickers_df = pd.read_csv(INCOMPLETE_TICKERS_FILE_PATH)
incomplete_tickers = list(incomplete_tickers_df["Symbol"].unique())

file_path = "/home/rizpython236/BT5/trade-logs/screener-output_mhtly.csv"
# delete_file(file_path)


def delete_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"Deleted file: {file_path}")
    else:
        print(f"File not found: {file_path}")


TOKEN = "6108615209:AAF8ZiMMxbrT1D46enyrO0rSlChCuo9d4ro"
CHAT_IDS = [-1001757309399]  # -1001863996731 -1001757309399

# --- Configuration ---
API_TOKEN = "6108615209:AAF8ZiMMxbrT1D46enyrO0rSlChCuo9d4ro"
CHAT_ID = "-1001757309399"  # Replace with your target chat ID

# --- Initialize bot ---
bot = telebot.TeleBot(API_TOKEN)


def post_telegram_message(message: str):
    """Send a text message to Telegram."""
    # Convert lists/tuples to a comma-separated string
    if isinstance(message, (list, tuple)):
        message = ", ".join(str(m) for m in message if str(m).strip())

    # Ensure message is a string
    message = str(message) if message is not None else ""

    min_length: int = 1
    if not message or not message.strip() or len(message.strip()) < min_length:
        print(
            f"⏭️  Message too short (min {min_length} chars), skipping Telegram send")
        return

    try:
        bot.send_message(CHAT_ID, message)
        print(f"✅ Message sent: {message}")
    except Exception as e:
        print(f"❌ Error sending message: {e}")


def post_telegram_file(file_path: str):
    """Send a file (document) to Telegram."""
    try:
        if not os.path.exists(file_path):
            print(f"⚠️ File not found: {file_path}")
            return
        with open(file_path, "rb") as f:
            bot.send_document(CHAT_ID, f)
        print(f"✅ File sent: {file_path}")
    except Exception as e:
        print(f"❌ Error sending file: {e}")


def shutdown_bot():
    """Cleanly stop the bot (mainly for long-running polling)."""
    try:
        bot.stop_bot()
        print("✅ Bot shutdown complete.")
    except Exception as e:
        print(f"❌ Error during shutdown: {e}")


def trigger_telegram_notifications():
    # post_telegram_message("Hey! Telegram alerts for {}".format(str(date.today())))

    if invalid_tickers:
        # post_telegram_message("Invalid Tickers Found - {}".format(invalid_tickers))
        # post_telegram_file('/home/rizpython236/BT5/screener-outputs/invalid_tickers.csv')
        1 + 1

    if incomplete_tickers:
        # post_telegram_message(
        #    "Incomplete Data Tickers Found - {}".format(incomplete_tickers)
        # )
        # post_telegram_file('/home/rizpython236/BT5/screener-outputs/incomplete_data_tickers.csv')
        1 + 1
        # SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
        # if monthly=="YES":
        # SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
        # else:
        #    1+1

    csv_to_send = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
    trade_list = pd.read_csv(csv_to_send)
    try:
        trade_list.drop(["talib_date", "talib_price", "talib_signal",
                        "trade_id", "trade_logged_on", "status"], axis=1, inplace=True)
    except:
        1 + 1
    trade_list = trade_list.to_dict("records")
    chunk_size = 5
    chunked_trade_list = [trade_list[i:i + chunk_size]
                          for i in range(0, len(trade_list), chunk_size)]

    print("Sending Ticker Alert Messages and CSV now ...")
    for trade_packet in chunked_trade_list:
        time.sleep(1)
        # post_telegram_message(json.dumps(trade_packet, sort_keys=True, indent=4))

    # Replace with your CSV file
    input_csv_file = "/home/rizpython236/BT5/trade-logs/screener-output.csv"
    # Replace with desired output PDF file
    output_pdf_file = "/home/rizpython236/BT5/screener-outputs/screener-output.pdf"
    input_csv_file1 = "/home/rizpython236/BT5/screener-outputs/screener-output1.csv"

    new_df = pd.read_csv(input_csv_file)
    try:
        notmatching1 = new_df.drop(["trade_logged_on", "trade_id", "status",
                                   "talib_date", "talib_signal", "talib_price"], axis=1, inplace=True)
    except:
        1 + 1
    new_df.to_csv(input_csv_file1, index=False)
    # print(new_df)
    create_pdf(input_csv_file1, output_pdf_file)
    time.sleep(2)
    post_telegram_file(output_pdf_file)
    # except:
    #    1+1

    time.sleep(2)
    # create_pdf(input_csv_file, output_pdf_file)

    # post_telegram_file(output_pdf_file)
    # post_telegram_message("That was all for today!")

# --- Example usage ---
# if __name__ == "__main__":
#    post_telegram_message("Hello from pyTelegramBotAPI!")
#    post_telegram_file("/home/rizpython236/BT5/BT5dailyx.zip")
#    shutdown_bot()


'''
import os
import time
import asyncio
import telebot
from telebot.async_telebot import AsyncTeleBot

# --- Configuration ---
API_TOKEN = os.getenv("TELEGRAM_TOKEN", "YOUR_TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "YOUR_CHAT_ID")

# Toggle between sync and async
USE_ASYNC = False  # 👈 change to True if you want async mode

# --- Initialize bots ---
bot = telebot.TeleBot(API_TOKEN)
async_bot = AsyncTeleBot(API_TOKEN)


def _safe_send(send_func, *args, retries=1, delay=2, **kwargs):
    """Generic safe send with optional retry (sync)."""
    for attempt in range(retries + 1):
        try:
            send_func(*args, **kwargs)
            return True
        except Exception as e:
            print(f"Send failed (attempt {attempt+1}): {e}")
            if attempt < retries:
                time.sleep(delay)
    return False


async def _safe_send_async(send_func, *args, retries=1, delay=2, **kwargs):
    """Generic safe send with optional retry (async)."""
    for attempt in range(retries + 1):
        try:
            await send_func(*args, **kwargs)
            return True
        except Exception as e:
            print(f"Async send failed (attempt {attempt+1}): {e}")
            if attempt < retries:
                await asyncio.sleep(delay)
    return False


def _run_async(coro):
    """Run coroutine safely whether or not an event loop is already running."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # Already inside an event loop → schedule task
        return asyncio.ensure_future(coro)
    else:
        # No loop running → run normally
        return asyncio.run(coro)


def post_telegram_message(message: str):
    """Send a text message (sync or async depending on flag)."""
    min_length: int = 1
    if not message or not message.strip() or len(message.strip()) < min_length:
        print(f"⏭️  Message too short (min {min_length} chars), skipping Telegram send")
        return

    if USE_ASYNC:
        return _run_async(_safe_send_async(async_bot.send_message, CHAT_ID, message))
    return _safe_send(bot.send_message, CHAT_ID, message)


def post_telegram_file(file_path: str):
    """Send a file (document) (sync or async depending on flag)."""
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return False

    if USE_ASYNC:
        async def _send():
            with open(file_path, "rb") as f:
                return await _safe_send_async(async_bot.send_document, CHAT_ID, f)
        return _run_async(_send())

    with open(file_path, "rb") as f:
        return _safe_send(bot.send_document, CHAT_ID, f)


def shutdown_bot():
    """Cleanly stop the bot (only relevant if polling)."""
    try:
        if USE_ASYNC:
            _run_async(async_bot.close_session())
        else:
            bot.stop_bot()
        print("Bot shutdown complete.")
    except Exception as e:
        print(f"Error during shutdown: {e}")


# --- Example usage ---
if __name__ == "__main__":
    post_telegram_message("Hello Telegram! (sync by default)")
    post_telegram_file("test.txt")
    shutdown_bot()
'''
