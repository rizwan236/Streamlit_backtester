import sys

import pandas as pd


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
from yahoofinancials import YahooFinancials


print("start")

# Load CSV file with 'symbol' column
csv_file_path = '/home/rizpython236/BT5/Final.csv'
df = pd.read_csv(csv_file_path)[:]

'''
get_dividend_yield()
get_dividend_rate()
get_payout_ratio()
get_market_cap()
get_earnings_per_share()
get_total_revenue()
get_ten_day_avg_daily_volume()
get_current_price()
'''

# Initialize an empty DataFrame for storing dividend information
dividend_df = pd.DataFrame(columns=['Symbol', 'Dividend Yield', 'Dividend Rate', 'Dividend Payout','Market Cap','EPS','Sales','AVGVol','Price'])

# Iterate through each symbol in the CSV file
for symbol in df['Symbol']:
    try:
        # Initialize YahooFinancials object with the current symbol
        yahoo_financials = YahooFinancials(symbol)

        # Get dividend information
        try:
            dividends_Price_data = yahoo_financials.get_current_price()
            #print(f"Dividend rate: {dividends_rate_data}")
            dividend_Price = round(dividends_Price_data,2) #[symbol]['dividendRate']
        except Exception as e:
            dividend_Price = "Blank"

        try:
            dividends_EPS_data = yahoo_financials.get_earnings_per_share()
            #print(f"Dividend rate: {dividends_rate_data}")
            dividend_EPS = round(dividends_EPS_data,2) #[symbol]['dividendRate']
        except Exception as e:
            dividend_EPS = "Blank"

        try:
            dividends_Sales_data = yahoo_financials.get_total_revenue()
            #print(f"Dividend rate: {dividends_rate_data}")
            dividend_Sales = round(dividends_Sales_data/10000000,2) #[symbol]['dividendRate']
        except Exception as e:
            dividend_Sales = "Blank"

        try:
            dividends_AvgVol_data = yahoo_financials.get_ten_day_avg_daily_volume()
            #print(f"Dividend rate: {dividends_rate_data}")
            dividend_AvgVol = dividends_AvgVol_data #[symbol]['dividendRate']
        except Exception as e:
            dividend_AvgVol = "Blank"


        try:
            dividends_rate_data = yahoo_financials.get_dividend_rate()
            #print(f"Dividend rate: {dividends_rate_data}")
            dividend_rate = dividends_rate_data #[symbol]['dividendRate']
        except Exception as e:
            dividend_rate = "Blank"

        try:
            dividends_yielddata = yahoo_financials.get_dividend_yield()
            #print(f"Dividend Yield: {dividends_yielddata}")
            Dividend_yield = round(dividends_yielddata*100,2) #[symbol]['dividendYield']
        except Exception as e:
            Dividend_yield= "Blank"

        try:
            dividends_payout_data = yahoo_financials.get_payout_ratio1()
            #print(f"dividends_payout: {dividends_payout_data}")
            dividend_payout = round(dividends_payout_data*100,2) #[symbol]['payoutRatio']
        except Exception as e:
            dividend_payout ="Blank"

        try:
            dividends_market_cap_data = yahoo_financials.get_market_cap()
            dividends_market_cap_data =round(dividends_market_cap_data/10000000,2)
            #print(f"dividends_market_cap: {dividends_market_cap_data}")
            dividend_market_cap = dividends_market_cap_data #[symbol]['Marketcap']
        except Exception as e:
            dividend_market_cap="Blank"

        # Append the data to the new DataFrame
        dividend_df = dividend_df.append({
            'Symbol': symbol,
            'Dividend Yield': Dividend_yield,
            'Dividend Rate': dividend_rate,
            'Dividend Payout': dividend_payout,
            'Market Cap': dividend_market_cap,
            'EPS': dividend_EPS,
            'Sales': dividend_Sales,
            'AVGVol': dividend_AvgVol,
            'Price': dividend_Price
        }, ignore_index=True)

        print(f"Symbol: {symbol}, Dividend Yield: {Dividend_yield}, Dividend Rate: {dividend_rate}, Dividend Payout: {dividend_payout},Market Cap: {dividend_market_cap},EPS: {dividend_EPS},Sales: {dividend_Sales},AVGVol: {dividend_AvgVol},Price: {dividend_Price}")

    except Exception as e:
        print(f"Error fetching data for {symbol}: {str(e)}")
        #print(f"Symbol: {symbol}, Dividend Yield: {Dividend_yield}, Dividend Rate: {dividend_rate}, Dividend Payout: {dividend_payout},Market Cap: {dividend_market_cap}")

# Save the new DataFrame to a new CSV file
dividend_df.to_csv('/home/rizpython236/BT5/trade-logs/Yahoofindividend_info.csv', index=False)
print(dividend_df)
