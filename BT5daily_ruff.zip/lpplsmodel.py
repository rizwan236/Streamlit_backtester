
'''
from lppls import lppls, data_loader
import numpy as np
import pandas as pd
from datetime import datetime as dt
%matplotlib inline

# read example dataset into df
data = data_loader.nasdaq_dotcom()

# convert time to ordinal
time = [pd.Timestamp.toordinal(dt.strptime(t1, '%Y-%m-%d')) for t1 in data['Date']]

# create list of observation data
price = np.log(data['Adj Close'].values)

# create observations array (expected format for LPPLS observations)
observations = np.array([time, price])

# set the max number for searches to perform before giving-up
# the literature suggests 25
MAX_SEARCHES = 25

# instantiate a new LPPLS model with the Nasdaq Dot-com bubble dataset
lppls_model = lppls.LPPLS(observations=observations)

# fit the model to the data and get back the params
tc, m, w, a, b, c, c1, c2, O, D = lppls_model.fit(MAX_SEARCHES)

# visualize the fit
lppls_model.plot_fit()

# should give a plot like the following...



# compute the confidence indicator
res = lppls_model.mp_compute_nested_fits(
    workers=8,
    window_size=120,
    smallest_window_size=30,
    outer_increment=1,
    inner_increment=5,
    max_searches=25,
    # filter_conditions_config={} # not implemented in 0.6.x
)

lppls_model.plot_confidence_indicators(res)
# should give a plot like the following...


import numpy as np
import pandas as pd
from datetime import datetime as dt
import matplotlib.pyplot as plt
from telegram_bot import post_telegram_message,post_telegram_file
from PDFconvert import create_pdf

import sys
sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
from lppls import lppls  # assuming lppls is installed locally



def analyze_lppls(data_path="ticker.csv", max_searches=25 , output_path="/home/rizpython236/BT5/screener-outputs/"):
  """
  This function reads NASDAQ data from a CSV file, performs LPPLS analysis,
  and saves the fit and confidence indicator plots as PNGs.

  Args:
      data_path (str, optional): Path to the CSV file containing NASDAQ data.
          Defaults to "ticker.csv".
      max_searches (int, optional): Maximum number of searches for the LPPLS model.
          Defaults to 25.
  """

  # Read the CSV data into a pandas DataFrame
  data = pd.read_csv(data_path)

  # Extract ticker name from filename (assuming filename format like 'abc.csv')
  filename = data_path.split("/")[-1]  # Get the filename from the path
  ticker = filename.split(".")[0]  # Extract the part before the extension (.csv)

  # Assuming the CSV has 'Date' and 'Adj Close' columns
  # Convert 'Date' column to datetime format
  #data['Date'] = pd.to_datetime(data['Date'])
  #time = data['Date'].values

  # Convert time to ordinal
  time = [pd.Timestamp.toordinal(dt.strptime(t1, '%Y-%m-%d')) for t1 in data['Date']]

  # Create list of observation data (log of Adjusted Close price)
  price = np.log(data['Close'].values)

  # Create observations array
  observations = np.array([time, price])

  # Instantiate a new LPPLS model
  lppls_model = lppls.LPPLS(observations=observations)

  # Fit the model to the data and get back the parameters
  tc, m, w, a, b, c, c1, c2, O, D = lppls_model.fit(max_searches)

  # Function to save the fit plot as PNG
  def save_fit_plot(model,ticker, output_path):
    plt.figure()
    model.plot_fit()
    plt.savefig(f"{output_path}{ticker}_lppls_fit.png")
    plt.close()

  # Function to save the confidence indicator plot as PNG
  def save_confidence_plot(model, results,ticker, output_path):
    plt.figure()
    model.plot_confidence_indicators(results)
    plt.savefig(f"{output_path}{ticker}_lppls_confidence.png")
    plt.close()

  # Save the fit plot
  save_fit_plot(lppls_model, ticker, output_path)

  # Compute the confidence indicator
  res = lppls_model.mp_compute_nested_fits(
      workers=8,
      window_size=120,
      smallest_window_size=30,
      outer_increment=1,
      inner_increment=5,
      max_searches=25,
  )

  # Save the confidence indicator plot
  save_confidence_plot(lppls_model, res, ticker, output_path)

  print(f"LPPLS model analysis for {ticker} complete. Plots saved to {output_path}.")


# Example usage
#analyze_lppls()  # Use default parameters
# or
output_path="/home/rizpython236/BT5/screener-outputs/"

folder_path='/home/rizpython236/BT5/ticker_15yr/^NSEI.csv'
folder_path1='/home/rizpython236/BT5/ticker_15yr/^CRSLDX.csv'
folder_path2='/home/rizpython236/BT5/ticker_15yr/^NSEMDCP50.csv'

#folder_path='/home/rizpython236/BT5/screener-outputs/'
analyze_lppls(folder_path, 25, output_path)  # Specify different data path and max_searches
'''


'''
from lppls import lppls, data_loader
import numpy as np
import pandas as pd
from datetime import datetime as dt
%matplotlib inline

# read example dataset into df
data = data_loader.nasdaq_dotcom()

# convert time to ordinal
time = [pd.Timestamp.toordinal(dt.strptime(t1, '%Y-%m-%d')) for t1 in data['Date']]

# create list of observation data
price = np.log(data['Adj Close'].values)

# create observations array (expected format for LPPLS observations)
observations = np.array([time, price])

# set the max number for searches to perform before giving-up
# the literature suggests 25
MAX_SEARCHES = 25

# instantiate a new LPPLS model with the Nasdaq Dot-com bubble dataset
lppls_model = lppls.LPPLS(observations=observations)

# fit the model to the data and get back the params
tc, m, w, a, b, c, c1, c2, O, D = lppls_model.fit(MAX_SEARCHES)

# visualize the fit
lppls_model.plot_fit()

# should give a plot like the following...



# compute the confidence indicator
res = lppls_model.mp_compute_nested_fits(
    workers=8,
    window_size=120,
    smallest_window_size=30,
    outer_increment=1,
    inner_increment=5,
    max_searches=25,
    # filter_conditions_config={} # not implemented in 0.6.x
)

lppls_model.plot_confidence_indicators(res)
# should give a plot like the following...
'''

from datetime import datetime as dt
import sys

#%matplotlib inline
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PDFconvert import create_pdf
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
import time

from lppls import data_loader, lppls  # assuming lppls is installed locally
import yfinance as yf


ticker_symbol = "^GSPC"  # S&P 500
start_date = "1999-07-30"  # start date from the paper
end_date = "2024-04-12"   # end date from the paper

#data = yf.download(ticker_symbol, start=start_date, end=end_date)

def analyze_lppls(data_path="ticker.csv", max_searches=25 , output_path="/home/rizpython236/BT5/screener-outputs/"):
  #def analyze_lppls(data, max_searches=25 , output_path="/home/rizpython236/BT5/screener-outputs/"):
  """
  This function reads NASDAQ data from a CSV file, performs LPPLS analysis,
  and saves the fit and confidence indicator plots as PNGs.

  Args:
      data_path (str, optional): Path to the CSV file containing NASDAQ data.
          Defaults to "ticker.csv".
      max_searches (int, optional): Maximum number of searches for the LPPLS model.
          Defaults to 25.
  """

  # Read the CSV data into a pandas DataFrame
  data = pd.read_csv(data_path)
  #data = data_loader.nasdaq_dotcom()

  # Extract ticker name from filename (assuming filename format like 'abc.csv')
  filename = data_path.split("/")[-1]  # Get the filename from the path
  ticker = filename.split(".")[0]  # Extract the part before the extension (.csv)

  # Assuming the CSV has 'Date' and 'Adj Close' columns
  # Convert 'Date' column to datetime format
  #data['Date'] = pd.to_datetime(data['Date'])
  #time = data['Date'].values

  # Convert time to ordinal
  time = [pd.Timestamp.toordinal(dt.strptime(t1, '%Y-%m-%d')) for t1 in data['Date']]

  # Create list of observation data (log of Adjusted Close price)
  price = np.log(data['Close'].values)

  # Create observations array
  observations = np.array([time, price])

  # Instantiate a new LPPLS model
  lppls_model = lppls.LPPLS(observations=observations)

  # Fit the model to the data and get back the parameters
  tc, m, w, a, b, c, c1, c2, O, D = lppls_model.fit(max_searches)

  lppls_model.plot_fit()

  filename="/home/rizpython236/BT5/screener-outputs/lppls_fit.png"
  plt.savefig(filename)
  time.sleep(1)
  post_telegram_file(filename)
  # (Optional) Close the plot window
  plt.close()


  # Function to save the fit plot as PNG
  def save_fit_plot(model,ticker, output_path):
    plt.figure()
    model.plot_fit()
    plt.savefig(f"{output_path}{ticker}_lppls_fit.png")
    plt.close()

  # Function to save the confidence indicator plot as PNG
  def save_confidence_plot(model, results,ticker, output_path):
    plt.figure()
    model.plot_confidence_indicators(results)
    plt.savefig(f"{output_path}{ticker}_lppls_confidence.png")
    plt.close()

  # Save the fit plot
  #save_fit_plot(lppls_model, ticker, output_path)

  # Compute the confidence indicator
  res = lppls_model.mp_compute_nested_fits(
      workers=8,
      window_size=24, #120,
      smallest_window_size=6, #30,
      outer_increment=1,
      inner_increment=5,
      max_searches=25,
  )

  lppls_model.plot_confidence_indicators(res)

  filename="/home/rizpython236/BT5/screener-outputs/lppls_confidence.png"
  plt.savefig(filename)
  time.sleep(1)
  post_telegram_file(filename)
  # (Optional) Close the plot window
  plt.close()

  # Save the confidence indicator plot
  #save_confidence_plot(lppls_model, res, ticker, output_path)

  print(f"LPPLS model analysis for {ticker} complete. Plots saved to {output_path}.")


# Example usage
#analyze_lppls()  # Use default parameters
# or
output_path="/home/rizpython236/BT5/screener-outputs/"

folder_path='/home/rizpython236/BT5/ticker_15yr/^NSEI.csv'
folder_path1='/home/rizpython236/BT5/ticker_15yr/^CRSLDX.csv'
folder_path2='/home/rizpython236/BT5/ticker_15yr/^NSEMDCP50.csv'
#folder_path='/home/rizpython236/BT5/ticker_daily1yr/^NSEI.csv'

#folder_path='/home/rizpython236/BT5/screener-outputs/'
analyze_lppls(folder_path2, 25, output_path)  # Specify different data path and max_searches

print("completed")



print("completed")

