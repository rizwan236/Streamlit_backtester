#!/usr/bin/env python3
from pathlib import Path
import subprocess


# Path to the folder containing Python files
PROJECT_PATH = Path("/home/rizpython236/BT5")

# List of filenames to exclude (just filenames, not full paths)
exclude_files = [
    "printsymbols.py",
    "Elders Force Index.py",
    "refactored_csv15yrs.py",
    "nifty_OI.py",
    "install_wheel.py",
]

include_files = [
    "BSENSEtickerdownloader.py",
    "BTmombroker.py",
    "BToutputindustry.py",
    "CCIST.py",
    "Drawdownchart.py",
    "Drawdownchart15yr.py",
    "EMASMA.py",
    "ISINbsense.py",
    "MMI_index.py",
    "Mktcap2GDP.py",
    "PDFconvert.py",
    "SME_.py",
    "add_company_name.py",
    # "bse_ticker_download.py",
    "cleanup.py",
    "csv15yrs_short.py",
    "custum_index.py",
    "datadownload15yr.py",
    "dividend.py",
    "MRPPlot.py",
    "filtersymbols.py",
    "holding_unique.py",
    "mail_utils.py",
    "nse500.py",
    "pybrokerBT.py",
    "sector_rotation.py",
    "sectorupdate.py",
    "symbol_copy.py",
    "telebotscript.py",
    "trade_compiler.py",
    "zipper.py",
    "ruff_all.py",
    "trade_compiler_final.py"
    "telegram_bot.py",
    "create_requirement.py",
    "email2telegram.py",
    "mail_utils.py",
    "scheduler.py",
    "scheduler2.py",
    "google_sheetsdata.py"
    "tradebookanalysis.py",
]


# include_files = ["csv15yrs_short.py",]

def get_python_files(path: Path, exclude=None, include=None):
    """Get a list of all top-level .py files in the folder (exclude subfolders and files in exclude list)
    """
    exclude = exclude or []
    py_files = []
    for f in path.glob("*.py"):
        if f.is_file() and f.name not in exclude and f.name in include:
            py_files.append(str(f))
    return py_files


def run_ruff_on_files(files):
    """Run Ruff --fix --diff on each Python file.
    """
    if not files:
        print("No Python files found in the specified path.")
        return

    for py_file in files:
        # cmd = ["ruff", "check", py_file, "--fix"]
        # cmd = ["ruff", "check", py_file, "--fix","--quiet" ] #--quiet flag suppresses all output except errors.
        # cmd = ["ruff", "check", py_file, "--fix", "--silent"]    # Completely silent (no output at all)
        # Or show errors in concise format
        cmd = ["ruff", "check", py_file, "--fix", "--output-format=concise"]
        # cmd = ["ruff", "check", py_file, "--unsafe-fixes", "--diff"]
        # cmd = ["ruff", "check", py_file, "--fix", "--diff"]
        print(f"Running: {' '.join(cmd)}")
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            print(f"Ruff failed on {py_file} with exit code {e.returncode}")


def run_autopep8(files):
    """Run autopep8 to reformat the given file.
    """
    if not files:
        print("No Python files found in the specified path.")
        return

    for py_file in files:
        # W391 ,W293 ,W292,W291,E502,E402,E401,E304,E303,E302,E301,E27,E265,E26,E251,E241,E231,E225,E226,E227,E228,E20,E211
        select_options = "E1,E2,E3,W1,W2,W3,F401,F841,W391,W293,W292,W291,E502,E402,E401,E304,E303,E302,E301,E27,E265,E26,E251,E241,E231,E225,E226,E227,E228,E20,E211"
        select_options = ""
        # cmd = ["autopep8", "--in-place", "--aggressive", "--aggressive", py_file]
        cmd = ["autopep8", "--in-place", py_file]
        # cmd = ["autopep8", "--diff", "--select E1,E2,E3,W1,W2,W3,F401,F841", py_file]
        # cmd = ["autopep8", "--diff", "--select", select_options, py_file]
        # cmd = ["autopep8", "--in-place", "--select", select_options, py_file]

        print(f"Running: {' '.join(cmd)}")
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            print(
                f"autopep8 failed on {py_file} with exit code {e.returncode}")


def main():
    py_files = get_python_files(
        PROJECT_PATH, exclude=exclude_files, include=include_files)
    run_ruff_on_files(py_files)
    run_autopep8(py_files)


if __name__ == "__main__":
    main()
