import platform
import subprocess


def clear_console():
    system_name = platform.system().lower()

    if system_name == "windows":
        subprocess.call("cls", shell=True)
    else:
        subprocess.call("clear", shell=True)


# Example usage
clear_console()

# Define the output file name
output_file = "/home/rizpython236/BT5/trade-logs/pybroker_requirements.txt"
output_file = "pybroker_requirements.txt"

# Define the path to the site-packages directory of the specific virtual environment
env_site_packages = "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/"

# Execute pip freeze command to get list of installed packages in the specific environment
pip_freeze = subprocess.Popen(
    ["pip", "freeze", "--path", env_site_packages], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Read the output and handle any errors
output, error = pip_freeze.communicate()

if pip_freeze.returncode != 0:
    print(f"Failed to generate {output_file}: {error.decode('utf-8')}")
    exit(1)

# Write the output to requirements.txt
try:
    lines = output.decode("utf-8").splitlines()
    formatted_lines = []
    output_with_commas = ", ".join(lines)

    # Process lines to group them into chunks of 5
    for i in range(0, len(lines), 1):
        chunk = lines[i:i + 1]  # Get the next 5 items
        formatted_lines.append(", ".join(chunk))  # Join them with a comma

    with open(output_file, "w") as f:
        1+1
        f.write(output.decode("utf-8"))
    print(f"Successfully generated {output_file}")
    # Print the formatted output
    for line in formatted_lines:
        print(line)
        # print(formatted_lines)

    # print(output_with_commas)
except Exception as e:
    print(f"Failed to write {output_file}: {e!s}")
    exit(1)

ffffffffffffffffffffffffffffffffffffffffff

r"""
https://www.bseindia.com/corporates/List_Scrips.html   Equity.csv
https://archives.nseindia.com/content/indices/ind_nifty500list.csv  nse500.csv
https://archives.nseindia.com/content/indices/ind_niftymicrocap250_list.csv   FinalMicrocap250.csv
https://archives.nseindia.com/content/equities/EQUITY_L.csv  nse.csv



pip install --upgrade pandas numpy beautifulsoup4 matplotlib numba openpyxl pandas_ta reportlab requests scipy seaborn selenium yagmail zipp ta-lib pytz tzdata tzlocal yfinance
pip install --force-reinstall --no-binary :all: numpy

pip uninstall -y numba llvmlite
pip install --no-cache-dir --force-reinstall llvmlite==0.45.0 numba==0.62.0
ls -l /home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/llvmlite/binding/libllvmlite.so
pip install --no-cache-dir llvmlite==0.45.0 --only-binary=:all:
pip install --no-cache-dir numba==0.62.0 --only-binary=:all:

pip install pandas-ta==0.4.71b0 --no-deps
pip install git+ssh://git@github.com/Data-Analisis/Technical-Analysis-Indicators---Pandas.git
pip install git+https://github.com/Data-Analisis/Technical-Analysis-Indicators---Pandas.git


$ pip install pip-review
After that, you can either upgrade the packages interactively:

$ pip-review --local --interactive
Or automatically:

$ pip-review --local --auto


pip install -r /home/rizpython236/BT5/trade-logs/pybroker_requirements.txt
cat /home/rizpython236/BT5/trade-logs/pybroker_requirements.txt | grep -v '^#' | grep -v '^$' | xargs -n 1 pip uninstall -y   ###uninstall packages


pipdeptree --reverse --warn silence | grep tornado
pipdeptree --warn silence | grep -E '^\w+'
pipdeptree -f --warn silence | grep -E '^[a-zA-Z0-9\-]+' > requirements.txt

pip-autoremove lib-pybroker -y
pip3-autoremove lib-pybroker
pip3-autoremove packages-to-uninstall


pip uninstall -y annotated-types==0.7.0 decorator==5.1.1 jsonpath==0.82.2 xlrd==2.0.1 tabulate==0.9.0 websockets==14.1 sseclient-py==1.8.0 py-mini-racer==0.6.0 PySocks==1.7.1 msgpack==1.1.0 akshare>=1.10.1 alpaca-py>=0.7.2
pip3-autoremove alpaca-py akshare akracer pydantic pydantic-core
pip3 uninstall alpaca-py akshare akracer pydantic pydantic-core

pip install asyncio  Bottleneck==1.4.2 numexpr==2.10.2 pandas_market_calendars==4.6.1 pipdeptree==2.28.0 regex==2025.9.18 reportlab==4.4.4 scipy==1.13.1 seaborn==0.13.2 selenium==4.35.0 TA-Lib==0.6.7 webdriver-manager==4.0.2 yagmail==0.15.293
pip install lib-pybroker==1.2.10 pip-review==1.3.0 pip3-autoremove==2.0.1 pipdeptree==2.28.0 python-telegram-bot

core libraries
asyncio==4.0.0
#boltons==25.0.0
Bottleneck==1.4.2
#chardet==5.2.0
#httpx==0.28.1
lib-pybroker==1.2.10
numexpr==2.10.2
pandas_market_calendars==4.6.1
pandas-ta==0.4.71b0
#pip-check==3.2.1
#pip-chill==1.0.3
pip-review==1.3.0
#pip-upgrade-tool==0.7.4
#pip-upgrader==1.4.15
pip3-autoremove==2.0.1
pipdeptree==2.28.0
#pipgrip==0.11.0
#psutil==7.1.0
#pyOpenSSL==25.3.0
#PySocks==1.7.1
python-telegram-bot==13.15
regex==2025.9.18
reportlab==4.4.4
scipy==1.13.1
seaborn==0.13.2
selenium==4.35.0
TA-Lib==0.6.7
#tinycss2==1.4.0
#urllib3-secure-extra==0.1.0
webdriver-manager==4.0.2
yagmail==0.15.293


Pybroker39zz) 09:33 ~ $ pipdeptree --warn silence | grep -E '^\w+'
asyncio==4.0.0
boltons==25.0.0
Bottleneck==1.4.2
chardet==5.2.0
httpx==0.28.1
lib-pybroker==1.2.10
numexpr==2.10.2
pandas_market_calendars==4.6.1
pandas_ta==0.3.14b0
pip-check==3.2.1
pip-chill==1.0.3
pip-review==1.3.0
pip-upgrade-tool==0.7.4
pip-upgrader==1.4.15
pip3-autoremove==2.0.0
pipdeptree==2.28.0
pipgrip==0.11.0
psutil==7.0.0
pyOpenSSL==25.1.0
PySocks==1.7.1
python-telegram-bot==13.15
regex==2025.9.1
reportlab==4.4.3
scipy==1.13.1
seaborn==0.13.2
selenium==4.35.0
TA-Lib==0.6.6
tinycss2==1.4.0
urllib3-secure-extra==0.1.0
webdriver-manager==4.0.2
yagmail==0.15.293


touch /var/www/your_domain_wsgi.py
pip install -r /home/rizpython236/requirements.txt

# Define the output file name
output_file = "pybroker_requirements.txt"

# Execute pip freeze command to get list of installed packages
pip_freeze = subprocess.Popen(['pip', 'freeze'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Read the output and handle any errors
output, error = pip_freeze.communicate()

if pip_freeze.returncode != 0:
    print(f"Failed to generate {output_file}: {error.decode('utf-8')}")
    exit(1)

print(output_file)
# Write the output to requirements.txt
try:
    with open(output_file, 'w') as f:
        f.write(output.decode('utf-8'))
    print(f"Successfully generated {output_file}")
except Exception as e:
    print(f"Failed to write {output_file}: {str(e)}")
    exit(1)





AARON INDUSTRIES
Ador Welding
Amines and Plasticizers
Apcotex Industries
Archean Chemical Industries
Avanti Feeds
Bhageria Industries
Borosil Renewables
Container Corporation of India
DDEV PLASTIKS INDUSTRIES
Eco Recycling
ELGI Equipments
Expleo Solutions
Galaxy Surfactants
Ganesh Benzoplast
Gujarat Ambuja Exports
Indusind Bank
Macpower CNC Machines
Manorama Industries
Natco Pharma
Neogen Chemicals
Niyogin Fintech
P N Gadgil Jewellers
Poonawalla Fincorp
Praveg
Pricol
RACL Geartech
Rajoo Engineers
Raminfo
RedTape
Roto Pumps
Shivalik Bimetal Controls
Shyam Metalics and Energy
Syngene International
Tatva Chintan Pharma Chem
TCI Express
Tega Industries
Tembo Global Industries
Vaibhav Global
Zota Health Care
Uniparts India
TAAL Enterprises
PPAP Automotive
FIEM Industries
Jamna Auto Industries
Pix Transmissions
AIA Engineering
Landmark Cars
HDFC Bank
Honda Siel Power Products
Ador Fontech
Somi Conveyor Beltings
Permanent Magnets
GMM Pfaudler
HLE Glascoat
Rain Industries
Oriental Carbon and Chemicals
Dalmia Bharat
Asian Granito India
Camlin Fine Sciences
MEGHMANI ORGANICS INR1
Paushak
Vinati Organics
Valiant Organics
Alkyl Amines Chemicals
Crompton Greaves Consumer Electricls
Aimco Pesticides
HP Adhesives
Jyoti Resins and Adhesives
20 Microns
Dharmaj Crop Guard
V I P Industries
Cupid
IFB Industries
Bata India
Brand Concepts
Sika Interplant Systems
Nibe
Agro Tech Foods
Bajaj Consumer Care
Amrutanjan Health Care
Restaurant Brands Asia
Ksolves India
Mphasis
Tanla Platforms
Route Mobile
E2E Networks
Advait Infratech
Saregama India
MSTC
Manappuram Finance
Arman Financial Services
Panama Petrochem
Ester Industries
Arrow Greentech
Nile
Repro India
Innovative Tech Pack
JK Paper
Ruchira Papers
Yash Papers
Astec LifeSciences
Biocon
Granules India
Sigachi Industries
Tarsons Products
Concord Biotech Ord Shs
AVRO INDIA
Indian Energy Exchange
Adani Transmission
Servotech Power Systems
KP Green Engineering
Bigbloc Construction
Ambika Cotton Mills
Delta Corp
"""
