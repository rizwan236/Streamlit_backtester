import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
import pytz
import time
import sys
import re
#sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
#sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages')
import numpy as np  #numpy-1.26.4   1.21.6   2.0.2
import pandas as pd
print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")
sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
import yfinance as yf
from telegram_bot import post_telegram_message,post_telegram_file
from custum_index import load_index_constituents_from_csv,calculate_custom_index,plot_index_close_prices
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import traceback
#from scipy.stats import gmean
import talib as tb
#from concurrent.futures import ThreadPoolExecutor, as_completed
#from tqdm import tqdm
#import asyncio

#import logging
#logger = logging.getLogger('yfinance')
#logger.setLevel(logging.ERROR)  # default: only print errors
#logger.setLevel(logging.CRITICAL)  # disable printing
#logger.setLevel(logging.DEBUG)  # verbose: print errors & debug info

from datetime import date, datetime, timedelta
from settings import (
    INVALID_TICKERS_FILE,
    SCREENER_OUTPUT_FOLDER_PATH,
    TICKER_CSV_DATA_FOLDER_PATH,
    NIFTY_CSV,
    SYMBOLS_CSV,
    VALID_TICKERS_CSV,
    INCOMPLETE_TICKERS_CSV,
)




# --- Configuration (kept as in your original script, can be tuned) ---
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
dir5 = Path("/home/rizpython236/BT5/ticker_15yr")
SYMBOLS_CSV = "/home/rizpython236/BT5/symbol_list.csv"
TICKER_CSV_DATA_FOLDER_PATH = str(dir5)
exclude_file = "/home/rizpython236/BT5/exclude_tickers.csv"

# These are referenced later in your script; keep as-is or set where appropriate in your environment
# NIFTY_CSV, SCREENER_OUTPUT_FOLDER_PATH, INVALID_TICKERS_FILE, VALID_TICKERS_CSV, INCOMPLETE_TICKERS_CSV
# are expected to be defined elsewhere in your environment. If not, define them before running.

# --- Date range calculation (same logic as original) ---
end_date = datetime.now(IST_TIMEZONE).date()
start_date = end_date - timedelta(weeks=52 + 8)  # ~ 77 weeks
END_DATE = str(end_date)
START_DATE = str(start_date)
print(f"Start date {START_DATE} , End date {END_DATE}.")
time.sleep(1)
# notify
try:
    from telegram_bot import post_telegram_message, post_telegram_file
    post_telegram_message(f"The start date is {START_DATE} and the end date is {END_DATE}.")
except Exception:
    pass

# clear output folder (same as original script)
if dir5.exists():
    for f in dir5.iterdir():
        try:
            f.unlink()
        except Exception:
            pass
else:
    dir5.mkdir(parents=True, exist_ok=True)

# --- Download helper (signature unchanged) ---
def download_ticker_data(symbol):
    """
    Download historical ticker data (daily) for a symbol between START_DATE and END_DATE.

    Returns: (symbol, pandas.DataFrame or None)
      - DataFrame is returned if the downloaded data length is sufficient (len > 55).
      - None returned for invalid / insufficient data or any error.

    NOTE: this function relies on global START_DATE and END_DATE (kept for compatibility).
    """
    try:
        '''
        # quick validation: try to use fast_info if available; fall back to basic checks
        t = yf.Ticker(symbol)

        # Best-effort last price check. Use fast_info or try a tiny history lookup.
        reg_mp = None
        try:
            fi = getattr(t, "fast_info", None)
            if fi and isinstance(fi, dict):
                reg_mp = fi.get("last_price") or fi.get("last_close") or fi.get("last_price")
        except Exception:
            reg_mp = None

        # fallback small history to determine if ticker exists
        if reg_mp is None:
            try:
                small_hist = t.history(period="5d", interval="1d", auto_adjust=True, actions=False)
                if isinstance(small_hist, pd.DataFrame) and not small_hist.empty:
                    reg_mp = small_hist['Close'].iloc[-1]
            except Exception:
                reg_mp = None

        # Basic threshold: require a market price > 15 to consider valid (same idea as your script)
        if reg_mp is None or not (reg_mp > 15):
            return symbol, None
        '''
        
        # Download the full period
        data = yf.download(
            symbol,
            start=START_DATE,
            end=END_DATE,
            interval="1d",
            rounding=True,
            threads=True,
            multi_level_index=False,
            progress=False,
            back_adjust=True,
            repair=False,
            keepna=False,
            actions=False,
            auto_adjust=True,
        )

        # require some minimum rows to be usable (original used >55 in function)
        if isinstance(data, pd.DataFrame) and len(data) > 55:
            # keep date as index.date for consistency with your later code
            data.index = pd.to_datetime(data.index).date
            data.rename_axis("Date", inplace=True)
            return symbol, data
        return symbol, None

    except Exception:
        # on any error, return None for this symbol (caller handles adding to invalid list)
        return symbol, None


# --- Orchestration: read symbol list and parallel download ---
tickers_df = pd.read_csv(SYMBOLS_CSV)
tickers_list = list(tickers_df["Symbol"].unique())
#additional_tickers = ["^NSEI", "^NSEBANK", "^CRSLDX","^NSMIDCP","^CRSMID","^CNXSC","RELIANCE.NS", "INFY","LOTUSEYE.NS","MARUTI.NS"]
#tickers_list.extend(additional_tickers)

print("-" * 100)
print("Starting download for data from {} to {}.".format(START_DATE, END_DATE))
print("-" * 100)
print("Total number of symbols: ", len(tickers_list))

# Prepare exclude list file: read existing exclude list if available
try:
    df_exclude_old = pd.read_csv(exclude_file)
except Exception:
    df_exclude_old = pd.DataFrame(columns=["Symbol"])

# trackers
invalid_tickers = []
incomplete_data_tickers = []
valid_tickers = []
errorlist = []  # for missing files when building indices later
datasum = 0
datacount = 0

# concurrency tuning: adjust workers according to environment
MAX_WORKERS = 8

# submit downloads in parallel (ThreadPool is appropriate for I/O-bound yfinance)
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    future_to_symbol = {executor.submit(download_ticker_data, sym): sym for sym in tickers_list}
    processed = 0
    for future in as_completed(future_to_symbol):
        symbol = future_to_symbol[future]
        processed += 1

        # small periodic pause to be kind to remote service (avoid bursts)
        if processed % 300 == 0:
            print(f"Processed {processed} symbols. Pausing for 4 minutes...")
            time.sleep(4 * 60)

        try:
            result_symbol, data = future.result()
        except Exception:
            result_symbol, data = symbol, None

        # If no data returned, mark invalid
        if data is None:
            invalid_tickers.append(symbol)
            continue

        # Apply your original thresholds for saving/excluding
        try:
            # convert to DataFrame if not already
            if not isinstance(data, pd.DataFrame):
                invalid_tickers.append(symbol)
                continue

            rows = len(data)
            last_close = float(data['Close'].iloc[-1]) if 'Close' in data.columns and not data['Close'].isnull().all() else None
            last_volume = data['Volume'].iloc[-1] if 'Volume' in data.columns else None

            # Condition to save high-history tickers (original: >277 rows and other checks)
            if (rows > 277) and (last_close is not None) and (
                last_close > 50
                or symbol == "^INDIAVIX"
                or symbol.startswith("^")
                or symbol.startswith("CNXC")
                or symbol.startswith("TJI_")
                or re.search(r"BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP", symbol)
            ):
                # persist CSV exactly like original
                ticker_csv_file_path = os.path.join(TICKER_CSV_DATA_FOLDER_PATH, f"{symbol}.csv")
                data.to_csv(ticker_csv_file_path)
                datasum += rows
                datacount += 1
                valid_tickers.append(symbol)

            # Condition to add to exclude list (original: >125 rows and last_close < 35 etc.)
            if (rows > 125) and (last_close is not None) and (
                last_close < 35
                and symbol != "^INDIAVIX"
                and not symbol.startswith("^")
                and not symbol.startswith("TJI_")
                and pd.notna(last_volume)
            ):
                df_exclude_old = pd.concat([df_exclude_old, pd.DataFrame({"Symbol": [symbol]})], ignore_index=True)

            # small polite delay between processing results
            time.sleep(0.05)

        except Exception as e:
            # if something unexpected happened while processing a valid download
            invalid_tickers.append(symbol)
            print(f"Processing error for {symbol}: {e}")

# finalize exclude file (dedupe)
df_exclude_old = df_exclude_old.drop_duplicates(subset=["Symbol"], ignore_index=True)
df_exclude_old.to_csv(exclude_file, index=False)

print("Data download task completed.")
if datacount > 0:
    datamean = int(datasum / datacount)
else:
    datamean = 0
print("Average rows for saved tickers:", datamean)

# --- Helper utilities kept from original (slightly cleaned) ---
def get_filepaths(directory):
    """Return list of full file paths for files under `directory`."""
    file_paths = []
    for root, _, files in os.walk(directory):
        for filename in files:
            file_paths.append(os.path.join(root, filename))
    return file_paths

def check_data_continuity(df, interval=7):
    """
    Return True if no gaps larger than `interval` days are found between consecutive Date rows.
    Expects df['Date'] to be datetime or date type.
    """
    if df.shape[0] < 2:
        return False
    deltas = pd.to_datetime(df['Date']).diff().dropna()
    # count gaps larger than allowed interval
    large_gaps = deltas[deltas > pd.Timedelta(days=interval)]
    return large_gaps.empty

def check_num_rows(df1, df2):
    """Return True if df1 has at least as many rows as df2."""
    return df1.shape[0] >= df2.shape[0]

# --- Validate downloaded CSV files (same logic as original) ---
files_to_process = get_filepaths(TICKER_CSV_DATA_FOLDER_PATH)

# load nifty reference
nifty_file_path = os.path.join(TICKER_CSV_DATA_FOLDER_PATH, '^NSEI.csvv')  # replace with NIFTY_CSV var if set
if 'NIFTY_CSV' in globals():
    nifty_file_path = os.path.join(TICKER_CSV_DATA_FOLDER_PATH, globals()['^NSEI.csv'])

nifty_df = pd.read_csv(nifty_file_path)
nifty_df.dropna(inplace=True)
nifty_rows = len(nifty_df)

# parse date strings robustly
def parse_date_str(s):
    s = str(s)
    for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S%z"):
        try:
            return datetime.strptime(s, fmt).date()
        except Exception:
            pass
    # fallback: try pandas
    try:
        return pd.to_datetime(s).date()
    except Exception:
        return None

nifty_start_date_obj = parse_date_str(nifty_df["Date"].iloc[0])
nifty_end_date_obj = parse_date_str(nifty_df["Date"].iloc[-1])

valid_tickers_files = []
for file in files_to_process:
    ticker_name = os.path.basename(file).replace(".csv", "")
    try:
        ticker_df = pd.read_csv(file)
    except Exception:
        continue

    # Clean and filter bad rows
    ticker_df.dropna(inplace=True)
    for c in ['Open','High','Low','Close']:
        if c in ticker_df.columns:
            ticker_df = ticker_df[ticker_df[c] != 0]

    # volume fallback
    if 'Volume' in ticker_df.columns:
        ticker_df['Volume'] = ticker_df['Volume'].replace(0, 1).fillna(1)

    ticker_df.reset_index(drop=True, inplace=True)
    ticker_df["Date"] = pd.to_datetime(ticker_df["Date"]).dt.date
    ticker_df = ticker_df[ticker_df["Date"] <= nifty_end_date_obj]

    # continuity & rows checks
    is_data_continuous = check_data_continuity(ticker_df)  # weekly gap check
    is_data_rows_equal = check_num_rows(ticker_df, nifty_df)  # daily rows check (>=)

    if (len(ticker_df) >= nifty_rows) and is_data_continuous:
        # good ticker
        valid_tickers_files.append(ticker_name)
        ticker_df.to_csv(file, index=False)
    else:
        # incomplete: remove file
        if os.path.exists(file):
            try:
                os.remove(file)
            except Exception:
                pass

# At this point `valid_tickers_files` is similar to original `valid_tickers` list
print("Total valid 15yr symbols:", len(valid_tickers_files))
try:
    post_telegram_message(f"Total valid 15yr weekly symbols: {len(valid_tickers_files)}")
except Exception:
    pass

# --- Load index constituents and compute custom indices (unchanged logic, called safely) ---
try:
    csv_path = '/home/rizpython236/BT5/trade-logs/index_constituents.csv'
    index_constituents = load_index_constituents_from_csv(csv_path)
    calculate_custom_index(TICKER_CSV_DATA_FOLDER_PATH, index_constituents, weighting_method='return_equal', valid_tickers=valid_tickers_files)
    # plotting (split into batches as you did before)
    TJI_IC_path = pd.read_csv('/home/rizpython236/BT5/trade-logs/TJI_index.csv')['Symbol'].tolist()
    index_csv_file = os.path.join(TICKER_CSV_DATA_FOLDER_PATH, "^NSEI.csv")
    # call the plotting in batches (your original calls)
    plot_index_close_prices(TICKER_CSV_DATA_FOLDER_PATH, TJI_IC_path[:33], index_csv_file, Frequency='Daily')
    plot_index_close_prices(TICKER_CSV_DATA_FOLDER_PATH, TJI_IC_path[33:], index_csv_file, Frequency='Daily')
    plot_index_close_prices(TICKER_CSV_DATA_FOLDER_PATH, TJI_IC_path[:], index_csv_file, Frequency='All200daily')
except Exception as e:
    print(f"Error occurred in index creation/plotting: {e}")
    traceback.print_exc()

# Save invalid and incomplete lists similar to your original script
invalid_tickers_df = pd.DataFrame({"invalid_ticker": invalid_tickers})
valid_tickers_df = pd.DataFrame({"Symbol": valid_tickers_files})
incomplete_data_tickers_df = pd.DataFrame({"Symbol": incomplete_data_tickers})

# You can persist these files where your environment expects them
# e.g.:
# invalid_tickers_df.to_csv(os.path.join(SCREENER_OUTPUT_FOLDER_PATH, INVALID_TICKERS_FILE), index=False)
# valid_tickers_df.to_csv(os.path.join(SCREENER_OUTPUT_FOLDER_PATH, "Valid15yr.csv"), index=False)
# incomplete_data_tickers_df.to_csv(os.path.join(SCREENER_OUTPUT_FOLDER_PATH, INCOMPLETE_TICKERS_CSV), index=False)

print("Script finished.")
