# refactored_final_builder.py
import io
import os
import re
import time
import traceback
from pathlib import Path

import pandas as pd
import requests
from requests.adapters import HTTPAdapter, Retry
from bs4 import BeautifulSoup  # pip install beautifulsoup4

from settings import (
    EXCLUDE_TICKERS_CSV,
    INCLUDE_TICKERS_CSV,
    MAX_RETRIES,
    NSE_NIFTY_500_URL,
    NSE_MICROCAP_250_URL,
    SYMBOLS_CSV,
)
from telegram_bot import post_telegram_message
from add_company_name import add_company_names_and_industry, vlookup_and_merge, update_output_file, copyfile1

# ---- Paths ----
BASE = Path("/home/rizpython236/BT5")
FINAL_CSV = BASE / "Final.csv"
NEW_TICKERS_CSV = BASE / "trade-logs" / "new_tickers.csv"
BSE_CSV = BASE / "Equity.csv"
NSE_CSV = BASE / "nse.csv"
DELISTED_LOCAL = BASE / "Companies_proposed_to_be_delisted_list_2.xlsx"
DELISTED_OUT = BASE / "trade-logs" / "Companies_proposed_to_be_delisted_list_2.xlsx"
FINAL_ISIN_CSV = BASE / "trade-logs" / "FinalISIN.csv"
SYMBOLS_OUT = BASE / "trade-logs" / "fullbsenseFinal.csv"

# ---- Load include/exclude lists ----
include_tickers = pd.read_csv(INCLUDE_TICKERS_CSV, dtype=str)
include_list = include_tickers["Symbol"].dropna().astype(str).unique().tolist()
exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV, dtype=str)
exclude_set = set(exclude_tickers["Symbol"].dropna().astype(str).unique().tolist())

# ---- Load Final.csv and new_tickers.csv (existing) ----
Final111 = pd.read_csv(FINAL_CSV, dtype=str) if FINAL_CSV.exists() else pd.DataFrame(columns=["Symbol"])
new_tickers = pd.read_csv(NEW_TICKERS_CSV, dtype=str) if NEW_TICKERS_CSV.exists() else pd.DataFrame(columns=["FULLSymbol"])

# ---- Helper: robust requests session with retries ----
session = requests.Session()
retries = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504], allowed_methods=["GET", "POST"])
session.mount("https://", HTTPAdapter(max_retries=retries))
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
})

# ---- Attempt to obtain "proposed to be delisted" file ----
delisted = pd.DataFrame()
# prefer local copy if available
if DELISTED_LOCAL.exists():
    try:
        delisted = pd.read_excel(DELISTED_LOCAL)
        if "Symbol" in delisted.columns:
            delisted["Symbol"] = delisted["Symbol"].astype(str)
        print("Loaded local delisted file:", DELISTED_LOCAL)
        copyfile1(str(DELISTED_LOCAL), str(DELISTED_OUT))
        post_telegram_message("NSE_proposed_to_be_delisted loaded from local file")
    except Exception as exc:
        print("Failed to read local delisted file:", exc)
        delisted = pd.DataFrame()
else:
    # try to fetch the page and find an xlsx link
    try:
        page_url = "https://www.nseindia.com/regulations/list-of-companies-proposed-to-be-delisted"
        resp = session.get(page_url, timeout=15)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")

        # look for links pointing to .xlsx/.xls or files containing 'delisted' text
        link = None
        for a in soup.find_all("a", href=True):
            href = a["href"]
            if href.lower().endswith((".xlsx", ".xls", ".csv")) or "delist" in href.lower() or "delisted" in href.lower():
                link = href
                break

        if link:
            if link.startswith("/"):
                link = "https://www.nseindia.com" + link
            dl_resp = session.get(link, timeout=20)
            dl_resp.raise_for_status()
            # try read into pandas
            try:
                if link.lower().endswith(".csv"):
                    delisted = pd.read_csv(io.StringIO(dl_resp.text))
                else:
                    # excel bytes
                    delisted = pd.read_excel(io.BytesIO(dl_resp.content))
                if "Symbol" in delisted.columns:
                    delisted["Symbol"] = delisted["Symbol"].astype(str)
                copyfile1(str(DELISTED_LOCAL), str(DELISTED_OUT)) if DELISTED_LOCAL.exists() else None
                post_telegram_message("NSE_proposed_to_be_delisted downloaded")
                print("Downloaded delisted file from:", link)
            except Exception:
                print("Downloaded file could not be parsed as CSV/XLSX.")
                delisted = pd.DataFrame()
        else:
            print("No delisted link found on page.")
    except Exception as exc:
        print("Failed to fetch delisted page:", exc)
        traceback.print_exc()
        delisted = pd.DataFrame()

# ---- Load BSE file (with retry attempts similar to your original) ----
bse = pd.DataFrame()
bse_attempts = 0
while bse_attempts < 3 and bse.empty:
    try:
        import bse_ticker_download
        bse = pd.read_csv(BSE_CSV, dtype=str)
        print("Loaded BSE file.")
    except Exception as exc:
        bse_attempts += 1
        print(f"BSE load attempt {bse_attempts} failed:", exc)
        time.sleep(1)
        if bse_attempts >= 3:
            print("Giving up on re-downloading BSE. Proceeding with whatever we have (empty).")

# ---- Download NSE symbol list (robust) ----
download_successful = False
nse_attempts = 0
nse_url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
while nse_attempts < 3 and not download_successful:
    try:
        r = session.get(nse_url, timeout=15)
        r.raise_for_status()
        text = r.text
        if "Access Denied" in text:
            print("Access Denied returned by NSE. Will fallback to local copy.")
            download_successful = False
            break
        datanse = pd.read_csv(io.StringIO(text), dtype=str)
        datanse.to_csv(NSE_CSV, index=False)
        download_successful = True
        print("NSE CSV downloaded and saved.")
    except Exception as exc:
        nse_attempts += 1
        print(f"NSE download attempt {nse_attempts} failed:", exc)
        time.sleep(2)

if not download_successful:
    # fallback to existing local file if available
    if NSE_CSV.exists():
        datanse = pd.read_csv(NSE_CSV, dtype=str)
        print("Loaded NSE from local CSV fallback.")
    else:
        datanse = pd.DataFrame()
        print("No NSE data available; datanse is empty.")

# ---- Data cleaning and vectorized processing ----
# Safely drop columns if present
drop_bse_cols = [c for c in [
    "Industry", "Instrument", "Sector Name", "Industry New Name", "Igroup Name", "ISubgroup Name"
] if c in bse.columns]
if drop_bse_cols:
    bse = bse.drop(columns=drop_bse_cols)

drop_nse_cols = [c for c in [" SERIES", " DATE OF LISTING", " PAID UP VALUE", " MARKET LOT", " FACE VALUE"] if c in datanse.columns]
if drop_nse_cols:
    datanse = datanse.drop(columns=drop_nse_cols)

# Rename columns for BSE to standard names
if "Security Id" in bse.columns:
    bse = bse.rename(columns={"Security Id": "SYMBOL"})
if "Security Name" in bse.columns:
    bse = bse.rename(columns={"Security Name": "NAME OF COMPANY"})

# Filter active BSE securities if Status column exists
if "Status" in bse.columns:
    bse = bse[bse["Status"].astype(str).str.strip().eq("Active")]

# Remove rows containing ETF/FUND keywords in name (vectorized)
if "NAME OF COMPANY" in bse.columns:
    bse = bse[~bse["NAME OF COMPANY"].astype(str).str.contains("|".join(["ETF", "EXCHANGE TRADED", "FUND", "Fund"]), na=False)]

# strip trailing '*' from SYMBOLs
if "SYMBOL" in bse.columns:
    bse["SYMBOL"] = bse["SYMBOL"].astype(str).str.rstrip("*")

# Filter groups similar to your logic
if "Group" in bse.columns:
    unique_groups = pd.Series(bse["Group"].dropna().unique()).astype(str).tolist()
    to_remove = {"P", "ZP", "IP", "Y"}
    accepted_groups = [g for g in unique_groups if g not in to_remove]
    if accepted_groups:
        bse = bse[bse["Group"].isin(accepted_groups)]

# Merge NSE & BSE on ISIN (if columns exist)
isin_col_nse = next((c for c in datanse.columns if "ISIN" in c.upper()), None)
isin_col_bse = next((c for c in bse.columns if "ISIN" in c.upper()), None)
if isin_col_nse:
    datanse = datanse.rename(columns={isin_col_nse: "ISIN_NSE"})
if isin_col_bse:
    bse = bse.rename(columns={isin_col_bse: "ISIN_BSE"})

if "ISIN_NSE" in datanse.columns and "ISIN_BSE" in bse.columns:
    datansebse = pd.merge(datanse, bse, left_on="ISIN_NSE", right_on="ISIN_BSE", how="right")
else:
    datansebse = pd.DataFrame()

# Remove common ISINs (present both sides) from bse similar to original
if "ISIN_BSE" in bse.columns and "ISIN_NSE" in datanse.columns:
    common_isins = bse[bse["ISIN_BSE"].isin(datanse["ISIN_NSE"])]
    if not common_isins.empty:
        bse = bse[~bse["ISIN_BSE"].isin(common_isins["ISIN_BSE"])]

# Add suffixes vectorized
if "SYMBOL" in bse.columns:
    bse["SYMBOL"] = bse["SYMBOL"].astype(str) + ".BO"
if "SYMBOL" in datanse.columns:
    datanse["SYMBOL"] = datanse["SYMBOL"].astype(str) + ".NS"

# Concatenate, keep only SYMBOL column for final list
parts = []
if "SYMBOL" in bse.columns:
    parts.append(bse[["SYMBOL"]])
if "SYMBOL" in datanse.columns:
    parts.append(datanse[["SYMBOL"]])

if parts:
    result = pd.concat(parts, axis=0, ignore_index=True).drop_duplicates().reset_index(drop=True)
    result = result.rename(columns={"SYMBOL": "Symbol"})
else:
    result = pd.DataFrame(columns=["Symbol"])

# Add include tickers not already present
missing_includes = [s for s in include_list if s not in set(result["Symbol"].astype(str))]
if missing_includes:
    result = pd.concat([result, pd.DataFrame({"Symbol": missing_includes})], ignore_index=True).drop_duplicates().reset_index(drop=True)

# Remove excluded tickers (vectorized)
if not result.empty and exclude_set:
    result = result[~result["Symbol"].isin(exclude_set)]

# Remove delisted symbols if we have a delisted DataFrame and it contains a Symbol column
if not delisted.empty and "Symbol" in delisted.columns:
    delisted_syms = set(delisted["Symbol"].astype(str).tolist())
    result = result[~result["Symbol"].isin(delisted_syms)]

# Append explicit extra symbols in one shot (vectorized)
extra_symbols = [
    '^NSEI', '^NSEBANK', '^CRSLDX', '^NSEMDCP50', 'MON100.NS', 'MAFANG.NS', 'MAHKTECH.NS', 'SBIGETS.BO',
    'AXISCETF.NS', 'ICICIINFRA.NS', '^CNXCMDT', '^CNXINFRA', '^CNXAUTO', '^CNXPHARMA', '^CNXPSUBANK',
    '^CNXIT', '^CNXCONSUM', 'NIFTYPVTBANK.NS', '^CNXMETAL', '^CNXREALTY', '^CNXENERGY', '^CNXFMCG',
    'NIFTYSMLCAP250.NS', 'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'NIFTY_FIN_SERVICE.NS'
]
result = pd.concat([result, pd.DataFrame({"Symbol": extra_symbols})], ignore_index=True).drop_duplicates().reset_index(drop=True)

# Filter out '-RE' and 'DUMMY' in Symbol
if not result.empty:
    result = result[~result["Symbol"].astype(str).str.contains(r"-RE\.|DUMMY", na=False)]

# Save Final.csv (overwrite)
result.to_csv(FINAL_CSV, index=False)
print("Final symbol list saved to:", FINAL_CSV)

post_telegram_message(message=f"Found {len(result)} tickers in final Symbol list")
print("Found {} tickers in previous Final.csv".format(len(Final111)))
print("Found {} tickers in final Symbol list".format(len(result)))

# ---- Discover new tickers (set difference) ----
result_set = set(result["Symbol"].astype(str))
Final111_set = set(Final111["Symbol"].astype(str)) if not Final111.empty else set()
new_tickers_set = set(new_tickers["FULLSymbol"].astype(str)) if not new_tickers.empty and "FULLSymbol" in new_tickers.columns else set()

items_not_in_Final111 = result_set - Final111_set - new_tickers_set
if items_not_in_Final111:
    items_msg = ", ".join(sorted(items_not_in_Final111))
    print("New items not in Final111:", items_msg)
    post_telegram_message(message=items_msg)
else:
    print("No new items found vs Final111 and existing new_tickers.")

# ---- Append new items to new_tickers.csv (de-duplicated) ----
try:
    if NEW_TICKERS_CSV.exists():
        existing_tickers_df = pd.read_csv(NEW_TICKERS_CSV, dtype=str)
    else:
        existing_tickers_df = pd.DataFrame(columns=["FULLSymbol"])

    new_tickers_df = pd.DataFrame(sorted(items_not_in_Final111), columns=["FULLSymbol"])
    if not new_tickers_df.empty:
        merged_df = pd.concat([existing_tickers_df, new_tickers_df], ignore_index=True)
    else:
        merged_df = existing_tickers_df.copy()

    # ensure columns exist used in dedupe; keep NSE750 if present else create empty col
    if "NSE750" not in merged_df.columns:
        merged_df["NSE750"] = merged_df.get("NSE750", "")

    merged_df["FULLSymbol"] = merged_df["FULLSymbol"].astype(str)
    merged_df["NSE750"] = merged_df["NSE750"].astype(str)

    merged_df = merged_df.drop_duplicates(subset=["FULLSymbol"], keep="first").reset_index(drop=True)
    merged_df.to_csv(NEW_TICKERS_CSV, index=False)
    print("Updated new_tickers.csv with new entries.")
except Exception as exc:
    print("Failed to update new_tickers.csv:", exc)
    traceback.print_exc()

# ---- Run post-processing modules (as in original) ----
time.sleep(1)
try:
    import holding_unique  # noqa: F401
    import filtersymbols  # noqa: F401
    import ISINbsense  # noqa: F401
    print("Imported post-processing modules.")
except Exception as exc:
    print("Post-processing module import failed:", exc)

# ---- Final: print and exit ----
import symbol_copy  # noqa: F401
print("Ticker download operation finished successfully!")
post_telegram_message("Ticker download operation finished successfully!")
