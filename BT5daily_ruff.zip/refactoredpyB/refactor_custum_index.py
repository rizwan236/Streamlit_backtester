
import os
import pytz
import sys
#sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages')
import pandas as pd
import numpy as np
import traceback
from telegram_bot import post_telegram_message,post_telegram_file
import time
import numpy as np
#print(f"Pandas version: {pd.__version__}")
#print(f"Numpy version: {np.__version__} ")
#from scipy.stats import gmean
import talib as tb
from datetime import date, datetime, timedelta
#import sys
sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")
import yfinance as yf
from refactor_functions import manage_zip
#import zipfile
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from settings import (
    INVALID_TICKERS_FILE,
    SCREENER_OUTPUT_FOLDER_PATH,
    TICKER_CSV_DATA_FOLDER_PATH,
    NIFTY_CSV,
    SYMBOLS_CSV,
    VALID_TICKERS_CSV,
    INCOMPLETE_TICKERS_CSV,
)


TICKER_CSV_DATA_FOLDER_PATH = "/home/rizpython236/BT5/ticker_15yr"


def load_index_constituents_from_csv(csv_path):
    """
    Load index constituents and their weights from a CSV file.
    Ensures total weights for each index sum to exactly 1.0.

    Parameters:
    - csv_path: Path to the CSV file containing index constituents and weights.

    Returns:
    - A dictionary mapping index names to {stock: weight} dictionaries.
    """

    # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_path)

    # Drop the 'Long_Name' column if it exists, as it is not needed for weight calculations
    if "Long_Name" in df.columns:
        df.drop("Long_Name", axis=1, inplace=True)

    # Identify columns containing stock symbols (Stock1, Stock2, etc.)
    stock_cols = [col for col in df.columns if col.startswith("Stock") and "weight" not in col]

    # Generate corresponding weight column names (e.g., 'Stock1 weight')
    weight_cols = [f"{col} weight" for col in stock_cols]

    # Transform the stock columns into a long format (one row per stock per index)
    df_stocks = df.melt(
        id_vars=['Index', 'Default Stock'],  # Columns to keep
        value_vars=stock_cols,               # Columns to unpivot
        var_name='StockNum',                 # Name for the temporary stock column number
        value_name='Stock'                   # Name for the stock symbol column
    )

    # Transform the weight columns into a long format to match the stocks
    df_weights = df.melt(
        id_vars=['Index', 'Default Stock'],
        value_vars=weight_cols,
        var_name='StockNum',   # Must match the df_stocks order
        value_name='Weight'
    )

    # Combine the melted stocks and weights into a single DataFrame
    df_long = pd.concat(
        [df_stocks['Index'], df_stocks['Default Stock'], df_stocks['Stock'], df_weights['Weight']],
        axis=1
    )

    # Remove rows where the stock symbol is missing
    df_long = df_long[df_long['Stock'].notna()]

    # Initialize the dictionary that will store index constituents
    index_constituents = {}

    # Group by 'Index' to process each index individually
    for index_name, group in df_long.groupby('Index'):
        # Create a dictionary mapping stock symbols to weights
        constituents = dict(zip(group['Stock'], group['Weight']))

        # Get the default stock for the index
        default_stock = group['Default Stock'].iloc[0]

        # Calculate the sum of all weights
        total_weight = sum(constituents.values())

        # If total weight exceeds 1.0, scale all weights proportionally
        if total_weight > 1.0:
            scale_factor = 1.0 / total_weight
            constituents = {k: round(v * scale_factor, 6) for k, v in constituents.items()}
            total_weight = sum(constituents.values())  # Recalculate total weight after scaling

        # Calculate any remaining weight to reach exactly 1.0
        remainder = round(1.0 - total_weight, 6)

        # Add the remainder to the default stock, if specified
        if remainder > 0:
            if pd.notna(default_stock):
                if default_stock in constituents:
                    constituents[default_stock] += remainder
                else:
                    constituents[default_stock] = remainder
            else:
                print(f"Warning: Default stock not specified for index {index_name}, remainder {remainder} ignored.")

        # Round all final weights for numerical stability
        constituents = {k: round(v, 6) for k, v in constituents.items()}

        # Add the index and its constituents to the final dictionary
        index_constituents[index_name] = constituents

    # Return the dictionary containing all index constituents
    return index_constituents



def calculate_custom_index(folder_path, index_constituents, weighting_method='return_equal', valid_tickers=None):
    """
    Calculate custom indices based on stock data stored in CSV files.
    Each index is normalized to start at 1000 and evolves based on chosen weighting method.

    Parameters:
    - folder_path (str): Path to the folder containing stock CSV files.
    - index_constituents (dict): {index_name: {stock_symbol: weight}} mapping.
    - weighting_method (str): Method to calculate the index:
        'price'        → Price-weighted index (Dow Jones style).
        'Price_equal'  → Normalize each stock, then average (equal price weighting).
        'return_equal' → Equal-weighted returns-based index.
        'custom'       → Use weights specified in index_constituents.
        'ATR'          → Weights based on Average True Range (volatility measure).
        'RSI'          → Weights based on Relative Strength Index.
    - valid_tickers (list, optional): If provided, appends successfully created index names.

    Returns:
    - None (saves index CSV files to folder_path, sends missing ticker info via Telegram).
    """

    errorlist = []  # Track missing or invalid tickers

    # Helper: toggle NSE (.NS) <-> BSE (.BO) suffix if file missing
    def change_stock_suffix(stock):
        if stock.endswith('.NS'):
            return stock[:-3] + '.BO'
        elif stock.endswith('.BO'):
            return stock[:-3] + '.NS'
        else:
            return stock

    # Iterate through each index and its constituent stocks
    for index_name, constituents in index_constituents.items():
        combined_data = pd.DataFrame()  # Store all stock data for this index

        # Load data for each stock
        for stock, weight in constituents.items():
            file_name = f"{stock}.csv"
            file_path = os.path.join(folder_path, file_name)

            # If file not found, try alternate suffix
            if not os.path.exists(file_path):
                chgstock = change_stock_suffix(stock)
                file_name = f"{chgstock}.csv"
                file_path = os.path.join(folder_path, file_name)

                if not os.path.exists(file_path):
                    errorlist.append(stock)
                    print(f"File {file_path} not found. Skipping {stock}.")
                    continue

            # Read CSV into DataFrame
            stock_data = pd.read_csv(file_path)
            stock_data['Stock'] = stock  # Add stock identifier
            combined_data = pd.concat([combined_data, stock_data], axis=0)

        # Skip if no data collected
        if combined_data.empty or stock_data.empty:
            continue

        # Ensure numeric columns are properly typed
        for col in ['Open', 'High', 'Low', 'Close', 'Volume']:
            if col in combined_data.columns:
                combined_data[col] = pd.to_numeric(combined_data[col], errors='coerce')
            else:
                print(f"Column '{col}' missing from {index_name} data.")

        try:
            # -----------------------
            # 1. Price-weighted index
            # -----------------------
            if weighting_method == 'price':
                def calculate_price_weighted_index(group, price_column):
                    total_price = group[price_column].sum()
                    weights = group[price_column] / total_price
                    return (group[price_column] * weights).sum()

                index_data = combined_data.groupby('Date').agg({
                    'Close': lambda x: calculate_price_weighted_index(x, 'Close'),
                    'High': lambda x: calculate_price_weighted_index(x, 'High'),
                    'Low':  lambda x: calculate_price_weighted_index(x, 'Low'),
                    'Open': lambda x: calculate_price_weighted_index(x, 'Open'),
                    'Volume': 'sum'
                }).reset_index()

            # ----------------------------
            # 2. Equal (price normalized)
            # ----------------------------
            elif weighting_method == 'Price_equal':
                def normalize_group(group):
                    """ Scale each stock’s price to start at 1000. """
                    for column in ['Open', 'High', 'Low', 'Close']:
                        base_value = group[column].iloc[0]
                        group[column] = (group[column] / base_value) * 1000
                    return group

                combined_data = combined_data[~combined_data['Stock'].str.startswith("^NSEI")]
                combined_data = combined_data.groupby('Stock').apply(normalize_group)

                index_data = combined_data.groupby('Date').agg({
                    'Open': 'mean', 'High': 'mean',
                    'Low': 'mean',  'Close': 'mean',
                    'Volume': 'sum'
                }).reset_index()

            # -------------------------
            # 3. Equal-weighted returns
            # -------------------------
            elif weighting_method == 'return_equal':
                # Compute % returns
                for column in ['Open', 'High', 'Low', 'Close']:
                    combined_data[f'{column}_Return'] = combined_data.groupby('Stock')[column].pct_change()

                # Fill missing returns
                combined_data[['Open_Return', 'High_Return', 'Low_Return', 'Close_Return']] = (
                    combined_data[['Open_Return', 'High_Return', 'Low_Return', 'Close_Return']].fillna(0.0001)
                )

                combined_data = combined_data[~combined_data['Stock'].str.startswith("^NSEI")]
                num_stocks = combined_data['Stock'].nunique()

                if num_stocks == 0:
                    print(f"No valid stocks for {index_name}, skipping.")
                    continue

                combined_data['Weight'] = 1 / num_stocks  # Equal weights

                # Weighted returns
                for column in ['Open', 'High', 'Low', 'Close']:
                    combined_data[f'{column}_Weighted_Return'] = combined_data[f'{column}_Return'] * combined_data['Weight']

                # Aggregate by date
                index_data = combined_data.groupby('Date').agg({
                    'Open_Weighted_Return': 'sum',
                    'High_Weighted_Return': 'sum',
                    'Low_Weighted_Return': 'sum',
                    'Close_Weighted_Return': 'sum',
                    'Volume': 'sum'
                }).reset_index()

                # Rename
                index_data.rename(columns={
                    'Open_Weighted_Return': 'Open',
                    'High_Weighted_Return': 'High',
                    'Low_Weighted_Return': 'Low',
                    'Close_Weighted_Return': 'Close'
                }, inplace=True)

                # Rebase to 1000
                for col in ['Open', 'High', 'Low', 'Close']:
                    index_data[col] = 1000 * (1 + index_data[col]).cumprod()

            # -------------------------
            # 4. Custom-weighted index
            # -------------------------
            elif weighting_method == 'custom':
                def calculate_custom_weighted_index(group, price_column):
                    weighted_sum = 0
                    for stock, weight in constituents.items():
                        stock_data = group[group['Stock'] == stock]
                        if not stock_data.empty:
                            weighted_sum += stock_data[price_column].iloc[0] * weight
                    return weighted_sum

                index_data = combined_data.groupby('Date').apply(
                    lambda g: pd.Series({
                        'Open':  calculate_custom_weighted_index(g, 'Open'),
                        'High':  calculate_custom_weighted_index(g, 'High'),
                        'Low':   calculate_custom_weighted_index(g, 'Low'),
                        'Close': calculate_custom_weighted_index(g, 'Close'),
                        'Volume': g['Volume'].sum()
                    })
                ).reset_index()

            # -------------------------
            # 5. ATR-weighted index
            # -------------------------
            elif weighting_method == 'ATR':
                def calculate_atr(data, period=14):
                    """ Average True Range (volatility measure). """
                    high, low, close = data['High'], data['Low'], data['Close']
                    tr = pd.concat([
                        abs(high - low),
                        abs(high - close.shift()),
                        abs(low - close.shift())
                    ], axis=1).max(axis=1)
                    return tr.rolling(window=period, min_periods=1).mean()

                def create_atr_weighted_index(data, atr_period=14):
                    data = data[~data['Stock'].str.startswith("^NSEI")]
                    data['ATR'] = data.groupby('Stock').apply(
                        lambda x: calculate_atr(x, atr_period)
                    ).reset_index(level=0, drop=True)

                    # Hybrid weighting: 60% ATR + 40% inverse ATR
                    data['Weight'] = 0.6 * data['ATR'] + 0.4 * (1 / data['ATR'])
                    data['Weight'] = data['Weight'].replace([float('inf'), -float('inf')], 0)
                    data['Weight'] = data.groupby('Date')['Weight'].apply(lambda x: x / x.sum())

                    return data.groupby('Date').apply(
                        lambda g: pd.Series({
                            'Open': (g['Open'] * g['Weight']).sum(),
                            'High': (g['High'] * g['Weight']).sum(),
                            'Low':  (g['Low']  * g['Weight']).sum(),
                            'Close': (g['Close'] * g['Weight']).sum(),
                            'Volume': g['Volume'].sum()
                        })
                    ).reset_index()

                index_data = create_atr_weighted_index(combined_data)

            # -------------------------
            # 6. RSI-weighted index
            # -------------------------
            elif weighting_method == 'RSI':
                def calculate_rsi(data, period=21, column='Close'):
                    delta = data[column].diff()
                    gain = delta.where(delta > 0, 0).rolling(period, min_periods=1).mean()
                    loss = -delta.where(delta < 0, 0).rolling(period, min_periods=1).mean()
                    rs = gain / loss
                    return 100 - (100 / (1 + rs))

                def create_rsi_weighted_index(data, rsi_period=21):
                    data = data[~data['Stock'].str.startswith("^NSEI")]
                    data['RSI'] = data.groupby('Stock')[['Close']].apply(
                        lambda x: calculate_rsi(x, period=rsi_period)
                    ).reset_index(level=0, drop=True)

                    # Weighting: higher near 50, lower near extremes
                    data['Weight'] = data['RSI'].apply(
                        lambda x: 1 - abs((x - 50) / 50) if 30 <= x <= 70 else 0.1
                    )
                    data['Weight'] = data.groupby('Date')['Weight'].apply(lambda x: x / x.sum())

                    return data.groupby('Date').apply(
                        lambda g: pd.Series({
                            'Open': (g['Open'] * g['Weight']).sum(),
                            'High': (g['High'] * g['Weight']).sum(),
                            'Low':  (g['Low']  * g['Weight']).sum(),
                            'Close': (g['Close'] * g['Weight']).sum(),
                            'Volume': g['Volume'].sum()
                        })
                    ).reset_index()

                index_data = create_rsi_weighted_index(combined_data)

            else:
                raise ValueError(f"Invalid weighting method: {weighting_method}")

            # -------------------------
            # Normalize index to 1000
            # -------------------------
            for column in ['Open', 'High', 'Low', 'Close']:
                first_value = index_data[column].iloc[0]
                index_data[column] = round((index_data[column] / first_value) * 1000, 2)

            # Save results
            if valid_tickers is not None:
                valid_tickers.append(index_name)
            output_file = os.path.join(folder_path, f'{index_name}.csv')
            index_data.to_csv(output_file, index=False)
            print(f"Index saved to {output_file}")

        except Exception as e:
            print(f"Error in {index_name}: {e}")
            traceback_str = traceback.format_exc()
            #print(traceback_str)  # Uncomment if debugging
            continue

    # Report missing tickers
    print(errorlist)
    post_telegram_message(f"Missing TJI Tickers: {', '.join(errorlist)}")



'''
# Example usage:
# Load index constituents from a CSV file
csv_path = '/home/rizpython236/BT5/trade-logs/index_constituents.csv'
index_constituents = load_index_constituents_from_csv(csv_path)
path=  '/home/rizpython236/BT5/ticker_15yr'
# Calculate indices
valid_tickers = []
calculate_custom_index(path, index_constituents, weighting_method='return_equal', valid_tickers=valid_tickers) #Choose 'price', 'Price_equal', return_equal or 'custom'." RSI  ATR
'''
#______________________________

def plot_index_close_prices(folder_path, index_names, index_csv_file, Frequency=None):
    """
    Plot multiple indices' MRP in a single chart using vectorized operations for speed.
    """

    # --- Load benchmark (Nifty) ---
    nifty = pd.read_csv(index_csv_file, usecols=['Date', 'Close'])
    nifty['Date'] = pd.to_datetime(nifty['Date'])

    freq_map = {"Wk": 52, "Daily": 252, "All52wk": 52, "All200daily": 252}
    if Frequency in freq_map:
        nifty = nifty[-freq_map[Frequency]:]

    nifty['Nifty50'] = nifty['Close'] / nifty['Close'].iloc[0]
    nifty.set_index('Date', inplace=True)

    # --- Load index name mapping ---
    constituents = pd.read_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv')
    Index_to_Longname = dict(zip(constituents['Symbol'], constituents['Company']))

    # --- Prepare plot ---
    plt.figure(figsize=(22, 18))
    plt.title("Comparison of Index MRP levels")
    plt.xlabel("Date")
    plt.ylabel("Close MRP (Indexed to 1)")
    plt.grid(True)
    colors = ['yellow', 'red', 'blue', 'green', 'purple', 'orange', 'brown', 'teal',
              'fuchsia', 'gold', 'darkcyan', 'limegreen', 'magenta', 'pink', 'grey']
    line_styles = ['-', '--', '-.', ':']

    # --- Plot benchmark Nifty ---
    plt.plot(nifty.index, nifty['Nifty50'], linestyle='--', color='black', label='Nifty50')

    no = 0
    for index_name in index_names:
        file_path = os.path.join(folder_path, f"{index_name}.csv")
        if not os.path.exists(file_path):
            print(f"File {file_path} not found. Skipping.")
            continue

        # --- Load index data ---
        idx = pd.read_csv(file_path)
        idx['Date'] = pd.to_datetime(idx['Date'])
        if Frequency in freq_map:
            idx = idx[-freq_map[Frequency]:]
        idx.set_index('Date', inplace=True)

        # --- Vectorized returns & cumulative returns ---
        idx['returns'] = idx['Close'].pct_change()
        idx['cumreturns'] = (1 + idx['returns']).cumprod()
        idx = idx.join(nifty['Nifty50'], how='inner', rsuffix='_nifty')
        idx['MRP'] = (idx['cumreturns'] / idx['Nifty50']).ffill()

        # --- Indicators ---
        idx['RSI'] = tb.RSI(idx['Close'], timeperiod=14)
        idx['CCI'] = tb.CCI(idx['High'], idx['Low'], idx['Close'], timeperiod=34)

        # --- Skip indices not meeting conditions ---
        last = idx.iloc[-1]
        if ((last['MRP'] > last['Nifty50'] * 1.1 and last['RSI'] > 55 and last['CCI'] > 10) or
            (last['MRP'] < last['Nifty50'] and last['RSI'] < 45 and last['CCI'] < 10)):

            long_name = f"{Index_to_Longname.get(index_name, index_name)}_{round(last['MRP'],3)}"
            color = colors[no % len(colors)]
            linestyle = line_styles[no % len(line_styles)]
            plt.plot(idx.index, idx['MRP'], label=long_name, color=color, linestyle=linestyle)
            plt.text(idx.index[-1], last['MRP'], long_name, fontsize=11, color=color,
                     va='baseline', ha='left', backgroundcolor='white')
            no += 1
        else:
            print(f"Index {index_name} skipped. MRP={last['MRP']}")

    # --- Finalize plot ---
    plt.legend(ncol=2, loc='upper left', fontsize=16)
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=1))
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    plt.xticks(rotation=90, ha='right')
    plt.tight_layout()

    chart_path = os.path.join(folder_path, f'TJI_Indices_{Frequency if Frequency else "All"}.png')
    plt.savefig(chart_path)
    time.sleep(3)
    post_telegram_file(chart_path)
    os.remove(chart_path)


# Example usage:
# Define the index names to plot
TJI_IC_path = '/home/rizpython236/BT5/trade-logs/TJI_index.csv'
TJI_IC_path = pd.read_csv(TJI_IC_path)
TJI_IC_path = TJI_IC_path['Symbol'].tolist()[:]
#TJI_IC_path = list(set(TJI_IC_path))
index_names = []
TJI_IC_path.extend(index_names)

#index_names = ['TJI_AVTN', 'TJI_RTGAGY']
path=  '/home/rizpython236/BT5/ticker_15yr'
index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

# Plot the Close Prices of the indices

#plot_index_close_prices(path, TJI_IC_path[:33],index_csv_file,Frequency='Daily') # Wk Daily All52wk All200daily Allfull
#plot_index_close_prices(path, TJI_IC_path[33:],index_csv_file,Frequency='Daily') # Wk Daily All52wk All200daily Allfull
#plot_index_close_prices(path, TJI_IC_path[:],index_csv_file,Frequency='All200daily') # Wk Daily All52wk All200daily Allfull



def calculate_momentum(data, lookback_period=12, column='Close'):
    """
    Calculate momentum as the percentage change in price over a lookback period.
    """
    momentum = data[column].pct_change(periods=lookback_period)
    return momentum


def download_ticker_data(tickers_list=None,TICKER_CSV_DATA_FOLDER_PATH=None):


    try:
        count =0
        IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
        end_date = datetime.now(IST_TIMEZONE).date() #- timedelta(weeks=2)
        #start_date = end_date - timedelta(weeks=77) #77 weekly  52+12 64
        start_date = end_date - timedelta(weeks=52+8)
        END_DATE = str(end_date)
        START_DATE = str(start_date)
        print(f"start date {START_DATE} ,end date {END_DATE}.")
        additional_tickers = []
        tickers_list.extend(additional_tickers)
        #tickers_list = additional_tickers + tickers_list
        for symbol in tickers_list:
            count +=1
            if count % 200 == 0:
                print(f"Processed {count} symbols. Pausing for 5 minutes...")
                time.sleep(4*60)  # 600 seconds = 10 minutes

            #print("Downloading data for => {}".format(symbol))
            data = yf.download(
                symbol,
                start=START_DATE,
                end=END_DATE,
                interval="1d" , #1wk "1d"
                rounding=True,
                threads=True,
                multi_level_index=False,
                progress=False,
                back_adjust=True,
                repair=False,  # Data repair is used to fill in missing or corrupted data
                keepna=False,  # removes any rows with missing data.
                actions=False,  #excludes dividend and stock split events from the dat
                auto_adjust=True  #adjusted for corporate actions like stock splits and dividends
                #ignore_tz=True
            )


            ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
            if len(data) > 277:
                #print(data.column)
                #print(data)
                # Strip spaces from column names
                #data.columns = data.columns.str.strip()
                #Convert the 'Date' column to datetime and remove the time part
                #data[0] = pd.to_datetime(data[0]).dt.date
                data.index = data.index.date
                data.rename_axis("Date", inplace=True)
                ##data["Date"] = pd.to_datetime(data["Date"]).dt.date
                data.to_csv(ticker_csv_file_path)
                #print(data)
            time.sleep(0.10)


    except Exception as e:
        print(f"Error processing download_ticker_data: {str(e)}")
        traceback_str = traceback.format_exc()
        print(traceback_str)




import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates
import talib as tb


def addchartspdf(screenercsv_path=None, folder_path=None, filepathpdf=None):
    try:
        screener_BTouputtickers = []
        if screenercsv_path =='/home/rizpython236/BT5/trade-logs/screener-output.csv':
            data = pd.read_csv(screenercsv_path)
            screener_BTouputtickers = data['ticker'].tolist()
            #screener_BTouputtickers =["INFY","LOTUSEYE.NS","MARUTI.NS"]
            #screener_BTouputtickers =  data[data['dir'] == 'BUY']['ticker'].tolist()
            # Sort the DataFrame by 'dir' (BUY first) and then by 'ticker'
            #screener_BTouputtickers = data.sort_values(by=['signal', 'ticker'])
            # Extract all tickers in order (BUY followed by SELL)
            #screener_BTouputtickers = screener_BTouputtickers['ticker'].tolist()
        elif screenercsv_path =='/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv':
            data = pd.read_csv(screenercsv_path)
            screener_BTouputtickers =  data[data['dir'] == 'BUY']['ticker'].tolist()
            #screener_BTouputtickers = data['ticker'].tolist()
        else:
            raise ValueError("Invalid screener CSV path provided.")



        print(screener_BTouputtickers)
        #print(screenercsv_path)
        #print(folder_path)
        #print(filepathpdf)
        manage_zip("unzip")


        for ticker in screener_BTouputtickers:
            file_path = os.path.join(folder_path, f"{ticker}.csv")

            if os.path.exists(file_path):
                # File already exists
                print(f"✅ Found: {ticker}.csv")
            else:
                # File missing → download
                print(f"⬇️ Downloading missing ticker: {ticker}")
                download_ticker_data(
                    tickers_list=[ticker],
                    TICKER_CSV_DATA_FOLDER_PATH=TICKER_CSV_DATA_FOLDER_PATH
                )

        #for file_name in os.listdir(folder_path):
        #    #if file_name.endswith('.csv'):
        #    file_path = os.path.join(folder_path, file_name)
        #    base_name = os.path.splitext(file_name)[0]
        #    if base_name in screener_BTouputtickers:
        #        continue
        #    else:
        #        base_list = [base_name]
        #        download_ticker_data(tickers_list=base_list,TICKER_CSV_DATA_FOLDER_PATH=TICKER_CSV_DATA_FOLDER_PATH)
        #        #download_ticker_data(tickers_list=screener_BTouputtickers,TICKER_CSV_DATA_FOLDER_PATH=TICKER_CSV_DATA_FOLDER_PATH)


        valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
        valid_df = pd.read_csv(valid_file)
        symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))


        with PdfPages(filepathpdf) as pdf:
            # Loop through all files in the folder
            for file_name in os.listdir(folder_path):

                if file_name.endswith('.csv'):
                    file_path = os.path.join(folder_path, file_name)
                    #total_files += 1
                    base_name = os.path.splitext(file_name)[0]
                    #file_names.append(base_name)
                    #print(file_name)

                    try:

                        if base_name in screener_BTouputtickers:   #if base_name in minervinitickers:
                            file_path = os.path.join(folder_path, file_name)
                            #total_files += 1
                            #print(file_name,file_path)
                            Base_name=symbol_to_company.get(base_name, base_name)
                            # Read the CSV file into a DataFrame
                            dfM = pd.read_csv(file_path,usecols=["Date", "Open", "High", "Low", "Close", "Volume"])
                            dfM["Date"] = pd.to_datetime(dfM["Date"]).dt.date
                            dfM['Date'] = pd.to_datetime(dfM['Date'])  # Convert index to datetime

                            dfM["CCI"]=tb.CCI(dfM['High'], dfM['Low'], dfM['Close'], timeperiod=34)
                            #dfM["CCImovavgL"] = tb.EMA(dfM["CCI"], timeperiod=14)
                            dfM["RSI14"] = tb.RSI(dfM['Close'], timeperiod=14)
                            dfM["SMA_50"] = tb.EMA(dfM['Close'], timeperiod=10*5)
                            dfM["SMA_200"] = tb.SMA(dfM['Close'], timeperiod=40*5)
                            #df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                            dfM["SMA_150"] = tb.EMA(dfM['Close'], timeperiod=25*5) #25
                            #df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                            #df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                            dfM["SMA_200_15"] = tb.SMA(dfM['SMA_200'], timeperiod=12*5)
                            dfM["OBV"] = tb.OBV(dfM['Close'], dfM['Volume'])
                            #print(dfM)
                            #print(f"minervini_Charts for {Base_name}")


                            # 1. Combined Price, Volume, RSI Chart
                            fig_combined = plt.figure(figsize=(11, 8.5))
                            #gs = fig_combined.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                            #gs = fig_combined.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])
                            gs = fig_combined.add_gridspec(4, 1, height_ratios=[6, 1, 1.5, 1.5])  #Custom GridSpec for 60% Price, 10% Volume, 15% RSI, 15% CCI

                            # Price chart (line plot)
                            ax1 = fig_combined.add_subplot(gs[0])
                            ax1.plot(dfM['Date'], dfM['Close'], label='Price', color='black', linewidth=1)

                            # Plot SMAs on top of line chart
                            ax1.plot(dfM['Date'], dfM['SMA_50'], label='EMA 10', color='blue', linewidth=1.5)
                            ax1.plot(dfM['Date'], dfM['SMA_150'], label='EMA 25', color='orange', linewidth=1.5)
                            ax1.plot(dfM['Date'], dfM['SMA_200'], label='SMA 40', color='red', linewidth=1.5)
                            ax1.plot(dfM['Date'], dfM['SMA_200_15'], label='SMA 40(1)', color='purple', linewidth=1.5)

                            ax1.set_title(f'{Base_name} Price and Moving Averages', fontsize=14)
                            ax1.legend()

                            '''
                            # Volume chart
                            ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                            ax2.bar(dfM['Date'], dfM['Volume']/ 1000, color='blue', width=0.5, alpha=0.5)
                            #ax2.set_title('Volume', fontsize=12)
                            #ax2.set_ylabel('Volume')
                            #ax2.set_title('Volume (in thousands)', fontsize=12)  # Update title to reflect units
                            ax2.set_ylabel('Volume (K)')  # Change y-axis label to indicate thousands
                            '''

                            # Volume chart with OBV
                            ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                            # Plot volume bars
                            ax2.bar(dfM['Date'], dfM['Volume']/1000, color='blue', width=0.5, alpha=0.5, label='Volume')
                            # Plot OBV line on secondary y-axis
                            ax2b = ax2.twinx()
                            ax2b.plot(dfM['Date'], dfM['OBV']/1000, color='black', linewidth=1.5, label='OBV')
                            # Set labels and title
                            ax2.set_ylabel('Volume (K)', color='blue')
                            ax2b.set_ylabel('OBV (K)', color='black')
                            # Set colors for y-axes to match their respective data
                            ax2.tick_params(axis='y', colors='blue')
                            ax2b.tick_params(axis='y', colors='black')
                            # Add legend
                            lines, labels = ax2.get_legend_handles_labels()
                            lines2, labels2 = ax2b.get_legend_handles_labels()
                            ax2.legend(lines + lines2, labels + labels2, loc='upper left')



                            # RSI chart
                            ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                            ax3.plot(dfM['Date'], dfM["RSI14"], color='purple', label='RSI')
                            ax3.axhline(70, color='red', linestyle='--', alpha=0.5)
                            ax3.axhline(30, color='green', linestyle='--', alpha=0.5)
                            ax3.fill_between(dfM['Date'], 70, dfM["RSI14"],
                                           where=(dfM["RSI14"] >= 70), color='red', alpha=0.3)
                            ax3.fill_between(dfM['Date'], 30, dfM["RSI14"],
                                           where=(dfM["RSI14"] <= 30), color='green', alpha=0.3)
                            ax3.set_title('RSI (24)', fontsize=12)
                            ax3.set_ylim(0, 100)
                            ax3.legend()

                            # CCI chart
                            ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                            ax4.plot(dfM['Date'], dfM["CCI"], color='purple', label='CCI')
                            ax4.axhline(0, color='red', linestyle='--', alpha=0.5)
                            ax4.axhline(50, color='green', linestyle='--', alpha=0.5)
                            ax4.fill_between(dfM['Date'], 0, dfM["CCI"],
                                           where=(dfM["CCI"] <= 0), color='red', alpha=0.3)
                            ax4.fill_between(dfM['Date'], 50, dfM["CCI"],
                                           where=(dfM["CCI"] >= 50), color='green', alpha=0.3)
                            ax4.set_title('CCI (34)', fontsize=12)
                            ax4.set_ylim(-100, 150)
                            ax4.legend()

                            # Format x-axis to show labels on a quarterly basis
                            plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))  # Quarterly labels  6
                            plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format as 'YYYY-MM'
                            #plt.xticks(rotation=25)
                            plt.xticks(rotation=90, ha='right')
                            plt.tight_layout()
                            # Reduce margins using tight_layout with padding adjustments
                            #plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)  # Adjust padding as needed
                            #pdf.savefig(fig_combined)
                            pdf.savefig(fig_combined, bbox_inches='tight')

                            folder_pathf='/home/rizpython236/BT5/screener-outputs/'
                            file_path = os.path.join(folder_pathf)
                            chart_path = os.path.join(folder_pathf, f'screener_output_Charts_{Base_name}.png')
                            #plt.savefig(chart_path)
                            #time.sleep(3)
                            #post_telegram_file(chart_path)
                            #os.remove(chart_path)
                            #if total_files == symNo:
                            plt.close(fig_combined)

                            # Add metadata
                            d = pdf.infodict()
                            d['Title'] = f'{Base_name} Technical Analysis Report'
                            d['Author'] = 'Automated Report Generator'

                            print(f"Generated report for {Base_name} at: {filepathpdf}")
                    except Exception as e:
                        print(f"Error processing screener_output_Charts {Base_name}: {str(e)}")
                        traceback_str = traceback.format_exc()
                        print(traceback_str)
                        plt.close('all')


        time.sleep(3)
        print(f"Send telegrame report: {filepathpdf}")
        if len(screener_BTouputtickers) != 0:
            post_telegram_file(filepathpdf)
            1+1
    except Exception as e:
        print(f"Error processing screener_output_Charts: {str(e)}")
        traceback_str = traceback.format_exc()
        print(traceback_str)
        #plt.close('all')


#folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
folder_path = '/home/rizpython236/BT5/ticker_15yr/'
filepathpdf = '/home/rizpython236/BT5/screener-outputs/screener_output_Charts.pdf'
screenercsv_path = '/home/rizpython236/BT5/trade-logs/screener-output.csv'


filepathBTpdf = '/home/rizpython236/BT5/screener-outputs/BTbuy_Charts.pdf'
screenercsvBT_path = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'


#addchartspdf(screenercsv_path=screenercsv_path, folder_path=folder_path, filepathpdf=filepathpdf)
#addchartspdf(screenercsv_path=screenercsvBT_path, folder_path=folder_path, filepathpdf=filepathBTpdf)


#addchartspdf(screenercsv_path=screenercsv_path, folder_path=folder_path, filepathpdf=filepathpdf)