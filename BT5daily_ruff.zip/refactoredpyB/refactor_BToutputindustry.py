# refactored_trade_list_builder.py
import os,sys
import re
from pathlib import Path
from datetime import datetime
import pandas as pd
import numpy as np
sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
import yfinance as yf
from concurrent.futures import ThreadPoolExecutor, as_completed
from symbol_copy import NSE_BSE_symbol_name_df

print("company details started")

# ----- Settings (same variables/names as your original file) -----
from settings import (
    EXCLUDE_TICKERS_CSV,
    INCLUDE_TICKERS_CSV,
    MAX_RETRIES,
    NSE_NIFTY_500_URL,
    NSE_MICROCAP_250_URL,
    SYMBOLS_CSV,
)

# ----- Load include / exclude tickers -----
include_tickers = pd.read_csv(INCLUDE_TICKERS_CSV, dtype=str)
include_list = include_tickers["Symbol"].dropna().unique().tolist()

exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV, dtype=str)
exclude_set = set(exclude_tickers["Symbol"].dropna().unique().tolist())

# ----- Read BSE and NSE master files -----
# Use dtype=str to avoid unexpected numeric conversions
bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv", dtype=str)
datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv", dtype=str)

# Drop unneeded columns safely (only if present)
bse = bse.drop(columns=[c for c in [
    "Industry", "Instrument", "Sector Name", "Industry New Name", "Igroup Name", "ISubgroup Name"
] if c in bse.columns], errors="ignore")

datanse = datanse.drop(columns=[c for c in [
    " SERIES", " DATE OF LISTING", " PAID UP VALUE", " MARKET LOT", " FACE VALUE"
] if c in datanse.columns], errors="ignore")

# Standardize column names and filters
bse = bse.rename(columns={"Security Id": "SYMBOL", "Security Name": "NAME OF COMPANY"})
# Keep only Active securities and exclude Funds/ETF etc via vectorized str.contains
if "Status" in bse.columns:
    bse = bse[bse["Status"].str.strip().eq("Active")]
# Remove rows with NAME containing unwanted words
mask = ~bse["NAME OF COMPANY"].str.contains("|".join(["ETF", "EXCHANGE TRADED", "FUND", "Fund"]), na=False)
bse = bse[mask]

# remove trailing asterisk in SYMBOL (if any)
bse["SYMBOL"] = bse["SYMBOL"].str.rstrip("*")

# Establish accepted group values (vectorized)
unique_groups = bse.get("Group", pd.Series(dtype=object)).dropna().unique().tolist()
to_remove = {"P", "ZP", "IP", "Y"}
accepted_groups = [g for g in unique_groups if g not in to_remove]
if "Group" in bse.columns and accepted_groups:
    bse = bse[bse["Group"].isin(accepted_groups)]

# Merge NSE and BSE using ISIN numbers where possible
# datanse has column " ISIN NUMBER" (with leading space) in original; handle both names
isin_col_nse = next((c for c in datanse.columns if "ISIN" in c.upper()), None)
isin_col_bse = next((c for c in bse.columns if "ISIN" in c.upper() or "ISIN No".upper() in c.upper()), None)

# Normalize columns to common keys if present
if isin_col_nse:
    datanse = datanse.rename(columns={isin_col_nse: "ISIN_NSE"})
if "ISIN No" in bse.columns:
    bse = bse.rename(columns={"ISIN No": "ISIN_BSE"})

# Merge right join similar to original
if "ISIN_NSE" in datanse.columns and "ISIN_BSE" in bse.columns:
    datansebse = pd.merge(datanse, bse, left_on="ISIN_NSE", right_on="ISIN_BSE", how="right")
else:
    datansebse = pd.DataFrame(columns=list(datanse.columns) + list(bse.columns))

# Exclude common symbols present in both (as per your logic)
if "ISIN_BSE" in bse.columns:
    common_isins = bse[bse["ISIN_BSE"].isin(datanse.get("ISIN_NSE", pd.Series(dtype=object)))]
    # drop the common ones from bse
    if not common_isins.empty:
        bse = bse[~bse["ISIN_BSE"].isin(common_isins["ISIN_BSE"])]

# Add suffixes vectorized
bse["SYMBOL"] = bse["SYMBOL"].astype(str) + ".BO"
datanse["SYMBOL"] = datanse["SYMBOL"].astype(str) + ".NS"

# Compose result: right-concat bse (suffixed), datanse (suffixed)
result = pd.concat([bse[["SYMBOL"]], datanse[["SYMBOL"]]], axis=0, ignore_index=True).drop_duplicates().reset_index(drop=True)
result = result.rename(columns={"SYMBOL": "Symbol"})

# Add include tickers that are not present already
missing_includes = [s for s in include_list if s not in set(result["Symbol"].astype(str))]
if missing_includes:
    result = pd.concat([result, pd.DataFrame({"Symbol": missing_includes})], ignore_index=True)

# Remove excluded tickers (vectorized)
if "Symbol" in result.columns:
    result = result[~result["Symbol"].isin(exclude_set)]

# Append explicit extra symbols as a list (added in bulk)
extra_symbols = [
    '^NSEI', '^NSEBANK', '^CRSLDX', '^NSEMDCP50', 'MON100.NS', 'MAFANG.NS', 'MAHKTECH.NS', 'SBIGETS.BO',
    'AXISCETF.NS', 'ICICIINFRA.NS', '^CNXCMDT', '^CNXINFRA', '^CNXAUTO', '^CNXPHARMA', '^CNXPSUBANK',
    '^CNXIT', '^CNXCONSUM', 'NIFTYPVTBANK.NS', '^CNXMETAL', '^CNXREALTY', '^CNXENERGY', '^CNXFMCG',
    'NIFTYSMLCAP250.NS', 'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'NIFTY_FIN_SERVICE.NS'
]
result = pd.concat([result, pd.DataFrame({"Symbol": extra_symbols})], ignore_index=True).drop_duplicates().reset_index(drop=True)

# Clean out rows containing '-RE' or 'DUMMY' in Symbol
result = result[~result["Symbol"].str.contains(r"-RE\.|DUMMY", na=False)]

# Save intermediate list (same file name as original)
result.to_csv('/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv', index=False)
print(f"NSE rows: {len(datanse)}, BSE rows: {len(bse)}, NSE-BSE merged rows: {len(datansebse)}, final symbols: {len(result)}")

# ----- Fetch stock info concurrently using yfinance -----
input_file = '/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv'
output_file = '/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv'

symbols_df = pd.read_csv(input_file, dtype=str)
symbols = symbols_df["Symbol"].dropna().astype(str).tolist()

# Build symbol_to_name mapping using provided helper (kept as-is)
sym_name_df = NSE_BSE_symbol_name_df()
# handle missing columns defensively
if "SYMBOL" in sym_name_df.columns and "NAME OF COMPANY" in sym_name_df.columns:
    symbol_to_name = dict(zip(sym_name_df["SYMBOL"].astype(str), sym_name_df["NAME OF COMPANY"].astype(str)))
else:
    symbol_to_name = {}

# Small worker function used for concurrency (keeps per-ticker try/except/timeout)
def _fetch(sym):
    # minimal retry logic
    attempts = 0
    while attempts < 3:
        attempts += 1
        try:
            t = yf.Ticker(sym)
            info = {}
            # safe access to info dict
            try:
                info = t.info or {}
            except Exception:
                info = {}
            # Use symbol_to_name mapping prefered, else fallback to info.longName
            longName = symbol_to_name.get(sym, info.get("longName", "Blank"))
            # history for latest price/volume - use robust fallback
            price = "Blank"
            volume = "Blank"
            try:
                hist = t.history(period="1d", auto_adjust=True)
                if not hist.empty:
                    price = round(float(hist['Close'].iloc[-1]), 2)
                    volume = float(hist['Volume'].iloc[-1])
            except Exception:
                price = "Blank"
                volume = "Blank"
            marketCap = round(info.get('marketCap', 0) / 10000000, 0) if info.get('marketCap') else "Blank"
            industry = info.get('industry', "Blank")
            sector = info.get('sector', "Blank")
            # placeholders for other metrics to match your CSV structure
            eps = info.get('trailingEps', 0) or 0
            equity = info.get('totalStockholderEquity', 0) or 0
            debt = info.get('totalDebt', 0) or 0
            sales = info.get('totalRevenue', 0) or 0
            dividend = info.get('trailingAnnualDividendRate', 0) or 0
            payoutRatio = round((info.get('payoutRatio', 0) or 0) * 100, 2) if info.get('payoutRatio') else 0

            return {
                "Symbol": sym,
                "LongName": longName,
                "Industry": industry,
                "Sector": sector,
                "MarketCapCr": marketCap,
                "Price": price,
                "Volume": volume,
                "EPS": eps,
                "Equity": equity,
                "Debt": debt,
                "Sales": sales,
                "Dividend": dividend,
                "payoutRatio": payoutRatio
            }
        except Exception:
            # small backoff; last attempt will return Blank row
            if attempts < 3:
                continue
            return {
                "Symbol": sym,
                "LongName": "Blank",
                "Industry": "Blank",
                "Sector": "Blank",
                "MarketCapCr": "Blank",
                "Price": "Blank",
                "Volume": "Blank",
                "EPS": "Blank",
                "Equity": "Blank",
                "Debt": "Blank",
                "Sales": "Blank",
                "Dividend": "Blank",
                "payoutRatio": "Blank"
            }

# Use ThreadPoolExecutor to parallelize network I/O
max_workers = min(12, (os.cpu_count() or 4) * 2)  # conservative limit
results = []
with ThreadPoolExecutor(max_workers=max_workers) as ex:
    future_to_sym = {ex.submit(_fetch, s): s for s in symbols}
    for fut in as_completed(future_to_sym):
        sym = future_to_sym[fut]
        try:
            results.append(fut.result())
        except Exception:
            # ensure a fallback row
            results.append({
                "Symbol": sym, "LongName": "Blank", "Industry": "Blank", "Sector": "Blank",
                "MarketCapCr": "Blank", "Price": "Blank", "Volume": "Blank",
                "EPS": "Blank", "Equity": "Blank", "Debt": "Blank", "Sales": "Blank",
                "Dividend": "Blank", "payoutRatio": "Blank"
            })

industry_df = pd.DataFrame(results)
# Write to CSV
industry_df.to_csv(output_file, index=False)
print(f"Wrote {len(industry_df)} rows to {output_file}")

# ----- Post-processing: fill missing LongName using final ISIN file and clean company names -----
# load files you used in original script
trade_list = pd.read_csv(output_file, dtype=str)
final_isin = pd.read_csv('/home/rizpython236/BT5/trade-logs/FinalISIN.csv', dtype=str)

# Build mapping symbol->COMPANY from final_isin
if 'Symbol' in final_isin.columns and 'COMPANY' in final_isin.columns:
    symbol_to_company = final_isin.set_index('Symbol')['COMPANY'].to_dict()
else:
    symbol_to_company = {}

# Replace "Blank" with NaN and fill from mapping
trade_list["LongName"] = trade_list["LongName"].replace({"Blank": pd.NA})
trade_list["LongName"] = trade_list["LongName"].fillna(trade_list["Symbol"].map(symbol_to_company))
trade_list["LongName"] = trade_list["LongName"].fillna("Blank")

# Filtered trade_list showing Blank longnames (for debugging)
na_long_names = trade_list[trade_list["LongName"].eq("Blank")]
print("Entries in 'LongName' where the value is Blank:")
print(na_long_names.head(10))

# ----- Clean company names vectorized -----
# Build replacements dict (kept your mapping, trimmed for brevity -- you can paste full mapping here)
replacements = {
        " Company Limited": "", " Corporation Limited": "", " (India) Limited": "", " India Limited": " India",
        " Pharmaceuticals Limited": " Pharma", " (Delhi) Limited": "", " (Maharashtra) Limited": "",
        " Ltd.": "", " Co. Ltd.": "", " (India) Ltd.": "", " Ltd": "", " Co.": ""," Commercial ":" Comm.",
        " Advanced ":" Adv."," Solutions ":" Solu."," Appliances ":" App."," Logistics ":" Logis."," Insurance ":" Insur."," Accessories ":" Accs."," Specialities ":" Spcl."," National ":" Nat."," Software ":" Soft."," Instrumental ":" Instr."," System ":" Sys."," Transformers ":" Transfor.",
        "ICICI Prudential ": "ICICI Pru", "Special Economic Zone": "Spl Eco Zone.", " Limited": "",
        " and ": " & ", " (India)": "", " Company": " Co.", " Infrastructure": " Infra.",
        " & ": " & ", " Corporation ": "Corp. ", " (Gujarat)": "", " (S.A.)": "",
        " And ": " & ", "Engineers": "Engrs.", " (Chennai)": "", " Infrastructures ": " Infra. ",
        " limited": "", "Technologies": "Tech.", " Infrastructure": " Infra.", " Infrastructures": " Infra.",
        " (Kalamandir)": "", " (Madras)": "", "Nippon India Mutual Fund ": "Nippon India ",
        "Nippon India ": "", " Financial ": " Fin. ", " Engineering ": " Eng. ",
        " Industries": " Ind.", " Industries ": " Ind. ", " International": " Intl.",
        " Engineering": " Eng.", "(International)": "", " Development ": " Dev. ",
        " Development": " Dev.", " International ": " Intl. ", " Technology": " Tech.",
        " Technology ": " Tech. ", " Services": " Srvs.", " Holding": " Hldg.",
        " Agricultural ": " Agri. ", " Management ": " Mgmt. ", " Investment ": " Invest. ", " E-Governance": " e-Gov.",
        " Consolidated ": " Consol. ", " Chemicals ": " Chem. ", " Chemicals": " Chem.",
        " Fertilizers ": " Fert. ", " Fertilizers": " Fert.", " Biochemicals": " Biochem.",
        " Associated ": " Assoc. ", " Associated": " Assoc.", " Hospital": " Hosp.",
        " Hospital ": " Hosp. ", " Manufacturing": " Mfg.", " Manufacturing ": " Mfg. ",
        "The ": "", "General ": " Gen. ", " Ventures": " Vntrs.", " Enterprises": " Entp.",
        " Industrial ": " Ind. ", " Industrial": " Ind.", " International": " Int.",
        "(International)": "", " Technologies": " Tech.", " (Coimbatore)": "",
        " Petrochemicals": " petrochem.", "Petrochemical": "Petrochem.",
        " Petrochemicals ": " Petrochem.", " Fertilisers ": " Fert. ", " -$ ": ""," MARKET": " MKT."," Laboratory": " Lab."," Automobile": " Auto.",
        " Infrastructure": " Infra. "," Technologies": " Tech. "," Pharmaceuticals": " Pharma. "," Industries ": " Ind. "," Immunologicals ": " Immunog. "," Biologicals ": " Bio. "," Petroleum ": " Petro. "," Electronics ": " Electro. "," Telecommunications ": " Telec. "," Systems ": " Sys. "," Petroleum ": " Petro. "," Petroleum ": " Petro. ",
        " Institute ": " Inst. ", "Electricals": "Elect.", "Construction": "Constr.",
        "Systems": "Sys.", "Investments": "Invest.", "Management": "Mgmt.",
        "Exchange": "Exch.", " Fertilisers": " Fert.", "Housing Finance": "Hsg. Fin.","Procter & Gamble": "P&G ",
        "Housing": "Hsg.", "Motilal Oswal S&P": "Motilal Oswal", "Developers": "Develp.",
        " Corporation": "", " Standard": " Std.", " Manufactures": " Mfg..", " Laboratories": " Lab.",
        " Industry": " Ind.", " Estates": " Est.", " Communications": " comm."," Infrastructure": " Infra.",
        " Pharmaceutical": " Pharma."," Development": " Develp."," Equipment": " Equip."," Specialty": " Spl.",
        " Education": " Edu."," Chemicals": " Chem.","Indian Railway Catering & Tourism":"IRCTC","Renewable":"Renew","Corporate":"Corp.",
        "Products":"Prod.","Investment":"Invest.","Consultancy":"Consult.","Electrical":"Elect.","Performance":"Perf.","Consolidated":"Consol.",
        "Intermediaries":"intermeds.","Automotive":"Auto.","Entertainment":"Entmt.","Institute":"Inst.","Limited":"","Company":"Compy.","of India":"",
}

# Create patterns and apply vectorized replacements to final_isin['COMPANY']
if 'COMPANY' in final_isin.columns:
    s = final_isin['COMPANY'].astype(str)
    # apply mapping sequentially but vectorized on the Series
    for old, new in replacements.items():
        # Trim and escape pattern, allow flexible surrounding whitespace, case-insensitive
        pat = r"(?i)\s*" + re.escape(old.strip()) + r"\s*"
        s = s.str.replace(pat, new, regex=True)
    final_isin['COMPANY'] = s

# Save updated trade_list (same output file name as original)
trade_list.to_csv('/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv', index=False)
print("Final trade_list saved.")
