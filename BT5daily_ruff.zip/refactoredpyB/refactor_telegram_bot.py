import os
import time
import json
import pandas as pd
from datetime import date
from typing import List, Optional
sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
from telegram import Bot
from telegram.error import TelegramError
from telegram.constants import ParseMode
from PDFconvert import create_pdf
import asyncio

from settings import (
    TRADE_LOGS_FOLDER_PATH,
    SCREENER_OUTPUT_FOLDER_PATH,
    SCREENER_OUTPUT_CSV,
    INVALID_TICKERS_FILE,
    INCOMPLETE_TICKERS_CSV,
)




# Telegram Bot token and chat IDs
TOKEN = "6108615209:AAF8ZiMMxbrT1D46enyrO0rSlChCuo9d4ro"
CHAT_IDS = [-1001757309399]

bot = Bot(token=TOKEN)

# File paths
INVALID_TICKERS_FILE_PATH = os.path.join(SCREENER_OUTPUT_FOLDER_PATH, INVALID_TICKERS_FILE)
INCOMPLETE_TICKERS_FILE_PATH = os.path.join(SCREENER_OUTPUT_FOLDER_PATH, INCOMPLETE_TICKERS_CSV)

# Load invalid/incomplete tickers
invalid_tickers = pd.read_csv(INVALID_TICKERS_FILE_PATH)["invalid_ticker"].unique().tolist()
incomplete_tickers = pd.read_csv(INCOMPLETE_TICKERS_FILE_PATH)["Symbol"].unique().tolist()


# -------------------------------
# Asynchronous Telegram functions
# -------------------------------

async def async_post_telegram_message(message: str):
    """Send a text message asynchronously to all chat IDs."""
    if not message:
        return
    for chat_id in CHAT_IDS:
        try:
            await bot.send_message(chat_id=chat_id, text=message)
            print(f"✅ Posted Telegram message: {message}")
        except TelegramError as e:
            print(f"❌ Telegram error: {e} -- Message: {message}")


async def async_post_telegram_file(file_path: str):
    """Send a file asynchronously to all chat IDs."""
    if not os.path.exists(file_path):
        print(f"❌ File not found: {file_path}")
        return

    file_ext = os.path.splitext(file_path)[1].lower()
    with open(file_path, "rb") as file:
        for chat_id in CHAT_IDS:
            try:
                if file_ext in [".jpg", ".jpeg", ".png"]:
                    await bot.send_photo(chat_id=chat_id, photo=file)
                else:
                    await bot.send_document(chat_id=chat_id, document=file)
                print(f"✅ Posted Telegram attachment: {file_path}")
            except TelegramError as e:
                print(f"❌ Telegram error sending file: {e} -- File: {file_path}")


# -------------------------------
# Synchronous wrappers
# -------------------------------

def post_telegram_message(message: str):
    """Sync wrapper for async_post_telegram_message"""
    asyncio.run(async_post_telegram_message(message))


def post_telegram_file(file_path: str):
    """Sync wrapper for async_post_telegram_file"""
    asyncio.run(async_post_telegram_file(file_path))


# -------------------------------
# Utility functions
# -------------------------------

def delete_file(file_path: str):
    """Delete a file if it exists."""
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"Deleted file: {file_path}")
    else:
        print(f"File not found: {file_path}")


# -------------------------------
# Main notification function
# -------------------------------

async def async_trigger_telegram_notifications():
    """Trigger telegram notifications for invalid/incomplete tickers and trade CSV."""
    # Notify invalid tickers
    if invalid_tickers:
        message = f"Invalid Tickers Found: {invalid_tickers}"
        await async_post_telegram_message(message)
        # await async_post_telegram_file(os.path.join(SCREENER_OUTPUT_FOLDER_PATH, "invalid_tickers.csv"))

    # Notify incomplete tickers
    if incomplete_tickers:
        message = f"Incomplete Data Tickers Found: {incomplete_tickers}"
        await async_post_telegram_message(message)
        # await async_post_telegram_file(os.path.join(SCREENER_OUTPUT_FOLDER_PATH, "incomplete_data_tickers.csv"))

    # Send trade list messages
    csv_to_send = os.path.join(TRADE_LOGS_FOLDER_PATH, SCREENER_OUTPUT_CSV)
    trade_list = pd.read_csv(csv_to_send)

    # Remove unnecessary columns if present
    drop_cols = ["talib_date", "talib_price", "talib_signal", "trade_id", "trade_logged_on", "status"]
    trade_list.drop(columns=[c for c in drop_cols if c in trade_list.columns], inplace=True)

    trade_list_dict = trade_list.to_dict('records')
    chunk_size = 5
    chunked_trade_list = [trade_list_dict[i:i + chunk_size] for i in range(0, len(trade_list_dict), chunk_size)]

    for chunk in chunked_trade_list:
        await async_post_telegram_message(json.dumps(chunk, indent=4, sort_keys=True))
        await asyncio.sleep(1)

    # Convert CSV to PDF and send
    input_csv_file = '/home/rizpython236/BT5/trade-logs/screener-output.csv'
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/screener-output.pdf'
    input_csv_file1 = '/home/rizpython236/BT5/screener-outputs/screener-output1.csv'

    df = pd.read_csv(input_csv_file)
    drop_cols_pdf = ['trade_logged_on', 'trade_id', 'status', 'talib_date', 'talib_signal', 'talib_price']
    df.drop(columns=[c for c in drop_cols_pdf if c in df.columns], inplace=True)
    df.to_csv(input_csv_file1, index=False)

    create_pdf(input_csv_file1, output_pdf_file)
    await async_post_telegram_file(output_pdf_file)


# -------------------------------
# Synchronous wrapper for notifications
# -------------------------------

def trigger_telegram_notifications():
    """Sync wrapper to call async notifications."""
    asyncio.run(async_trigger_telegram_notifications())


# Example usage:
# trigger_telegram_notifications()
# post_telegram_message("Hello world!")
# post_telegram_file("/path/to/file.pdf")
