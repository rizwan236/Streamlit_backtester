import os,sys, shutil
import re
import time
import traceback
import pandas as pd
sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
import yfinance as yf
from symbol_copy import NSE_BSE_symbol_name_df
from telegram_bot import post_telegram_message,post_telegram_file
from collections import Counter



# Specify the paths for the input and output files
input_file_path = '/home/rizpython236/BT5/Final.csv'
output_file_path = '/home/rizpython236/BT5/symbol_list.csv'

# Load the CSV file into a DataFrame
df = pd.read_csv(input_file_path)


# Check the number of rows in the DataFrame
num_rows = df.shape[0]

if num_rows > 1900:
    # Duplicate and save the file as "symbol.csv"
    #shutil.copy(input_file_path, output_file_path)
    #time.sleep(3)
    #df = pd.read_csv(output_file_path)
    df = df.sort_values(by='Symbol')
    df = df.drop_duplicates()
    df.to_csv(output_file_path, index=False)
    #shutil.copy(input_file_path, output_file_path)
    print(f'Duplicated {input_file_path} as {output_file_path}')
else:
    print(f'The file {input_file_path} does not have more than 1000 rows.')


def add_suffix_to_column(df, column_name, suffix):
    df[column_name] = df[column_name].astype(str) + suffix
    return df


def add_company_names_and_industry(input_file, output_file):
    try:
        df = pd.read_csv(input_file)
        print(len(df))

        # --- Precompute dictionaries for replacements ---
        company_replacements = {
            " Company Limited": "", " Corporation Limited": "", " (India) Limited": "", " India Limited": " India",
            " Pharmaceuticals Limited": " Pharma", " (Delhi) Limited": "", " (Maharashtra) Limited": "",
            " Ltd.": "", " Co. Ltd.": "", " (India) Ltd.": "", " Ltd": "", " Co.": ""," Commercial ":" Comm.",
            " Advanced ":" Adv."," Solutions ":" Solu."," Appliances ":" App."," Logistics ":" Logis."," Insurance ":" Insur."," Accessories ":" Accs."," Specialities ":" Spcl."," National ":" Nat."," Software ":" Soft."," Instrumental ":" Instr."," System ":" Sys."," Transformers ":" Transfor.",
            "ICICI Prudential ": "ICICI Pru", "Special Economic Zone": "Spl Eco Zone.", " Limited": "",
            " and ": " & ", " (India)": "", " Company": " Co.", " Infrastructure": " Infra.",
            " & ": " & ", " Corporation ": "Corp. ", " (Gujarat)": "", " (S.A.)": "",
            " And ": " & ", "Engineers": "Engrs.", " (Chennai)": "", " Infrastructures ": " Infra. ",
            " limited": "", "Technologies": "Tech.", " Infrastructure": " Infra.", " Infrastructures": " Infra.",
            " (Kalamandir)": "", " (Madras)": "", "Nippon India Mutual Fund ": "Nippon India ",
            "Nippon India ": "", " Financial ": " Fin. ", " Engineering ": " Eng. ",
            " Industries": " Ind.", " Industries ": " Ind. ", " International": " Intl.",
            " Engineering": " Eng.", "(International)": "", " Development ": " Dev. ",
            " Development": " Dev.", " International ": " Intl. ", " Technology": " Tech.",
            " Technology ": " Tech. ", " Services": " Srvs.", " Holding": " Hldg."," E-Governance": " e-Gov.",
            " Agricultural ": " Agri. ", " Management ": " Mgmt. ", " Investment ": " Invest. ",
            " Consolidated ": " Consol. ", " Chemicals ": " Chem. ", " Chemicals": " Chem.",
            " Fertilizers ": " Fert. ", " Fertilizers": " Fert.", " Biochemicals": " Biochem.",
            " Associated ": " Assoc. ", " Associated": " Assoc.", " Hospital": " Hosp.",
            " Hospital ": " Hosp. ", " Manufacturing": " Mfg.", " Manufacturing ": " Mfg. ",
            "The ": "", "General ": " Gen. ", " Ventures": " Vntrs.", " Enterprises": " Entp.",
            " Industrial ": " Ind. ", " Industrial": " Ind.", " International": " Int.",
            "(International)": "", " Technologies": " Tech.", " (Coimbatore)": "",
            " Petrochemicals": " petrochem.", "Petrochemical": "Petrochem.",
            " Petrochemicals ": " Petrochem.", " Fertilisers ": " Fert. ", " -$ ": ""," MARKET": " MKT.", " Laboratory": " Lab.", " Automobile": " Auto.",
            " Infrastructure": " Infra. "," Technologies": " Tech. "," Pharmaceuticals": " Pharma. "," Industries ": " Ind. "," Immunologicals ": " Immunog. "," Biologicals ": " Bio. "," Petroleum ": " Petro. "," Electronics ": " Electro. "," Telecommunications ": " Telec. "," Systems ": " Sys. "," Petroleum ": " Petro. "," Petroleum ": " Petro. ",
            " Institute ": " Inst. ", "Electricals": "Elect.", "Construction": "Constr.",
            "Systems": "Sys.", "Investments": "Invest.", "Management": "Mgmt.",
            "Exchange": "Exch.", " Fertilisers": " Fert.", "Housing Finance": "Hsg. Fin.","Procter & Gamble": "P&G ",
            "Housing": "Hsg.", "Motilal Oswal S&P": "Motilal Oswal", "Developers": "Develp.",
            " Corporation": "", " Standard": " Std.", " Manufactures": " Mfg..", " Laboratories": " Lab.",
            " Industry": " Ind.", " Estates": " Est.", " Communications": " comm."," Infrastructure": " Infra.",
            " Pharmaceutical": " Pharma."," Development": " Develp."," Equipment": " Equip."," Specialty": " Spl.",
            " Education": " Edu."," Chemicals": " Chem.","Indian Railway Catering & Tourism":"IRCTC","Renewable":"Renew","Corporate":"Corp.",
            "Products":"Prod.","Investment":"Invest.","Consultancy":"Consult.","Electrical":"Elect.","Performance":"Perf.","Consolidated":"Consol.",
            "Intermediaries":"intermeds.","Automotive":"Auto.","Entertainment":"Entmt.","Institute":"Inst.","Limited":"","Company":"Compy.","of India":"",
        }

        industry_replacements = {
            "Corporation of India": "Corp. of India", "Drug Manufacturers—General": "Pharma-General",
            "Engineering & Construction": "Engr./Constr", "Agricultural": "Agri.",
            "Chemicals": "Chem.", "Financial": "Fin.", "Estate": "Est.",
            " - Regional": "", "Drug Manufacturers—Specialty & Generic": "Pharma-Specialty/Generic",
            "Regional": "", "Drug Manufacturers - Specialty & Generic": "Pharma-Specialty/Generic",
            "Drug Manufacturers - General": "Pharma-General", "Farm & Heavy Construction Machinery": "Farm/Heavy Mach.",
            "Information Technology ": "IT ", " Equipment ": " Equip ", " Equipment": " Equip",
            "Other Industrial Metals & Mining": "Other Metals/Mining", "Pharmaceutical ": "Pharma ",
            " Infrastructure": " Infra", "Independent": "", "Infrastructure ": "Infra ",
            "Lodging": "Hotel", "Medical Care Facilities": "Hospital",
            "Integrated Freight & Logistics": "Freight/Logistics", " & ": "/",
            " - ": "-", " — ": "-", " and ": "/", "Manufacturing": "Mfg.",
            "Development": "Develp.", "Industrial": "Ind.", "Services": "Serv.",
            "Manufacturers": "Mfg.", "Electrical": "Elect.", "Manufacturing": "Mfg.",
            "Products": "prod.", "Machinery": "Mach.", "Communication": "Comm.",
            "Specialty": "Spl.", "Biotechnology": "Biotech", "Fabrication": "Fab.",
            "Production": "Prod.", "Conglomerates": "Conglo.", "Finance": "Fin.",
            "Management": "Mgmt.", "Packaged": "Pkg.", "Advertising": "Advert.",
            "Education": "Edu."
        }

        # Compile regex patterns for performance
        company_patterns = [(re.compile(rf"\s*{re.escape(old)}\s*", flags=re.IGNORECASE), new) for old, new in company_replacements.items()]
        industry_patterns = [(re.compile(rf"\s*{re.escape(old)}\s*", flags=re.IGNORECASE), new) for old, new in industry_replacements.items()]

        def clean_text(text, patterns):
            if not isinstance(text, str):
                return text
            for pat, repl in patterns:
                text = pat.sub(repl, text)
            return text

        # NSE/BSE symbol map
        sym_name_df = NSE_BSE_symbol_name_df()
        symbol_to_name = dict(zip(sym_name_df["SYMBOL"], sym_name_df["NAME OF COMPANY"]))

        # Fetch company/industry info
        results = []
        for idx, symbol in enumerate(df['Symbol']):
            try:
                stock = yf.Ticker(symbol)
                company_name = clean_text(symbol_to_name.get(symbol, symbol), company_patterns)

                # Override if unusually long
                if len(company_name) >= len("Garden Reach Shipbuilders & Engineers"):
                    company_name = symbol

                try:
                    yfindustry = stock.info.get("industry", "Blank")
                    industry = clean_text(yfindustry, industry_patterns)
                except Exception:
                    yfindustry, industry = "Blank", "Blank"

                results.append((company_name, yfindustry, industry))

            except Exception:
                results.append((symbol, "Blank", "Blank"))

            if (idx + 1) % 300 == 0:
                print(f"Processed {idx + 1} symbols. Pausing 4 minutes...")
                time.sleep(4 * 60)

        # Assign results
        df[["Company", "YFindustry", "Industry"]] = pd.DataFrame(results, index=df.index)

        # Map with MYindustry.csv
        myind = pd.read_csv('/home/rizpython236/BT5/MYindustry.csv')
        merged_data = df.drop(columns=["Industry"]).merge(myind, left_on="YFindustry", right_on="Industry", how="left")
        merged_data["MYindustry"].fillna("Blank", inplace=True)
        post_telegram_message(merged_data.loc[merged_data["MYindustry"] == "Blank", "YFindustry"].unique().tolist())
        merged_data = merged_data.drop(columns=["Industry"]).rename(columns={"MYindustry": "Industry"})

        # NSE/BSE reference files
        try:
            datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv").drop(
                columns=[" SERIES", " DATE OF LISTING", " PAID UP VALUE", " MARKET LOT", " FACE VALUE"], errors="ignore")
            datanse = add_suffix_to_column(datanse, "SYMBOL", ".NS")

            bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
            bse = bse[bse["Status"] == "Active"].rename(columns={"Security Id": "SYMBOL", "Security Name": "NAME OF COMPANY"})
            bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF|EXCHANGE TRADED|FUND", case=False, na=False)]
            bse.loc[bse['SYMBOL'].str.endswith('*'), 'SYMBOL'] = bse['SYMBOL'].str.rstrip('*')
            bse = bse[bse["Group"].isin(["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"])]
            bse = add_suffix_to_column(bse, "SYMBOL", ".BO")

            # Clean company names
            bse["NAME OF COMPANY"] = bse["NAME OF COMPANY"].apply(lambda x: clean_text(x, company_patterns))
            mapping = dict(zip(bse["SYMBOL"], bse["NAME OF COMPANY"]))
            merged_data["Company"] = merged_data["Company"].map(mapping).fillna(merged_data["Company"])

        except Exception:
            traceback.print_exc()

        # Append TJI index and save
        tji = pd.read_csv('/home/rizpython236/BT5/trade-logs/TJI_index.csv')
        merged_data = pd.concat([merged_data, tji], ignore_index=True)
        merged_data.to_csv(output_file, index=False)
        merged_data.to_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv', index=False)

    except Exception:
        traceback.print_exc()





def vlookup_and_merge(output_file):
    print("vlookup_and_merge trade_list_BT_Screener")

    try:
        # Read input files with only needed columns
        valid_tickers = pd.read_csv(
            '/home/rizpython236/BT5/trade-logs/valid_tickers.csv',
            usecols=["Symbol", "Company", "Industry", "YFindustry"],  # restrict columns
        )
        trade_list = pd.read_csv(
            '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
        )

        # Merge directly (sorting unnecessary since merge uses hashing)
        merged_data = trade_list.merge(
            valid_tickers, left_on="ticker", right_on="Symbol", how="left"
        )

        # Drop redundant columns safely
        merged_data.drop(columns=["Symbol", "YFindustry"], errors="ignore", inplace=True)

        # Fill missing values
        merged_data["Company"] = merged_data["Company"].fillna("Blank")

        # Save to CSV
        merged_data.to_csv(output_file, index=False)
        print(f"✅ Successfully merged data and saved to {output_file}")

    except Exception as e:
        print(f"❌ Error in vlookup_and_merge: {e}")




def update_output_file(input_file, output_file):
    """
    Updates the output file with VLOOKUP logic for Symbol, Company, YFindustry, and Industry.
    Fills missing data where no matches are found.

    Args:
        input_file (str): Path to the input CSV file.
        output_file (str): Path to the output CSV file.
    """

    try:
        # Read input with only required columns
        df_input = pd.read_csv(
            input_file, usecols=["Symbol", "Company", "YFindustry", "Industry"]
        )
        df_output = pd.read_csv(output_file)

        # Merge (left join on Symbol)
        merged_data = df_output.merge(df_input, on="Symbol", how="left", suffixes=("", "_y"))

        # Fill Company: fallback to Symbol if missing
        merged_data["Company"] = merged_data["Company"].fillna(merged_data["Symbol"])

        # Fill other missing fields with "Blank"
        for col in ["YFindustry", "Industry"]:
            merged_data[col] = merged_data[col].fillna("Blank")

        # Drop duplicate columns created by merge (if any)
        dup_cols = [c for c in merged_data.columns if c.endswith("_y")]
        merged_data.drop(columns=dup_cols, inplace=True, errors="ignore")

        # Save updated data
        merged_data.to_csv(output_file, index=False)
        print(f"✅ Successfully updated {output_file} with VLOOKUP logic")

    except Exception as e:
        print(f"❌ Error in update_output_file: {e}")





def copyfile1(input_file, output_file):
    """
    Copies a file from input_file to output_file.

    Args:
        input_file (str): Path to the source file.
        output_file (str): Path to the destination file.
    """
    try:
        if not os.path.exists(input_file):
            print(f"❌ Source file does not exist: {input_file}")
            return

        # Ensure destination directory exists
        os.makedirs(os.path.dirname(output_file), exist_ok=True)

        shutil.copy2(input_file, output_file)  # copy2 preserves metadata
        print(f"✅ File copied successfully → {output_file}")

    except Exception as e:
        print(f"❌ Error copying file: {e}")



# Example usage
#vlookup_and_merge(output_file)

# Example usage
input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
#update_output_file(input_file, output_file)


input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
##copyfile1(input_file, output_file)


input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
#update_output_file(input_file, output_file)

output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
#vlookup_and_merge(output_file)

# Example usage:
input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
input_file = '/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv'
input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'

input_file = '/home/rizpython236/BT5/Final.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
#add_company_names_and_industry(input_file, output_file)






def NSE_BSE_symbol_name_df():
    """
    Reads NSE and BSE symbol files, cleans company names,
    standardizes tickers, merges them, and returns a combined DataFrame.
    """

    try:
        # --- Load data ---
        bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
        nse = pd.read_csv("/home/rizpython236/BT5/nse.csv")

        # --- Drop unused columns ---
        bse.drop(
            columns=[
                "Face Value",
                "Issuer Name",
                "Industry",
                "Instrument",
                "Sector Name",
                "Industry New Name",
                "Igroup Name",
                "ISubgroup Name",
            ],
            inplace=True,
            errors="ignore",
        )
        nse.drop(
            columns=[
                " SERIES",
                " DATE OF LISTING",
                " PAID UP VALUE",
                " MARKET LOT",
                " FACE VALUE",
            ],
            inplace=True,
            errors="ignore",
        )

        # --- Rename columns for consistency ---
        bse.rename(
            columns={"Security Id": "SYMBOL", "Security Name": "NAME OF COMPANY"},
            inplace=True,
        )

        # --- Merge check (not used further, but kept for validation) ---
        _ = nse.merge(bse, left_on=" ISIN NUMBER", right_on="ISIN No", how="right")

        # --- Add suffixes to tickers ---
        bse["SYMBOL"] = bse["SYMBOL"].astype(str) + ".BO"
        nse["SYMBOL"] = nse["SYMBOL"].astype(str) + ".NS"

        # --- Combine datasets ---
        result = pd.concat([bse, nse], axis=0, ignore_index=True)

        # --- Company name cleanup rules ---
        replacements = {
            r"\b(consultancy|consultant)\b": "Consult",
            r"\b(INDUSTRIES|INDUSTRY)\b": "IND.",
            r"\b(infrastructure)\b": "Infra.",
            r"\b(automobile|automobiles)\b": "Auto.",
            r"\b(and)\b": "&",
            r"\b(company)\b": "Co.",
            r"\b(services|service)\b": "Serv.",
            r"\b(technologies|technology)\b": "Tech.",
            r"\b(corporation)\b": "Corp.",
            r"\b(international)\b": "Int'l.",
            r"\b(engineering)\b": "Engr.",
            r"\b(enterprises|enterprise)\b": "Ent.",
            r"\b(financial|financials)\b": "Fin.",
            r"\b(systems|system)\b": "Sys.",
            r"\b(securities)\b": "Sec.",
        }

        # Apply regex replacements
        for pattern, repl in replacements.items():
            result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
                pattern, repl, regex=True, case=False
            ).str.strip()

        # Remove trailing Ltd/Limited/India if present
        result["NAME OF COMPANY"] = (
            result["NAME OF COMPANY"]
            .str.replace(r"\s+(Ltd|Limited)$", "", regex=True, case=False)
            .str.replace(r"\s+(INDIA)$", "", regex=True, case=False)
            .str.strip()
        )

        # --- Word frequency analysis ---
        all_text = " ".join(result["NAME OF COMPANY"].dropna().astype(str))
        words = re.findall(r"\b\w+\b", all_text.lower())
        word_counts = Counter(words)
        top_50 = word_counts.most_common(50)

        # (Optional debug) Print top 50 word frequencies
        # for word, count in top_50:
        #     print(f"{word}: {count}")

        print("✅ NSE + BSE symbols processed successfully")
        return result

    except Exception as e:
        print(f"❌ Error in NSE_BSE_symbol_name_df: {e}")
        return pd.DataFrame()

#NSE_BSE_symbol_name_df()





def update_exclude_list(exclude_file="/home/rizpython236/BT5/exclude_tickers.csv"):
    """
    Updates exclude_tickers.csv based on Yahoo Finance data.

    A symbol is kept in the exclude list if:
      - Data returned has >3 rows
      - Latest Close < 35
      - Symbol is not ^INDIAVIX
      - Symbol does not match ETF/Index/Gold/Silver patterns
      - Symbol does not start with '^' or 'TJI_'
    Otherwise, it is removed.

    Args:
        exclude_file (str): Path to the exclude tickers CSV.
    """

    try:
        # --- Ensure file exists ---
        if not os.path.exists(exclude_file):
            print(f"⚠️ {exclude_file} does not exist. Creating an empty file.")
            pd.DataFrame(columns=["Symbol"]).to_csv(exclude_file, index=False)

        # --- Load exclude list ---
        df_exclude = pd.read_csv(exclude_file)
        if "Symbol" not in df_exclude.columns:
            df_exclude = pd.DataFrame(columns=["Symbol"])

        df_exclude.drop_duplicates(subset=["Symbol"], inplace=True)
        symbols = df_exclude["Symbol"].dropna().unique()
        print(f"📌 {len(symbols)} items in exclude_tickers.csv")

        updated_symbols, removed_symbols, error_symbols = [], [], []

        # --- Process symbols ---
        for i, symbol in enumerate(symbols, start=1):
            if i % 200 == 0:
                print(f"⏸ Processed {i} tickers. Sleeping for 4 minutes...")
                time.sleep(4 * 60)

            try:
                data = yf.download(
                    symbol,
                    period="5d",
                    interval="1d",
                    progress=False,
                    rounding=True,
                    multi_level_index=False,
                    auto_adjust=True,
                    actions=False,
                    keepna=False,
                    threads=True,
                    back_adjust=True,
                )

                # Apply filtering conditions
                keep_symbol = (
                    len(data) > 3
                    and data["Close"].iloc[-1] < 35
                    and symbol != "^INDIAVIX"
                    and not symbol.startswith("^")
                    and not symbol.startswith("TJI_")
                    and not re.search(
                        r"(BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP)",
                        symbol,
                        re.IGNORECASE,
                    )
                )

                if keep_symbol:
                    updated_symbols.append(symbol)
                else:
                    removed_symbols.append(symbol)

            except Exception as e:
                # Keep symbol if fetch fails
                error_symbols.append(symbol)
                updated_symbols.append(symbol)
                print(f"⚠️ Error fetching {symbol}: {e}")

        # --- Save updated exclude list ---
        pd.DataFrame({"Symbol": updated_symbols}).to_csv(exclude_file, index=False)

        # --- Summary ---
        print(f"✅ Updated exclude list saved to {exclude_file}")
        print(f"   ➕ Kept (conditions met): {len(updated_symbols)}")
        print(f"   ➖ Removed: {len(removed_symbols)}")
        print(f"   ⚠️ Errors: {len(error_symbols)}")

    except Exception as e:
        print(f"❌ Fatal error in update_exclude_list: {e}")

#update_exclude_list(exclude_file="/home/rizpython236/BT5/exclude_tickers.csv")







def update_include_tickers(include_file="/home/rizpython236/BT5/include_tickers.csv"):
    """
    Updates include_tickers.csv based on Yahoo Finance data.

    A symbol is kept in the include list if:
      - Data returned has >3 rows
      - Latest Close > 10
      - Symbol matches ETF/Index/Gold/Silver patterns OR is ^INDIAVIX OR starts with '^' or 'TJI_'

    Args:
        include_file (str): Path to the include tickers CSV.
    """

    try:
        # --- Ensure file exists ---
        if not os.path.exists(include_file):
            print(f"⚠️ {include_file} does not exist. Creating an empty file.")
            pd.DataFrame(columns=["Symbol"]).to_csv(include_file, index=False)

        # --- Load include list ---
        df_include = pd.read_csv(include_file)
        if "Symbol" not in df_include.columns:
            df_include = pd.DataFrame(columns=["Symbol"])

        df_include.drop_duplicates(subset=["Symbol"], inplace=True)
        symbols = df_include["Symbol"].dropna().unique()
        print(f"📌 {len(symbols)} items in include file")

        updated_symbols, removed_symbols, error_symbols = [], [], []

        # --- Process symbols ---
        for i, symbol in enumerate(symbols, start=1):
            if i % 200 == 0:
                print(f"⏸ Processed {i} tickers. Sleeping for 4 minutes...")
                time.sleep(4 * 60)

            try:
                data = yf.download(
                    symbol,
                    period="5d",
                    interval="1d",
                    progress=False,
                    rounding=True,
                    multi_level_index=False,
                    auto_adjust=True,
                    actions=False,
                    keepna=False,
                    threads=True,
                    back_adjust=True,
                )

                # Apply inclusion conditions
                include_symbol = (
                    len(data) > 3
                    and (
                        data["Close"].iloc[-1] > 10
                        or symbol == "^INDIAVIX"
                        or symbol.startswith("^")
                        or symbol.startswith("TJI_")
                        or re.search(
                            r"(BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP)",
                            symbol,
                            re.IGNORECASE,
                        )
                    )
                )

                if include_symbol:
                    updated_symbols.append(symbol)
                else:
                    removed_symbols.append(symbol)
                    print(
                        f"⛔ No {i}: Removing {symbol}, Close={data['Close'].iloc[-1]} from include list"
                    )

            except Exception as e:
                # If fetch fails, keep symbol for now
                error_symbols.append(symbol)
                updated_symbols.append(symbol)
                print(f"⚠️ Error fetching {symbol}: {e}")

        # --- Save updated include list ---
        new_df = pd.DataFrame({"Symbol": updated_symbols}).sort_values("Symbol").reset_index(drop=True)
        new_df.to_csv(include_file, index=False)

        # --- Summary ---
        print(f"✅ Updated include list saved to {include_file}")
        print(f"   ➕ Kept: {len(updated_symbols)}")
        print(f"   ➖ Removed: {len(removed_symbols)}")
        print(f"   ⚠️ Errors: {len(error_symbols)}")

    except Exception as e:
        print(f"❌ Fatal error in update_include_tickers: {e}")



#update_include_tickers(include_file="/home/rizpython236/BT5/include_tickers.csv")




import zipfile

def manage_zip(mode="zip"):
    source_folder = "/home/rizpython236/BT5/ticker_15yr"
    zip_path = "/home/rizpython236/BT5/screener-outputs/Tickerdata.zip"
    extract_folder = "/home/rizpython236/BT5/ticker_15yr"

    if mode == "zip":
        # ✅ Create a zip file from the source folder
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_folder):
                for file in files:
                    if file.startswith("TJI_") and file.endswith(".csv"):
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, source_folder)  # relative path inside zip
                        zipf.write(file_path, arcname)
        print(f"Zipped contents of {source_folder} → {zip_path}")

    elif mode == "unzip":
        if os.path.exists(zip_path):
            # ✅ Extract back to target folder
            with zipfile.ZipFile(zip_path, "r") as zipf:
                zipf.extractall(extract_folder)
            print(f"Unzipped {zip_path} → {extract_folder}")

            if os.path.exists(zip_path):
                # ✅ Delete the zip file after extraction
                #os.remove(zip_path)
                print(f"Deleted zip file {zip_path}")

    else:
        raise ValueError("mode must be 'zip' or 'unzip'")


#manage_zip(mode="zip")
#manage_zip(mode="unzip")

#################################

import gc

def manage_user_variables(delete_top_n=None, delete_threshold=None, confirm=False):
    """
    List all user-defined variables sorted by size (descending).
    Options:
      - delete_top_n: deletes the top N largest variables
      - delete_threshold: deletes all variables larger than this threshold
                          (accepts bytes or strings like '1MB', '500KB', '2GB').
      - confirm: if True, ask user confirmation before deletion
    """
    gc.collect()  # force garbage collection

    def format_size(bytes_val):
        """Convert bytes into human-readable KB/MB/GB."""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_val < 1024:
                return f"{bytes_val:.2f} {unit}"
            bytes_val /= 1024
        return f"{bytes_val:.2f} PB"



    def parse_size(size_str):
        """Convert string like '1MB', '500KB', '2GB' into bytes."""
        if isinstance(size_str, (int, float)):  # already numeric (bytes)
            return int(size_str)

        size_str = size_str.strip().upper()
        units = [("TB", 1024**4), ("GB", 1024**3), ("MB", 1024**2), ("KB", 1024), ("B", 1)]

        for unit, factor in units:
            if size_str.endswith(unit):
                num = float(size_str.replace(unit, ""))
                return int(num * factor)

        raise ValueError("Invalid size format. Use like '1MB', '500KB', '2GB'.")


    # Collect global variables (ignore dunders, modules, functions)
    all_vars = {
        k: v for k, v in globals().items()
        if not k.startswith("__")
        and not isinstance(v, type(sys))   # exclude imported modules
        and not callable(v)                # exclude functions
    }

    if not all_vars:
        print("No user-defined variables found.")
        return []

    # Get variable sizes
    var_info = []
    for name, val in all_vars.items():
        try:
            size = sys.getsizeof(val)
        except Exception:
            size = 0
        var_info.append((name, type(val).__name__, size))

    # Sort descending by size
    var_info.sort(key=lambda x: x[2], reverse=True)

    # Print table
    print(f"{'Name':<20} | {'Type':<15} | {'Size':<12}")
    print("-" * 55)
    for name, typ, size in var_info:
        print(f"{name:<20} | {typ:<15} | {format_size(size):<12}")

    # --- Deletion logic ---
    to_delete = []

    if delete_top_n is not None:
        to_delete.extend([name for name, _, _ in var_info[:delete_top_n]])

    if delete_threshold is not None:
        threshold_bytes = parse_size(delete_threshold)
        to_delete.extend([name for name, _, size in var_info if size > threshold_bytes])

    to_delete = list(set(to_delete))  # remove duplicates

    if to_delete:
        if confirm:
            #answer = input(f"\n⚠️ About to delete: {to_delete}. Type 'yes' to confirm: ")
            answer = 'yes'
            if answer.lower() != "yes":
                print("❌ Deletion cancelled.")
                return var_info

        for var in to_delete:
            del globals()[var]

        print(f"\n✅ Deleted variables: {to_delete}")


    return var_info


#big_list = list(range(2000000))  # ~16 MB
#small_list = list(range(10))     # ~112 B
#text = "hello" * 1000            # ~5 KB


#manage_user_variables(delete_top_n=0,delete_threshold="10MB", confirm=True)

print("done2")