# If you have higher limits and want better performance:
import pandas as pd  # pandas-1.5.3  1.3.5   2.2.3
import numpy as np  # numpy-1.26.4   1.21.6   2.0.2
from settings import (
    BT_SCREENER_CSV,
    EMPTY_BT_SCREENER_MSG,
    MAX_RETRIES,
    NIFTY_WEEKLY_AVG_STATS_IMAGE,
    NO_NEW_SIGNALS_FOUND_MSG,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    TALIB_SCREENER_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
    TRADEBOOK_CSV,
)
from mail_utils import trigger_generic_email
from datetime import date
from telegram_bot import (
    post_telegram_file,
    post_telegram_message,
    shutdown_bot,
    trigger_telegram_notifications,
)
from symbol_copy import (
    manage_user_variables,
)
from PDFconvert import create_pdf
from custum_index import addchartspdf
from cleanup import (
    cleanup_files,
    delete_large_files,
)
from add_company_name import (
    copyfile1,
    update_output_file,
    vlookup_and_merge,
)
from symbol_copy import (
    import_user_module,
    manage_user_variables,
    manage_zip,
    update_exclude_list,
)

import traceback
import yfinance as yf
import uuid
import time
import csv
import matplotlib
import warnings
import multiprocessing
import os
import subprocess
import sys


cpu_count = multiprocessing.cpu_count()
print(cpu_count)

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
os.environ['NUMEXPR_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'

# Use 2-4 threads if system allows
# os.environ['OPENBLAS_NUM_THREADS'] = str(min(4, cpu_count))


def ensure_llvmlite_numba_by_file():
    """
    Checks if libllvmlite.so exists in the Pybroker39zz virtual environment.
    If not, installs specific versions of llvmlite and numba.
    """
    lib_file = "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/llvmlite/binding/libllvmlite.so"

    if os.path.isfile(lib_file):
        print(f"{lib_file} exists. Skipping installation.")
    else:
        print(f"{lib_file} not found. Installing llvmlite and numba...")
        packages = [
            "llvmlite==0.45.0",
            "numba==0.62.0"
        ]
        cmd = [sys.executable, "-m", "pip", "install",
               "--no-cache-dir", "--force-reinstall"] + packages
        try:
            subprocess.check_call(cmd)
            print("Successfully installed llvmlite and numba.")
        except subprocess.CalledProcessError as e:
            print(f"Error installing packages: {e}")

# ensure_llvmlite_numba_by_file()


# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


file_path = '/home/rizpython236/BT5/screener-outputs/Tickerdata.zip'
if os.path.exists(file_path):
    1+1
    #os.remove(file_path)
# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
# sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages')


print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")
# import pandas as pd
# pd.options.mode.copy_on_write = True  # Enable CoW for the entire session
warnings.simplefilter(action='ignore', category=FutureWarning)
# Pandas version: 1.3.5
# Numpy version: 1.21.6
# pd.options.compute.use_bottleneck = True  # Enable bottleneck
# Check if bottleneck is installed and enabled
print(f"Bottleneck acceleration: {pd.options.compute.use_bottleneck} "
      "(Faster NaN-aware operations like mean(), median())")
# Check if numexpr is installed and enabled
# pd.options.compute.use_numexpr = True     # Enable numexpr
print(f"Numexpr acceleration: {pd.options.compute.use_numexpr} "
      "(Optimizes arithmetic/boolean operations)")
# pd.options.mode.string_storage = "pyarrow"  # For pandas 2.0+
print(f"PyArrow string storage: {pd.options.mode.string_storage} "
      "(Reduces memory usage for text columns by 50-80%)")
# pd.options.mode.dtype_backend = "pyarrow"  # Not "dtype="
# print(f"PyArrow dtype backend: {pd.options.mode.dtype_backend} "
#       "(Uses Arrow types for all columns - experimental in Pandas 2.0+)")
# pd.options.compute.use_numba = True
print(f"Numba JIT compilation: {pd.options.compute.use_numba} "
      "(Speeds up rolling/groupby operations - requires numba install)")
np.set_printoptions(precision=6, suppress=True)
pd.set_option('display.precision', 6)
# pd.set_option("mode.chained_assignment", "warn")  # Detects inefficiencies


matplotlib.use('agg')  # Must be set BEFORE importing plt


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


yf.set_tz_cache_location("/home/rizpython236/.cache/py-yfinance")
# yf.enable_debug_mode()
# import yfinance_cache as yfc
# import shutil


# from functools import lru_cache, cache
# @lru_cache(maxsize=32)  # Stores up to 32 most recent calls
# np.__config__.show()

# from Valid_add_company_name import Valid_add_company_name,Validvlookup_and_merge,copyfile

# print(sys.prefix)
# print("sys.path before append:", sys.path)
# print("______________________________________________________________")
sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
# print("sys.path after append:", sys.path)
time.sleep(2)
# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/pandas_ta/__init__.py")

base_dir_module = "/home/rizpython236/BT5"
# print(ta)
# import SME_

'''
input_file = '/home/rizpython236/BT5/Final.csv'
#input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
copyfile1(input_file, output_file)

input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
update_output_file(input_file, output_file)

output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
vlookup_and_merge(output_file)


update_exclude_list(exclude_file="/home/rizpython236/BT5/exclude_tickers.csv")

input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
add_company_names_and_industry(input_file, output_file)

dddd



#import_user_module(base_dir_module, "datadownload15yr")
#import_user_module(base_dir_module, "BTmombroker")

input_file = '/home/rizpython236/BT5/Final.csv'
# input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
copyfile1(input_file, output_file)

input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
update_output_file(input_file, output_file)
'''
#import_user_module(base_dir_module, "pybrokerBT")


output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
vlookup_and_merge(output_file)

delete_large_files('/home/rizpython236/', 10000)
manage_user_variables(delete_top_n=0, delete_threshold="2MB", confirm=True)


Codestart_time = time.time()

BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
df_trade_list_BT_Screener = pd.read_csv(BT_FILE_PATH)
df_trade_list_BT_Screener = df_trade_list_BT_Screener[[
    'Score', 'N750', 'ticker', 'dir', 'datein', 'pricein', 'Company', 'Industry']]
df_trade_list_BT_Screener.sort_values(by=['dir', 'Industry', 'N750', 'Score'], ascending=[
                                      True, True, False, True], inplace=True)
df_trade_list_BT_Screener.to_csv(BT_FILE_PATH, index=False)

time.sleep(5)
# Replace with desired output PDF file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf'
# create_pdf(BT_FILE_PATH, output_pdf_file,pageA4= True)
# time.sleep(5)
# post_telegram_file("/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf")
bt_data = pd.read_csv(BT_FILE_PATH)
holding_file = "/home/rizpython236/BT5/myholding.csv"
holding_file = pd.read_csv(holding_file)

filtered = bt_data[bt_data['ticker'].isin(holding_file['Symbol'])]
filtered.sort_values(by=['dir', 'Industry', 'N750', 'Score'], ascending=[
                     True, True, False, True], inplace=True)
filtered.to_csv(
    "/home/rizpython236/BT5/screener-outputs/filteredBT.csv", index=False)
time.sleep(2)
BT_FILE_PATH_filtered = "/home/rizpython236/BT5/screener-outputs/filteredBT.csv"

# Replace with desired output PDF file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/filteredBT.pdf'
create_pdf(BT_FILE_PATH_filtered, output_pdf_file, pageA4=True)
time.sleep(5)
post_telegram_file("/home/rizpython236/BT5/screener-outputs/filteredBT.pdf")


BT_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + BT_SCREENER_CSV
TALIB_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + TALIB_SCREENER_CSV
CURRENT_DAY_SCREENER_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
TRADEBOOK_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + TRADEBOOK_CSV
TODAYS_DATE = date.today()
empty_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/emptyscreener.csv"


dir6 = "/home/rizpython236/BT5/ticker-csv-files"
for f in os.listdir(dir6):
    # os.remove(os.path.join(dir6, f))
    1+1

BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
if os.path.exists(BT_FILE_PATH):
    # if 123565 == 123565:
    # dir6 = "/home/rizpython236/BT5/ticker_daily1yr"
    dir6 = "/home/rizpython236/BT5/ticker_15yr"
    for f in os.listdir(dir6):
        # os.remove(os.path.join(dir6, f))
        1+1
else:
    1+1


######################
# Calculate elapsed time
elapsed_seconds = time.time() - Codestart_time

# Convert to hours, minutes, seconds
hours = int(elapsed_seconds // 3600)
remaining_seconds = elapsed_seconds % 3600
minutes = int(remaining_seconds // 60)
seconds = remaining_seconds % 60
print(f"Execution time: {hours}h {minutes}m {seconds:.2f}s")
post_telegram_message(f"Execution time: {hours}h {minutes}m {seconds:.2f}s")
###############################


with open(BT_FILE_PATH, "r") as f:
    reader = csv.reader(f)
    header = next(reader)
    data = [row for row in reader]
    if not data:
        print("NO_NEW_SIGNALS_FOUND_MSG")
        post_telegram_message("NO_NEW_SIGNALS_FOUND_MSG")
        src_path = empty_FILE_PATH
        dst_path = BT_FILE_PATH
        # shutil.copy2(src_path, dst_path)
        # shutil.copy2(trade_list_BT_Screener.csv, trade_list_Talib_Screener.csv)
        # print("The file has no data under the header column.")
    else:
        # post_telegram_message("BT_file_has_screener_data")
        print("BT file has screener data")
        # continue
        # shutil.copy2(BT_FILE_PATH.csv, empty_FILE_PATH)
        # Continue with the rest of the code here

bt_data = pd.read_csv(BT_FILE_PATH)
talib_data = pd.read_csv(TALIB_FILE_PATH)
# new_screener_data = pd.read_csv(NEW_FILE_PATH)
tradebook = pd.read_csv(TRADEBOOK_FILE_PATH)


"""
Checking if the BT-data is empty or not and
triggering a mail if it's empty.
"""
if len(bt_data) == 0:
    print(EMPTY_BT_SCREENER_MSG)
    trigger_generic_email(msg=EMPTY_BT_SCREENER_MSG)
    sys.exit()


bt_tickers = list(bt_data["ticker"].unique())
talib_tickers = list(talib_data["ticker"].unique())


active_tradebook = tradebook[tradebook["status"] == "active"]
active_tradebook_tickers = list(active_tradebook["ticker"].unique())


def fetch_talib_results_for_ticker(ticker):

    talib_record = {"talib_date": "", "talib_signal": "", "talib_price": ""}

    if ticker not in talib_tickers:
        return talib_record

    talib_record["talib_date"] = talib_data.loc[
        talib_data["ticker"] == ticker, "datein"
    ].iloc[0]
    talib_record["talib_signal"] = talib_data.loc[
        talib_data["ticker"] == ticker, "dir"
    ].iloc[0]
    talib_record["talib_price"] = talib_data.loc[
        talib_data["ticker"] == ticker, "pricein"
    ].iloc[0]

    return talib_record


def trigger_compilation():

    new_trades = []
    signal_changed_messages = []

    for row in range(len(bt_data)):

        ticker = bt_data["ticker"][row]
        generated_signal = bt_data["dir"][row]

        ticker_date = bt_data.loc[bt_data["ticker"]
                                  == ticker, "datein"].iloc[0]
        ticker_signal = bt_data.loc[bt_data["ticker"] == ticker, "dir"].iloc[0]
        ticker_price = bt_data.loc[bt_data["ticker"]
                                   == ticker, "pricein"].iloc[0]
        ticker_Company = bt_data.loc[bt_data["ticker"]
                                     == ticker, "Company"].iloc[0]
        ticker_Industry = bt_data.loc[bt_data["ticker"]
                                      == ticker, "Industry"].iloc[0]
        ticker_Score = bt_data.loc[bt_data["ticker"]
                                   == ticker, "Score"].iloc[0]
        pnl_percentage = None

        if ticker in active_tradebook_tickers:
            # print("Ticker already present, checking for active signal ...")
            active_signal = active_tradebook.loc[
                active_tradebook["ticker"] == ticker, "signal"
            ].iloc[0]

            if active_signal == generated_signal:
                # signal has not changed, hence continue
                continue
            else:
                #print("Signal changed for => {}. Updating status to...".format(ticker))
                print(
                    f"Signal changed for => {ticker}. Updating status to {generated_signal}...")
                message = "Signal changed {}.".format(ticker)
                signal_changed_messages.append(message)
                time.sleep(2)
                post_telegram_message(f"Signal changed for => {ticker}. Updating status to {generated_signal}...")
                trade_id = active_tradebook.loc[
                    active_tradebook["ticker"] == ticker, "trade_id"
                ].iloc[0]
                old_trade_price = active_tradebook.loc[
                    active_tradebook["trade_id"] == trade_id, "price"
                ].iloc[0]

                tradebook.loc[
                    (tradebook["trade_id"] == trade_id), ["status"]
                ] = "closed"
                tradebook.loc[
                    (tradebook["trade_id"] == trade_id), ["trade_updated_on"]
                ] = str(TODAYS_DATE)

                if active_signal == "BUY" and generated_signal == "SELL":
                    print(
                        "Buy + Sell completed for {}, calculating PnL.".format(
                            ticker)
                    )
                    pnl_percentage = round(
                        ((ticker_price - old_trade_price) / old_trade_price) * 100, 2
                    )
                    # tradebook.loc[
                    #     active_tradebook["trade_id"] == trade_id, "pnl"
                    # ] = pnl_percentage

        talib_data_dict = fetch_talib_results_for_ticker(ticker)
        # new_screener_dict = fetch_new_screener_dict(ticker)

        record = {
            "trade_logged_on": str(TODAYS_DATE),
            "trade_id": str(uuid.uuid4()),
            "status": "active",
            "date": ticker_date,
            "ticker": ticker,
            "signal": ticker_signal,
            "price": ticker_price,
            "Company": ticker_Company,
            "Industry": ticker_Industry,
            "Score": ticker_Score,
        }

        if pnl_percentage:
            record.update({"pnl": pnl_percentage})

        record.update(talib_data_dict)
        # record.updated(new_screener_dict)
        new_trades.append(record)
        record = {}

    try:
        for i in range(0, len(signal_changed_messages), 35):
            block = signal_changed_messages[i:i+35]
            print('\n'.join(block))
            time.sleep(3)
            #post_telegram_message('\n'.join(block))
    except Exception as e:
        print(f"⚠️signal_changed_messages error: {e}")
        post_telegram_message("signal_changed_messages error")
        pass

    return new_trades


def cleanup_files():

    print("-" * 50)
    print("Removing the files ...")
    print("-" * 50)

    # remove BT Screener Output
    print("Deleting BT Screener Output File.")
    if os.path.exists(BT_FILE_PATH):
        os.remove(BT_FILE_PATH)

    # remove Talib Output
    print("Deleting Talib Screener Output File.")
    if os.path.exists(TALIB_FILE_PATH):
        os.remove(TALIB_FILE_PATH)

    # remove Talib Output
    print("Deleting Last Saved Screener Output File.")
    if os.path.exists(CURRENT_DAY_SCREENER_FILE_PATH):
        # os.remove(CURRENT_DAY_SCREENER_FILE_PATH)
        1+1

    # remove valid, invalid and incomplete ticker csvs
    print("Emptying valid, invalid and incomplete ticker output files.")
    dir1 = SCREENER_OUTPUT_FOLDER_PATH
    for f in os.listdir(dir1):
        ff = dir1 + "/" + f
        temp_df = pd.read_csv(ff)
        temp_df.drop(temp_df.index, inplace=True)
        temp_df.to_csv(ff, index=False)
        # os.remove(os.path.join(dir1, f))

    # remove Symbol list
    # print("Emptying Symbol List")
    # sym_df = pd.read_csv(SYMBOLS_CSV)
    # sym_df.drop(sym_df.index, inplace=True)
    # sym_df.to_csv(SYMBOLS_CSV, index=False)

    # ff = "./screener-outputs/valid_tickers.csv"
    # temp_df = pd.read_csv(ff)
    # temp_df.drop(temp_df.index, inplace=True)
    # temp_df.to_csv(ff, index=False)

    # remove ticker data csv files
    print("Deleting all the ticker data csv files.")
    dir2 = TICKER_CSV_DATA_FOLDER_PATH
    for f in os.listdir(dir2):
        # os.remove(os.path.join(dir2, f))
        1+1

    print("Deleting Nifty Weekly Avg Stats Image")
    if os.path.exists(NIFTY_WEEKLY_AVG_STATS_IMAGE):
        os.remove(NIFTY_WEEKLY_AVG_STATS_IMAGE)

    # folder = TICKER_CSV_DATA_FOLDER_PATH
    # for filename in os.listdir(folder):
    #    file_path = os.path.join(folder, filename)
    #    try:
    #        if os.path.isfile(file_path) or os.path.islink(file_path):
    #            os.unlink(file_path)
    #        elif os.path.isdir(file_path):
    #            shutil.rmtree(file_path)
    #    except Exception as e:
    #        print("Failed to delete %s. Reason: %s" % (file_path, e))


def generate_notifications(new_trades):

    if not new_trades:
        print("No new signals for today!")
        # trigger_generic_email(msg=NO_NEW_SIGNALS_FOUND_MSG)
        post_telegram_message(message=NO_NEW_SIGNALS_FOUND_MSG)
        # cleanup_files()
        return

    new_trades_df = pd.DataFrame(data=new_trades)
    # here we are sorting based on BT signal type - column = "signal"
    new_trades_df = new_trades_df.sort_values("signal")
    updated_tradebook = pd.concat([tradebook, new_trades_df], axis=0)
    updated_tradebook.to_csv(TRADEBOOK_FILE_PATH, index=False)

    FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/Finalnse.csv")
    FinalMicrocap250symbols = FinalMicrocap250['Symbol'].tolist()[:]
    # NSE570symbols = list(dict.fromkeys(symbols))
    FinalMicrocap250symbols = list(set(FinalMicrocap250symbols))

    '''
    Scoretickersall = pd.read_csv("/home/rizpython236/BT5/trade-logs/Scoretickersall.csv")
    Scoretickersall = Scoretickersall.drop(columns=['Company'])
    # Merge on ticker symbol
    new_trades_df = new_trades_df.merge(Scoretickersall, left_on='ticker', right_on='Ticker', how='left')
    # Drop duplicate 'Ticker' column (optional)
    new_trades_df = new_trades_df.drop(columns=['Ticker'])
    '''

    new_trades_df['N750'] = new_trades_df['ticker'].apply(
        lambda x: 'Y' if x in FinalMicrocap250symbols else '')
    # date ticker signal price Company Industry  N750
    new_trades_df = new_trades_df[[
        'date', 'N750', 'ticker', 'signal', 'price', 'Company', 'Industry', 'Score']]
    new_trades_df.sort_values(by=['signal', 'Industry', 'N750', 'Score'], ascending=[
                              True, True, False, True], inplace=True)
    new_trades_file_path = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
    new_trades_df.to_csv(new_trades_file_path, index=False)

    # trigger_email_notification()
    time.sleep(1)
    trigger_telegram_notifications()

    # cleanup_files()
    # import cleanup


def main():

    new_trades = trigger_compilation()
    try:
        generate_notifications(new_trades)

        folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
        folder_path = "/home/rizpython236/BT5/ticker_15yr"
        filepathpdf = '/home/rizpython236/BT5/screener-outputs/screener_output_Charts.pdf'
        screenercsv_path = '/home/rizpython236/BT5/trade-logs/screener-output.csv'
        addchartspdf(screenercsv_path=screenercsv_path,
                     folder_path=folder_path, filepathpdf=filepathpdf)
    except Exception as e:
        print(f"⚠️ generate_notifications error: {e}")

    BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
    # Replace with desired output PDF file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf'
    create_pdf(BT_FILE_PATH, output_pdf_file, pageA4=True)
    time.sleep(5)
    post_telegram_file(
        "/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf")

    filepathBTpdf = '/home/rizpython236/BT5/screener-outputs/BTbuy_Charts.pdf'
    screenercsvBT_path = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
    addchartspdf(screenercsv_path=screenercsvBT_path,
                 folder_path=folder_path, filepathpdf=filepathBTpdf)

    try:
        base_dir_module = "/home/rizpython236/BT5"
        import_user_module(base_dir_module, "tradebookanalysis")
    except Exception as e:
        print(f"⚠️ tradebookanalysis error: {e}")
        # post_telegram_message("signal_changed_messages error")

    # import csv15yrs
    dir6 = "/home/rizpython236/BT5/ticker-csv-files"
    for f in os.listdir(dir6):
        # os.remove(os.path.join(dir6, f))
        1+1

    # import datadownload15yr
    # import relative_performance15yr
    # time.sleep(1)
    # import csv15yrs
    # import Drawdownchart15yr
    # import tradebookanalysis
    post_telegram_message("That was all for today!")
    dir6 = "/home/rizpython236/BT5/ticker_15yr"
    for f in os.listdir(dir6):
        # os.remove(os.path.join(dir6, f))
        1+1
    # shutdown_bot()
    # atexit.register(shutdown_bot)
    shutdown_bot()
    sys.exit(1)


MAX_RETRIES = 1

while MAX_RETRIES:
    try:
        main()
        MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(10)
        print("💀Operation Failed! Retrying...")
        print(traceback.format_exc())
        print(exc)
        print("-" * 50)
        sys.exit(1)
        MAX_RETRIES -= 1
