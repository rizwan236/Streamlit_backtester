import os
import sys

#import yfinance as yf
import numpy as np
import pandas as pd
from scipy import stats


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")
import pandas_ta as ta


print("MRP")
'''
def add_relative_performance_folder(folder_path, lookback):
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            add_relative_performance(file_path, lookback)

def add_relative_performance(filename, lookback):
    # Load the CSV file into a DataFrame
    df = pd.read_csv(filename)

    # Retrieve data for Nifty and Bank Nifty
    nifty_df = pd.read_csv("/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv",parse_dates=['Date'])
    banknifty_df = pd.read_csv("/home/rizpython236/BT5/ticker-csv-files/^NSEBANK.csv",parse_dates=['Date'])

    # Calculate daily returns for Nifty and Bank Nifty
    nifty_df['Return'] = (nifty_df['Close'] - nifty_df['Close'].shift(1)) / nifty_df['Close'].shift(1) * 100
    banknifty_df['Return'] = (banknifty_df['Close'] - banknifty_df['Close'].shift(1)) / banknifty_df['Close'].shift(1) * 100

    # Calculate average returns for Nifty and Bank Nifty
    nifty_df['Avg_Return'] = nifty_df['Return'].rolling(lookback).mean()
    banknifty_df['Avg_Return'] = banknifty_df['Return'].rolling(lookback).mean()

    # Fill missing values in 'Avg_Return' column with 0
    nifty_df['Avg_Return'].fillna(0, inplace=True)
    banknifty_df['Avg_Return'].fillna(0, inplace=True)

    # Convert 'Avg_Return' column to numeric type
    #nifty_df['Avg_Return'] = pd.to_numeric(nifty_df['Avg_Return'], errors='coerce')
    #banknifty_df['Avg_Return'] = pd.to_numeric(banknifty_df['Avg_Return'], errors='coerce')

    print(nifty_df)

    print(df['Date'].isnull().sum())
    print(nifty_df['Date'].isnull().sum())
    df['Date'] = pd.to_datetime(df['Date'])
    print(df['Date'].dtype)
    print(nifty_df['Date'].dtype)

    # Merge Nifty and Bank Nifty data with the original DataFrame
    merged_df = pd.merge(df, nifty_df[['Date', 'Avg_Return']], left_on='Date', right_on='Date', how='left', sort=False)
    merged_df = pd.merge(merged_df, banknifty_df[['Date', 'Avg_Return']], on='Date', how='left', sort=False)

    # Calculate relative performance
    merged_df['Relative_Performance'] = (merged_df['Close'] - merged_df['Close'].rolling(lookback).mean()) / merged_df['Close'].rolling(lookback).mean() * 100 - (merged_df['Avg_Return_x'] + merged_df['Avg_Return_y']) / 2

    # Save the updated DataFrame back to the CSV file
    merged_df.to_csv(filename, index=False)

# Example usage
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
lookback = 55
add_relative_performance_folder(folder_path, lookback)
'''

import os

import numpy as np
import pandas as pd
from scipy import stats


def calculate_exponential_linear_regression(dataexp,period=12):
    # Download historical data from yfinance
    #data =  dataexp # yf.download(stock_symbol, period="1y")
    #print(data)
    dataexp = dataexp.iloc[-(period+5):]
    # Calculate the natural logarithm of returns
    returns = np.log(dataexp['Close'])
    #print(returns)
    x = np.arange(len(returns))
    #print(x)

    slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
    annualized_slope = (np.power(np.exp(slope), 252) - 1) * 100
    r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
    annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    #print(slope)
    #print(annualized_slope)

    # Calculate linear regression
    #slope, _, r_value, _, _ = stats.linregress(x, returns)

    # Calculate annualized slope
    #annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    # Calculate annualized_slope_r_value
    #annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Round the annualized slope and annualized_slope_r_value
    #rounded_annualized_slope = round(annualized_slope, 2)

    # Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    #higher_value = annualized_slope_r_value #np.maximum(annualized_slope_r_value, rounded_annualized_slope)

    return annualized_slope_r_value
'''
def get_stock_csv_files(folder_path):
    csv_files = []

    for file in os.listdir(folder_path):
        if file.endswith(".csv"):
            csv_files.append(os.path.join(folder_path, file))

    return csv_files
'''
def get_stock_csv_files(folder_path):
    return [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith(".csv")]

'''
def calculate_mrp(stock_csv_file, index_csv_file):
    # Load stock and index data from CSV files
    stock_data = pd.read_csv(stock_csv_file)
    index_data = pd.read_csv(index_csv_file)

    MDD_df = pd.DataFrame()
    MDD_df =stock_data
    MDD_df.ta.exchange = "NSE"


    # Calculate daily returns
    stock_data_df = pd.DataFrame()
    index_data_df = pd.DataFrame()
    stock_data_df['Close'] = stock_data['Close'].pct_change()
    index_data_df['Close'] = index_data['Close'].pct_change()

    MDD_df1 = ta.drawdown(MDD_df.Close)
    #print(MDD_df1)
    #MDD_df1 = ta.cdl_pattern(MDD_df.Open, MDD_df.High, MDD_df.Low, MDD_df.Close,name=["2crows", "3blackcrows","3whitesoldiers","identical3crows","morningstar",])
    MDD_df1['DD'] = (MDD_df1['DD'] * 1).round(2)
    MDD_df1['DD_PCT'] = (MDD_df1['DD_PCT'] * 100).round(2)
    MDD_df1['DD_LOG'] = (MDD_df1['DD_LOG'] * 100).round(2)

    #MDD_df2 = ta.zscore(MDD_df.Close, length=25, std=1.5, offset=None)
    #print(MDD_df2)
    #MDD_df2['ZS_25'] = (MDD_df2 * 1).round(2)
    #print(MDD_df2['ZS_25'])


    # Print the DataFrame to see the added column
    #print('xxxxxxxxxxxx')
    #print(MDD_df1)




    # Calculate cumulative returns
    stock_data_df['Stock_Cumulative_Return'] = (1 + stock_data_df['Close']).cumprod()
    index_data_df['Dow_Cumulative_Return'] = (1 + index_data_df['Close']).cumprod()

    # Set initial value to 100
    initial_value = 100
    dataexp = pd.DataFrame()
    dataexp['Close']=stock_data_df['Close'] = initial_value * stock_data_df['Stock_Cumulative_Return']
    index_data_df['Close'] = initial_value * index_data_df['Dow_Cumulative_Return']
    #print(np.log(index_data['Close']))

    result = calculate_exponential_linear_regression(dataexp,period=180)


    # Calculate Relative Performance (RP)
    RP = (stock_data_df["Close"] / index_data_df["Close"])
    #RP = (np.log10(stock_data_df["Close"]) / np.log10(index_data_df["Close"]))
    #RP = (np.log(stock_data["Close"])  / np.log(index_data["Close"])) * 1
    #print(RP1)
    #print(RP)

    # Calculate RP52W (Simple Moving Average over 52 weeks)
    RP13SMA = RP.rolling(window=13*5).mean()  #RP.ewm(span=13).mean()
    RP25SMA = RP.rolling(window=26*5).mean()
    RP13EMA = RP.ewm(span=13*5).mean()  #RP.ewm(span=13).mean()
    RP25EMA = RP.ewm(span=26*5).mean()

    # Calculate Mansfield Relative Performance (MRP)
    MRP13S = ((RP / RP13SMA) - 1) * 100 #(np.log((RP / RP13W) -1))*100 #
    MRP25S = ((RP / RP25SMA) - 1) * 100
    MRP13E = ((RP / RP13EMA) - 1) * 100 #(np.log((RP / RP13W) -1))*100 #
    MRP25E = ((RP / RP25EMA) - 1) * 100
    MAX13 = pd.concat([MRP13S, MRP13E], axis=1).min(axis=1)
    MAX25 = pd.concat([MRP25S, MRP25E], axis=1).min(axis=1)

    #print(MRP13)


    # Add MRP values to the stock data
    stock_data["MRP13"] = round(MAX13,3)
    stock_data["MRP25"] = round(MAX25,3)
    stock_data['MRP'] = round(pd.to_numeric(RP, errors='coerce'),3)
    #stock_data["MRP"] = round(RP,3)
    stock_data["Exp"] = round(result,3)
    #stock_data["Corr"] = round(correlation_coefficient,3)
    #time.sleep(20000)
    stock_data= pd.concat([stock_data, MDD_df1], axis=1)

    #print(stock_data)


    # Save the updated stock data to a new CSV file
    stock_data.to_csv(stock_csv_file, index=False)
'''


def calculate_mrp(stock_csv_file, index_csv_file):
    # Load stock and index data from CSV files
    stock_data = pd.read_csv(stock_csv_file)
    index_data = pd.read_csv(index_csv_file)

    # Assuming MDD_df is a placeholder for stock_data, adjust as necessary
    MDD_df = stock_data.copy()
    #MDD_df.ta.exchange = "NSE"

    # Calculate daily returns
    #max_rows = min(len(stock_data), len(index_data))
    #stock_data = stock_data.iloc[max_rows:]  # Slice stock_data to match index_data
    #index_data = index_data.iloc[max_rows:]  # Slice stock_data to match index_data
    #MDD_df =MDD_df.iloc[max_rows:]
    stock_data1 = pd.DataFrame()
    index_data1 = pd.DataFrame()
    stock_data1['Close'] = stock_data['Close'].pct_change()
    index_data1['Close'] = index_data['Close'].pct_change()

    MDD_df1 = ta.drawdown(MDD_df['Close'])
    MDD_df1[['DD', 'DD_PCT', 'DD_LOG']] = MDD_df1[['DD', 'DD_PCT', 'DD_LOG']].round(4)

    # Calculate cumulative returns
    stock_data['Stock_Cumulative_Return'] = 100*(1 + stock_data1['Close']).cumprod()
    index_data['Dow_Cumulative_Return'] = 100*(1 + index_data1['Close']).cumprod()

    # Adjust initial value calculation
    initial_value = 1
    stock_data1['Close'] = initial_value * stock_data['Stock_Cumulative_Return']
    index_data1['Close'] = initial_value * index_data['Dow_Cumulative_Return']

    # Assuming calculate_exponential_linear_regression is defined elsewhere
    result = calculate_exponential_linear_regression(stock_data, period=180)

    # Calculate Relative Performance (RP)
    RP = stock_data1['Close'] / index_data1['Close']
    RP=round(RP,4)

    # Calculate RP52W (Simple Moving Average over 52 weeks)
    #RP13SMA = RP.rolling(window=13*5).mean()
    #RP25SMA = RP.rolling(window=26*5).mean()
    #RP13EMA = RP.ewm(span=5).mean()
    #RP25EMA = RP.ewm(span=14*5).mean()

    # Calculate Mansfield Relative Performance (MRP)
    #MRP13S = ((RP / RP13SMA) - 1) * 100
    #MRP25S = ((RP / RP25SMA) - 1) * 100
    #MRP13E = ((RP / RP13EMA) - 1) * 100
    #MRP25E = ((RP / RP25EMA) - 1) * 100
    #MAX13 = pd.concat([MRP13S, MRP13E], axis=1).min(axis=1)
    #MAX25 = pd.concat([MRP25S, MRP25E], axis=1).min(axis=1)

    # Add MRP values to the stock data
    stock_data['MRP13'] = round(RP, 3)
    stock_data['MRP25'] = round(RP, 3)
    stock_data['MRP'] = round(RP, 3)
    stock_data['Exp'] = round(result, 3)

    # Assuming MDD_df1 is a DataFrame with relevant columns
    stock_data = pd.concat([stock_data, MDD_df1], axis=1)
    stock_data[['DD_PCT', 'DD_LOG']] *= 100
    #print(stock_data)
    # Save the updated stock data to a new CSV file
    stock_data.to_csv(stock_csv_file, index=False)


# Provide the folder path where the stock CSV files are located
stock_folder_path = '/home/rizpython236/BT5/ticker_daily1yr/'

# Get the list of stock CSV files in the folder
stock_csv_files = get_stock_csv_files(stock_folder_path)

# Provide the file path for the index CSV file
index_csv_file = "/home/rizpython236/BT5/ticker_daily1yr/^NSEI.csv"

# Calculate MRP and update each stock CSV file
for stock_csv_file in stock_csv_files:
    calculate_mrp(stock_csv_file, index_csv_file)



def delete_mrp_column(stock_csv_file):
    # Load stock data from CSV file
    stock_data = pd.read_csv(stock_csv_file)

    # Check if MRP column exists in the stock data
    if 'MRP' in stock_data.columns:
        # Remove the MRP column
        stock_data.drop('MRP', axis=1, inplace=True)

        # Save the updated stock data to the same CSV file
        stock_data.to_csv(stock_csv_file, index=False)
        print(f"MRP column removed from {stock_csv_file}")
    else:
        print(f"No MRP column found in {stock_csv_file}")

# Provide the folder path where the stock CSV files are located
stock_folder_path = '/home/rizpython236/BT5/ticker-csv-files/'

# Get the list of stock CSV files in the folder
stock_csv_files = [os.path.join(stock_folder_path, file) for file in os.listdir(stock_folder_path) if file.endswith('.csv')]

# Delete the MRP column from each stock CSV file
#for stock_csv_file in stock_csv_files:
#    delete_mrp_column(stock_csv_file)


print("done")


'''
import yfinance as yf
import numpy as np
from scipy import stats

def calculate_exponential_linear_regression(period=12):
    # Download historical data from yfinance
    data =  stock_data_df['Close'] # yf.download(stock_symbol, period="1y")

    # Calculate the natural logarithm of returns
    returns = np.log(data['Close'])
    x = np.arange(len(returns))

    slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
    annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100
    r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
    annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Calculate linear regression
    #slope, _, r_value, _, _ = stats.linregress(x, returns)

    # Calculate annualized slope
    #annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    # Calculate annualized_slope_r_value
    #annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Round the annualized slope and annualized_slope_r_value
    rounded_annualized_slope = round(annualized_slope, 2)

    # Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    higher_value = max(annualized_slope_r_value, rounded_annualized_slope)

    return higher_value

# Example usage:
#stock_symbol = "AAPL"  # Replace with the stock symbol you want to analyze
#result = calculate_exponential_linear_regression(stock_symbol, period=12)
#print(f"The higher value is: {result}")
'''






