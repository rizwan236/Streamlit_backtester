from nsetools import Nse


# Create an instance of Nse
nse = Nse()

# Get stock details for a specific symbol
symbol = 'RELIANCE'  # Replace with the desired stock symbol
stock_info = nse.get_quote(symbol)

# Print fundamental data
print("Stock Name:", stock_info['companyName'])
print("Symbol:", stock_info['symbol'])
print("Industry:", stock_info['industry'])
print("Last Traded Price:", stock_info['lastPrice'])
print("PE Ratio:", stock_info['pe'])
print("Market Cap:", stock_info['marketCap'])

# You can explore other available attributes in the stock_info dictionary
