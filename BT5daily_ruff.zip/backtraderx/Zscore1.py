
import backtrader as bt
from datetime import datetime
from backtrader.indicators import PeriodN
#from scipy.stats import zscore
#import numpy as np


#https://github.com/mementum/backtrader/blob/master/backtrader/indicators/ols.py
class Z_score(PeriodN):

    #Calculates the ``zscore`` for data0 and data1. 
        
    _mindatas = 2  # ensure at least 2 data feeds are passed
    lines = ('zscore',)
    # lines = ('price', 'price_mean', 'price_std', 'zscore',)
    params = (('period', 10),('upperband', 3), ('lowerband', -3))

    def __init__(self):
        
        price = self.data.close
        self.l.price = price

        self.l.price_mean = bt.ind.SMA(price, period=self.p.period)
        self.l.std = bt.ind.StdDev(price, period=self.p.period)
        self.l.zscore = (price - self.l.price_mean) / self.l.std


'''

class Z_score(bt.Indicator):
    lines = ('trend',)
    #params = (('period', 125),('upperband', 40),('lowerband', 0),)
    params = (('period', 25),)

    #def _plotinit(self):
    #   self.plotinfo.plotyhlines = [self.params.upperband, self.params.lowerband]

    def __init__(self):
        self.addminperiod(self.params.period)
    
    def next(self):
        abc = np.array(self.data.get(size=self.p.period))
        zscorex =zscore(abc, axis=0, ddof=0, nan_policy='propagate')
        self.lines.trend = zscorex.item(0)  

'''