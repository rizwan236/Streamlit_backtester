import os
from pathlib import Path
import pandas as pd
import numpy as np
import vectorbt as vbt
import pandas_ta as ta
import matplotlib.pyplot as plt

# ===========================
# CONFIGURATION
# ===========================

# Data & Computation
DATA_FOLDER = Path("yfinance_data")    # Folder with OHLCV CSVs
USE_PARALLEL = True                     # Disable parallel computation if False
SAVE_REPORTS = True                     # Save CSV reports

# Backtest Parameters
INIT_CASH = 100_000
FEES = 0.001
SLIPPAGE = 0.0

# Position sizing options: "equal", "cash_per_ticker", "fixed_percent", "fixed_units"
POSITION_SIZING = "fixed_units"
FIXED_UNITS = 1  # Used only if POSITION_SIZING="fixed_units"
FIXED_PERCENT = 0.1  # Used only if POSITION_SIZING="fixed_percent"

# SMA Strategy Parameters
FAST_SMA_PERIOD = 10
SLOW_SMA_PERIOD = 50

# Optional Indicators (toggle True/False)
USE_RSI = False
RSI_PERIOD = 14
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30

USE_MACD = False
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9

# Plot Settings
PLOT_EQUITY = True
PLOT_DRAWDOWN = True

# ===========================
# VECTORBT PARALLEL CONTROL
# ===========================
if not USE_PARALLEL:
    vbt.settings.numba_parallel = False

# ===========================
# HELPER FUNCTIONS
# ===========================
def load_multi_ticker_data(folder_path: Path):
    """Load all CSVs into wide OHLCV DataFrames."""
    ohlcv_dict = {}
    for file in folder_path.glob("*.csv"):
        symbol = file.stem
        df = pd.read_csv(file, index_col="Date", parse_dates=True)
        ohlcv_dict[symbol] = df

    ohlcv_data = {}
    for col in ["Open", "High", "Low", "Close", "Adj Close", "Volume"]:
        ohlcv_data[col] = pd.DataFrame(
            {symbol: df[col] if col in df.columns else np.nan for symbol, df in ohlcv_dict.items()}
        )
    return ohlcv_data

def calculate_indicators(ohlcv_data):
    """Calculate SMA, RSI, MACD or other indicators."""
    close = ohlcv_data["Close"]
    indicators = {}

    # SMA
    indicators["SMA_fast"] = close.rolling(FAST_SMA_PERIOD).mean()
    indicators["SMA_slow"] = close.rolling(SLOW_SMA_PERIOD).mean()

    # RSI (optional)
    if USE_RSI:
        indicators["RSI"] = close.ta.rsi(length=RSI_PERIOD)

    # MACD (optional)
    if USE_MACD:
        macd = close.ta.macd(fast=MACD_FAST, slow=MACD_SLOW, signal=MACD_SIGNAL)
        indicators.update(macd)  # adds MACD, MACDs, MACDh

    return indicators

def generate_signals(indicators):
    """Generate SMA crossover entries/exits; can include optional filters."""
    entries = indicators["SMA_fast"] > indicators["SMA_slow"]
    exits = indicators["SMA_fast"] < indicators["SMA_slow"]

    # Example: Add RSI filter
    if USE_RSI and "RSI" in indicators:
        entries &= indicators["RSI"] < RSI_OVERSOLD
        exits |= indicators["RSI"] > RSI_OVERBOUGHT

    return entries, exits

def run_vectorbt_backtest(ohlcv_data, entries, exits, 
                          position_sizing="equal", fixed_units=10, fixed_percent=0.1):
    """Run vectorbt backtest for all tickers with flexible position sizing."""
    close = ohlcv_data["Close"]

    # Determine size argument
    if position_sizing == "equal":
        size = "auto"
    elif position_sizing == "cash_per_ticker":
        n_tickers = close.shape[1]
        size = INIT_CASH / n_tickers
    elif position_sizing == "fixed_percent":
        size = fixed_percent
    elif position_sizing == "fixed_units":
        size = fixed_units
    else:
        raise ValueError(f"Unknown position_sizing: {position_sizing}")

    portfolio = vbt.Portfolio.from_signals(
        close=close,
        entries=entries,
        exits=exits,
        init_cash=INIT_CASH,
        fees=FEES,
        slippage=SLIPPAGE,
        size=size
    )

    return portfolio

def generate_reports(portfolio, save_csv=False):
    """Generate all reports: stats, trades, equity curve, drawdowns."""
    stats = portfolio.stats()
    trades = portfolio.trades.records_readable
    equity_curve = portfolio.total_equity()
    drawdowns = portfolio.drawdowns.records_readable

    if save_csv:
        stats.to_csv("vectorbt_stats.csv")
        trades.to_csv("vectorbt_trades.csv")
        equity_curve.to_csv("vectorbt_equity.csv")
        drawdowns.to_csv("vectorbt_drawdowns.csv")

    return stats, trades, equity_curve, drawdowns

def plot_reports(portfolio):
    """Plot equity curve and drawdowns."""
    if PLOT_EQUITY:
        portfolio.total_equity().vbt.plot(title="Total Equity Curve")
        plt.show()
    if PLOT_DRAWDOWN:
        portfolio.drawdowns.plot(title="Drawdowns")
        plt.show()

# ===========================
# MAIN SCRIPT
# ===========================
if __name__ == "__main__":
    # 1️⃣ Load all tickers
    ohlcv_data = load_multi_ticker_data(DATA_FOLDER)

    # 2️⃣ Calculate indicators
    indicators = calculate_indicators(ohlcv_data)

    # 3️⃣ Generate signals
    entries, exits = generate_signals(indicators)

    # 4️⃣ Run backtest
    portfolio = run_vectorbt_backtest(
        ohlcv_data, entries, exits,
        position_sizing=POSITION_SIZING,
        fixed_units=FIXED_UNITS,
        fixed_percent=FIXED_PERCENT
    )

    # 5️⃣ Generate reports
    stats, trades, equity_curve, drawdowns = generate_reports(portfolio, save_csv=SAVE_REPORTS)

    # 6️⃣ Print reports
    print("===== Portfolio Stats =====")
    print(stats)
    print("\n===== Trade History =====")
    print(trades)
    print("\n===== Equity Curve (last 10) =====")
    print(equity_curve.tail(10))
    print("\n===== Drawdowns =====")
    print(drawdowns)

    # 7️⃣ Plot reports
    plot_reports(portfolio)
