import backtrader as bt
import pandas as pd
import talib
import pytz
import pandas as pd
import yfinance as yf

from datetime import datetime, date, timedelta
from backtrader.indicators.smma import SmoothedMovingAverage
from SCtrade_list import trade_list  # custum analyzer

# from limited_test_report import LimitedTestReport  # custum analyzer
from tabulate import tabulate

# from Baranalysis1 import BarAnalysis
from settings import SCREENER_OUTPUT_FOLDER_PATH, INVALID_TICKERS_FILE


INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
invalid_tickers_df = pd.read_csv(INVALID_TICKERS_FILE_PATH)
invalid_tickers = list(invalid_tickers_df["invalid_ticker"].unique())


class firstStrategy(bt.Strategy):
    params = (("sma10", 40), ("oneplot", True))

    def __init__(self):

        self.inds = dict()
        for i, d in enumerate(self.datas):
            self.inds[d] = dict()
            self.inds[d]["ADX"] = bt.indicators.AverageDirectionalMovementIndex(
                d, period=14, plotname="ADX", plot=False
            )
            self.inds[d]["RSI"] = bt.indicators.RSI(d.close, period=14, plot=False)
            self.inds[d]["OBV"] = bt.talib.OBV(d.close, d.volume)
            self.inds[d]["obvmovavg"] = bt.talib.EMA(self.inds[d]["OBV"], timeperiod=14)

            if i > 0:  # Check we are not on the first loop of data feed:
                if self.p.oneplot == True:
                    d.plotinfo.plotmaster = self.datas[0]
        """
        self.macd = bt.indicators.MACD(
            self.data, period_me1=12, period_me2=26, period_signal=9, plot=False)
        self.macdH = bt.indicators.MACDHisto()
        self.RSI = bt.indicators.RSI(period=14)
        self.ADX = bt.indicators.AverageDirectionalMovementIndex(
            self.data, period=14, plotname="ADX", plot=True)
        self.ATR = bt.talib.ATR(
            self.data.high, self.data.low, self.data.close, timeperiod=14, plotname='ATR')
        self.atrmovavg = bt.talib.EMA(self.ATR, timeperiod=7)
        self.max52 = bt.talib.MAX(
            self.data.high, timeperiod=52, plotname='wk52H', plot=True)
        self.min52 = bt.talib.MIN(
            self.data.low, timeperiod=52, plotname='wk52L', plot=True)
        self.Bema200 = bt.talib.EMA(
            self.data1.close, timeperiod=42, plotname='Bema52')
        self.Bema30 = bt.talib.EMA(
            self.data1.close, timeperiod=12, plotname='Bema30')"""

    def next(self):
        for i, d in enumerate(self.datas):
            dt, dn = self.datetime.date(), d._name
            # print("_________________")
            # print(dt, dn)
            # print("_________________")
            pos = self.getposition(d).size
            # print(len(d))
            lastdate = len(d) == (d.buflen() - 1)
            # self.position(d):  # no market / no orders
            if lastdate and not pos:
                if (
                    self.inds[d]["ADX"][0] > 0
                    and d.close[0] < 1000
                    # and self.macdH[0] > 0
                ):
                    self.buy(data=d, size=1)
                else:
                    if (
                        self.inds[d]["ADX"][0] < 100
                        # and self.macdH[0] < 0
                        and d.close[0] > 1000
                    ):
                        self.sell(data=d, size=1)
                    else:
                        if self.inds[d]["ADX"][0] < 28 and self.inds[d]["RSI"][0] > 80:
                            self.sell(data=d, size=1)

    """      
    def notify_trade(self, trade):
        dt = self.data.datetime.date()
        if trade.isopen:
            print('{} {} Opened: Price'.format(dt,trade.data._name,))    
            
    
    def next(self):
        if len(self.data) == (self.data.buflen()-1) and not self.position:
            if (
                #self.ADX[0] > 0
                d.close > 1000
                #and self.macdH[0] > 0
            ):
                self.buy()
            else: 
                if(
                    #self.ADX[0] > 28
                    #and self.macdH[0] < 0
                    d.close < 1000
                    ):
                    self.sell()
                else:
                    if (
                        self.ADX[0] < 28
                        and self.RSI[0] > 80
                    ):
                        self.sell()
    """


"""
def printTradeAnalysis(
    analyzer,
):
    total_open = analyzer.total.open
    total_closed = analyzer.total.closed
    total_won = analyzer.won.total
    total_lost = analyzer.lost.total
    win_streak = analyzer.streak.won.longest
    lose_streak = analyzer.streak.lost.longest
    pnl_net = round(analyzer.pnl.net.total, 2)
    strike_rate = round((total_won / total_closed) * 100, 2)
    # Designate the rows
    h1 = ["Total Open", "Total Closed", "Total Won", "Total Lost"]
    h2 = ["Strike Rate", "Win Streak", "Losing Streak", "PnL Net"]
    r1 = [total_open, total_closed, total_won, total_lost]
    r2 = [strike_rate, win_streak, lose_streak, pnl_net]
    # Check which set of headers is the longest.
    if len(h1) > len(h2):
        header_length = len(h1)
    else:
        header_length = len(h2)
    # Print the rows
    print_list = [h1, r1, h2, r2]
    row_format = "{:<15}" * (header_length + 1)
    print("Trade Analysis Results:")
    for row in print_list:
        print(row_format.format("", *row))

len(d) == (d.buflen()-1) and

def printSQN(analyzer):
    sqn = round(analyzer.sqn, 2)
    print("SQN: {}".format(sqn))
"""


def get_stock_symbols_from_csv(csv_file_path):
    symbols_df = pd.read_csv(csv_file_path)
    symbols_column_name = "Symbol"
    symbols_list = list(symbols_df[symbols_column_name].unique())
    return symbols_list


cerebro = bt.Cerebro()

startcash = 1000000000

# symbol_list = ['TCS.NS','INFY.NS']#,'WIPRO.NS']
symbol_list = get_stock_symbols_from_csv("./symbol_list.csv") #[:3]
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
END_DATE = datetime.now(IST_TIMEZONE).replace(
    hour=0, minute=0, second=0, microsecond=0
) - timedelta(days=0)
TIME_DELTA_DAYS = 365
START_DATE = END_DATE - timedelta(days=TIME_DELTA_DAYS)

"""
dataj = yf.download("^NSEI", start=START_DATE.replace(tzinfo=None), end=END_DATE.replace(tzinfo=None))
dataj.to_csv("./{}.csv".format("^NSEI"))
datapath = ('./^NSEI.csv')
dataframe = pd.read_csv(datapath,
                            skiprows=0,
                            header=0,
                            parse_dates=True,
                            index_col=0
                            )
datak = bt.feeds.PandasData(dataname=dataframe)
cerebro.adddata(datak, name="NIFTY")
"""

"""
data = bt.feeds.YahooFinanceData(
        dataname="WIPRO.NS",
        timeframe=bt.TimeFrame.Days,
        fromdate=START_DATE.replace(tzinfo=None),
        todate=END_DATE.replace(tzinfo=None),
        compression=1,
        buffered=True,
        adjclose=True,
        decimals=2,
        plot=True,
)
"""
INVALID_TICKERS = invalid_tickers
for symbol in symbol_list:

    # detecting invalid tickers
    ticker = yf.Ticker(symbol)
    ticker_info = None
    try:
        ticker_info = ticker.info
        reg_mp = ticker_info.get("regularMarketPrice")
        if not reg_mp:
            INVALID_TICKERS.append(symbol)
            continue
    except:
        INVALID_TICKERS.append(symbol)
        print("Invalid ticker - {}".format(symbol))
        continue

    data = bt.feeds.YahooFinanceData(
        dataname=symbol,
        timeframe=bt.TimeFrame.Weeks,
        fromdate=START_DATE.replace(tzinfo=None),
        todate=END_DATE.replace(tzinfo=None),
        compression=1,
        buffered=True,
        adjclose=True,
        decimals=2,
        plot=True,
    )
    cerebro.adddata(data, name=symbol)  # cerebro.adddata(data)

INVALID_TICKERS = list(set(INVALID_TICKERS))
invalid_tickers_df["invalid_ticker"] = INVALID_TICKERS
invalid_tickers_df.to_csv(INVALID_TICKERS_FILE_PATH, index=False)

"""
feed = bt.feeds.YahooFinanceData(
    dataname="^NSEI",
    timeframe=bt.TimeFrame.Days,
    fromdate=START_DATE.replace(tzinfo=None),
    todate=END_DATE.replace(tzinfo=None),
    compression=1,
    buffered=True,
    adjclose=True,
    decimals=2,
    plot=False,
)
"""


"""
data3 = bt.feeds.YahooFinanceData(
    dataname= "VINATIORGA.NS",            
    timeframe=bt.TimeFrame.Months,  
    fromdate=datetime(2012, 1, 1),
    todate=datetime(2021, 8, 15),
    compression =1,
    buffered=True,
    calendar='BSE',
    adjclose =True,
    decimals =2,
    plot=True,
)
"""
"""
data = bt.feeds.Quandl(
    dataname='TSLA',
    timeframe=bt.TimeFrame.Days, 
    apikey='QBb7Ym7AFLYZ3CkamXys',
    fromdate = datetime(2010,1,6),
    todate = datetime(2021,2,15),
    buffered= True
    )

"""

cerebro.addstrategy(firstStrategy, oneplot=True)
# cerebro = bt.Cerebro()
# cerebro.adddata(data)
# cerebro.adddata(feed)
cerebro.broker.setcash(startcash)
cerebro.addsizer(bt.sizers.FixedSize)
"""
cerebro.broker.setcommission(
    commission=0.000, margin=False
)
"""
cerebro.broker.set_shortcash(True)


# cerebro.addwriter(bt.WriterFile, csv=True, rounding=1)

cerebro.addobserver(bt.observers.FundValue)
cerebro.addanalyzer(trade_list, _name="trade_list")
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name="ta")
cerebro.addanalyzer(bt.analyzers.Transactions)
# cerebro.addanalyzer(BarAnalysis, _name="bar_data")

results = cerebro.run(tradehistory=True)
firstStrat = results[0]

for strat in results:
    print("=" * 79)
    print(strat.__class__.__name__)

trade_list = results[0].analyzers.trade_list.get_analysis()
print(tabulate(trade_list, headers="keys"))

"""
LimitedTestReport = results[0].analyzers.LimitedTestReport.get_analysis()
print (tabulate(LimitedTestReport, headers="keys"))
"""
portvalue = cerebro.broker.getvalue()
pnl = round(portvalue - startcash, 1)

print("Final Portfolio Value: %.2f" % cerebro.broker.getvalue())
print(
    "Final value is %.2f times the initial investment"
    % (cerebro.broker.getvalue() / startcash)
)
print("P/L: ${}".format(pnl))

# cerebro.plot(
#     iplot=False, numfigs=1, volume=False
# )

"""
bar_data_res = results[0].analyzers.bar_data.get_analysis()
df = pd.DataFrame(bar_data_res)
df.to_csv("bar_data_res.csv")"""

trade_list = results[0].analyzers.getbyname("trade_list").get_analysis()
df = pd.DataFrame(trade_list)

SCREENER_OUTPUT_FILENAME = "trade_list_BT_Screener.csv"
BT_SCREENER_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + SCREENER_OUTPUT_FILENAME
df.to_csv(BT_SCREENER_FILE_PATH, index=False)
print("ALL OVER")
# https://backtest-rookies.com/2017/08/22/backtrader-multiple-data-feeds-indicators/
