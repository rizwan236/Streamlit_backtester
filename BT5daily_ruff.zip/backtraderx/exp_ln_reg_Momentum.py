import backtrader as bt
import numpy as np
from scipy import stats

# regression slope of the past 90 days,top 20% momentum ranking, 100 day Mvg avg  https://teddykoker.com/2019/05/momentum-strategy-from-stocks-on-the-move-in-python/


class Momentum(bt.Indicator):
    lines = ("trend",)
    # params = (('period', 18),('upperband', 40),('lowerband', 0),)
    params = (("period", 18),)  # 18 weeks is 90 days

    """def _plotinit(self):
        self.plotinfo.plotyhlines = [self.params.upperband, self.params.lowerband]"""

    def __init__(self):
        self.addminperiod(self.params.period)

    def next(self):
        returns = np.log(self.data.get(size=self.p.period))
        x = np.arange(len(returns))
        slope, _, r_value, _, _ = stats.linregress(x, returns)
        # annualized_slope =  (np.power(np.exp(slope), 50)- 1) * 100  #50 weeks in a 252 day year
        # annualized_slope = (np.power((1 + slope), 50) - 1) * 100
        annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100
        # annualized_slope2 = (np.power((1 + slope), 50) - 0) * 100
        self.lines.trend[0] = round(annualized_slope * (r_value**2), 0) #
