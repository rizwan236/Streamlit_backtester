import asyncio
from datetime import datetime
import os
import time

from mail_utils import trigger_email_notification, trigger_generic_email
import pandas as pd
from PDFconvert import create_pdf
import pytz
from settings import (
    BT_SCREENER_CSV,
    EMPTY_BT_SCREENER_MSG,
    MAX_RETRIES,
    NIFTY_WEEKLY_AVG_STATS_IMAGE,
    NO_NEW_SIGNALS_FOUND_MSG,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    SYMBOLS_CSV,
    TALIB_SCREENER_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
    TRADEBOOK_CSV,
)
from telegram_bot import post_telegram_file, post_telegram_message


IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
#print(weekday)


BT_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + BT_SCREENER_CSV

def delete_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"Deleted file: {file_path}")
    else:
        print(f"File not found: {file_path}")

old_df = pd.read_csv('/home/rizpython236/BT5/yesterdayWatchlist.csv')

if os.path.exists(BT_FILE_PATH):
    #os.remove(BT_FILE_PATH_)
    file_path ='/home/rizpython236/BT5/yesterdayWatchlist.csv'
    delete_file(file_path)


# Load the trade.csv and order.csv files into dataframes
order_df = pd.read_csv('/home/rizpython236/BT5/myholding.csv')
#print(order_df)
trade_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv')

# Get unique values from a specific column, e.g., 'symbol'
#order_df = order_df['symbol'].unique()#.tolist()

#BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
#bt_data = pd.read_csv(BT_FILE_PATH)
#holding_file = "/home/rizpython236/BT5/myholding.csv"
#holding_file = pd.read_csv(holding_file)
#holding_file = holding_file['symbol'].unique()
#signal2_dfx = bt_data[bt_data['ticker'].isin(holding_file['symbol'])]  #[['ticker', 'dir','pricein','datein']]
#print(filtered)


#print(trade_df.dtypes)
#trade_df['ticker'] = trade_df['ticker'].astype(str)
#missing_values = trade_df['ticker'].isnull()
#print(missing_values)
#trade_df['datein'] = pd.to_datetime(trade_df['datein'])
#print(trade_df.dtypes)
# Filter the trade_df based on the 'ticker' column matching the 'symbol' values
#signal2_df=trade_df[trade_df['ticker'].isin(order_df['symbol'])]
#filtered = trade_df[trade_df['ticker'].isin(order_df['symbol'])]
#signal2_df=trade_df[trade_df['ticker'].isin(order_df['symbol'])].reset_index(drop=True)
signal2_df = trade_df[trade_df['ticker'].isin(order_df['Symbol'])]#[['ticker', 'dir','pricein','datein']]
#signal2_df = signal2_df.drop(columns=['ref'])

# Sort the signal2_df DataFrame based on the 'dir' column
signal2_df = signal2_df.sort_values(by='dir')

#print(signal2_df)

# Save the resulting dataframe as a new CSV file, e.g., signal2.csv
signal2_df.to_csv('/home/rizpython236/BT5/screener-outputs/Watchlist.csv', index=False)
if weekday != "Tuesday":
    signal2_df.to_csv('/home/rizpython236/BT5/yesterdayWatchlist.csv', index=False)
print(signal2_df)
time.sleep(2)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/Watchlist.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Watchlist.pdf'  # Replace with desired output PDF file

try:
    new_df = pd.read_csv(input_csv_file)
    notmatching1=new_df.drop(['ref',], axis=1, inplace=True)
    new_df.to_csv(input_csv_file, index=False)
except Exception as e:
    print(f"Error generating Watchlist: {e}")
    1+1

time.sleep(2)
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)

post_telegram_file('/home/rizpython236/BT5/screener-outputs/Watchlist.pdf')
trigger_generic_email(msg="holding screener", attachment='/home/rizpython236/BT5/screener-outputs/Watchlist.pdf')

print("completed watchlist")

#################################
# Load the trade.csv and order.csv files into dataframes
trade_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/trade_list_Talib_Screener.csv')
order_df = pd.read_csv('/home/rizpython236/BT5/myholding.csv')
# Get unique values from a specific column, e.g., 'symbol'
#order_df = order_df['symbol'].unique()#.tolist()

print(len(order_df))

# Filter the trade_df based on the 'ticker' column matching the 'symbol' values
signal2_df = trade_df[trade_df['ticker'].isin(order_df['Symbol'])]#[['ticker','dir','pricein','datein']]   #[['ticker', 'dir','datein','pricein']] #[['ticker', 'dir']]

#signal2_df = trade_df[trade_df['ticker'].isin(order_df['symbol'])]

# Sort the signal2_df DataFrame based on the 'dir' column
signal2_df = signal2_df.sort_values(by='dir')
print(signal2_df)

# Save the resulting dataframe as a new CSV file, e.g., signal2.csv
#signal2_df.to_csv('/home/rizpython236/BT5/screener-outputs/TBholding_signals.csv', index=False)
time.sleep(2)

#post_telegram_file('/home/rizpython236/BT5/screener-outputs/TBholding_signals.csv')
#trigger_generic_email(msg="holding screener", attachment='/home/rizpython236/BT5/screener-outputs/TBholding_signals.csv')

print("completed TB watchlist")
#################################


# Assuming you have two DataFrames called "new" and "old"
#old_df = pd.read_csv('/home/rizpython236/BT5/yesterdayWatchlist.csv')
new_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/Watchlist.csv')
#print(new_df)
#print(old_df)

if weekday == "Wednesday":
    try:
        # Create a DataFrame "notmatching" by merging the "old" and "new" DataFrames on columns "ab" and "jp" with an outer join
        notmatching = pd.merge(new_df,old_df ,on=["ticker","dir"], how="left", indicator=True)

        # Filter rows where the merge indicator is 'left_only', meaning they exist in "old" but not in "new"
        notmatching = notmatching[notmatching["_merge"] == "left_only"]

        #print(notmatching)

        #111notmatching.to_csv('/home/rizpython236/BT5/screener-outputs/changeholding_signals.csv', index=False)
        # Assuming you have loaded old_df from a CSV file
        #111notmatching = pd.read_csv('/home/rizpython236/BT5/screener-outputs/changeholding_signals.csv')

        file_path ='/home/rizpython236/BT5/screener-outputs/changeWatchlist.csv'
        #111delete_file(file_path)

        # Use the drop method to remove the specified columns
        selected_columns = ['ticker', 'dir', 'pricein_x', 'datein_x']
        notmatching1=notmatching.drop(['pricein_y', 'datein_y','_merge',], axis=1, inplace=True) #'Company_y','Industry_y'


        notmatching.to_csv('/home/rizpython236/BT5/screener-outputs/changeWatchlist.csv', index=False)
        print(notmatching)

        input_csv_file = '/home/rizpython236/BT5/screener-outputs/changeWatchlist.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/changeWatchlist.pdf'  # Replace with desired output PDF file


        time.sleep(2)
        if not notmatching.empty:
            create_pdf(input_csv_file, output_pdf_file)
            time.sleep(2)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/changeWatchlist.pdf')
            trigger_generic_email(msg="Change holding signals", attachment='/home/rizpython236/BT5/screener-outputs/changeWatchlist.pdf')

        file_path ='/home/rizpython236/BT5/screener-outputs/changeWatchlist.csv'
        delete_file(file_path)
    except Exception as e:
        print(f"Error generating changeWatchlist: {e}")
        pass

print("completed changeWatchlist")
################################################

input_csv_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.pdf'  # Replace with desired output PDF file

try:
    new_df = pd.read_csv(input_csv_file)

    notmatching1=new_df.drop(['ref',], axis=1, inplace=True)
    new_df.to_csv(input_csv_file, index=False)
except Exception as e:
    print(f"Error generating changeBTscreener: {e}")
    1+1
time.sleep(2)
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.pdf')
#BT change

# Assuming you have two DataFrames called "new" and "old"
old_df = pd.read_csv('/home/rizpython236/BT5/yesterdayBTscreener.csv')

if os.path.exists(BT_FILE_PATH):
    #os.remove(BT_FILE_PATH_)
    file_path ='/home/rizpython236/BT5/yesterdayBTscreener.csv'
    delete_file(file_path)

import shutil


# Specify the paths for the input and output files
input_file_path = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
output_file_path = '/home/rizpython236/BT5/yesterdayBTscreener.csv'

# Load the CSV file into a DataFrame
df = pd.read_csv(input_file_path)

# Check the number of rows in the DataFrame
num_rows = df.shape[0]


if num_rows > 3:
    # Duplicate and save the file as "symbol.csv"
    shutil.copy(input_file_path, output_file_path)
    print(f'Duplicated {input_file_path} as {output_file_path}')
else:
    print(f'The file {input_file_path} does not have more than 3 rows.')


new_df = pd.read_csv('/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv')

if weekday == "Wednesday":
    try:
        # Create a DataFrame "notmatching" by merging the "old" and "new" DataFrames on columns "ab" and "jp" with an outer join
        notmatching = pd.merge(new_df,old_df ,on=["ticker","dir"], how="left", indicator=True)


        # Filter rows where the merge indicator is 'left_only', meaning they exist in "old" but not in "new"
        notmatching = notmatching[notmatching["_merge"] == "left_only"]

        #print(notmatching)

        #111notmatching.to_csv('/home/rizpython236/BT5/screener-outputs/changeholding_signals.csv', index=False)
        # Assuming you have loaded old_df from a CSV file
        #111notmatching = pd.read_csv('/home/rizpython236/BT5/screener-outputs/changeholding_signals.csv')

        #file_path ='/home/rizpython236/BT5/screener-outputs/changeWatchlist.csv'
        #111delete_file(file_path)
        #time.sleep(2)

        # Use the drop method to remove the specified columns
        selected_columns = ['ticker', 'dir', 'pricein_x', 'datein_x']
        notmatching1=notmatching.drop(['pricein_y', 'datein_y','_merge','Company_y','Industry_y'], axis=1, inplace=True)
        notmatching = notmatching.sort_values(by='dir')

        notmatching.to_csv('/home/rizpython236/BT5/screener-outputs/changeBTscreener.csv', index=False)
        print(notmatching)
        time.sleep(2)

        input_csv_file = '/home/rizpython236/BT5/screener-outputs/changeBTscreener.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/changeBTscreener.pdf'  # Replace with desired output PDF file

        if not notmatching.empty:
            create_pdf(input_csv_file, output_pdf_file)
            time.sleep(2)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/changeBTscreener.pdf')
            trigger_generic_email(msg="Change holding signals", attachment='/home/rizpython236/BT5/screener-outputs/changeBTscreener.pdf')

        file_path ='/home/rizpython236/BT5/screener-outputs/changeBTscreener.csv'
        delete_file(file_path)
    except Exception as e:
        print(f"Error generating changeBTscreener: {e}")
        pass

input_file_path = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
output_file_path = '/home/rizpython236/BT5/yesterdayBTscreener.csv'
shutil.copy(input_file_path, output_file_path)
signal2_df.to_csv('/home/rizpython236/BT5/yesterdayWatchlist.csv', index=False)
print("completed changeBTscreener")
