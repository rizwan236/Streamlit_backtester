'''
from symbol_copy import fix_bse_column_names
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# === CONFIG ===
DOWNLOAD_DIR = "/home/rizpython236/Downloads/BSE"  # <-- change if needed
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

# === Chrome Options ===
chrome_options = webdriver.ChromeOptions()
chrome_options.page_load_strategy = "none"  # 🚀 Key fix
chrome_options.add_experimental_option("prefs", {
    "download.default_directory": DOWNLOAD_DIR,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True,
})
#options.add_argument("--start-maximized")

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
# avoid small /dev/shm space
chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--disable-software-rasterizer")
chrome_options.add_argument("--disable-background-timer-throttling")
chrome_options.add_argument("--disable-renderer-backgrounding")
chrome_options.add_argument("--disable-backgrounding-occluded-windows")

chrome_options.add_argument("--disable-features=NetworkService")
chrome_options.add_argument("--disable-features=VizDisplayCompositor")
chrome_options.add_argument("--disable-background-timer-throttling")
chrome_options.add_argument("--disable-renderer-backgrounding")
chrome_options.add_argument("--disable-backgrounding-occluded-windows")
chrome_options.add_argument("--window-size=1920,1080")
chrome_options.add_argument("--remote-debugging-port=9222")
chrome_options.add_argument("--disable-extensions")
chrome_options.add_argument("--dns-prefetch-disable")
chrome_options.add_argument("--hide-scrollbars")
chrome_options.add_argument("--mute-audio")

# chrome_options.add_argument("--disable-software-rasterizer")
# chrome_options.add_argument("--disable-features=VizDisplayCompositor")
# Increase timeout in ms (default ~60s)
# chrome_options.add_argument("--timeout=100000")
#chrome_options.set_capability("pageLoadStrategy", "eager")
chrome_options.add_argument(
    "--disable-blink-features=AutomationControlled")
chrome_options.add_experimental_option(
    "excludeSwitches", ["enable-automation"])
chrome_options.add_experimental_option("useAutomationExtension", False)
chrome_options.add_argument(
    "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")
chrome_options.add_experimental_option("prefs", {
    # "download.default_directory": download_dir,
    #"download.default_directory": "/home/rizpython236/BT5",
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True,
})


# === Start Browser ===
#browser = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
browser = webdriver.Chrome(options=chrome_options)
wait = WebDriverWait(browser, 20)
browser.set_page_load_timeout(30)

# === Go to Website ===
#browser.get("https://www.bseindia.com/corporates/List_Scrips.html")
try:
    browser.get("https://www.bseindia.com/corporates/List_Scrips.html")
except Exception as e:
    print(f"⚠️ Page load timeout: {e}, retrying with execute_script()...")
    browser.execute_script("window.location.href='https://www.bseindia.com/corporates/List_Scrips.html';")
    time.sleep(10)


# === Select Segment ===
segment_dropdown = wait.until(EC.presence_of_element_located((By.ID, "ddlsegment")))
select = Select(segment_dropdown)
select.select_by_visible_text("Equity T+1")

# === Wait for Submit Button and Click ===
Submit_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#btnSubmit")))
try:
    Submit_button.click()
except Exception:
    browser.execute_script("arguments[0].click();", Submit_button)

# === Wait for Download Icon ===
download_button = wait.until(
    EC.element_to_be_clickable((By.CSS_SELECTOR, "i.fa.fa-download.iconfont"))
)
time.sleep(2)  # small delay for stability

# === Click Download Button ===
try:
    download_button.click()
except Exception:
    browser.execute_script("arguments[0].click();", download_button)

# === Wait for File Download to Complete ===
print("Downloading CSV file...")
time.sleep(15)

browser.quit()
print(f"✅ CSV file downloaded to: {DOWNLOAD_DIR}")

#filepath ='/home/rizpython236/BT5/Equity5.csv'
#fix_bse_column_names(filepath)

#Industry, Sector Name, Industry New Name, Igroup Name, ISubgroup Name

ffffffff
'''
























"""#template
import chromedriver_autoinstaller
from selenium import webdriver
from selenium.webdriver.chrome.service import Service

# 1️⃣ Auto-install driver
chromedriver_path = chromedriver_autoinstaller.install()
service = Service(chromedriver_path)

# 2️⃣ Chrome options
chrome_options = webdriver.ChromeOptions()
#chrome_options.add_argument("--headless=new")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--remote-debugging-port=9222")
chrome_options.binary_location = "/usr/bin/chromium"

# 3️⃣ Launch browser
browser = webdriver.Chrome(service=service, options=chrome_options)
browser.get("https://www.google.com")
print(browser.title)
browser.quit()
"""


"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time
import os

print("bse_ticker_download")


max_retries = 3  # Set the maximum number of retries
retry_count = 0

while retry_count < max_retries:
    try:
        # Set up Selenium WebDriver with the given Chrome options
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--disable-gpu")

        browser = webdriver.Chrome(options=chrome_options)

        # Step 1: Navigate to the URL
        url = "https://www.bseindia.com/corporates/List_Scrips.html"
        browser.get(url)

        # Step 2: Wait until the dropdown is present and interact with the dropdown menu to select "Equity T+1"
        wait = WebDriverWait(browser, 20)
        ddlsegment = wait.until(EC.presence_of_element_located((By.ID, 'ddlsegment')))
        select = Select(ddlsegment)
        select.select_by_visible_text('Equity T+1')

        # Step 3: Wait until the download button is present and click it to download the CSV file
        download_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, 'i.fa.fa-download.iconfont')))
        download_button.click()

        # Wait for the download to complete (you might need to adjust the sleep time depending on your internet speed)
        time.sleep(10)

        # Step 4: Load the CSV file into a pandas DataFrame
        # Assuming the file is downloaded to the default download directory
        download_dir = '/home/rizpython236/BT5'
        csv_filename = f'{download_dir}/Equity.csv'


        df = pd.read_csv(csv_filename)

        # Step 5: Save the DataFrame as a gzipped pickle file
        #pkl_filename = os.path.join(download_dir, '/Equity.pkl.gz')
        #df.to_pickle(pkl_filename, compression='gzip')

        #print(f"CSV file saved to: {csv_filename}")
        #print(f"Gzipped pickle file saved to: {pkl_filename}")

        print(df.head())

        # Close the browser
        browser.quit()

    except Exception as exc:
        retry_count += 1
        print(f"Attempt {retry_count} failed: {exc}")
        time.sleep(2)  # Wait 1 second before retrying
        #bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
        if retry_count == max_retries:
            print("Max retries reached. Exiting.")
            post_telegram_message("Download from bse_ticker_download failed!...")
            print("Download from bse_ticker_download failed!...")

"""

from symbol_copy import fix_bse_column_names
import traceback
import chromedriver_autoinstaller  # pip install chromedriver-autoinstaller
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.chrome.options import Options
from telegram_bot import post_telegram_message


try:
    filepath = "/home/rizpython236/BT5/Equity5xx.csv"
    fix_bse_column_names(filepath)
except Exception as e:
    print("Error occurred:")
    traceback.print_exc()  # Prints full traceback


USER_AGENTS = [
    # Windows Chrome
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36",

    # Linux Chrome
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36",

    # macOS Safari
    # "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    # "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    # "Version/17.0 Safari/605.1.15",

    # iPhone Safari
    # "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
    # "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    # "Version/17.0 Mobile/15E148 Safari/604.1",

    # Android Chrome
    # "Mozilla/5.0 (Linux; Android 13; Pixel 7) "
    # "AppleWebKit/537.36 (KHTML, like Gecko) "
    # "Chrome/120.0.0.0 Mobile Safari/537.36",
]


# chromedriver_autoinstaller.install()
chromedriver_path = chromedriver_autoinstaller.install()
# sys.path.append("/home/rizpython236/.local/lib/python3.9/site-packages/")
# import py_chromedriver_installer
# py_chromedriver_installer.install()  # Automatically downloads the correct version of Chromedriver,
# then adds it to PATH.
print("Chromedriver path:", chromedriver_path)

print("bse_ticker_download")

"""
#BASH
chromium --version
which chromium
df -h /dev/shm
sudo mount -o remount,size=2G /dev/shm  # if it’s too small
/usr/bin/chromium --headless --no-sandbox --disable-gpu --remote-debugging-port=9222 https://www.google.com

"""


def download_equity_csv(USER_AGENTS=USER_AGENTS):
    """Ua = random.choice(USER_AGENTS)
    print(f"🌀 Using User-Agent: {ua[:50]}...")
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--headless")
    #chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--disable-dev-shm-usage")  # Prevents memory issues
    chrome_options.add_argument("--remote-debugging-port=9222")  # ensures DevTools port exists
    chrome_options.binary_location = "/usr/bin/chromium"     # explicit binary path
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--ignore-certificate-errors")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_argument("--disable-features=VizDisplayCompositor")
    chrome_options.add_argument("--disable-software-rasterizer")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    prefs = {
        "download.default_directory": "/home/rizpython236/BT5",  # ✅ your path
        "download.prompt_for_download": False,                   # auto-download
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True                             # avoid Chrome blocking download
    }
    chrome_options.add_experimental_option("prefs", prefs)
    chrome_options.add_argument("--enable-logging")
    chrome_options.add_argument("--v=1")

    #chrome_options.add_argument(f"user-agent={ua}")  #random agent
    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120 Safari/537.36"
    )
    """
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    # avoid small /dev/shm space
    chrome_options.add_argument("--disable-dev-shm-usage")
    # chrome_options.add_argument("--disable-software-rasterizer")
    # chrome_options.add_argument("--disable-features=VizDisplayCompositor")
    # Increase timeout in ms (default ~60s)
    # chrome_options.add_argument("--timeout=100000")
    chrome_options.set_capability("pageLoadStrategy", "eager")
    chrome_options.add_argument(
        "--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option(
        "excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")
    chrome_options.add_experimental_option("prefs", {
        # "download.default_directory": download_dir,
        "download.default_directory": "/home/rizpython236/BT5",
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })

    attempt = 0
    max_attempts = 3
    success = False
    browser = None

    while attempt < max_attempts and not success:
        try:
            # Step 1: Initialize browser and navigate to the URL
            # service = ChromeService(chromedriver_path)
            # browser = webdriver.Chrome(service=service, options=chrome_options)

            browser = webdriver.Chrome(options=chrome_options)

            browser.set_page_load_timeout(150)
            # browser.implicitly_wait(5)
            # browser.get("https://www.bseindia.com")
            # time.sleep(15)

            # browser = driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
            # browser = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()),options=chrome_options)
            # browser = webdriver.Chrome(options=chrome_options)
            url = "https://www.bseindia.com/corporates/List_Scrips.html"
            browser.execute_cdp_cmd("Network.setExtraHTTPHeaders", {
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
                },
            })
            # browser.set_page_load_timeout(15)
            browser.get(url)

            # Step 2: Wait until the dropdown is present and select "Equity T+1"
            wait = WebDriverWait(browser, 25)
            ddlsegment = wait.until(EC.presence_of_element_located(
                (By.ID, "ddlsegment")))  # /html/body/div[4]/div[1]/div[2]/select
            select = Select(ddlsegment)
            select.select_by_visible_text("Equity T+1")

            # /html/body/div[4]/div[2]/div[5]/input  #btnSubmit
            Submit_button = wait.until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "#btnSubmit")))
            time.sleep(10)
            try:
                Submit_button.click()
            except Exception as e:
                browser.execute_script("arguments[0].click();", Submit_button)

            time.sleep(15)
            # Step 3: Wait for the download button and click it
            download_button = wait.until(EC.element_to_be_clickable(
                (By.CSS_SELECTOR, "i.fa.fa-download.iconfont")))
            try:
                download_button.click()
            except Exception as e:
                print(f"⚠️Error occurred: {e!s}")
                traceback_str = traceback.format_exc()
                browser.execute_script(
                    "arguments[0].click();", download_button)

            # Wait for the download to complete (adjust the sleep time if necessary)
            time.sleep(15)

            # Step 4: Load the downloaded CSV into a pandas DataFrame
            download_dir = "/home/rizpython236/BT5"
            csv_filename = f"{download_dir}/Equity.csv"
            df = pd.read_csv(csv_filename)
            # df.to_csv("/home/rizpython236/BT5/Equity.csv", index=False)

            # Print and/or save the DataFrame as needed
            print(df.head())

            # If successful, mark success as True to stop retrying
            success = True
            print("Download and processing successful for bse_ticker_download.")

        except (TimeoutException, Exception) as e:
            attempt += 1
            print(f"Attempt {attempt} failed bse_ticker_download: {e!s}")
            if attempt < max_attempts:
                print("Retrying...")
            else:
                print("Max attempts reached. Failed to download CSV.")
                print(f"⚠️Error occurred: {e!s}")
                traceback_str = traceback.format_exc()
                print(traceback_str)
                post_telegram_message(
                    "Download from bse_ticker_download failed!...")
        finally:
            # Ensure the browser is always closed after the attempt
            if browser is not None:
                browser.quit()


# Run the download function
download_equity_csv()
