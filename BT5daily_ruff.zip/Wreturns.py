import os

import pandas as pd
import talib as tb


print("Start csv2")

# Specify the folder path containing CSV files
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'  # Replace with the actual folder path
ticker_path = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()[:]
selected_files = []
results = []


# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    if file_name.endswith('.csv'):
        file_path = os.path.join(folder_path, file_name)
        base_name = os.path.splitext(file_name)[0]
        #file_names.append(base_name)
        #print(base_name)
        if base_name in symbols:
            file_path = os.path.join(folder_path, file_name)
            selected_files.append(file_path)

            # Read the CSV file into a DataFrame
            df = pd.read_csv(file_path)

            for period in [1, 2, 4, 12, 24, 52]:
                column_name = f'ROC_{period}'
                df[column_name] = tb.ROC(df['Close'], timeperiod=period).round(2)

            df["52wkH"] = tb.MAX(df['Close'], timeperiod=52)
            df["52wkL"] = tb.MIN(df['Close'], timeperiod=52)
            df["52WeekPosition"] = ((df['Close'] - df['52wkL']) / (df['52wkH'] - df['52wkL']) * 100).round(2)

            results.append((base_name, df['ROC_1'].iloc[-1],df['ROC_2'].iloc[-1], df['ROC_4'].iloc[-1], df['ROC_12'].iloc[-1], df['ROC_24'].iloc[-1], df['ROC_52'].iloc[-1], df['52WeekPosition'].iloc[-1]))

# Create DataFrame from the results
columns = ['base_name','ROC_1','ROC_2', 'ROC_4', 'ROC_12', 'ROC_24', 'ROC_52', '52WeekPosition']
df = pd.DataFrame(results, columns=columns)
merged_df = pd.merge(df, ticker_df[['Symbol', 'Company','Industry']], how='left', left_on='base_name', right_on='Symbol')
# Drop the redundant Symbol column
merged_df = merged_df.drop(columns=['Symbol'])
merged_df.to_csv('/home/rizpython236/BT5/trade-logs/Returns.csv', index=False)
print(merged_df)

