import os
import sys
import time
import traceback

#import telegram  #python-telegram-bot==13.15
import pandas as pd

from PDFconvert import create_pdf
from telebotscript import (
    post_telegram_file,
    post_telegram_message,
    shutdown_bot,
    trigger_telegram_notifications,
)


try:
    post_telegram_message()
    post_telegram_file()
    shutdown_bot()
    trigger_telegram_notifications()
except Exception as e:
    1+1
    #print(e)



sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
# import telegram  #python-telegram-bot==13.15
# from telegram import Bot  # Only import Bot instead of entire telegram module
# from telegram.error import TelegramError


# from telegram_bot_latest import send_telegram_message,send_telegram_file,trigger_telegram_notifications,post_telegram_message,post_telegram_file,shutdown_bot


# post_telegram_message("xx")
"""
for _ in range(1):
    1+1
    post_telegram_message("That was all for today!")

post_telegram_message("That was all for today!")
post_telegram_file('/home/rizpython236/BT5/pybrokerBT.py')
"""

if False:  # works with python-telegram-bot==13.15
    # from telegram_send import configure, send
    def post_telegram_messagexx(message):
        """Unified send function for messages/files  . uses telegram_send library"""
        try:
            if message:
                send(messages=[message])
            # if file_path:
            #    with open(file_path, "rb") as f:
            #        send(files=[file_path])
        except Exception as e:
            print(f"Telegram error: {e}")
            print(traceback.format_exc())

    def post_telegram_filexx(file_path):
        """Unified send function for messages/files  . uses telegram_send library"""
        try:
            # if message:
            #    send(messages=[message])
            if file_path:
                with open(file_path, "rb") as f:
                    send(files=[file_path])
        except Exception as e:
            print(f"Telegram error: {e}")
            print(traceback.format_exc())

    # print('telegram_bot')

    from settings import (
        INCOMPLETE_TICKERS_CSV,
        INVALID_TICKERS_FILE,
        SCREENER_OUTPUT_CSV,
        SCREENER_OUTPUT_FOLDER_PATH,
        TRADE_LOGS_FOLDER_PATH,
    )

    file_path = "/home/rizpython236/BT5/trade-logs/screener-output_mhtly.csv"
    # delete_file(file_path)

    def delete_file(file_path):
        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"Deleted file: {file_path}")
        else:
            print(f"File not found: {file_path}")

    if os.path.exists(file_path):
        SCREENER_OUTPUT_CSV = "screener-output_mhtly.csv"
    else:
        1+1

    # https://api.telegram.org/bot2081787314:AAHvtYN4xEq_Vv9tsF570WyXD1OAvcnnsks/getUpdates
    TOKEN = "6108615209:AAF8ZiMMxbrT1D46enyrO0rSlChCuo9d4ro"
    CHAT_IDS = [-1001757309399]  # -1001863996731 -1001757309399
    # bot = telegram.Bot(token=TOKEN)
    bot = Bot(token=TOKEN)

    INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
    invalid_tickers_df = pd.read_csv(INVALID_TICKERS_FILE_PATH)
    invalid_tickers = list(invalid_tickers_df["invalid_ticker"].unique())

    INCOMPLETE_TICKERS_FILE_PATH = (
        SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV
    )
    incomplete_tickers_df = pd.read_csv(INCOMPLETE_TICKERS_FILE_PATH)
    incomplete_tickers = list(incomplete_tickers_df["Symbol"].unique())

    def post_telegram_messagexx(message):
        # print("Triggering Telegram Alerts!")
        try:
            for id in CHAT_IDS:
                # print(message)
                bot.send_message(id, message)
                message = ""
                print(f"✅  💬Posted Telegram Message: { message}")
        except TelegramError as e:  # telegram.error.TelegramError as e:
            print(f"An error occurred: {e}")
            print(f"❌ 💬NOT posted telegram Message: {message}----")
            print(traceback.format_exc())
            return

    # post_telegram_message("message")

    def post_telegram_filexx(file_path):
        # csv_file_path = "./rizwan-screener-3/ticker-csv-files/BHARTIARTL.NS.csv"
        file_extension = os.path.splitext(
            file_path)[1].lower()  # Get the file extension
        file = open(file_path, "rb")
        # print("Triggering Telegram attachment!")
        try:
            for id in CHAT_IDS:
                if file_extension == ".pngxxx":
                    bot.send_photo(id, file)
                else:
                    bot.send_document(id, file)
            print(f"✅ 📎Posted Telegram attachment! {file_path}")
        except TelegramError as e:  # Exception as e:
            print(f"An error occurred: {e}")
            print(f"❌ 📎NOT posted telegram attachment {file_path} ---")
            print(traceback.format_exc())
            return

    def trigger_telegram_notificationsxx():
        # post_telegram_message("Hey! Telegram alerts for {}".format(str(date.today())))

        if invalid_tickers:
            # post_telegram_message("Invalid Tickers Found - {}".format(invalid_tickers))
            # post_telegram_file('/home/rizpython236/BT5/screener-outputs/invalid_tickers.csv')
            1+1

        if incomplete_tickers:
            # post_telegram_message(
            #    "Incomplete Data Tickers Found - {}".format(incomplete_tickers)
            # )
            # post_telegram_file('/home/rizpython236/BT5/screener-outputs/incomplete_data_tickers.csv')
            1+1
        # SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
        # if monthly=="YES":
        # SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"
        # else:
        #    1+1

        csv_to_send = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
        trade_list = pd.read_csv(csv_to_send)
        try:
            trade_list.drop(["talib_date", "talib_price", "talib_signal",
                            "trade_id", "trade_logged_on", "status"], axis=1, inplace=True)
        except:
            1+1
        trade_list = trade_list.to_dict("records")
        chunk_size = 5
        chunked_trade_list = [trade_list[i:i + chunk_size]
                              for i in range(0, len(trade_list), chunk_size)]

        print("Sending Ticker Alert Messages and CSV now ...")
        for trade_packet in chunked_trade_list:
            time.sleep(1)
            # post_telegram_message(json.dumps(trade_packet, sort_keys=True, indent=4))

        # Replace with your CSV file
        input_csv_file = "/home/rizpython236/BT5/trade-logs/screener-output.csv"
        # Replace with desired output PDF file
        output_pdf_file = "/home/rizpython236/BT5/screener-outputs/screener-output.pdf"
        input_csv_file1 = "/home/rizpython236/BT5/screener-outputs/screener-output1.csv"

        new_df = pd.read_csv(input_csv_file)
        try:
            notmatching1 = new_df.drop(["trade_logged_on", "trade_id", "status",
                                       "talib_date", "talib_signal", "talib_price"], axis=1, inplace=True)
        except:
            1+1
        new_df.to_csv(input_csv_file1, index=False)
        # print(new_df)
        create_pdf(input_csv_file1, output_pdf_file)
        time.sleep(2)
        post_telegram_filexx(output_pdf_file)
        # except:
        #    1+1

        time.sleep(2)
        # create_pdf(input_csv_file, output_pdf_file)

        # post_telegram_file(output_pdf_file)
        # post_telegram_message("That was all for today!")

    """
    async def main():
        await post_telegram_message(message)
        await post_telegram_message("Your message here")
        await post_telegram_file(file_path)
        await trigger_telegram_notifications()

    if __name__ == "__main__":
        # Create an event loop and run the asynchronous main function
        loop = asyncio.get_event_loop()
        loop.run_until_complete(main())
        #asyncio.run(main())
    """
    # trigger_telegram_notifications()
else:
    pass
