import csv
import datetime
import sys
import time

import matplotlib.pyplot as plt
import pandas as pd

#sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
#import xirr
from telegram_bot import post_telegram_file, post_telegram_message


def calculate_and_save_returns(csv_file_path, output_file_path):
    """Calculates XIRR or simple return and saves results to a CSV file.

    Args:
        csv_file_path (str): Path to the CSV file with transaction data.
        output_file_path (str): Path to the output CSV file.
    """

    with open(csv_file_path, newline='') as csvfile, open(output_file_path, 'w', newline='') as outfile:
        reader = csv.DictReader(csvfile)
        writer = csv.writer(outfile)

        # Write header row
        writer.writerow(['Company', 'XIRR (%)', 'Simple Return (%)', 'Holding Period (Days)'])

        companies_transactions = {}
        for row in reader:
            try:
                company = row['company']
                date = datetime.datetime.strptime(row['date'], '%Y-%m-%d')
                cash_flow = float(row['cash flow'])

                if company not in companies_transactions:
                    companies_transactions[company] = [(date, cash_flow)]
                else:
                    companies_transactions[company].append((date, cash_flow))

            except ValueError as e:
                print(f"Error processing row: {row}, {e}")

        for company, transactions in companies_transactions.items():
            if len(transactions) < 2:
                print(f"Insufficient transactions for {company}, skipping.")
                continue

            first_date, first_cash_flow = transactions[0]
            last_date, last_cash_flow = transactions[-1]
            holding_period_days = (last_date - first_date).days

            if holding_period_days > 365:
                dates, cash_flows = zip(*transactions)
                try:
                    xirr_value = XIRR(cash_flows, dates)
                    simple_return = (last_cash_flow - first_cash_flow) / first_cash_flow * 100
                    writer.writerow([company, f'{xirr_value:.2%}', f'{simple_return:.2%}', holding_period_days])
                except (ValueError, ZeroDivisionError) as e:
                    print(f"Error calculating XIRR for {company}: {e}")
                    writer.writerow([company, None, None, holding_period_days])
            else:
                simple_return = (last_cash_flow - first_cash_flow) / first_cash_flow * 100
                writer.writerow([company, None, f'{simple_return:.2%}', holding_period_days])

# Example usage:
csv_file_path = 'your_transactions.csv'
output_file_path = 'returns.csv'
#calculate_and_save_returns(csv_file_path, output_file_path)

print("Results saved to", output_file_path)


import matplotlib.pyplot as plt
import pandas as pd


plt.figure(figsize=(12, 10))  # Adjust figure size as needed
#fig, ax = plt.subplots(figsize=(12, 10))  # Create figure and axis
#ax.margins(left=0.05, right=0.99, top=0.9, bottom=0.08)  # Set subplot margins
#plt.figure(left=0.05, right=0.99, top=0.09, bottom=0.08)

# Define initial investment and years
initial_investment = 45
years = range(1, 31)  # Adjust years to show future value over 30 years

# Create a list of CAGR values
cagr_values = list(range(11, 51, 5))  #range(15, 51, 5)

# Create an empty DataFrame
df = pd.DataFrame(columns=['Year'] + [f'CAGR {cagr}%' for cagr in cagr_values])

# Calculate future values for each CAGR and year
for year in years:
    row = [year]
    for cagr in cagr_values:
        future_value = initial_investment * (1 + cagr/100) ** year
        future_value = int(future_value)
        row.append(future_value)
    df.loc[len(df)] = row

# Plot the future values for each CAGR
for cagr in cagr_values:
    plt.plot(df['Year'], df[f'CAGR {cagr}%'], label=f'CAGR {cagr}%')

# Set plot labels and title
plt.xlabel('Year')
plt.ylabel('Future Value')
plt.title('Future Value over 30 Years at Different CAGR Rates')



# Set y-axis to log scale
plt.yscale('log', base=10)
# Force integer ticks on the y-axis (manually set)
'''
plt.yticks([10, 20, 40, 80, 160, 320, 640, 1280, 2560, 5120, 10240,
            20480, 40960, 81920, 163840, 327680, 655360,
            1310720, 2621440, 5242880, 10485760, 20971520,
            41943040, 83886080, 100000000])
'''

# Add legend
plt.legend()

# Show the plot
plt.grid(True)

chart_path = '/home/rizpython236/BT5/screener-outputs/CAGRchart.png'
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)
#plt.show()

# Print the DataFrame
print(df.to_string())

















