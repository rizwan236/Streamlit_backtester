from datetime import datetime
import glob
import multiprocessing
import os
import sys
import time
import traceback

from numba import njit
import numpy as np
import pandas as pd
import pybroker
import pybroker as pyb
from pybroker import (  # ,YFinance
    ExecContext,
    IndicatorSet,
    RandomSlippageModel,
    Strategy,
    StrategyConfig,
)
from pybroker.data import DataSource
import talib

from settings import (
    SCREENER_OUTPUT_FOLDER_PATH,
)
from symbol_copy import upload_binary_file_to_github
from telegram_bot import post_telegram_message


print("pybrokerBT")


# os.environ['OPENBLAS_NUM_THREADS'] = '1'
# os.environ['MKL_NUM_THREADS'] = '1'
# os.environ['NUMEXPR_NUM_THREADS'] = '1'
# os.environ['OMP_NUM_THREADS'] = '1'
os.environ["LOKY_MAX_CPU_COUNT"] = "2"
os.environ["PYBROKER_DISABLE_PARALLEL"] = "1"
# os.environ["JOBLIB_START_METHOD"] = "fork"


cpu_count = multiprocessing.cpu_count()
print(cpu_count)

# Use 2-4 threads if system allows
# os.environ['OPENBLAS_NUM_THREADS'] = str(min(4, cpu_count))

# source /home/rizpython236/.virtualenvs/rizenvnew/bin/activate && python /home/rizpython236/BT5/scheduler2.py

# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.13/site-packages/")


# sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.13/site-packages')


print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
# from pybroker.indicator import highest,lowest,returns, detrended_rsi,macd, stochastic, stochastic_rsi,linear_trend,quadratic_trend,cubic_trend,adx,aroon_up,aroon_down,aroon_diff,close_minus_ma,linear_deviation,quadratic_deviation,cubic_deviation,price_intensity,price_change_oscillator,intraday_intensity,money_flow,reactivity,price_volume_fit,volume_weighted_ma_ratio,normalized_on_balance_volume,delta_on_balance_volume,normalized_positive_volume_index,normalized_negative_volume_index,volume_momentum,laguerre_rsi,)
# edit __init__.py     data.py     strategy.py", line 1294 return self._config.enable_fractional_shares
# pip uninstall -y akracer==0.0.13 akshare==1.15.21 alpaca-py==0.33.0 pydantic==2.9.2 pydantic-core==2.23.4
# pip3-autoremove alpaca-py akshare akracer pydantic pydantic-core
# indicators=highest('high_10d', 'close', period=10))
# high_10d = ctx.indicator('high_10d')  if not ctx.long_pos() and high_10d[-1] > high_10d[-2]:
# except (ModuleNotFoundError, ImportError) as e:
#    # Print the exception with traceback
#    print(f"Error importing modules: {e}")
#    traceback.print_exc()
#    # Handle the error gracefully, or you can simply pass
#    #pass
# import riskfolio as rp
# import quantstats as qs
# from sklearn.linear_model import LinearRegression
# from sklearn.metrics import r2_score
# import xlwings as xw


# from telegram_bot import post_telegram_message,post_telegram_file

# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


# pyb.enable_data_source_cache('PYByfinance')
# pyb.enable_indicator_cache('PYBmy_indicators')
# pyb.clear_data_source_cache()
# pyb.clear_indicator_cache()
# pyb.disable_data_source_cache()
# pyb.disable_indicator_cache()


def cmma(bar_data, lookback):

    @njit  # Enable Numba JIT.
    def vec_cmma(values):
        # Initialize the result array.
        n = len(values)
        out = np.array([np.nan for _ in range(n)])

        # For all bars starting at lookback:
        for i in range(lookback, n):
            # Calculate the moving average for the lookback.
            ma = 0
            for j in range(i - lookback, i):
                ma += values[j]
            ma /= lookback
            # Subtract the moving average from value.
            out[i] = values[i] - ma
        return out

    # Calculate with close prices.
    return vec_cmma(bar_data.close)

# cmma_20 = pybroker.indicator('cmma_20', cmma, lookback=20)


def cmedian(bar_data, lookback):

    @njit
    def vec_cmedian(values):
        n = len(values)
        out = np.empty(n)
        out[:] = np.nan   # initialize with NaN

        for i in range(lookback, n):
            window = values[i - lookback:i]
            out[i] = np.median(window)

        return out

    # Calculate with close prices
    return vec_cmedian(bar_data.close)


def sma_based_sma(bar_data, short_lookback=10, long_lookback=200):
    """Calculates a short-term SMA (default 10-day) based on a long-term SMA (default 200-day).

    Args:
        bar_data: The bar data containing price information.
        short_lookback: Lookback period for the short-term SMA.
        long_lookback: Lookback period for the long-term SMA.

    Returns:
        numpy.array: Array with the short-term SMA based on long-term SMA values.

    """

    @njit  # Enable Numba JIT for performance
    def vec_sma_based_sma(values):
        n = len(values)
        out = np.array([np.nan for _ in range(n)])

        # First calculate the long-term SMA values
        long_sma = np.array([np.nan for _ in range(n)])
        for i in range(long_lookback, n):
            ma = 0.0
            for j in range(i - long_lookback, i):
                ma += values[j]
            long_sma[i] = ma / long_lookback

        # Then calculate the short-term SMA based on the long-term SMA
        for i in range(long_lookback + short_lookback, n):
            short_ma = 0.0
            for j in range(i - short_lookback, i):
                short_ma += long_sma[j]
            out[i] = short_ma / short_lookback

        return out
    # Calculate using close prices
    return vec_sma_based_sma(bar_data.close)


def delete_columns(data_path, columns):
    for file in glob.glob(data_path + "/*.csv"):
        try:
            # Load the CSV file into a DataFrame
            df = pd.read_csv(file)

            # Drop the specified columns
            df.drop(columns=columns, inplace=True, errors="ignore")

            # Save the modified DataFrame back to the CSV file
            df.to_csv(file, index=False)
            # print(f"Processed file: {file}")
        except Exception as e:
            print(f"An error occurred: {e} {file}")


# Specify the columns to delete
columns_to_delete = ["Score"]

data_path = "/home/rizpython236/BT5/ticker-csv-files"
data_path = "/home/rizpython236/BT5/ticker_15yr"
# data_path = r"C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\abc"
# data_pathpathlib = Path(data_path)

# Call the function to delete the columns
# delete_columns(data_path, columns_to_delete)


def get_25th_percentile_close(combined_data):
    # Step 0: Keep only required columns
    combined_data = combined_data[["Symbol", "Date", "Close", "Score"]]

    # Step 1: Take last 2 rows per symbol
    last2 = combined_data.groupby("Symbol").tail(3)

    # Step 2: Keep only symbols where both last 2 scores > 1
    valid_symbols = (
        last2.groupby("Symbol")["Score"]
        .apply(lambda x: (x > 1).all())   # check if all last 2 > 1
    )
    valid_symbols = valid_symbols[valid_symbols].index   # keep only True

    # Step 3: From those valid symbols, take only their latest row
    latest_data = combined_data.groupby("Symbol").tail(1)
    filtered_data = latest_data[latest_data["Symbol"].isin(valid_symbols)]
    # print(len(last2)/3)
    latest_data_len = len(latest_data)
    post_telegram_message(f"Total symbol on Pybroker: {latest_data_len}")

    # Step 1: Get the latest row for each symbol (assuming data is sorted by date or row index)
    latest_data = filtered_data.groupby("Symbol").tail(1)
    numberAll = len(last2) / 3

    # Step 2: Filter close > 100
    filtered_data = latest_data[latest_data["Score"] > 1]
    numberG1 = len(filtered_data)
    Pctnumber = (numberG1 / numberAll) * 100
    Pctnumber = round(Pctnumber, 1)

    # Step 3: Sort descending by Close
    sorted_data = filtered_data.sort_values(by="Score", ascending=False)
    number = len(sorted_data)

    # Step 4: Get the cutoff where 75% are above
    percentile_25 = sorted_data["Score"].quantile(0.25)
    # print("Cutoff price (75% above):", percentile_25)
    # print(sorted_data.head())

    # Step 5: Find the row with the highest Close
    # highest_row = sorted_data.loc[sorted_data["Score"].idxmax(), [
    #    "Symbol", "Date", "Close", "Score"]]
    highest_Score = sorted_data["Score"].max()

    print("Highest Score:")
    # print(highest_row.to_dict())  # Prints in clean dict form
    print("Cutoff price (75% above):", percentile_25)
    print("Number of Symbols - Cutoff price (75% above):", number)
    print(
        f"Number of Symbols  All-- {numberAll}, Greater than 1-- {numberG1}, Percentage-- {Pctnumber}% ")
    # print(sorted_data.head())

    latest_data = combined_data.groupby("Symbol").tail(1)
    # ✅ Step 8: Create dictionary {Symbol: last Score}
    symbol_score_dict = dict(zip(latest_data["Symbol"], latest_data["Score"]))

    return highest_Score, percentile_25, sorted_data, symbol_score_dict

# Function to read ticker files and add symbol column


def process_files(folder_path, limit=10):
    # Initialize an empty DataFrame to store all data
    combined_data = pd.DataFrame()
    # Counter for the number of processed files
    file_count = 0

    # Iterate through files in the folder
    for file_name in os.listdir(folder_path):
        if file_name.endswith(".csv"):
            # Extract symbol from file name
            symbol = os.path.splitext(file_name)[0]
            # print(symbol)
            if symbol == "^NSEI":
                print("has NSEI file")

            # Read the CSV file
            file_path = os.path.join(folder_path, file_name)
            data = pd.read_csv(file_path)
            # print(file_path)
            # data =data[:]

            data["SMA_200C"] = talib.SMA(data["Close"], timeperiod=200)
            data["AD"] = talib.AD(data["High"], data["Low"],
                                  data["Close"], data["Volume"])
            data["RSI_e"] = talib.RSI(data["Close"], timeperiod=21)
            # df_test = data.copy()
            # Higher Highs/Higher Lows (Uptrend signals)
            # df_test['HH_shift'] = df_test['High'] > df_test['High'].shift(1).rolling(2).max()
            # df_test['HL_shift'] = df_test['Low'] > df_test['Low'].shift(1).rolling(5).min()
            # data['HH_HL'] = np.where(df_test['HH_shift'] & df_test['HL_shift'], 100, -100)

            # Lower Highs/Lower Lows (Downtrend signals) - CORRECTED
            # df_test['LH_shift'] = df_test['High'] < df_test['High'].shift(1).rolling(5).max()
            # df_test['LL_shift'] = df_test['Low'] < df_test['Low'].shift(1).rolling(5).min()
            # data['LH_LL'] = np.where(df_test['LH_shift'] & df_test['LL_shift'], 100, -100)

            # df_test['High_diff'] = df_test['High'].diff()
            # df_test['Low_diff'] = df_test['Low'].diff()
            # df_test['Close_diff'] = df_test['Close'].diff()

            # df_test['HH_shift'] = df_test['High_diff'].gt(0).rolling(2).apply(lambda x: x.all(), raw=True)
            # df_test['HL_shift'] = df_test['Low_diff'].gt(0).rolling(3).apply(lambda x: x.all(), raw=True)
            # data['HH_HL'] = np.where(df_test['HH_shift'] & df_test['HL_shift'], 100, -100)

            # df_test['LH_shift'] = df_test['High_diff'].lt(0).rolling(5).apply(lambda x: x.all(), raw=True)
            # df_test['LL_shift'] = df_test['Low_diff'].lt(0).rolling(2).apply(lambda x: x.all(), raw=True)
            # data['LH_LL'] = np.where(df_test['LH_shift'] & df_test['LL_shift'], 100, -100)

            # df_test['Close_shift'] = df_test['Close_diff'].gt(0).rolling(3).apply(lambda x: x.all(), raw=True)
            # data['HC_HL'] = np.where(df_test['Close_shift'] & df_test['HL_shift'], 100, -100)
            # data['HC_HL'] = int(100)

            # Replace 0 with .001 in the 'Score' column
            # data['Score'] = data['Score'].replace(0, 0.1111)

            data.drop(columns=["Annualized_lognormal_std24",
                      "Annualized_lognormal_std12"], errors="ignore", inplace=True)
            data.drop(columns=["MRP13", "MRP25", "Exp",
                      "Beta"], errors="ignore", inplace=True)

            # Add symbol column
            data.insert(0, "Symbol", symbol)
            data = data[-252:]

            # Concatenate data to the combined DataFrame
            combined_data = pd.concat([combined_data, data], ignore_index=True)

            # Increment the file count
            file_count += 1
            if file_count > 500000:
                break

            # Break the loop if the limit is reached
            # if limit is not None and file_count >= limit:
            #    break

    combined_data.fillna(0, inplace=True)
    # Get the unique symbols in order of first appearance
    unique_symbols = combined_data["Symbol"].unique()

    # Take the first 50 (or fewer if there aren't 50 unique symbols)
    first_50_symbols = unique_symbols[:80]

    # Filter the DataFrame to keep only rows with those symbols
    # combined_data = combined_data[combined_data['Symbol'].isin(first_50_symbols)]
    return combined_data


# Define folder path containing ticker CSV files
folder_path = "/home/rizpython236/BT5/ticker-csv-files"
folder_path = "/home/rizpython236/BT5/ticker_15yr"


# Process files and get combined data
combined_data = process_files(folder_path, limit=None)

nifty_data = combined_data[combined_data["Symbol"] ==
                           "^NSEI"][["Date", "Open", "High", "Low", "Close"]]
nifty_data.rename(columns={"Open": "niftyOpen", "High": "niftyHigh",
                  "Low": "niftyLow", "Close": "niftyClose"}, inplace=True)


combined_data = combined_data.merge(nifty_data, on="Date", how="left")
# print(combined_data)
# print("Column headers of the combined_data DataFrame:", combined_data.columns.tolist())

try:
    highest_Score, percentile_25, sorted_symbols, symbol_score_dict = get_25th_percentile_close(
        combined_data)
    post_telegram_message(f"Highest Score:, {highest_Score}")
    time.sleep(3)
    post_telegram_message(f"Cutoff price (75% above):, {percentile_25}")

    # symbol_score_dict = dict(zip(latest_data["Symbol"], latest_data["Score"]))
    top_20 = sorted(symbol_score_dict.items(),
                    key=lambda item: item[1], reverse=True)[:25]
    df = pd.DataFrame(top_20, columns=["symbol", "score"])
    df.to_csv(r"/home/rizpython236/BT5/screener-outputs/Top_score.csv", index=False)

    # Create a readable list string
    items_str = ", ".join([f"{symbol} ({score})" for symbol, score in top_20])
    # print(f"The top 25 symbols and their scores are: {items_str}.")
    time.sleep(3)
    post_telegram_message(
        f"The top 25 symbols and their scores are: {items_str}.")

except Exception as e:
    print(f"Error occurred: {e!s}")
    traceback_str = traceback.format_exc()
    print(traceback_str)

####################################################################
"""
# Define the main function to perform all calculations
def calculate_indicators(group):
    # Calculate ROCP
    group['ROCPmom'] = talib.ROCP(group['Close'], timeperiod=4)

    # Calculate the 52-period rolling product for ROCP
    group['ROCP_52_Rolling_Prod'] = (1 + group['ROCPmom']).rolling(window=52).apply(lambda x: x.prod(), raw=True) - 1

    # Calculate absolute change on a daily basis (SMO)
    group['ABS_chg'] = group['Close'].diff().abs()

    # Calculate custom aggregation for SMO using a rolling window
    def custom_smo_aggregation(rolling_window):
        valid_smo = rolling_window.dropna()
        if len(valid_smo) == 0:
            return float('nan')
        SMO = (rolling_window > 0).sum() / len(valid_smo)
        return SMO

    group = group.sort_values(by='Date')  # Ensure the data is sorted by date before applying rolling
    group['Rolling_SMO_Agg'] = group['ABS_chg'].rolling(window=18).apply(custom_smo_aggregation, raw=False)

    return group

# Group by 'Symbol' and apply the calculations
combined_data = combined_data.groupby('Symbol').apply(calculate_indicators).reset_index(drop=True)
combined_data= combined_data.drop(columns=['ROCPmom','ABS_chg'], errors='ignore') #, inplace=True)
#combined_data[['ROCP_52_Rolling_Prod', 'Rolling_SMO_Agg']] = combined_data[['Rolling_SMO_Agg', 'ROCP_52_Rolling_Prod']].round(4)
"""
# Display the result
# print(combined_data)

# combined_data_with_indicators.to_csv(r'C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\combined_ticker_data.csv',index=False)
# combined_data_with_indicators.to_pickle(r'C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\combined_ticker_data.pkl')

# Function to get the last row for each symbol
# def get_last_row_per_symbol(df):
#    return df.groupby('Symbol').tail(1)
"""
def get_last_row_per_symbol(df):
    if df is None:
        raise ValueError("DataFrame is None. Please check the DataFrame initialization.")
    if 'Symbol' not in df.columns:
        raise ValueError("DataFrame does not contain 'Symbol' column.")
    return df.groupby('Symbol').tail(1)

# Get the last row for each symbol
last_rows = get_last_row_per_symbol(combined_data)

# Sort based on ROCP_52_Rolling_Prod
filtered_values = last_rows[last_rows['ROCP_52_Rolling_Prod'] > 0]
last_rows_sorted = last_rows.sort_values(by='ROCP_52_Rolling_Prod')

# Print minimum value of ROCP_52_Rolling_Prod
min_rocp_52 = last_rows_sorted['ROCP_52_Rolling_Prod'].min()
max_rocp_52 = last_rows_sorted['ROCP_52_Rolling_Prod'].max()
print(f"Minimum value of ALL ROCP_52_Rolling_Prod: {min_rocp_52}")
print(f"Maximum value of ALL ROCP_52_Rolling_Prod: {max_rocp_52}")

# Determine the 40% quartile threshold
quantile_40 = last_rows_sorted['ROCP_52_Rolling_Prod'].quantile(0.4)

#The 60th percentile is the value below which 60% of the data falls. In other words, 60% of the data points in the ROCP_52_Rolling_Prod column are less than or equal to this value.


# Print the top 40% quartile based on ROCP_52_Rolling_Prod
top_40_percent = last_rows_sorted[last_rows_sorted['ROCP_52_Rolling_Prod'] >= quantile_40]
top_40_percent = top_40_percent.sort_values(by='ROCP_52_Rolling_Prod')
print("Top 40% quartile based on ROCP_52_Rolling_Prod:")
#print(top_40_percent)

# Print minimum value of ROCP_52_Rolling_Prod
min_rocp_52 = top_40_percent['ROCP_52_Rolling_Prod'].min()
max_rocp_52 = top_40_percent['ROCP_52_Rolling_Prod'].max()
rollMOMROCP=min_rocp_52
print(f"Minimum value of top_40_percent ROCP_52_Rolling_Prod: {min_rocp_52}")
print(f"Maximum value of top_40_percent ROCP_52_Rolling_Prod: {max_rocp_52}")
"""
# 3

# Save combined data to a single CSV file
# combined_data.to_csv(r'/home/rizpython236/BT5/screener-outputs/combined_ticker_data.csv',index=False)
combined_data.to_pickle(
    r"/home/rizpython236/BT5/screener-outputs/combined_ticker_data.pkl.gz", compression="gzip")

time.sleep(5)

combined_data = pd.read_pickle(
    r"/home/rizpython236/BT5/screener-outputs/combined_ticker_data.pkl.gz", compression="gzip")


unique_symbols = combined_data["Symbol"].unique()[:]

# Filter the data for only those symbols
# combined_data = combined_data[combined_data["Symbol"].isin(unique_symbols)]

try:
    upload_binary_file_to_github(
        token="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",
        repo_name="rizwan236/Streamlit_backtester",
        local_file_path="/home/rizpython236/BT5/BT5daily_ruff.zip",
        repo_file_path="BT5daily_ruff.zip",
        commit_message="Added file",
        branch="main",
    )
except exception as e:
    print(f"Error uploading to github BT5daily_ruff.zip : {e!s}")

upload_binary_file_to_github(
    token="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",
    repo_name="rizwan236/Streamlit_backtester",
    local_file_path="/home/rizpython236/BT5/screener-outputs/combined_ticker_data.pkl.gz",
    repo_file_path="combined_ticker_data.pkl.gz",
    commit_message="Added file",
    branch="main",
)


file_path = "/home/rizpython236/BT5/screener-outputs/combined_ticker_data.csv"
file_path1 = "/home/rizpython236/BT5/screener-outputs/combined_ticker_data.pkl.gz"

try:
    os.remove(file_path1)
    os.remove(file_path)
    print(f"{file_path} successfully deleted.")
except OSError as e:
    print(f"Error deleting {file_path}: {e.strerror}")


print("combined_data")

# Train and Backtest


def train_slr(symbol, train_data, test_data):
    # Train
    # Previous day close prices.
    train_prev_close = train_data["close"].shift(1)
    # Calculate daily returns.
    train_daily_returns = (
        train_data["close"] - train_prev_close) / train_prev_close
    # Predict next day's return.
    train_data["pred"] = train_daily_returns.shift(-1)
    train_data = train_data.dropna()
    # Train the LinearRegession model to predict the next day's return
    # given the 20-day CMMA.
    X_train = train_data[["cmma_20"]]
    y_train = train_data[["pred"]]
    model = LinearRegression()
    model.fit(X_train, y_train)

    # Test
    test_prev_close = test_data["close"].shift(1)
    test_daily_returns = (
        test_data["close"] - test_prev_close) / test_prev_close
    test_data["pred"] = test_daily_returns.shift(-1)
    test_data = test_data.dropna()
    X_test = test_data[["cmma_20"]]
    y_test = test_data[["pred"]]
    # Make predictions from test data.
    y_pred = model.predict(X_test)
    # Print goodness of fit.
    r2 = r2_score(y_test, np.squeeze(y_pred))
    print(symbol, f"R^2={r2}")

    # Return the trained model and columns to use as input data.
    return model, ["cmma_20"]

# Setting Position Sizes


def pos_size_handler(ctx):
    # Fetch all buy signals.
    signals = tuple(ctx.signals("buy"))
    # Return if there are no buy signals (i.e. there are only sell signals).
    if not signals:
        return
    # Calculates the inverse volatility, where volatility is defined as the
    # standard deviation of close prices for the last 100 days.
    # get_inverse_volatility = lambda signal: 1 / np.std(signal.bar_data.close[-100:])
    def get_inverse_volatility(signal): return np.std(
        signal.bar_data.close[-24:])
    # Sums the inverse volatilities for all of the buy signals.
    total_inverse_volatility = sum(map(get_inverse_volatility, signals))
    for signal in signals:
        size = get_inverse_volatility(signal) / total_inverse_volatility
        # Calculate the number of shares given the latest close price.
        shares = ctx.calc_target_shares(
            size, signal.bar_data.close[-1], cash=None)  # cash=100000
        ctx.set_shares(signal, shares)

# Equal Position Sizing


def start_of_month(dt: datetime) -> bool:
    if dt.month != pyb.param("current_month"):
        pyb.param("current_month", dt.month)
        return True
    return False


def set_target_shares(
        ctxs: dict[str, ExecContext],
        targets: dict[str, float]):
    for symbol, target in targets.items():
        ctx = ctxs[symbol]
        target_shares = ctx.calc_target_shares(target)
        pos = ctx.long_pos()
        if pos is None:
            ctx.buy_shares = target_shares
        elif pos.shares < target_shares:
            ctx.buy_shares = target_shares - pos.shares
        elif pos.shares > target_shares:
            ctx.sell_shares = pos.shares - target_shares


def rebalance(ctxs: dict[str, ExecContext]):
    dt = tuple(ctxs.values())[0].dt
    if start_of_month(dt):
        target = 1 / len(ctxs)
        set_target_shares(ctxs, dict.fromkeys(ctxs.keys(), target))
# ________________________________
# Portfolio Optimization


# pyb.param('lookback', 52)  # Use past year of returns.
pyb.param("lookback", 250)  # Use past year of returns.


def calculate_returns(ctxs: dict[str, ExecContext], lookback: int):
    prices = {}
    for ctx in ctxs.values():
        prices[ctx.symbol] = ctx.close[-lookback:]
    df = pd.DataFrame(prices)
    return df.pct_change().dropna()


def optimization(ctxs: dict[str, ExecContext]):
    lookback = pyb.param("lookback")
    first_ctx = tuple(ctxs.values())[0]
    if start_of_month(first_ctx.dt):
        Y = calculate_returns(ctxs, lookback)
        port = rp.Portfolio(returns=Y)
        port.assets_stats(method_mu="hist", method_cov="hist", d=0.94)
        w = port.optimization(
            model="Classic",
            rm="CVaR",
            obj="MinRisk",
            rf=.07,      # Risk free rate.
            l=0,       # Risk aversion factor.
            hist=True,  # Use historical scenarios.
        )
        targets = {
            symbol: w.T[symbol].values[0]
            for symbol in ctxs
        }
        set_target_shares(ctxs, targets)
# _______________________________

# Rotational Trading
# Rotational trading involves purchasing the best-performing assets while selling underperforming ones

# roc_20 = pyb.indicator('roc_20', lambda data: ta.ROC(data.adj_close, timeperiod=20))


# config = StrategyConfig(max_long_positions=2)
# pyb.param('target_size', 1 / config.max_long_positions)
pyb.param("rank_threshold", 1000)


def rank(ctxs: dict[str, ExecContext]):
    scores = {
        symbol: ctx.indicator("RSI_20")[-1]  # ctx.close[-1] #
        for symbol, ctx in ctxs.items()
    }
    sorted_scores = sorted(
        scores.items(),
        key=lambda score: score[1],
        reverse=True,
    )
    threshold = pyb.param("rank_threshold")
    top_scores = sorted_scores[:threshold]
    top_symbols = [score[0] for score in top_scores]
    pyb.param("top_symbols", top_symbols)


def rotate(ctx: ExecContext):
    if ctx.long_pos():
        if ctx.symbol not in pyb.param("top_symbols"):
            ctx.sell_all_shares()
    else:
        target_size = pyb.param("target_size")
        ctx.buy_shares = ctx.calc_target_shares(target_size)
        ctx.score = ctx.indicator("RSI_20")[-1]  # ctx.close[-1]


# pd.read_csv(r'C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\combined_ticker_data.csv')
df = combined_data
unique_symbols = df["Symbol"].unique()
symbol_list = list(unique_symbols)
# print(symbol_list)
# symbol_list=['^NSEI'] #    ['RELIANCE.NS','OFSS.NS','TANLA.NS','TATAELXSI.NS', 'TITAN.NS', 'ZENSARTECH.NS', 'OFSS.NS', 'ESCORTS.NS', 'DELTACORP.NS', 'WELSPUNLIV.NS', 'WHIRLPOOL.NS', 'WIPRO.NS', 'WOCKPHARMA.NS', 'WSTCSTPAPR.NS', 'YESBANK.NS', 'ZEEL.NS', 'ZENSARTECH.NS', 'ZFCVINDIA.NS']

if df["Date"].isna().any():
    print("There are NaT values in the 'Date' column. Handling NaT values...")
else:
    print("allgood")

if df["Score"].isnull().any() or (df["Score"] == 0).all():
    print("df['Score'] contains any NaNs or all zeros.")
else:
    print("allgood")

"""
min_date= df['Date'].iloc[0]
min_date_str= datetime.strptime(min_date, '%Y-%m-%d')
#min_date_str = min_date.strftime('%Y-%m-%d')
startdate=min_date_str
print(startdate)

# Get the date string from the last row
max_date = df['Date'].iloc[-1]
max_date_str=datetime.strptime(max_date, '%Y-%m-%d')
#max_date_str = max_date.strftime('%Y-%m-%d')  #strftime('%Y-%m-%d')
enddate=max_date_str
print(enddate)

"""
# print(df.dtypes)
# print(df['Date'].unique())
invalid_dates = df[df["Date"].isna()]
print(invalid_dates)

df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
min_date = df["Date"].min()
# + timedelta(weeks=52*12)    #strftime('%Y-%m-%d')
min_date_str = min_date.strftime("%Y-%m-%d")
startdate = min_date_str
print(startdate)

max_date = df["Date"].max()
max_date_str = max_date.strftime("%Y-%m-%d")  # strftime('%Y-%m-%d')
enddate = max_date_str
print(enddate)


filtered_df = df[df["Symbol"] == "^NSEI"]

# Print the length of the filtered DataFrame
print(len(filtered_df))
number = len(filtered_df)


class CSVDataSource(DataSource):

    def __init__(self):
        super().__init__()
        # Register custom columns in the CSV.
        pybroker.register_columns("Stock_Cumulative_Return", "MRP", "DD_PCT", "DD_LOG", "ta_DD_LOG", "ST", "OBV", "AD", "MOMScore", "niftyOpen", "niftyHigh",
                                  "niftyLow", "niftyClose", "SMA_200C", "AD", "weighted_MR", "weighted_excessMR", "RSI_e")  # 'Rolling_SMO_Agg', 'ROCP_52_Rolling_Prod') Beta HC_HL
        # pybroker.register_columns('Stock_Cumulative_Return','MRP','Exp','DD_PCT','DD_LOG','ST','OBV','AD','niftyOpen','niftyHigh','niftyLow','niftyClose','SMA_200C') #'Rolling_SMO_Agg', 'ROCP_52_Rolling_Prod')

    def _fetch_data(self, symbols, start_date, end_date, _timeframe, _adjust):
        # pd.read_csv(r'C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\combined_ticker_data.csv')
        df = combined_data

        df.rename(columns={"Date": "date", "Open": "open", "Symbol": "symbol", "Close": "close",
                  "High": "high", "Low": "low", "Volume": "volume", "Score": "MOMScore"}, inplace=True)
        # df.rename(columns={'Date': 'date', 'Open': 'open', 'Symbol': 'symbol', 'Open': 'open', 'Close': 'close', 'High': 'high', 'Low': 'low','Volume': 'volume'}, inplace=True)
        df = df[df["symbol"].isin(symbols)]
        # dates= df['Date']
        # dates= datetime.strptime(dates, '%Y-%m-%d')
        df["date"] = pd.to_datetime(df["date"])
        # print(df['date'])
        return df[(df["date"] >= start_date) & (df["date"] <= end_date)]


csv_data_source = CSVDataSource()
# df = csv_data_source.query(symbol_list, '2023-01-16', '2024-07-01')
df = csv_data_source.query(symbol_list, min_date_str, max_date_str)
# print(df)


def buy_highest_volume(ctx):
    # If there are no long positions across all tickers being traded:
    if not ctx.long_pos():  # tuple(ctx.long_positions()):
        ctx.buy_shares = ctx.calc_target_shares(.05)
        ctx.hold_bars = 2
        ctx.score = ctx.MOMScore[-1]


def buy_and_hold(ctx):
    if not ctx.long_pos() and ctx.bars >= 55:
        ctx.buy_shares = 100
        ctx.hold_bars = 30


def buy_low(ctx):
    # If shares were already purchased and are currently being held, then return.
    if ctx.long_pos():
        return
    # If the latest close price is less than the previous day's low price,
    # then place a buy order.
    if ctx.bars >= 2 and ctx.close[-1] < ctx.low[-2]:
        # Buy a number of shares that is equal to 25% the portfolio.
        ctx.buy_shares = ctx.calc_target_shares(0.25)
        # Set the limit price of the order.
        ctx.buy_limit_price = ctx.close[-1] - 0.01
        # Hold the position for 3 bars before liquidating (in this case, 3 days).
        ctx.hold_bars = 3


def short_high(ctx):
    # If shares were already shorted then return.
    if ctx.short_pos():
        return
    # If the latest close price is more than the previous day's high price,
    # then place a sell order.
    if ctx.bars >= 2 and ctx.close[-1] > ctx.high[-2]:
        # Short 100 shares.
        ctx.sell_shares = 100
        # Cover the shares after 2 bars (in this case, 2 days).
        ctx.hold_bars = 2


def buy_with_stop_loss(ctx):
    if not ctx.long_pos():
        ctx.buy_shares = ctx.calc_target_shares(1)
        ctx.stop_loss_pct = 20


def buy_with_trailing_stop_loss_and_profit(ctx):
    if not ctx.long_pos():
        ctx.buy_shares = ctx.calc_target_shares(1)
        ctx.stop_trailing_pct = 20
        ctx.stop_profit_pct = 10


def Momentum(ctx):  # ctx.indicator('cmma_20')[-1]
    # margin_requirement = Decimal('0.25')
    # max_margin = ctx.total_equity / margin_requirement - ctx.total_equity
    pos = ctx.long_pos()
    # print(tuple(ctx.long_positions()))  #and ctx.indicator("HT_TRENDMODE")[-1] >= 1  and ctx.indicator("LINEARREG_SLOPE_OBV")[-1] > 2
    # If shares were already purchased and are currently being held, then return.   number1 < ctx.indicator('SMAScore24')[-1] and ctx.Beta[-1] >= 1  and  (ctx.Beta[-1] >= .5 or ctx.Beta[-1] <= -.5) and ctx.indicator('SMAAD')[-1]*1.03 < ctx.AD[-1]
    # 279 : # ctx.long_pos() or  not ctx.short_pos():   #ctx.long_pos():  #tuple(ctx.long_positions())   and ( ctx.indicator('SMAScore24')[-1] < 1.5 and ctx.MOMScore[-2] < 1 and  ctx.MOMScore[-1] < 1) and ctx.HC_HL[-1] == 100
    # and ctx.indicator("HT_TRENDMODE_OBV")[-1] >= 1 and ctx.indicator("LINEARREG_SLOPE_OBV")[-1] >= 2
    if ctx.bars >= 248:
        # if ctx.bars > 248 and ctx.close[-1] >= 500: #
        if ctx.bars > 248 and ctx.volume[-2] >= 500 and ((ctx.indicator("ADX")[-1] > 25 and (ctx.MOMScore[-1] > 2 or ctx.weighted_excessMR[-1] > 0.8) and (ctx.indicator("PLUS_DI")[-1] - ctx.indicator("MINUS_DI")[-1]) > 10 and ctx.indicator("EMAMRP24")[-1] < ctx.MRP[-1] and ctx.close[-1] > ctx.indicator("wkH52")[-2] * 1 and ctx.close[-1] > ctx.indicator("wkL52")[-2] * 1 and ctx.ST[-1] == 1 and ctx.indicator("EMAOBV")[-2] * 1.0 < ctx.OBV[-1] and ctx.RSI_e[-1] > 40 and ctx.indicator("RSI_max")[-1] > 70 and ctx.close[-1] > ctx.indicator("SMAClose10")[-1] > ctx.indicator("SMAClose30")[-1] > ctx.indicator("SMAClose40")[-1] and ctx.indicator("SMAClose40")[-21] < ctx.indicator("SMAClose40")[-1] > ctx.indicator("sma_based_sma200")[-1] and ctx.indicator("SMAClose10")[-1] > ctx.indicator("SMAClose10")[-14]) or (ctx.indicator("HT_TRENDMODE_OBV")[-1] >= 1 and ctx.indicator("ADX")[-1] > 30 and (ctx.indicator("PLUS_DI")[-1] - ctx.indicator("MINUS_DI")[-1]) > 20 and ctx.volume[-3] >= 500 and (ctx.MOMScore[-1] > 1.5 or ctx.weighted_excessMR[-1] > 0.4) and (ctx.ST[-1] == 1 and ctx.indicator("EMAMRP24")[-1] < ctx.MRP[-1] and ctx.indicator("EMAOBV")[-2] * 1.1 < ctx.OBV[-1] and ctx.close[-1] > ctx.indicator("SMAClose10")[-1] > ctx.indicator("SMAClose30")[-1] > ctx.indicator("SMAClose40")[-1] and ctx.indicator("SMAClose40")[-21] < ctx.indicator("SMAClose40")[-1] > ctx.indicator("sma_based_sma200")[-1] and ctx.indicator("SMAClose10")[-1] > ctx.indicator("SMAClose10")[-14] and ctx.RSI_e[-1] > 50 and ctx.indicator("RSI_min")[-1] > 40 and ctx.indicator("RSI_max")[-1] > 70 and ctx.close[-1] > ctx.indicator("wkH52")[-2] * .60 and ctx.close[-1] > ctx.indicator("wkL52")[-2] * 1.35))):
            #  ctx.bars >= 55 and ((-1.5*ctx.indicator('STDDEV52')[-1] + ctx.indicator('SMAClose52')[-1]) > ctx.close[-1]*10000 or ctx.indicator('EMADD_PCT24')[-1] < ctx.DD_PCT[-1] > 30 or ctx.indicator('CCI_34')[-1] < -5000 or (ctx.indicator('RSI_20')[-1] < 40 and ctx.close[-1] < ctx.indicator('EMAClose12')[-1] < ctx.indicator('EMAClose24')[-1]  and ctx.indicator('EMAMRP24')[-1] > ctx.indicator('EMAMRP12')[-1] > ctx.MRP[-1] ) and ctx.ST[-1] > -6 or ctx.MRP[-24] > ctx.MRP[-1]*1000 ):
            # available_margin = max_margin - ctx.total_margin
            # ctx.sell_shares= ctx.sell_all_shares()
            ctx.buy_shares = 1
            # ctx.sell_shares = ctx.long_pos().shares+0  #ctx.long_positions().shares+1    $pos.shares+1   #ctx.long_pos().shares+1 #
            # ctx.sell_limit_price = ctx.close[-1]*.6
            # ctx.hold_bars = 8
            return
        # rollMOMROCP1 and ctx.Rolling_SMO_Agg[-1] > .4 and  3 < ctx.ROCP_52_Rolling_Prod[-1]   niftyClose   ctx.indicator('NiftyEMAClose12')[-1] or ctx.indicator('SMAAD')[-1]*0.97 > ctx.AD[-1]
        # ((ctx.indicator('CCI_34')[-1] < 20 and ctx.ST[-1] == -1 and ctx.indicator('RSI_20')[-1] < 50 and  (ctx.DD_LOG[-1] > 25 and ctx.DD_PCT[-1] > -25 )) or (( ctx.indicator('EMAMRP24')[-1] > ctx.indicator('EMAMRP12')[-1] > ctx.MRP[-1]*10000) or (ctx.close[-1] < ctx.indicator('SMAClose10')[-1] < ctx.indicator('SMAClose40')[-1] ))):
        # if ctx.bars > 248 and ctx.close[-1] <= 500: #
        if ctx.bars > 248 and ((ctx.close[-1] < ctx.indicator("SMAClose40")[-1] and ctx.DD_LOG[-1] > 15) or ((-10 != ctx.MOMScore[-1] < 1.5 or -10 != ctx.weighted_excessMR[-1] < 0.4 or ctx.DD_LOG[-1] > 25 or ctx.indicator("EMAOBV")[-1] * 0.95 > ctx.OBV[-1]) and ctx.ST[-1] == -1 and ctx.DD_LOG[-1] > 15 and (ctx.indicator("RSI_20")[-1] < 35 or ctx.indicator("CCI_34")[-1] < 0 or ctx.indicator("SMAClose10")[-1] < ctx.indicator("SMAClose30")[-1]))):
            # if ctx.bars > 279 and ctx.volume[-3] >= 100 and ctx.MOMScore[-2]  > 1 and  1 < ctx.MOMScore[-1]  and ( ctx.indicator('CCI_34')[-1] > -20 and ctx.ST[-1] == 1 and  ctx.indicator('EMAOBV')[-1]  < ctx.OBV[-1] > (ctx.OBV[-44]*1.2 or ctx.OBV[-34]*1.2 or ctx.OBV[-22]*1.2 or ctx.OBV[-14]*1.2  or ctx.OBV[-5]*1.2) and ctx.indicator('EMAMRP24')[-1] < ctx.MRP[-1]*99 and ctx.close[-1] > ctx.indicator('SMAClose10')[-1] > ctx.indicator('SMAClose30')[-1] > ctx.indicator('SMAClose40')[-1] and ctx.indicator('SMAClose40')[-1]  > ctx.indicator('sma_based_sma200')[-1] and 55 < ctx.indicator('RSI_14')[-1] > (ctx.indicator('RSI_14')[-5] or ctx.indicator('RSI_14')[-10] or ctx.indicator('RSI_14')[-15] ) and ctx.close[-1] > ctx.indicator('wkH52')[-1]*.65 and ctx.close[-1] > ctx.indicator('wkL52')[-1]*1.35 ) : #  or ( -100 > ctx.niftyClose[-1] > ctx.indicator('NiftyEMAClose52')[-1] and (ctx.MOMScore[-1] > 3 or ctx.indicator('SMAScore24')[-1] > 0 or ctx.indicator('SMAScore24')[-1] > ctx.indicator('SMAScore24')[-12]*1.2 ) and ( ctx.ST[-1] == 1 and ctx.indicator('CCI_34')[-1] > 50 and ctx.indicator('ADX')[-1] > 30 and ctx.OBV[-1] > ctx.OBV[-12]*1.25 and ctx.indicator('RSI_20')[-1] > 55 ) or (ctx.AD[-1] > ctx.indicator('EMAAD')[-12]*1.1 and ctx.OBV[-1] > ctx.OBV[-12]*1.25 and ctx.Exp[-1] > -20000000000000  and ctx.ST[-1] < 3 and ctx.indicator('CCI_34')[-1] > 50000 and ctx.indicator('ADX')[-1] > ctx.indicator('ADX')[-7] and ctx.indicator('RSI_20')[-7] < ctx.indicator('RSI_20')[-1] > 55 and ctx.indicator('EMAClose52')[-1] < ctx.indicator('EMAClose24')[-1] < ctx.indicator('EMAClose12')[-1]  and ctx.indicator('EMAMRP52')[-1] < ctx.indicator('EMAMRP24')[-1] < ctx.indicator('EMAMRP12')[-1] < ctx.MRP[-1] )):
            # ctx.bars >= 55  and ctx.indicator('NiftyEMAClose12')[-1] > ctx.indicator('NiftyEMAClose52')[-1] and (ctx.MOMScore[-1] > 3 or ctx.indicator('SMAScore24')[-1] > 0 or ctx.indicator('SMAScore24')[-1] > ctx.indicator('SMAScore24')[-12]*1.2 ) and ( ctx.ST[-1] == 1 and ctx.indicator('CCI_34')[-1] > 50 and ctx.indicator('ADX')[-1] > 30 and ctx.OBV[-1] > ctx.indicator('EMAOBV')[-34]*1.2 and ctx.indicator('RSI_20')[-1] > 55 ) or (ctx.AD[-1] > ctx.indicator('EMAAD')[-12]*1.1 and ctx.OBV[-1] > ctx.indicator('EMAOBV')[-34]*1.2 and ctx.Exp[-1] > -20000000000000  and ctx.ST[-1] < 3 and ctx.indicator('CCI_34')[-1] > 50 and ctx.indicator('ADX')[-1] > ctx.indicator('ADX')[-7] and ctx.indicator('RSI_20')[-7] < ctx.indicator('RSI_20')[-1] > 55 and ctx.indicator('EMAClose52')[-1] < ctx.indicator('EMAClose24')[-1] < ctx.indicator('EMAClose12')[-1]  and ctx.indicator('EMAMRP52')[-1] < ctx.indicator('EMAMRP24')[-1] < ctx.indicator('EMAMRP12')[-1] < ctx.MRP[-1] ):
            ctx.sell_shares = 1
            # ctx.indicator('EMAOBV')[-1] < ctx.OBV[-1] and any(ctx.OBV[-1] > threshold for threshold in [ ctx.OBV[-44] * 1.1,ctx.OBV[-34] * 1.1, ctx.OBV[-22] * 1.1, ctx.OBV[-14] * 1.1, ctx.OBV[-5]  * 1.1 ] )
            return

    # If the latest close price is less than the previous day's low price,
    # then place a buy order.
    # elif not ctx.long_pos() and ctx.short_pos():   # not tuple(ctx.long_positions()): #ctx.long_pos():
    # if ctx.bars >= 55 and ctx.indicator('SMAScore24')[-1] > 0 and ( ctx.ST[-1] == 1 and ctx.indicator('CCI_34')[-1] > 0 and ctx.indicator('ADX')[-1] > 30 and ctx.OBV[-1] > ctx.indicator('EMAOBV')[-12]*1 and ctx.indicator('RSI_20')[-1] > 55 ) or (ctx.AD[-1] > ctx.indicator('EMAAD')[-12]*1.1 and ctx.OBV[-1] > ctx.indicator('EMAOBV')[-12]*1.1 and ctx.Exp[-1] > -20000000000000 and 0*ctx.indicator('KAMA')[-1] < ctx.close[-1] > 15 and ctx.close[-1] < 10000 and ctx.ST[-1] < 3 and ctx.indicator('CCI_34')[-1] > 0 and ctx.indicator('ADX')[-1] > ctx.indicator('ADX')[-3] and ctx.indicator('RSI_20')[-7] < ctx.indicator('RSI_20')[-1] > 55 and ctx.indicator('EMAClose52')[-1] < ctx.indicator('EMAClose24')[-1] < ctx.indicator('EMAClose12')[-1]  and ctx.indicator('EMAMRP52')[-1] < ctx.indicator('EMAMRP24')[-1] < ctx.indicator('EMAMRP12')[-1] < ctx.MRP[-1]  and (0*ctx.indicator('STDDEV52')[-1] + ctx.indicator('SMAClose52')[-1]) < ctx.close[-1]*1 ):
    #  ctx.bars >= 55 and ctx.indicator('CCI_34')[-1] > 0 and ctx.indicator('ADX')[-1] > 30 and ctx.indicator('RSI_20')[-1] > 60 and ctx.indicator('EMAClose52')[-1] < ctx.indicator('EMAClose12')[-1] and ctx.indicator('EMAMRP52')[-1] < ctx.indicator('EMAMRP12')[-1] and 1.2 < ctx.MOMScore[-1] > ctx.indicator('EMAMOMScore24')[-1] and ctx.MRP[-14] < ctx.MRP[-1] > 7 :     and 2 < ctx.MOMScore[-1] > ctx.indicator('EMAMOMScore24')[-1]
    # Buy a number of shares that is equal to 25% the portfolio.   #and ctx.indicator('SMAROC1')[-1] > ctx.indicator('MIDPOINTROC_1')[-1]
    # ctx.buy_shares = 0 #
    # ctx.buy_shares = ctx.calc_target_shares(.20)        # 0.25   25%
    # Set the limit price of the order.
    # ctx.buy_limit_price = ctx.close[-1]
    # Hold the position for 3 bars before liquidating (in this case, 3 days).
    # ctx.stop_trailing_pct = 40
    # ctx.hold_bars = 3
    # ctx.score = ctx.MRP[-1]


duration = max_date - min_date
duration_in_days = duration.days
warmup = (duration_in_days - 55)
warmup = (duration_in_days - 250)

print(max_date)

print(duration_in_days)

print(warmup)
max_date = max_date

pyb.param("max_date", max_date)
pyb.param("last_day", duration_in_days)
pyb.param("warmup", warmup)
# pyb.param('number', number)
# pyb.param('rollMOMROCP', rollMOMROCP)

max_date1 = pyb.param("max_date")
last_day1 = pyb.param("last_day")
warmup1 = pyb.param("warmup")
number1 = pyb.param("number")
len1 = pyb.param("number")
# rollMOMROCP1=pyb.param('rollMOMROCP')


indicator_set = IndicatorSet()
"""
#sma_based_sma = pybroker.indicator('sma_based_sma', sma_based_sma, short_lookback=12, long_lookback=40)
sma_based_sma200 = pybroker.indicator('sma_based_sma200', lambda data: talib.SMA(data.SMA_200C, timeperiod=12))
#OBV = pybroker.indicator('OBV', lambda data: talib.OBV(data.close,data.volume))
#OBV52 = pybroker.indicator('OBV52', lambda data: talib.EMA(df.OBV, timeperiod=52))
CCI_34 = pybroker.indicator('CCI_34', lambda data: talib.CCI(data.high,data.low,data.close, timeperiod=34))
EMAClose12 = pybroker.indicator('EMAClose12', lambda data: talib.EMA(data.close, timeperiod=10))
EMAClose24 = pybroker.indicator('EMAClose24', lambda data: talib.EMA(data.close, timeperiod=20))
EMAClose52 = pybroker.indicator('EMAClose52', lambda data: talib.EMA(data.close, timeperiod=40))
#SMAClose52 = pybroker.indicator('SMAClose52', lambda data: talib.SMA(data.close, timeperiod=40))

SMAClose40 = pybroker.indicator('SMAClose40', lambda data: talib.SMA(data.close, timeperiod=40))   #ctx.SMA_200C #
SMAClose30 = pybroker.indicator('SMAClose30', lambda data: talib.EMA(data.close, timeperiod=25))
SMAClose10 = pybroker.indicator('SMAClose10', lambda data: talib.EMA(data.close, timeperiod=10))
RSI_14 = pybroker.indicator('RSI_14', lambda data: talib.RSI(data.close, timeperiod=14))
wkH52 = pybroker.indicator('wkH52', lambda data: talib.MAX(data.close, timeperiod=52))
wkL52 = pybroker.indicator('wkL52', lambda data: talib.MIN(data.close, timeperiod=52))

EMAMRP12 = pybroker.indicator('EMAMRP12', lambda data: talib.EMA(data.MRP, timeperiod=10))
EMAMRP52 = pybroker.indicator('EMAMRP52', lambda data: talib.SMA(data.MRP, timeperiod=40))
EMAMRP24 = pybroker.indicator('EMAMRP24', lambda data: talib.EMA(data.MRP, timeperiod=20))
RSI_20 = pybroker.indicator('RSI_20', lambda data: talib.RSI(data.close, timeperiod=24))
#SMAVol20 = pybroker.indicator('SMAVol20', lambda data: talib.SMA(data.volume, timeperiod=20))

EMADD_PCT24 = pybroker.indicator('EMADD_PCT24', lambda data: talib.EMA(data.DD_PCT, timeperiod=7))
ADX = pybroker.indicator('ADX', lambda data: talib.ADX(data.high,data.low,data.close, timeperiod=18))
#STDDEV52 = pybroker.indicator('STDDEV52', lambda data: talib.STDDEV(data.close,timeperiod=12, nbdev=1.0))
#KAMA = pybroker.indicator('KAMA', lambda data: talib.KAMA(data.close, timeperiod=12))
EMAAD = pybroker.indicator('EMAAD', lambda data: talib.EMA(data.AD, timeperiod=14))
EMAOBV = pybroker.indicator('EMAOBV', lambda data: talib.EMA(data.OBV, timeperiod=14))
SMAScore24= pybroker.indicator('SMAScore24', lambda data: talib.SMA(data.MOMScore, timeperiod=20))

#SMAROC1 = pybroker.indicator('SMAROC1', lambda data: talib.SMA(data.ROC_1, timeperiod=24))
#MIDPOINTROC_1 = pybroker.indicator('MIDPOINTROC_1', lambda data: talib.MIDPOINT(data.ROC_1, timeperiod=52))
#BBANDS = pybroker.indicator('BBANDS',lambda data: talib.BBANDS(data.close, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0))

NiftyEMAClose12 = pybroker.indicator('NiftyEMAClose12', lambda data: talib.EMA(data.niftyClose, timeperiod=10))
NiftyEMAClose24 = pybroker.indicator('NiftyEMAClose24', lambda data: talib.EMA(data.niftyClose, timeperiod=20))
NiftyEMAClose52 = pybroker.indicator('NiftyEMAClose52', lambda data: talib.EMA(data.niftyClose, timeperiod=40))
#NiftyCCI_34 = pybroker.indicator('NiftyCCI_34', lambda data: talib.CCI(data.niftyHigh,data.niftyLow,data.niftyClose, timeperiod=34))
#NiftyRSI_20 = pybroker.indicator('NiftyRSI_20', lambda data: talib.RSI(data.niftyClose, timeperiod=24))

bbup = pybroker.indicator('bbup', lambda data: talib.BBANDS(data.close).upperband)
bbdn = pybroker.indicator('bbdn', lambda data: talib.BBANDS(data.close).lowerband)
bbmd = pybroker.indicator('bbmd', lambda data: talib.BBANDS(data.close).middleband)
ema50 = pybroker.indicator('ema50', lambda data: ta.ema(pd.Series(data.close), length=50))   #to use pandas_ta as indicator
CCI_34 = pybroker.indicator("CCI_34",lambda data: (np.concatenate([np.full(len(data.close) - 30, np.nan),talib.CCI(data.high, data.low, data.close, timeperiod=34)[-30:]])))

"""

# sma_based_sma = pybroker.indicator('sma_based_sma', sma_based_sma, short_lookback=12, long_lookback=40)
sma_based_sma200 = pybroker.indicator(
    "sma_based_sma200", lambda data: talib.SMA(data.SMA_200C, timeperiod=10 * 4))
# OBV = pybroker.indicator('OBV', lambda data: talib.OBV(data.close,data.volume))
# OBV52 = pybroker.indicator('OBV52', lambda data: talib.EMA(df.OBV, timeperiod=52))
CCI_34 = pybroker.indicator("CCI_34", lambda data: talib.CCI(
    data.high, data.low, data.close, timeperiod=34))
# EMAClose12 = pybroker.indicator(
#    "EMAClose12", lambda data: talib.EMA(data.close, timeperiod=10 * 5))
# EMAClose24 = pybroker.indicator(
#    "EMAClose24", lambda data: talib.EMA(data.close, timeperiod=30 * 5))
# EMAClose52 = pybroker.indicator(
#    "EMAClose52", lambda data: talib.EMA(data.close, timeperiod=40 * 5))
# SMAClose52 = pybroker.indicator('SMAClose52', lambda data: talib.SMA(data.close, timeperiod=40))
# LINEARREG_SLOPE_OBV = pybroker.indicator(
#    "LINEARREG_SLOPE_OBV", lambda data: talib.LINEARREG_ANGLE(data.OBV, timeperiod=90))  # LINEARREG_ANGLE  LINEARREG_SLOPE
# HT_TRENDMODE = pybroker.indicator(
#    "HT_TRENDMODE", lambda data: talib.HT_TRENDMODE(data.close))
HT_TRENDMODE_OBV = pybroker.indicator(
    "HT_TRENDMODE_OBV", lambda data: talib.HT_TRENDMODE(data.OBV))


# SMAniftyClose30 = pybroker.indicator(
#    "SMAniftyClose30", lambda data: talib.EMA(data.niftyClose, timeperiod=30 * 5))
# SMAniftyClose10 = pybroker.indicator(
#    "SMAniftyClose10", lambda data: talib.EMA(data.niftyClose, timeperiod=10 * 5))
#
# niftyClosewkH52 = pybroker.indicator(
#    "niftyClosewkH52", lambda data: talib.MAX(data.niftyClose, timeperiod=50 * 5))

SMAClose40 = pybroker.indicator("SMAClose40", lambda data: talib.SMA(
    data.close, timeperiod=40 * 5))  # ctx.SMA_200C #
SMAClose30 = pybroker.indicator(
    "SMAClose30", lambda data: talib.EMA(data.close, timeperiod=30 * 5))
SMAClose10 = pybroker.indicator(
    "SMAClose10", lambda data: talib.EMA(data.close, timeperiod=10 * 5))
# RSI_14 = pybroker.indicator(
#    "RSI_14", lambda data: talib.RSI(data.close, timeperiod=21))
wkH52 = pybroker.indicator(
    "wkH52", lambda data: talib.MAX(data.close, timeperiod=245))
wkL52 = pybroker.indicator(
    "wkL52", lambda data: talib.MIN(data.close, timeperiod=245))

# EMAMRP12 = pybroker.indicator(
#    "EMAMRP12", lambda data: talib.EMA(data.MRP, timeperiod=10 * 5))
# EMAMRP52 = pybroker.indicator(
#    "EMAMRP52", lambda data: talib.SMA(data.MRP, timeperiod=40 * 5))
EMAMRP24 = pybroker.indicator(
    "EMAMRP24", lambda data: talib.EMA(data.MRP, timeperiod=10 * 5))
RSI_20 = pybroker.indicator(
    "RSI_20", lambda data: talib.RSI(data.close, timeperiod=24))
# SMAVol20 = pybroker.indicator('SMAVol20', lambda data: talib.SMA(data.volume, timeperiod=20))

# EMADD_PCT24 = pybroker.indicator('EMADD_PCT24', lambda data: talib.EMA(data.DD_PCT, timeperiod=7*2))
ADX = pybroker.indicator("ADX", lambda data: talib.ADX(
    data.high, data.low, data.close, timeperiod=21))
PLUS_DI = pybroker.indicator("PLUS_DI", lambda data: talib.PLUS_DI(
    data.high, data.low, data.close, timeperiod=14))
MINUS_DI = pybroker.indicator("MINUS_DI", lambda data: talib.MINUS_DI(
    data.high, data.low, data.close, timeperiod=14))

# STDDEV52 = pybroker.indicator('STDDEV52', lambda data: talib.STDDEV(data.close,timeperiod=12, nbdev=1.0))
# KAMA = pybroker.indicator('KAMA', lambda data: talib.KAMA(data.close, timeperiod=12))
# EMAAD = pybroker.indicator('EMAAD', lambda data: talib.EMA(data.AD, timeperiod=14))
# EMAAD = pybroker.indicator('EMAAD', lambda data: talib.EMA(data.AD, timeperiod=14))
# EMAAD = pybroker.indicator('EMAAD', lambda data: talib.EMA(data.MRP, timeperiod=14))
EMAOBV = pybroker.indicator(
    "EMAOBV", lambda data: talib.SMA(data.OBV, timeperiod=42))
# SMAScore24= pybroker.indicator('SMAScore24', lambda data: talib.SMA(data.MOMScore, timeperiod=20*5))
# SMAScore24 = pybroker.indicator(
#    "SMAScore24", lambda data: talib.SMA(data.MOMScore, timeperiod=7))
# SMAScore7= pybroker.indicator('SMAScore7', lambda data: talib.SMA(data.MOMScore, timeperiod=7))
# AD = pybroker.indicator('AD', lambda data: talib.AD(data.high,data.low,data.close,data.volume))
# SMAAD = pybroker.indicator(
#    "SMAAD", lambda data: talib.EMA(data.AD, timeperiod=34))

RSI_min = pybroker.indicator(
    "RSI_min", lambda data: talib.MIN(data.RSI_e, timeperiod=7))
RSI_max = pybroker.indicator(
    "RSI_max", lambda data: talib.MAX(data.RSI_e, timeperiod=120))

# SMAROC1 = pybroker.indicator('SMAROC1', lambda data: talib.SMA(data.ROC_1, timeperiod=24))
# MIDPOINTROC_1 = pybroker.indicator('MIDPOINTROC_1', lambda data: talib.MIDPOINT(data.ROC_1, timeperiod=52))
# BBANDS = pybroker.indicator('BBANDS',lambda data: talib.BBANDS(data.close, timeperiod=20, nbdevup=2, nbdevdn=2, matype=0))

# NiftyEMAClose12 = pybroker.indicator('NiftyEMAClose12', lambda data: talib.EMA(data.niftyClose, timeperiod=10*5))
# NiftyEMAClose24 = pybroker.indicator('NiftyEMAClose24', lambda data: talib.EMA(data.niftyClose, timeperiod=20*5))
# NiftyEMAClose52 = pybroker.indicator('NiftyEMAClose52', lambda data: talib.EMA(data.niftyClose, timeperiod=40*5))
# NiftyCCI_34 = pybroker.indicator('NiftyCCI_34', lambda data: talib.CCI(data.niftyHigh,data.niftyLow,data.niftyClose, timeperiod=34))
# NiftyRSI_20 = pybroker.indicator('NiftyRSI_20', lambda data: talib.RSI(data.niftyClose, timeperiod=24))

# indicator_set.add(ADX, PLUS_DI, MINUS_DI, EMAOBV, CCI_34, RSI_20, SMAClose40, SMAClose30, SMAClose10, wkH52, wkL52, sma_based_sma200, RSI_min, RSI_max,EMAMRP24)

# indicator_set.add(ADX, PLUS_DI, MINUS_DI, EMAOBV, CCI_34, EMAClose12, EMAClose52, EMAMRP12, EMAMRP52,
#                  RSI_20, EMAMRP24, EMAClose24, SMAClose40, SMAClose30, SMAClose10, wkH52, wkL52, sma_based_sma200, RSI_min, RSI_max,HT_TRENDMODE_OBV)

# indicator_set(df, disable_parallel=True)
# print(indicator_set(df))
# summary = indicator_set(df['STDDEV52']).describe()
# print(summary)


csv_data_source = CSVDataSource()
df = csv_data_source.query(symbol_list, min_date_str,
                           max_date_str)  # 2009-06-29 2024-06-03

# ,fee_mode=FeeMode.ORDER_PERCENT
order_percent = 0.00  # Assuming the fee mode is a percentage, e.g., 0.1% , .001
config = StrategyConfig(round_fill_price=True, fee_amount=0, fee_mode=pybroker.common.FeeMode.ORDER_PERCENT, initial_cash=500000000, exit_on_last_bar=False,
                        enable_fractional_shares=False, max_long_positions=None, max_short_positions=None, bars_per_year=252, bootstrap_sample_size=2, bootstrap_samples=5)
strategy = Strategy(df, min_date_str, max_date_str, config)
# pyb.param('target_size', 1 / config.max_long_positions)
pyb.param("rank_threshold", 1000)

slippage = RandomSlippageModel(min_pct=1.0, max_pct=5.0)  # Slippage of 1-5%
# strategy.set_slippage_model(slippage)
# model_slr = pybroker.model('slr', train_slr, indicators=[cmma_20])
# strategy.add_execution(None, ['NVDA', 'AMD'], models=model_slr)
# strategy.clear_executions()
# strategy.add_execution(hold_long, ['NVDA', 'AMD'], models=model_slr)
# strategy.set_pos_size_handler(pos_size_handler)
strategy.set_before_exec(rank)
strategy.add_execution(Momentum, symbol_list, indicators=(ADX, PLUS_DI, MINUS_DI, EMAOBV, CCI_34, EMAMRP24,
                       RSI_20, SMAClose40, SMAClose30, SMAClose10, wkH52, wkL52, sma_based_sma200, RSI_min, RSI_max, HT_TRENDMODE_OBV))
# strategy.add_execution(short_high, symbol_list)
# strategy.set_after_exec(rebalance)  #Equal Position Sizing
# strategy.set_after_exec(optimization) #Portfolio Optimization
# result = strategy.backtest(warmup=55)

result = strategy.backtest(disable_parallel=True,
                           calc_bootstrap=False, warmup=(247))
# result = strategy.backtest(calc_bootstrap=False,warmup=(number1-5))

"""
result = strategy.walkforward(
    warmup=52,
    windows=3,
    train_size=0.5,
    lookahead=1,
    calc_bootstrap=True
)
"""
portfolio = result.portfolio
positions = result.positions
trades = result.trades
orders = result.orders
metrics_df = result.metrics_df.round(1)
# conf_intervals=result.bootstrap.conf_intervals.round(1)
# drawdown_conf=result.bootstrap.drawdown_conf.round(1)

print("__________________________________________")
print(orders)
print("__________________________________________")
# print(trades)
# print(positions)
# print(portfolio)
# print(metrics_df)
# print(conf_intervals)
# print(drawdown_conf)
# print(orders)

# see the daily balances of the portfolio,
# chart = plt.subplot2grid((3, 2), (0, 0), rowspan=3, colspan=2)
# chart.plot(result.portfolio.index, result.portfolio['market_value'])

# BT_FILE_PATH = r"C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\PybrokerOrders.csv"
# post_telegram_file("/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv")


FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/Finalnse.csv")
# FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/FinalMicrocap250.csv")
# NSE570ticker_df = pd.read_csv(nse500)
# add_suffix_to_column(FinalMicrocap250, "Symbol", ".NS")  #FinalMicrocap250.csv
FinalMicrocap250symbols = FinalMicrocap250["Symbol"].tolist()[:]
# NSE570symbols = list(dict.fromkeys(symbols))
FinalMicrocap250symbols = list(set(FinalMicrocap250symbols))
# FinalMicrocap250symbolslen =len(FinalMicrocap250symbols)
# print(FinalMicrocap250symbolslen)

# FinalMicrocap250symbols = list(set(FinalMicrocap250['Symbol'].tolist()))

# print(FinalMicrocap250symbols[:10])

# NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""


# bt_data = pd.DataFrame()
# bt_data = orders #pd.read_csv(BT_FILE_PATH)
orders.reset_index(inplace=True)
# orders.rename(columns={'index': 'ref'}, inplace=True)

"""
id,type,symbol,date,shares,limit_price,fill_price,fees
trade_logged_on,trade_updated_on,trade_id,status,date,ticker,signal,price,talib_date,talib_signal,talib_price,pnl,Company,Industry

ref,ticker,dir,datein,pricein
"""


orders.drop(["id", "limit_price", "fees"], axis=1, inplace=True)

orders["type"] = orders["type"].str.upper()

orders.rename(columns={"type": "dir", "symbol": "ticker", "date": "datein",
              "fill_price": "pricein"}, inplace=True)  # 'id': 'ref',

# bt_data = bt_data[['ticker','dir','datein','pricein']]
# bt_data = bt_data.sort_values(by=['dir', 'Industry'], inplace=True)
# orders.sort_values(by='dir', inplace=True)

"""
Scoretickersall = pd.read_csv("/home/rizpython236/BT5/trade-logs/Scoretickersall.csv")
Scoretickersall = Scoretickersall.drop(columns=['Company', 'Close', 'AvgScore'], errors='ignore')
# Merge on ticker symbol
orders = orders.merge(Scoretickersall, left_on='ticker', right_on='Ticker', how='left')
# Drop duplicate 'Ticker' column (optional)
orders = orders.drop(columns=['Ticker'], errors='ignore')
orders['Score'] = orders['Score'].round(2)
"""

orders["Score"] = orders["ticker"].map(symbol_score_dict)
orders["Score"] = orders["Score"].round(2)


orders["N750"] = orders["ticker"].apply(
    lambda x: "Y" if x in FinalMicrocap250symbols else "")
# orders['N750'] = np.where(orders['ticker'].isin(FinalMicrocap250symbols), 'Y', '')
orders = orders[["N750", "ticker", "dir", "datein", "pricein", "Score"]]
orders.sort_values(by=["dir", "Score", "N750"], ascending=[
                   True, True, False], inplace=True)
# orders = orders[['N750', 'ticker', 'dir', 'datein', 'pricein']]
# orders.sort_values(by=['dir', 'N750'],ascending=[True, False], inplace=True)

# print(orders)
max_date = orders["datein"].max()
orders = orders[orders["datein"] == max_date]
# print("++++++++")
print(orders.head())
if orders.empty:
    post_telegram_message("ERROR: BT run was empty")

SCREENER_OUTPUT_FILENAME = "trade_list_BT_Screener.csv"
BT_SCREENER_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + SCREENER_OUTPUT_FILENAME
orders.to_csv(BT_SCREENER_FILE_PATH, index=False)
trades.to_csv(
    "/home/rizpython236/BT5/screener-outputs/pybrokerBT_Trades.csv", index=False)

# output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf'  # Replace with desired output PDF file
# create_pdf(BT_SCREENER_FILE_PATH, output_pdf_file,pageA4= True)
# time.sleep(5)
# post_telegram_file("/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf")

SCREENER_OUTPUT_FILENAME = "trade_list_Talib_Screener.csv"
TALIB_SCREENER_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + \
    "/" + SCREENER_OUTPUT_FILENAME
orders.to_csv(TALIB_SCREENER_FILE_PATH, index=False)

# output_path = r"C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\PybrokerOrders.csv"
# orders.to_csv(output_path,index=False)

# output_path = r"C:\Users\Abdul Qadir\Documents\Python\Projects\data acq\BACKTRADER\pyprokerriz\trade_list_Talib_Screener.csv"
# orders.to_csv(output_path,index=False)


file_path = "/home/rizpython236/BT5/screener-outputs/combined_ticker_data.csv"
file_path1 = "/home/rizpython236/BT5/screener-outputs/combined_ticker_data.pkl.gz"

try:
    # pyb.clear_indicator_cache()
    # pyb.clear_data_source_cache()

    os.remove(file_path1)
    os.remove(file_path)
    print(f"{file_path} successfully deleted.")
except OSError as e:
    print(f"Error deleting {file_path}: {e.strerror}")


print("All Done")
