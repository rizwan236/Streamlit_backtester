
import csv
from datetime import datetime, timedelta
import os
import sys

#from scipy import stats
import time
import traceback

from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates

#import mplfinance as mpf
import matplotlib.pyplot as plt

#import pytz
import numpy as np
import pandas as pd

#sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")
#import pandas_ta as ta
#import tulipy as ti
from PDFconvert import create_pdf, delete_file
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))



minervinitickers = ['BAJAJFINSV.NS.csv', 'TJI_pvtBK.csv', 'ASTRAZEN.NS.csv', 'MHEL.BO.csv', 'GLEAM.BO.csv', 'AVANTIFEED.NS.csv', 'JSWSTEEL.NS.csv', 'MANRAJH.BO.csv', 'INDIGO.NS.csv', 'MAHASTEEL.NS.csv',
 'SWARAJENG.NS.csv']

try:
    print(minervinitickers)
    folder_path = '/home/rizpython236/BT5/ticker_15yr/'
    filepathpdf = '/home/rizpython236/BT5/screener-outputs/minervini_Charts.pdf'


    with PdfPages(filepathpdf) as pdf:
        # Loop through all files in the folder
        for file_name in os.listdir(folder_path):

            if file_name.endswith('.csv'):
                file_path = os.path.join(folder_path, file_name)
                #total_files += 1
                base_name = os.path.splitext(file_name)[0]
                #file_names.append(base_name)
                #print(base_name)

                try:
                    if file_name in minervinitickers:
                        file_path = os.path.join(folder_path, file_name)
                        #selected_files.append(file_path)
                        #total_files += 1
                        Base_name=symbol_to_company.get(base_name, base_name)
                        # Read the CSV file into a DataFrame
                        dfM = pd.read_csv(file_path)
                        dfM['Date'] = pd.to_datetime(dfM['Date'])  # Convert index to datetime

                        dfM["CCI"]=tb.CCI(dfM['High'], dfM['Low'], dfM['Close'], timeperiod=34*5)
                        #dfM["CCImovavgL"] = tb.EMA(dfM["CCI"], timeperiod=14)
                        dfM["RSI14"] = tb.RSI(dfM['Close'], timeperiod=14)
                        dfM["SMA_50"] = tb.SMA(dfM['Close'], timeperiod=50)
                        dfM["SMA_200"] = tb.SMA(dfM['Close'], timeperiod=200)
                        #df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        dfM["SMA_150"] = tb.SMA(dfM['Close'], timeperiod=150)
                        #df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        #df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                        dfM["SMA_200_15"] = tb.SMA(dfM['SMA_200'], timeperiod=60)
                        dfM["OBV"] = tb.OBV(dfM['Close'], dfM['Volume'])
                        print(dfM)
                        print(f"minervini_Charts for {Base_name}")


                        # 1. Combined Price, Volume, RSI Chart
                        fig_combined = plt.figure(figsize=(11, 8.5))
                        #gs = fig_combined.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                        #gs = fig_combined.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])
                        gs = fig_combined.add_gridspec(4, 1, height_ratios=[6, 1, 1.5, 1.5])  #Custom GridSpec for 60% Price, 10% Volume, 15% RSI, 15% CCI

                        # Price chart (line plot)
                        ax1 = fig_combined.add_subplot(gs[0])
                        ax1.plot(dfM['Date'], dfM['Close'], label='Price', color='black', linewidth=1)

                        # Plot SMAs on top of line chart
                        ax1.plot(dfM['Date'], dfM['SMA_50'], label='SMA 50', color='blue', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_150'], label='SMA 150', color='orange', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200'], label='SMA 200', color='red', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200_15'], label='SMA 200(15)', color='purple', linewidth=1.5)

                        ax1.set_title(f'{Base_name} Price and Moving Averages', fontsize=14)
                        ax1.legend()

                        '''
                        # Volume chart
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        ax2.bar(dfM['Date'], dfM['Volume']/ 1000, color='blue', width=0.5, alpha=0.5)
                        #ax2.set_title('Volume', fontsize=12)
                        #ax2.set_ylabel('Volume')
                        #ax2.set_title('Volume (in thousands)', fontsize=12)  # Update title to reflect units
                        ax2.set_ylabel('Volume (K)')  # Change y-axis label to indicate thousands
                        '''

                        # Volume chart with OBV
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        # Plot volume bars
                        ax2.bar(dfM['Date'], dfM['Volume']/1000, color='blue', width=0.5, alpha=0.5, label='Volume')
                        # Plot OBV line on secondary y-axis
                        ax2b = ax2.twinx()
                        ax2b.plot(dfM['Date'], dfM['OBV'], color='black', linewidth=1.5, label='OBV')
                        # Set labels and title
                        ax2.set_ylabel('Volume (K)', color='blue')
                        ax2b.set_ylabel('OBV', color='black')
                        # Set colors for y-axes to match their respective data
                        ax2.tick_params(axis='y', colors='blue')
                        ax2b.tick_params(axis='y', colors='black')
                        # Add legend
                        lines, labels = ax2.get_legend_handles_labels()
                        lines2, labels2 = ax2b.get_legend_handles_labels()
                        ax2.legend(lines + lines2, labels + labels2, loc='upper left')



                        # RSI chart
                        ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                        ax3.plot(dfM['Date'], dfM["RSI14"], color='purple', label='RSI')
                        ax3.axhline(70, color='red', linestyle='--', alpha=0.5)
                        ax3.axhline(30, color='green', linestyle='--', alpha=0.5)
                        ax3.fill_between(dfM['Date'], 70, dfM["RSI14"],
                                       where=(dfM["RSI14"] >= 70), color='red', alpha=0.3)
                        ax3.fill_between(dfM['Date'], 30, dfM["RSI14"],
                                       where=(dfM["RSI14"] <= 30), color='green', alpha=0.3)
                        ax3.set_title('RSI (14)', fontsize=12)
                        ax3.set_ylim(0, 100)
                        ax3.legend()

                        # CCI chart
                        ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                        ax4.plot(dfM['Date'], dfM["CCI"], color='purple', label='CCI')
                        ax4.axhline(0, color='red', linestyle='--', alpha=0.5)
                        ax4.axhline(50, color='green', linestyle='--', alpha=0.5)
                        ax4.fill_between(dfM['Date'], 0, dfM["CCI"],
                                       where=(dfM["CCI"] <= 0), color='red', alpha=0.3)
                        ax4.fill_between(dfM['Date'], 50, dfM["CCI"],
                                       where=(dfM["CCI"] >= 50), color='green', alpha=0.3)
                        ax4.set_title('CCI (34)', fontsize=12)
                        ax4.set_ylim(-100, 150)
                        ax4.legend()

                        # Format x-axis to show labels on a quarterly basis
                        plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))  # Quarterly labels
                        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format as 'YYYY-MM'
                        plt.xticks(rotation=90)
                        #plt.tight_layout()
                        # Reduce margins using tight_layout with padding adjustments
                        plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)  # Adjust padding as needed
                        #pdf.savefig(fig_combined)
                        pdf.savefig(fig_combined, bbox_inches='tight')

                        folder_pathf='/home/rizpython236/BT5/screener-outputs/'
                        file_path = os.path.join(folder_pathf)
                        chart_path = os.path.join(folder_pathf, f'minervini_{Base_name}.png')
                        #plt.savefig(chart_path)
                        #time.sleep(3)
                        #post_telegram_file(chart_path)
                        #os.remove(chart_path)
                        #if total_files == symNo:
                        plt.close(fig_combined)

                        # Add metadata
                        d = pdf.infodict()
                        d['Title'] = f'{Base_name} Technical Analysis Report'
                        d['Author'] = 'Automated Report Generator'

                        print(f"Generated report for {Base_name} at: {filepathpdf}")
                except Exception as e:
                    print(f"Error processing minervini_Charts {Base_name}: {str(e)}")
                    traceback_str = traceback.format_exc()
                    plt.close('all')
                    continue

    time.sleep(5)
    print(f"Send telegrame report: {filepathpdf}")
    post_telegram_file(filepathpdf)
except Exception as e:
    print(f"Error processing minervini_Charts: {str(e)}")
    traceback_str = traceback.format_exc()
    #plt.close('all')

print("csv15yrs done")