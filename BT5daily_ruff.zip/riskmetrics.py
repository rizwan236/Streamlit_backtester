import os

import numpy as np
import pandas as pd


def calculate_sqrt_semi_kurtosis(returns):
  """
  Calculates the square root of semi-kurtosis for a given series of returns.

  Args:
    returns: A NumPy array of asset returns.

  Returns:
    The square root of semi-kurtosis.
  """

  # Calculate excess returns
  excess_returns = returns - np.mean(returns)

  # Calculate fourth moment
  fourth_moment = np.mean(excess_returns**4)

  # Calculate semi-kurtosis
  semi_kurtosis = fourth_moment / (3 * np.std(returns)**4)

  # Calculate square root of semi-kurtosis
  sqrt_semi_kurtosis = np.sqrt(np.abs(semi_kurtosis - 3))

  return sqrt_semi_kurtosis


def analyze_stock(data):
    """
    Analyzes OHLCV data for a single stock and returns a dictionary with risk metrics.

    Args:
        data (pd.DataFrame): DataFrame containing OHLCV data (Open, High, Low, Close, Volume)

    Returns:
        dict: Dictionary containing risk metrics for the stock
    """
    returns = data['Close'].pct_change()  # Calculate daily returns

    # Calculate risk metrics
    semi_stddev = np.sqrt(np.mean(np.power(returns.clip(lower=0), 2)))
    sqrt_semi_kurtosis = calculate_sqrt_semi_kurtosis(returns)
    #sqrt_semi_kurtosis = np.sqrt(np.abs(moments.kurtosis(returns) - 3))
    omega_ratio = np.mean(returns) / np.sqrt(np.mean(np.power(returns - np.mean(returns), 2).clip(lower=0)))
    sortino_ratio = np.mean(returns.clip(lower=0)) / np.sqrt(np.mean(np.power(returns - np.mean(returns.clip(lower=0)), 2)))
    cvar = returns.quantile(0.05)  # 5% CVaR
    #tail_gini = 1 - 2 * returns.sort_values(ascending=False).cumsum() / returns.sum()
    evar = -((1 - np.exp(-0.05 * returns.mean())) / 0.05)  # 5% EVaR

    return {
        'Semi Standard Deviation': round(semi_stddev*100,3),
        'Square Root Semi Kurtosis': round(sqrt_semi_kurtosis*100,3),
        'Omega Ratio': round(omega_ratio*100,3),
        'Sortino Ratio': round(sortino_ratio*100,3),
        'CVaR': round(cvar*100,3),
        #'Tail Gini': tail_gini,
        'EVaR': round(evar*100,3),
    }


input_folder = "/home/rizpython236/BT5/ticker_15yr/"  # Replace with your actual folder path
output_csv = "/home/rizpython236/BT5/screener-outputs/risk_metrics.csv"

results = []
for filename in os.listdir(input_folder):
    if filename.endswith(".csv"):
        file_path = os.path.join(input_folder, filename)
        try:
            data = pd.read_csv(file_path)
            risk_metrics = analyze_stock(data)
            risk_metrics['Filename'] = filename  # Add filename to the dictionary
            results.append(risk_metrics)
            print(f"Risk metrics for {filename}: {risk_metrics}")
        except Exception as e:
            print(f"Error processing {filename}: {e}")

# Save results to CSV
df = pd.DataFrame(results)
df.to_csv(output_csv, index=False)

print("Done")
