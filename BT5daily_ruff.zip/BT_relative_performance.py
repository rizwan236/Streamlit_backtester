
import backtrader as bt
import pandas as pd


'''
class RelativePerformanceIND(bt.Strategy):
    params = (
        ('window', 52),  # Default period is 52
    )

    def __init__(self):
        self.stock_close = self.datas[0].close
        self.index_close = self.datas[1].close

        # Calculate Relative Performance (RP)
        self.RP = (self.stock_close / self.index_close) * 100

        # Calculate RP52W (Simple Moving Average over the specified period)
        self.RP52W = bt.indicators.SMA(self.RP, period=self.params.period)

        # Calculate Mansfield Relative Performance (MRP)
        self.MRP = ((self.RP / self.RP52W) - 1) * 10

    def next(self):
        # Access the current MRP value and print it
        current_mrp = self.MRP[0]
        print("MRP:", current_mrp)
'''


class MRPIndicator(bt.Indicator):
    lines = ('mrp',)

    params = (
    ('window', 13),  # Default window value of 13
    #('stock_data', None),  # Default stock data value of None
    #('index_data', None),  # Default index data value of None
    )

    #def __init__(self):
    def __init__(self, stock_data,index_data, window=13):
        super(MRPIndicator, self).__init__()
        #stock_data = self.datas[0].close #self.data.close
        #index_csv_file = "/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv"
        #index_data = pd.read_csv(index_csv_file)

        # Calculate Relative Performance (RP)
        RP = (stock_data["Close"] / index_data["Close"]) * 100

        # Calculate RP52W (Simple Moving Average over 52 weeks)
        RP52W = RP.rolling(window=self.params.window).mean()

        # Calculate Mansfield Relative Performance (MRP)
        MRP = ((RP / RP52W) - 1) * 10

        self.lines.mrp = MRP.values