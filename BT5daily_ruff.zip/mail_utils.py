import sys

import pandas as pd
import yagmail

from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
)


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages/")


INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
invalid_tickers_df = pd.read_csv(INVALID_TICKERS_FILE_PATH)
invalid_tickers = list(invalid_tickers_df["invalid_ticker"].unique())

INCOMPLETE_TICKERS_FILE_PATH = (
    SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV
)
incomplete_tickers_df = pd.read_csv(INCOMPLETE_TICKERS_FILE_PATH)
incomplete_tickers = list(incomplete_tickers_df["Symbol"].unique())


user = "rizpython236@gmail.com"
# a token for gmail
app_password = "wjjjjoefafscpxus"
receiver_list = [
    "abdulqadir23@gmail.com",
    "rizpython236@gmail.com",
    "farhanshaikh464@gmail.com",
]

subject = "Screener Alerts"

attachment = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
content = ["Hey! Here are the latest alerts that need your attention!", attachment]


def trigger_email_notification():

    tickers_meta_info = {
        "invalid_tickers": invalid_tickers,
        "incomplete_data_tickers": incomplete_tickers,
    }
    content = [tickers_meta_info, attachment]

    for receiver_ in receiver_list:
        with yagmail.SMTP(user, app_password) as yag:
            # yag.send(receiver_, subject, content)
            print("Email sent successfully!")


def trigger_generic_email(msg, attachment=None):
    if attachment:
        content = [msg, attachment]
    else:
        content = msg
    for receiver_ in receiver_list:
        with yagmail.SMTP(user, app_password) as yag:
            # yag.send(receiver_, subject, content)
            print("Email sent successfully!")
