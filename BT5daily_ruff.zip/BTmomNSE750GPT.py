import csv
from datetime import datetime
import os
import sys

#from scipy import stats
import time
import traceback

#sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
#import pandas_ta as ta
import BTmombroker
import numpy as np
import pandas as pd
from PDFconvert import create_pdf
import pytz

#import yfinance as yf
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


time.sleep(5)

'''
use below strategy where the universe of stock ticker is in a csv file
1) 12 month , 6 month ,  3 month  Momentum Ratio =  Price return / σp  # [Price (M-1)/Price (M-13)]-1
2) σp = Annualised standard deviation of lognormal daily returns of the stock for 1 year
3) Z Score of the Momentum Ratio for 12 month , 6 month, 3 month where Z Score= (MR12 - µMR12)/σMR12
4) Weighted Average Z Score = 45% * (12 month Momentum Z Score) + 45% * (6 month Momentum Z Score) + 10% * (3 month Momentum Z Score)
5) Normalized Momentum Score = (1+ Wgt. Average Z score) if Wgt. Average Z score >=0  or (1- Weighted Average Z score)^-1 if Wgt. Average Z score < 0
6) The top 30 stocks with the highest Normalized Momentum Score are selected
The top 30 stocks with the highest Normalized Momentum Score are selected

MR12 is the 12 month Momentum Ratio of the stock
µMR12 is the mean of the 12 month Momentum Ratios of the eligible
universe
σMR12  is the std. deviation of the 12 month Momentum Ratios of the
eligible universe

'''

print("Start BTmomNSE750")
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)

#input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv'


def downside_deviation_from_pricesaaa(log_returns, mar=0):
    # Calculate the returns that are below the minimum acceptable return (MAR)
    downside_returns = log_returns[log_returns < mar]

    # Square these returns
    squared_downside_returns = downside_returns ** 2

    # Calculate the mean of these squared returns
    mean_squared_downside = squared_downside_returns.mean()

    # Take the square root of the mean squared downside returns
    downside_deviation = np.sqrt(mean_squared_downside)
    #print(downside_deviation)

    return downside_deviation

def update_output_file(input_file, output_file):
    """
    Updates the output file with VLOOKUP logic for Symbol, Company, YFindustry, and Industry columns.
    Fills in missing data for symbols without VLOOKUP matches.

    Args:
        input_file (str): Path to the input CSV file.
        output_file (str): Path to the output CSV file.
    """

    df_input = pd.read_csv(input_file)
    df_output = output_file# pd.read_csv(output_file)

    # Sort dataframes before merging to improve performance
    df_input.sort_values('Symbol', inplace=True)
    df_output.sort_values('Symbol', inplace=True)

    # Reduce dataframe size by selecting only necessary columns
    df_input = df_input[['Symbol', 'Company', 'YFindustry', 'Industry']]

    # Perform VLOOKUP and merge using the correct join type (left join in this case)
    merged_data = pd.merge(df_output, df_input, on='Symbol', how='left')

    # Fill 'Company' with corresponding 'Symbol' if it's missing
    merged_data['Company'] = merged_data['Company'].fillna(merged_data['Symbol'])
    merged_data["YFindustry"].fillna("Blank", inplace=True)
    merged_data["Industry"].fillna("Blank", inplace=True)

    # Save the merged data to a new CSV file
    rankedTop30=merged_data
    #merged_data.to_csv(output_file, index=False)

def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].astype(str) + suffix
    #df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df

#folder_path = '/home/rizpython236/BT5/ticker_15yr/'  # Replace with the actual folder path  ticker_daily1yr58
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
exclude_tickers = pd.read_csv('/home/rizpython236/BT5/exclude_tickers.csv')
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
#ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
#ticker_df = pd.read_csv(ticker_path)
#symbols = ticker_df['Symbol'].tolist()[:]
#symbols = list(dict.fromkeys(symbols))  #list(set(symbols))

#________________________

'''
NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(NSE570_path)
NSE570symbols1 = NSE570ticker_df['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols1))
symbols = list(dict.fromkeys(NSE570symbols1))
number=len(symbols)
print(number)
symbols= [symbol for symbol in NSE570symbols if symbol not in exclude_tickers["Symbol"]]
number=len(symbols)
print(number)
jj
'''

valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

#___________________________________

#NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'         #NSE750
#nse500 = pd.read_csv("/home/rizpython236/BT5/nse500.csv")  #NSE500
#nse500 = pd.read_csv(NSE570_path)   #NSE750
#add_suffix_to_column(nse500, "Symbol", ".NS")              # use with nse500.csv

nse500 = '/home/rizpython236/BT5/symbol_list.csv'
nse500 = pd.read_csv(nse500)
NSE570symbols1 = nse500['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols1))
symbols = list(dict.fromkeys(NSE570symbols1))
number=len(symbols)
print(number)

#symbols = symbols[~symbols["Symbol"].isin(exclude_tickers["Symbol"])]
#symbols = [symbol for symbol in symbols if symbol["Symbol"] not in exclude_tickers]
symbols= [symbol for symbol in NSE570symbols if symbol not in exclude_tickers["Symbol"]]
number=len(symbols)
print(number)

#_____________________________
rankedTop30 = []
selected_files=[]
#all_stats = []
momentumratiosall=[]


FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/Finalnse.csv")
#FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/FinalMicrocap250.csv")
#NSE570ticker_df = pd.read_csv(nse500)
#add_suffix_to_column(FinalMicrocap250, "Symbol", ".NS")  #FinalMicrocap250.csv
FinalMicrocap250symbols = FinalMicrocap250['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
FinalMicrocap250symbols = list(set(FinalMicrocap250symbols))
FinalMicrocap250symbolslen =len(FinalMicrocap250symbols)
print(FinalMicrocap250symbolslen)

def get_normalized_scores(data, df, df2, df3, periods, weight_12m=0.45, weight_6m=0.45, weight_3m=0.1):
    normalized_scores = {}

    for n in periods:
        lognormal_returns = calculate_lognormal_daily_returns(data['Close'][-(52+n):-n] if n != 0 else data['Close'][-52:])
        #annualized_lognormal_std = lognormal_returns.std(axis=0) #* np.sqrt(52)
        annualized_lognormal_std = lognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)

        data['ROC_3m'] = tb.ROC(data['Close'], timeperiod=12)
        data['ROC_6m'] = tb.ROC(data['Close'], timeperiod=24)
        data['ROC_12m'] = tb.ROC(data['Close'], timeperiod=52)

        momentum_ratio_12m = data['ROC_12m'].iloc[-(n+1)] / annualized_lognormal_std
        momentum_ratio_6m = data['ROC_6m'].iloc[-(n+1)]  / annualized_lognormal_std
        momentum_ratio_3m = data['ROC_3m'].iloc[-(n+1)]  / annualized_lognormal_std

        if n == 0:
            mean_momentum_3m = df['mean_momentum_3m'].iloc[-1]
            mean_momentum_6m = df['mean_momentum_6m'].iloc[-1]
            mean_momentum_12m = df['mean_momentum_12m'].iloc[-1]

            std_momentum_3m = df['std_momentum_3m'].iloc[-1]
            std_momentum_6m = df['std_momentum_6m'].iloc[-1]
            std_momentum_12m = df['std_momentum_12m'].iloc[-1]
        elif n == 1:
            mean_momentum_3m = df2['mean_momentum_3m'].iloc[-1]
            mean_momentum_6m = df2['mean_momentum_6m'].iloc[-1]
            mean_momentum_12m = df2['mean_momentum_12m'].iloc[-1]

            std_momentum_3m = df2['std_momentum_3m'].iloc[-1]
            std_momentum_6m = df2['std_momentum_6m'].iloc[-1]
            std_momentum_12m = df2['std_momentum_12m'].iloc[-1]
        else:
            mean_momentum_3m = df3['mean_momentum_3m'].iloc[-1]
            mean_momentum_6m = df3['mean_momentum_6m'].iloc[-1]
            mean_momentum_12m = df3['mean_momentum_12m'].iloc[-1]

            std_momentum_3m = df3['std_momentum_3m'].iloc[-1]
            std_momentum_6m = df3['std_momentum_6m'].iloc[-1]
            std_momentum_12m = df3['std_momentum_12m'].iloc[-1]

        z_score_3m =  (momentum_ratio_3m - mean_momentum_3m) / std_momentum_3m
        z_score_6m =  (momentum_ratio_6m - mean_momentum_6m) / std_momentum_6m
        z_score_12m = (momentum_ratio_12m - mean_momentum_12m) / std_momentum_12m

        weighted_zscore = (weight_12m * z_score_12m) + (weight_6m * z_score_6m) + (weight_3m * z_score_3m)

        #normalized_score = ((1 + weighted_zscore) * (weighted_zscore >= 0)) + (((1 / (1 - weighted_zscore))**(-1)) * (weighted_zscore < 0))
        #normalized_scores[f'{chr(65 + n)}normalized_score'] = round(normalized_score, 4)

    return weighted_zscore

# Example usage
# Assuming data, df, df2, and df3 are already defined DataFrames
# periods = [0, 1, 2]  # Corresponding to A, B, and C respectively
# normalized_scores = get_normalized_scores(data, df, df2, df3, periods)
# print(normalized_scores)

def get_stock_csv_files(folder_path):
    return [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith(".csv")]

def calculate_lognormal_daily_returns(prices):
    """Calculates lognormal daily returns of a stock.

    Args:
        prices (pandas.Series): Time series of closing prices.

    Returns:
        pandas.Series: Time series of lognormal daily returns.
    """

    log_returns = np.log(prices)-np.log(prices.shift(1))   #np.log(prices.pct_change() + 1)
    return log_returns

def nifty_momentum_backtest(file_path,data,Company,df1,df2,df3,df4,df5,df6,df7,df8,df9,df10,df11,df12,base_name,FinalMicrocap250symbols):
    data["SMA_30MRP"] = tb.EMA(data['MRP'], timeperiod=12)
    data["SMA_90MRP"] = tb.EMA(data['MRP'], timeperiod=52)
    data["SMA_30close"] = tb.EMA(data['Close'], timeperiod=12)
    data["SMA_90close"] = tb.EMA(data['Close'], timeperiod=52)
    data["OBV"] = tb.OBV(data['Close'], data['Volume'])
    data["obvmovavg"] = tb.EMA(data["OBV"], timeperiod=12)
    #data.drop(columns=['Score'], inplace=True)
    if  (data['SMA_30MRP'].iloc[-1] > data['SMA_90MRP'].iloc[-1]*1.0 and  data['SMA_30close'].iloc[-1] > data['SMA_90close'].iloc[-1]*1.02) : # True:

        #A , B , C where A is Latest
        Alognormal_returns = calculate_lognormal_daily_returns(data['Close'][-52:])
        Blognormal_returns = calculate_lognormal_daily_returns(data['Close'][-53:-1])
        Clognormal_returns = calculate_lognormal_daily_returns(data['Close'][-54:-2])
        Dlognormal_returns = calculate_lognormal_daily_returns(data['Close'][-55:-3])
        Elognormal_returns = calculate_lognormal_daily_returns(data['Close'][-56:-4])
        Flognormal_returns = calculate_lognormal_daily_returns(data['Close'][-57:-5])
        Glognormal_returns = calculate_lognormal_daily_returns(data['Close'][-58:-6])
        Hlognormal_returns = calculate_lognormal_daily_returns(data['Close'][-59:-7])
        Ilognormal_returns = calculate_lognormal_daily_returns(data['Close'][-60:-8])
        Jlognormal_returns = calculate_lognormal_daily_returns(data['Close'][-61:-9])
        Klognormal_returns = calculate_lognormal_daily_returns(data['Close'][-62:-10])
        Llognormal_returns = calculate_lognormal_daily_returns(data['Close'][-63:-11])

        Aannualized_lognormal_std =   Alognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa) #Alognormal_returns.std(axis=0) * np.sqrt(52)
        Bannualized_lognormal_std =  Blognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Blognormal_returns.std(axis=0) * np.sqrt(52)
        Cannualized_lognormal_std =  Clognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Clognormal_returns.std(axis=0) * np.sqrt(52)
        Dannualized_lognormal_std =  Dlognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Dlognormal_returns.std(axis=0) * np.sqrt(52)
        Eannualized_lognormal_std =  Elognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Elognormal_returns.std(axis=0) * np.sqrt(52)
        Fannualized_lognormal_std = Flognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Flognormal_returns.std(axis=0) * np.sqrt(52)
        Gannualized_lognormal_std = Glognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Glognormal_returns.std(axis=0) * np.sqrt(52)
        Hannualized_lognormal_std =  Hlognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Hlognormal_returns.std(axis=0) * np.sqrt(52)
        Iannualized_lognormal_std =  Ilognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Ilognormal_returns.std(axis=0) * np.sqrt(52)
        Jannualized_lognormal_std =  Jlognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Jlognormal_returns.std(axis=0) * np.sqrt(52)
        Kannualized_lognormal_std =  Klognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Klognormal_returns.std(axis=0) * np.sqrt(52)
        Lannualized_lognormal_std =  Llognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)  #Llognormal_returns.std(axis=0) * np.sqrt(52)

        data['ROC_3m']=tb.ROC(data['Close'], timeperiod=12)
        data['ROC_6m']=tb.ROC(data['Close'], timeperiod=24)
        data['ROC_12m']=tb.ROC(data['Close'], timeperiod=52)

        Amomentum_ratio_12m = data['ROC_12m'].iloc[-1] / Aannualized_lognormal_std
        Amomentum_ratio_6m = data['ROC_6m'].iloc[-1]  / Aannualized_lognormal_std
        Amomentum_ratio_3m = data['ROC_3m'].iloc[-1]  / Aannualized_lognormal_std

        Bmomentum_ratio_12m = data['ROC_12m'].iloc[-2] / Bannualized_lognormal_std
        Bmomentum_ratio_6m = data['ROC_6m'].iloc[-2]  / Bannualized_lognormal_std
        Bmomentum_ratio_3m = data['ROC_3m'].iloc[-2]  / Bannualized_lognormal_std

        Cmomentum_ratio_12m = data['ROC_12m'].iloc[-3] / Cannualized_lognormal_std
        Cmomentum_ratio_6m = data['ROC_6m'].iloc[-3]  / Cannualized_lognormal_std
        Cmomentum_ratio_3m = data['ROC_3m'].iloc[-3]  / Cannualized_lognormal_std

        Dmomentum_ratio_12m = data['ROC_12m'].iloc[-4] / Dannualized_lognormal_std
        Dmomentum_ratio_6m = data['ROC_6m'].iloc[-4]  / Dannualized_lognormal_std
        Dmomentum_ratio_3m = data['ROC_3m'].iloc[-4]  / Dannualized_lognormal_std

        Emomentum_ratio_12m = data['ROC_12m'].iloc[-5] / Eannualized_lognormal_std
        Emomentum_ratio_6m = data['ROC_6m'].iloc[-5]  / Eannualized_lognormal_std
        Emomentum_ratio_3m = data['ROC_3m'].iloc[-5]  / Eannualized_lognormal_std

        Fmomentum_ratio_12m = data['ROC_12m'].iloc[-6] / Fannualized_lognormal_std
        Fmomentum_ratio_6m = data['ROC_6m'].iloc[-6]  / Fannualized_lognormal_std
        Fmomentum_ratio_3m = data['ROC_3m'].iloc[-6]  / Fannualized_lognormal_std

        Gmomentum_ratio_12m = data['ROC_12m'].iloc[-7] / Gannualized_lognormal_std
        Gmomentum_ratio_6m = data['ROC_6m'].iloc[-7]  / Gannualized_lognormal_std
        Gmomentum_ratio_3m = data['ROC_3m'].iloc[-7]  / Gannualized_lognormal_std

        Hmomentum_ratio_12m = data['ROC_12m'].iloc[-8] / Hannualized_lognormal_std
        Hmomentum_ratio_6m = data['ROC_6m'].iloc[-8]  / Hannualized_lognormal_std
        Hmomentum_ratio_3m = data['ROC_3m'].iloc[-8]  / Hannualized_lognormal_std

        Imomentum_ratio_12m = data['ROC_12m'].iloc[-9] / Iannualized_lognormal_std
        Imomentum_ratio_6m = data['ROC_6m'].iloc[-9]  / Iannualized_lognormal_std
        Imomentum_ratio_3m = data['ROC_3m'].iloc[-9]  / Iannualized_lognormal_std

        Jmomentum_ratio_12m = data['ROC_12m'].iloc[-10] / Jannualized_lognormal_std
        Jmomentum_ratio_6m = data['ROC_6m'].iloc[-10]  / Jannualized_lognormal_std
        Jmomentum_ratio_3m = data['ROC_3m'].iloc[-10]  / Jannualized_lognormal_std

        Kmomentum_ratio_12m = data['ROC_12m'].iloc[-11] / Kannualized_lognormal_std
        Kmomentum_ratio_6m = data['ROC_6m'].iloc[-11]  / Kannualized_lognormal_std
        Kmomentum_ratio_3m = data['ROC_3m'].iloc[-11]  / Kannualized_lognormal_std

        Lmomentum_ratio_12m = data['ROC_12m'].iloc[-12] / Lannualized_lognormal_std
        Lmomentum_ratio_6m = data['ROC_6m'].iloc[-12]  / Lannualized_lognormal_std
        Lmomentum_ratio_3m = data['ROC_3m'].iloc[-12]  / Lannualized_lognormal_std

        # Calculate Z-scores
        Az_score_3m =  (Amomentum_ratio_3m -df1['mean_momentum_3m'].iloc[-1]) / df1['std_momentum_3m'].iloc[-1]
        Az_score_6m =  (Amomentum_ratio_6m -df1['mean_momentum_6m'].iloc[-1]) / df1['std_momentum_6m'].iloc[-1]
        Az_score_12m = (Amomentum_ratio_12m -df1['mean_momentum_12m'].iloc[-1])/ df1['std_momentum_12m'].iloc[-1]

        Bz_score_3m =  (Bmomentum_ratio_3m -df2['mean_momentum_3m'].iloc[-1]) / df2['std_momentum_3m'].iloc[-1]
        Bz_score_6m =  (Bmomentum_ratio_6m -df2['mean_momentum_6m'].iloc[-1]) / df2['std_momentum_6m'].iloc[-1]
        Bz_score_12m = (Bmomentum_ratio_12m -df2['mean_momentum_12m'].iloc[-1])/ df2['std_momentum_12m'].iloc[-1]

        Cz_score_3m =  (Cmomentum_ratio_3m -df3['mean_momentum_3m'].iloc[-1]) / df3['std_momentum_3m'].iloc[-1]
        Cz_score_6m =  (Cmomentum_ratio_6m -df3['mean_momentum_6m'].iloc[-1]) / df3['std_momentum_6m'].iloc[-1]
        Cz_score_12m = (Cmomentum_ratio_12m -df3['mean_momentum_12m'].iloc[-1])/ df3['std_momentum_12m'].iloc[-1]

        Dz_score_3m =  (Dmomentum_ratio_3m -df4['mean_momentum_3m'].iloc[-1]) / df4['std_momentum_3m'].iloc[-1]
        Dz_score_6m =  (Dmomentum_ratio_6m -df4['mean_momentum_6m'].iloc[-1]) / df4['std_momentum_6m'].iloc[-1]
        Dz_score_12m = (Dmomentum_ratio_12m -df4['mean_momentum_12m'].iloc[-1])/ df4['std_momentum_12m'].iloc[-1]

        Ez_score_3m =  (Emomentum_ratio_3m -df5['mean_momentum_3m'].iloc[-1]) / df5['std_momentum_3m'].iloc[-1]
        Ez_score_6m =  (Emomentum_ratio_6m -df5['mean_momentum_6m'].iloc[-1]) / df5['std_momentum_6m'].iloc[-1]
        Ez_score_12m = (Emomentum_ratio_12m -df5['mean_momentum_12m'].iloc[-1])/ df5['std_momentum_12m'].iloc[-1]

        Fz_score_3m =  (Fmomentum_ratio_3m -df6['mean_momentum_3m'].iloc[-1]) / df6['std_momentum_3m'].iloc[-1]
        Fz_score_6m =  (Fmomentum_ratio_6m -df6['mean_momentum_6m'].iloc[-1]) / df6['std_momentum_6m'].iloc[-1]
        Fz_score_12m = (Fmomentum_ratio_12m -df6['mean_momentum_12m'].iloc[-1])/ df6['std_momentum_12m'].iloc[-1]

        Gz_score_3m =  (Gmomentum_ratio_3m -df7['mean_momentum_3m'].iloc[-1]) / df7['std_momentum_3m'].iloc[-1]
        Gz_score_6m =  (Gmomentum_ratio_6m -df7['mean_momentum_6m'].iloc[-1]) / df7['std_momentum_6m'].iloc[-1]
        Gz_score_12m = (Gmomentum_ratio_12m -df7['mean_momentum_12m'].iloc[-1])/ df7['std_momentum_12m'].iloc[-1]

        Hz_score_3m =  (Hmomentum_ratio_3m -df8['mean_momentum_3m'].iloc[-1]) / df8['std_momentum_3m'].iloc[-1]
        Hz_score_6m =  (Hmomentum_ratio_6m -df8['mean_momentum_6m'].iloc[-1]) / df8['std_momentum_6m'].iloc[-1]
        Hz_score_12m = (Hmomentum_ratio_12m -df8['mean_momentum_12m'].iloc[-1])/ df8['std_momentum_12m'].iloc[-1]

        Iz_score_3m =  (Imomentum_ratio_3m -df9['mean_momentum_3m'].iloc[-1]) / df9['std_momentum_3m'].iloc[-1]
        Iz_score_6m =  (Imomentum_ratio_6m -df9['mean_momentum_6m'].iloc[-1]) / df9['std_momentum_6m'].iloc[-1]
        Iz_score_12m = (Imomentum_ratio_12m -df9['mean_momentum_12m'].iloc[-1])/ df9['std_momentum_12m'].iloc[-1]

        Jz_score_3m =  (Jmomentum_ratio_3m -df10['mean_momentum_3m'].iloc[-1]) / df10['std_momentum_3m'].iloc[-1]
        Jz_score_6m =  (Jmomentum_ratio_6m -df10['mean_momentum_6m'].iloc[-1]) / df10['std_momentum_6m'].iloc[-1]
        Jz_score_12m = (Jmomentum_ratio_12m -df10['mean_momentum_12m'].iloc[-1])/ df10['std_momentum_12m'].iloc[-1]

        Kz_score_3m =  (Kmomentum_ratio_3m -df11['mean_momentum_3m'].iloc[-1]) / df11['std_momentum_3m'].iloc[-1]
        Kz_score_6m =  (Kmomentum_ratio_6m -df11['mean_momentum_6m'].iloc[-1]) / df11['std_momentum_6m'].iloc[-1]
        Kz_score_12m = (Kmomentum_ratio_12m -df11['mean_momentum_12m'].iloc[-1])/ df11['std_momentum_12m'].iloc[-1]

        Lz_score_3m =  (Lmomentum_ratio_3m -df12['mean_momentum_3m'].iloc[-1]) / df12['std_momentum_3m'].iloc[-1]
        Lz_score_6m =  (Lmomentum_ratio_6m -df12['mean_momentum_6m'].iloc[-1]) / df12['std_momentum_6m'].iloc[-1]
        Lz_score_12m = (Lmomentum_ratio_12m -df12['mean_momentum_12m'].iloc[-1])/ df12['std_momentum_12m'].iloc[-1]


        # Calculate weighted average Z-score
        Aweighted_zscore = 0.45 * Az_score_12m + 0.45 * Az_score_6m + 0.1 * Az_score_3m
        Bweighted_zscore = 0.45 * Bz_score_12m + 0.45 * Bz_score_6m + 0.1 * Bz_score_3m
        Cweighted_zscore = 0.45 * Cz_score_12m + 0.45 * Cz_score_6m + 0.1 * Cz_score_3m
        Dweighted_zscore = 0.45 * Dz_score_12m + 0.45 * Dz_score_6m + 0.1 * Dz_score_3m
        Eweighted_zscore = 0.45 * Ez_score_12m + 0.45 * Ez_score_6m + 0.1 * Ez_score_3m
        Fweighted_zscore = 0.45 * Fz_score_12m + 0.45 * Fz_score_6m + 0.1 * Fz_score_3m
        Gweighted_zscore = 0.45 * Gz_score_12m + 0.45 * Gz_score_6m + 0.1 * Gz_score_3m
        Hweighted_zscore = 0.45 * Hz_score_12m + 0.45 * Hz_score_6m + 0.1 * Hz_score_3m
        Iweighted_zscore = 0.45 * Iz_score_12m + 0.45 * Iz_score_6m + 0.1 * Iz_score_3m
        Jweighted_zscore = 0.45 * Jz_score_12m + 0.45 * Jz_score_6m + 0.1 * Jz_score_3m
        Kweighted_zscore = 0.45 * Kz_score_12m + 0.45 * Kz_score_6m + 0.1 * Kz_score_3m
        Lweighted_zscore = 0.45 * Lz_score_12m + 0.45 * Lz_score_6m + 0.1 * Lz_score_3m




        # Calculate normalized momentum score
        Anormalized_score = (1 + Aweighted_zscore) * (Aweighted_zscore >= 0) + (1 / (1 - Aweighted_zscore))**(-1) * (Aweighted_zscore < 0)
        Bnormalized_score = (1 + Bweighted_zscore) * (Bweighted_zscore >= 0) + (1 / (1 - Bweighted_zscore))**(-1) * (Bweighted_zscore < 0)
        Cnormalized_score = (1 + Cweighted_zscore) * (Cweighted_zscore >= 0) + (1 / (1 - Cweighted_zscore))**(-1) * (Cweighted_zscore < 0)
        Dnormalized_score = (1 + Dweighted_zscore) * (Dweighted_zscore >= 0) + (1 / (1 - Dweighted_zscore))**(-1) * (Dweighted_zscore < 0)
        Enormalized_score = (1 + Eweighted_zscore) * (Eweighted_zscore >= 0) + (1 / (1 - Eweighted_zscore))**(-1) * (Eweighted_zscore < 0)
        Fnormalized_score = (1 + Fweighted_zscore) * (Fweighted_zscore >= 0) + (1 / (1 - Fweighted_zscore))**(-1) * (Fweighted_zscore < 0)
        Gnormalized_score = (1 + Gweighted_zscore) * (Gweighted_zscore >= 0) + (1 / (1 - Gweighted_zscore))**(-1) * (Gweighted_zscore < 0)
        Hnormalized_score = (1 + Hweighted_zscore) * (Hweighted_zscore >= 0) + (1 / (1 - Hweighted_zscore))**(-1) * (Hweighted_zscore < 0)
        Inormalized_score = (1 + Iweighted_zscore) * (Iweighted_zscore >= 0) + (1 / (1 - Iweighted_zscore))**(-1) * (Iweighted_zscore < 0)
        Jnormalized_score = (1 + Jweighted_zscore) * (Jweighted_zscore >= 0) + (1 / (1 - Jweighted_zscore))**(-1) * (Jweighted_zscore < 0)
        Knormalized_score = (1 + Kweighted_zscore) * (Kweighted_zscore >= 0) + (1 / (1 - Kweighted_zscore))**(-1) * (Kweighted_zscore < 0)
        Lnormalized_score = (1 + Lweighted_zscore) * (Lweighted_zscore >= 0) + (1 / (1 - Lweighted_zscore))**(-1) * (Lweighted_zscore < 0)

        Anormalized_score =round(Aweighted_zscore,4)
        Bnormalized_score =round(Bweighted_zscore,4)
        Cnormalized_score =round(Cweighted_zscore,4)
        Dnormalized_score =round(Dweighted_zscore,4)
        Enormalized_score =round(Eweighted_zscore,4)
        Fnormalized_score =round(Fweighted_zscore,4)
        Gnormalized_score =round(Gweighted_zscore,4)
        Hnormalized_score =round(Hweighted_zscore,4)
        Inormalized_score =round(Iweighted_zscore,4)
        Jnormalized_score =round(Jweighted_zscore,4)
        Knormalized_score =round(Kweighted_zscore,4)
        Lnormalized_score =round(Lweighted_zscore,4)

        #print(Company)
        #print(Anormalized_score,Bnormalized_score,Cnormalized_score,Dnormalized_score,Enormalized_score,Fnormalized_score,Gnormalized_score,Hnormalized_score,Inormalized_score,Jnormalized_score,Knormalized_score,Lnormalized_score)


        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                "Company": Company,
                "NSE750": NSE570s,
                "Score": Anormalized_score,
                }

        rankedTop30.append(ranked_data1)


        #last_row_index = data.index[-10:]
        Alast_row_index = data.index[-1]
        Blast_row_index = data.index[-2]
        Clast_row_index = data.index[-3]
        Dlast_row_index = data.index[-4]
        Elast_row_index = data.index[-5]
        Flast_row_index = data.index[-6]
        Glast_row_index = data.index[-7]
        Hlast_row_index = data.index[-8]
        Ilast_row_index = data.index[-9]
        Jlast_row_index = data.index[-10]
        Klast_row_index = data.index[-11]
        Llast_row_index = data.index[-12]
        RESTlast_row_index = data.index[:-12]
        RESTnormalized_score= round(1.00,4)

        data.loc[Alast_row_index, 'Score'] = Anormalized_score
        data.loc[Blast_row_index, 'Score'] = Bnormalized_score
        data.loc[Clast_row_index, 'Score'] = Cnormalized_score
        data.loc[Dlast_row_index, 'Score'] = Dnormalized_score
        data.loc[Elast_row_index, 'Score'] = Enormalized_score
        data.loc[Flast_row_index, 'Score'] = Fnormalized_score
        data.loc[Glast_row_index, 'Score'] = Gnormalized_score
        data.loc[Hlast_row_index, 'Score'] = Hnormalized_score
        data.loc[Ilast_row_index, 'Score'] = Inormalized_score
        data.loc[Jlast_row_index, 'Score'] = Jnormalized_score
        data.loc[Klast_row_index, 'Score'] =  Knormalized_score
        data.loc[Llast_row_index, 'Score'] = Lnormalized_score
        data.loc[RESTlast_row_index, 'Score'] = RESTnormalized_score


        data.drop(columns=['ROC_3m','ROC_6m','ROC_12m','SMA_30MRP','SMA_90MRP', 'SMA_30close', 'SMA_90close','OBV','obvmovavg'], inplace=True)
        data.to_csv(file_path, index=False)
        #print(data)
    else:
        Znormalized_score = round(0.001,4)
        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                "Company": Company,
                "NSE750": NSE570s,
                "Score": Znormalized_score,
                }
        rankedTop30.append(ranked_data1)

        zlast_row_index = data.index[:]
        data.loc[zlast_row_index, 'Score'] = Znormalized_score
        data.drop(columns=['SMA_30MRP','SMA_90MRP', 'SMA_30close', 'SMA_90close','OBV','obvmovavg'], inplace=True)
        data.to_csv(file_path, index=False)
        1+1


def nifty_momentum(file_path,data,Company,df1,base_name,FinalMicrocap250symbols):
    data["SMA_30MRP"] = tb.EMA(data['MRP'], timeperiod=12)
    data["SMA_90MRP"] = tb.EMA(data['MRP'], timeperiod=52)
    data["SMA_30close"] = tb.EMA(data['Close'], timeperiod=12)
    data["SMA_90close"] = tb.EMA(data['Close'], timeperiod=52)
    data["SMA_52Score"] = tb.EMA(data['Score'], timeperiod=24)
    data["OBV"] = tb.OBV(data['Close'], data['Volume'])
    data["obvmovavg"] = tb.EMA(data["OBV"], timeperiod=12)
    #data.drop(columns=['Score'], inplace=True)
    if  (data['SMA_30MRP'].iloc[-1] > data['SMA_90MRP'].iloc[-1]*1.0 and  data['SMA_30close'].iloc[-1] > data['SMA_90close'].iloc[-1]*1.0 and data["SMA_52Score"].iloc[-1] < data['Score'].iloc[-1] ) : # True:

        normalized_score=data['Score'].iloc[-1]
        normalized_score =round(normalized_score,4)

        #print(Company)
        #print(Anormalized_score,Bnormalized_score,Cnormalized_score,Dnormalized_score,Enormalized_score,Fnormalized_score,Gnormalized_score,Hnormalized_score,Inormalized_score,Jnormalized_score,Knormalized_score,Lnormalized_score)


        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                "Company": Company,
                "NSE750": NSE570s,
                "Score": normalized_score,
                }

        rankedTop30.append(ranked_data1)



        ##data.drop(columns=['ROC_3m','ROC_6m','ROC_12m','SMA_30MRP','SMA_90MRP', 'SMA_30close', 'SMA_90close','OBV','obvmovavg'], inplace=True)
        ##data.to_csv(file_path, index=False)
        #print(data)
    else:
        Znormalized_score = round(0.0001,4)
        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                "Company": Company,
                "NSE750": NSE570s,
                "Score": Znormalized_score,
                }
        rankedTop30.append(ranked_data1)
        1+1


def calculate_momentum_stats(folder_path,symbols,columns=0):
    all_stats = []
    #print(folder_path)
    for file_name in os.listdir(folder_path):
        #print(file_name)

        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            base_name = os.path.splitext(file_name)[0]
            #print(base_name)

            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                data1 = pd.read_csv(file_path)
                #print(columns)
                if columns ==0:
                    #data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    #print(bottom)
                    data1=data1[:]

                elif columns ==-1:
                    #data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-1]

                elif columns ==-2:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-2]

                elif columns ==-3:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-3]
                elif columns ==-4:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-4]
                elif columns ==-5:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-5]
                elif columns ==-6:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-6]
                elif columns ==-7:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-7]
                elif columns ==-8:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-8]
                elif columns ==-9:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-9]
                elif columns ==-10:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-10]
                elif columns ==-11:
                    data1 = pd.read_csv(file_path)
                    bottom= -52+columns
                    data1=data1[:-11]



                data1['ROC_3m']=tb.ROC(data1['Close'], timeperiod=12)
                data1['ROC_6m']=tb.ROC(data1['Close'], timeperiod=24)
                data1['ROC_12m']=tb.ROC(data1['Close'], timeperiod=52)
                #lendata1= len(data1)
                #print(lendata1)
                #print(data1)

                lognormal_returns = calculate_lognormal_daily_returns(data1['Close'][-52:])
                annualized_lognormal_std = lognormal_returns.std(axis=0) * np.sqrt(52)

                # Calculate momentum ratios (using ROC instead of TA-Lib for clarity)
                momentum_ratio_3m = data1['ROC_3m'].iloc[-1] / annualized_lognormal_std
                momentum_ratio_6m = data1['ROC_6m'].iloc[-1] / annualized_lognormal_std
                momentum_ratio_12m = data1['ROC_12m'].iloc[-1] / annualized_lognormal_std


                momentumratios ={
                    'Company': base_name,
                    'momentum_3m': momentum_ratio_3m,
                    'momentum_6m': momentum_ratio_6m,
                    'momentum_12m': momentum_ratio_12m,
                    }
                file_stats = {
                    'Company': base_name,
                    'momentum_3m': momentum_ratio_3m,
                    'momentum_6m': momentum_ratio_6m,
                    'momentum_12m': momentum_ratio_12m,
                }

                all_stats.append(file_stats)
            else:
                1+1
                #print("No base name")
        else:
            1+1
            #print("No file name")
    if 1==1:
        df = pd.DataFrame(all_stats)  # Create DataFrame from stats list
        #print(df)
        number= len(df['momentum_6m'])
        df['mean_momentum_3m'] = sum(df['momentum_3m'])/len(df['momentum_3m'])
        df['mean_momentum_6m'] = sum(df['momentum_6m'])/len(df['momentum_6m'])
        df['mean_momentum_12m'] = sum(df['momentum_12m'])/len(df['momentum_12m'])
        df['std_momentum_3m'] = tb.STDDEV(df['momentum_3m'], timeperiod=number, nbdev=1)
        df['std_momentum_6m'] = tb.STDDEV(df['momentum_6m'], timeperiod=number, nbdev=1) # Vectorized std calculation for 6m  df['momentum_6m'].pow(2).mean(axis=1)
        df['std_momentum_12m'] = tb.STDDEV(df['momentum_12m'], timeperiod=number, nbdev=1)  #df['momentum_12m'].pow(2).mean(axis=1)  # Vectorized std calculation for 12m

    else:
        df = pd.DataFrame(columns=['Company','mean_momentum_3m', 'mean_momentum_6m', 'mean_momentum_12m','std_momentum_3m','std_momentum_6m','std_momentum_12m'])
    #print(df)
    return df

universemomentum_stats= calculate_momentum_stats(folder_path,symbols,columns=0)
#universemomentum_stats1= calculate_momentum_stats(folder_path,symbols,columns=-1)
#universemomentum_stats2= calculate_momentum_stats(folder_path,symbols,columns=-2)
#universemomentum_stat3= calculate_momentum_stats(folder_path,symbols,columns=-3)
#universemomentum_stat4= calculate_momentum_stats(folder_path,symbols,columns=-4)
#universemomentum_stat5= calculate_momentum_stats(folder_path,symbols,columns=-5)
#universemomentum_stat6= calculate_momentum_stats(folder_path,symbols,columns=-6)
#universemomentum_stat7= calculate_momentum_stats(folder_path,symbols,columns=-7)
#universemomentum_stat8= calculate_momentum_stats(folder_path,symbols,columns=-8)
#universemomentum_stat9= calculate_momentum_stats(folder_path,symbols,columns=-9)
#universemomentum_stat10= calculate_momentum_stats(folder_path,symbols,columns=-10)
#universemomentum_stat11= calculate_momentum_stats(folder_path,symbols,columns=-11)


for file_name in os.listdir(folder_path):

    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            base_name = os.path.splitext(file_name)[0]

            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                # Read the CSV file into a DataFrame
                data = pd.read_csv(file_path)
                if len(data) >= 52:
                    Company=symbol_to_company.get(base_name, base_name)
                    nifty_momentum(file_path,data,Company,universemomentum_stats,base_name,FinalMicrocap250symbols)
                    ##nifty_momentum_backtest(file_path,data,Company,universemomentum_stats,universemomentum_stats1,universemomentum_stats2,universemomentum_stat3,universemomentum_stat4,universemomentum_stat5,universemomentum_stat6,universemomentum_stat7,universemomentum_stat8,universemomentum_stat9,universemomentum_stat10,universemomentum_stat11,base_name,FinalMicrocap250symbols)
                else:
                    1+1    #universemomentum_stat3,universemomentum_stat3,universemomentum_stat3,universemomentum_stat3,

            else:
                1+1
        else:
            print("No data found to write to momNSE750")
    except Exception as e:
        print(f"Error in  momNSE750- {e}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass

print("__________________________________________________________")

try:
    rankedTop30.sort(key=lambda row: row["Score"], reverse=True)
except Exception as e:
    print(f"Error in  MedianBTmomNSE750- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

rankedTop30 = pd.DataFrame(rankedTop30)
rankedTop30.sort_values(by='Score', ascending=False)
rankedTop30 = rankedTop30.drop_duplicates(subset=['Company'])

print(rankedTop30)



valid_tickers = pd.read_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv')
rankedTop30 = pd.merge(rankedTop30, valid_tickers, left_on='Company', right_on='Company', how='left')
#rankedTop30.drop(columns=['Symbol'], inplace=True)
desired_order = ['Symbol','Company', 'Industry', 'NSE750','Score']
rankedTop30 = rankedTop30[desired_order]
#print(rankedTop30)


rankedTop30.to_csv('/home/rizpython236/BT5/trade-logs/BTmomNSE750.csv', index=False)
time.sleep(5)
input_csv_file = '/home/rizpython236/BT5/trade-logs/BTmomNSE750.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/trade-logs/BTmomNSE750.pdf'  # Replace with desired output PDF file
time.sleep(5)
create_pdf(input_csv_file, output_pdf_file ,pageA4= True)
time.sleep(5)
post_telegram_file(output_pdf_file)


print('Done BTmomNSE750 1st part')


try:
    #valid_tickers = pd.read_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv')
    #valid_tickers.sort_values('Symbol', inplace=True)
    #rankedTop30.sort_values('Company', inplace=True)
    #valid_tickers = valid_tickers[['Symbol', 'Company', 'Industry']]

    # Perform VLOOKUP and merge using the correct join type (left join in this case)
    #rankedTop30 = pd.merge(rankedTop30, valid_tickers, left_on='Company', right_on='Company', how='left')
    #rankedTop30.drop(columns=['Symbol'], inplace=True)
    #desired_order = ['Company', 'Industry', 'NSE750','Score']
    #rankedTop30 = rankedTop30[desired_order]

    industry_scores = rankedTop30[:].groupby('Industry')['Score'].sum().reset_index()
    industry_scores['Count'] = rankedTop30[:].groupby('Industry')['Company'].count().reset_index()['Company']
    industry_scores = industry_scores[industry_scores['Count'] >= 1]
    industry_scores['Avg'] = round(industry_scores['Score'] / industry_scores['Count'],3)

    median_scores = rankedTop30.groupby('Industry')['Score'].median().reset_index()  # Calculate medians
    median_scores['Median'] = rankedTop30[:].groupby('Industry')['Score'].median().reset_index()['Score']
    median_scores['Median']=round(median_scores['Median'],3)
    median_scores.drop(columns=['Score'], inplace=True)
    #print(median_scores)
    industry_scores = industry_scores.merge(median_scores[['Industry', 'Median']], how='left', on='Industry')  # Merge DataFrames
    industry_scores.rename(columns={'Score': 'Sum_Score'}, inplace=True)
    industry_scores['Sum_Score'] =round(industry_scores['Sum_Score'],3)
    #industry_scoresM.rename(columns={'Score': 'Median'}, inplace=True)  # Rename column (optional)
    # Sort by sum of score (descending)
    industry_scores = industry_scores.sort_values(by='Median', ascending=False)

    industry_scores.to_csv('/home/rizpython236/BT5/trade-logs/MedianBTmomNSE750.csv', index=False)
    time.sleep(5)
    input_csv_file = '/home/rizpython236/BT5/trade-logs/MedianBTmomNSE750.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/trade-logs/MedianBTmomNSE750.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= True)
    time.sleep(5)
    post_telegram_file(output_pdf_file)
except Exception as e:
    print(f"Error in  MedianBTmomNSE750- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print('Done BTmomNSE750 Final part')



