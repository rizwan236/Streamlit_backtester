

import time
import traceback

import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from telegram_bot import post_telegram_message


print("NSE SME_ticker_download")


# /html/body/div[11]/div/section/div/div/div/div/div/div/div[1]/div[2]/div/div/table/tbody
#  /html/body/div[11]/div/section/div/div/div/div/div/div/div[1]/div[2]/div/div/table/tbody


# /html/body/div[11]/div/section/div/div/div/div/div/div/div[1]/div[2]/div/div/table

# body > div.main.static_content > div > section > div > div > div > div > div > div > div:nth-child(1) > div.col-md-12.midContainer.staticConetnt > div > div > table

def download_equity_csv():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")

    chrome_options.add_argument(
        "--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option(
        "excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option("useAutomationExtension", False)
    chrome_options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36")
    chrome_options.add_experimental_option("prefs", {
        # "download.default_directory": download_dir,
        "download.prompt_for_download": False,
        "download.directory_upgrade": True,
        "safebrowsing.enabled": True,
    })

    attempt = 0
    max_attempts = 2
    success = False

    while attempt < max_attempts and not success:
        try:

            # Step 1: Initialize browser and navigate to the URL
            browser = webdriver.Chrome(options=chrome_options)

            browser.get("https://www.nseindia.com")
            time.sleep(15)

            # WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.TAG_NAME, "body")))

            url = "https://www.nseindia.com/companies-listing/raising-capital-public-issues-emerge-selecting-a-migration-to-main-board"

            browser.execute_cdp_cmd("Network.setExtraHTTPHeaders", {
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
                },
            })
            browser.get(url)
            # print(browser.page_source)

            time.sleep(10)

            # Step 2: Wait until the dropdown is present and select "Equity T+1"
            wait = WebDriverWait(browser, 30)
            # text=wait.find_element(By.XPATH,get_xpath(driver,'7SqcnWPGomxhUBf')).text
            # driver.get('https://www.nseindia.com/companies-listing/raising-capital-public-issues-emerge-selecting-a-migration-to-main-board')

            # to fetch the text of element
            # text=browser.find_element(By.XPATH,get_xpath(browser,'7SqcnWPGomxhUBf')).text
            # Wait for the table to be present
            table_xpath = "/html/body/div[11]/div/section/div/div/div/div/div/div/div[1]/div[2]/div/div/table/tbody"
            # table = WebDriverWait(browser, 20).until(EC.presence_of_element_located((By.XPATH, table_xpath)))
            css_selector = "body > div.main.static_content > div > section > div > div > div > div > div > div > div:nth-child(1) > div.col-md-12.midContainer.staticConetnt > div > div > table"
            table = WebDriverWait(browser, 30).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, css_selector)))

            # Wait for container first
            # WebDriverWait(browser, 30).until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.midContainer")))
            # Instead of hardcoded CSS, use XPath for any table present in the section
            # table = WebDriverWait(browser, 30).until(EC.presence_of_element_located((By.XPATH, "//table[contains(@class, 'table')]")))

            # table = wait.until(lambda d: d.find_element(By.XPATH, table_xpath))
            # print(table)

            # Get the table HTML
            table_html = table.get_attribute("outerHTML")

            # Read the HTML table into a pandas DataFrame
            new_df = pd.read_html(table_html)[0]

            print(new_df)

            # Save the DataFrame to CSV
            download_dir = "/home/rizpython236/BT5"
            csv_filename = f"{download_dir}/NSE_SME_data.csv"

            old_df = pd.read_csv(csv_filename)
            # new_df.to_csv(csv_filename, index=False)
            # print("CSV file saved successfully.")

            success = True

            # Find new rows not in old_df
            merged_df = new_df.merge(
                old_df.drop_duplicates(), how="left", indicator=True)
            new_rows = merged_df[merged_df["_merge"] == "left_only"].drop(columns=[
                                                                          "_merge"])
            print(merged_df)
            if not new_rows.empty:
                new_rows = new_rows.drop("Symbol", axis=1)
                print("🆕 Newly added rows since last run:")
                print(new_rows.to_string(index=False))
                # message = new_rows.to_string(index=False)
                newadd = new_rows.to_string(index=False)
                post_telegram_message(newadd)
            else:
                print("No new rows found.")
                post_telegram_message(" No new NSE SME data")

            # Step 6: Save the latest data
            new_df.to_csv(csv_filename, index=False)
            print(f"CSV file saved successfully at {csv_filename}")

        except Exception as e:
            attempt += 1
            print(f"Attempt {attempt} failed with error: {e!s}")
            print(f"⚠️Error occurred: {e!s}")
            traceback_str = traceback.format_exc()
            print(traceback_str)
            # post_telegram_message("Download from bse_ticker_download failed!...")

            if attempt == max_attempts:
                print("Max attempts reached. Failed to download data.")
        finally:
            browser.quit()


# Call the function
download_equity_csv()
