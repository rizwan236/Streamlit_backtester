from collections import defaultdict
import os


print('Start')

# Define the root folder and excluded folders
root_folder = '/home'
root_folder = '/home/rizpython236/BT5/'
excluded_folders = {'/home/rizpython236/.local', '/home/rizpython236/.virtualenvs'}
excluded_folders = {}

# Function to get file size in MB
def get_file_size_mb(file_path):
    return os.path.getsize(file_path) / 1048576  # Convert bytes to MB

# Dictionary to store files grouped by their parent folder
folder_files = defaultdict(list)

# Walk through the root folder
for dirpath, dirnames, filenames in os.walk(root_folder):
    # Skip excluded folders and their subfolders
    if any(dirpath.startswith(excluded) for excluded in excluded_folders):
        continue

    # Add files and their sizes to the dictionary, grouped by parent folder
    for filename in filenames:
        file_path = os.path.join(dirpath, filename)
        try:
            file_size_mb = get_file_size_mb(file_path)
            # Only include files larger than 1 MB
            if file_size_mb > 1:
                folder_files[dirpath].append((filename, file_size_mb))
        except (FileNotFoundError, PermissionError):
            # Skip files that cannot be accessed
            continue

# Sort files within each folder by size (higher to lower)
for folder, files in folder_files.items():
    files.sort(key=lambda x: x[1], reverse=True)

# Print the results
for folder, files in folder_files.items():
    print(f"\nFolder: {folder}")
    for filename, file_size_mb in files:
        print(f"  File: {filename}, Size: {file_size_mb:.2f} MB")