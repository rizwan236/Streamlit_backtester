import csv
from datetime import date, datetime, timedelta
import multiprocessing
import os
import subprocess
import sys
import time
import traceback
import uuid
import warnings

import matplotlib
import numpy as np  # numpy-1.26.4   1.21.6   2.0.2
import pandas as pd  # pandas-1.5.3  1.3.5   2.2.3
import pandas_ta as ta
import pytz
import talib as tb
import yfinance as yf

from add_company_name import (
    add_company_names_and_industry,
    copyfile1,
    update_output_file,
    vlookup_and_merge,
)
from cleanup import (
    clean_memory,
    cleanup_files,
    delete_all_files_and_folders,
    delete_large_files,
    remove_ticker_data_csv_files,
)
from custum_index import addchartspdf
from mail_utils import trigger_generic_email
from PDFconvert import create_pdf
from settings import (
    BT_SCREENER_CSV,
    EMPTY_BT_SCREENER_MSG,
    MAX_RETRIES,
    NIFTY_WEEKLY_AVG_STATS_IMAGE,
    NO_NEW_SIGNALS_FOUND_MSG,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    TALIB_SCREENER_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
    TRADEBOOK_CSV,
)
from symbol_copy import (
    import_user_module,
    manage_user_variables,
    manage_zip,
    update_exclude_list,
)
from telegram_bot import (
    post_telegram_file,
    post_telegram_message,
    shutdown_bot,
    trigger_telegram_notifications,
)


print(f"Yfinance version: {yf.__version__} ")


"""
import yfinance as yf
import talib

# Get data
df = yf.download("ESILVER.NS", period="1y")

# Most reliable method
# 1. Get the values
close_data = df['Close'].values
# 2. Ensure it's a numpy array
close_array = np.asarray(close_data, dtype=np.float64)
# 3. Ensure it's 1D
close_array = np.ravel(close_array)

# Calculate HT_TRENDMODE
df['HT'] = talib.HT_TRENDMODE(close_array)

# Print
#print(df[['Close', 'HT']].tail(20))
print(df[['Close', 'HT']].to_string())
ll



base_dir_module = "/home/rizpython236/BT5"
folder_path = "/home/rizpython236/BT5/ticker_15yr"

try:
    #import tradebookanalysis
    import_user_module(base_dir_module, "tradebookanalysis")
except Exception as e:
    print(f"⚠️ tradebookanalysis error: {e}")
    # post_telegram_message("signal_changed_messages error")

time.sleep(3)
filepathBTpdf = "/home/rizpython236/BT5/screener-outputs/OpentradebookCharts.pdf"
screenercsvBT_path = "/home/rizpython236/BT5/trade-logs/Opentradebook.csv"
#addchartspdf(screenercsv_path=screenercsvBT_path,
#             folder_path=folder_path, filepathpdf=filepathBTpdf)

kkk
"""


base_dir_module = "/home/rizpython236/BT5"

num_cores = multiprocessing.cpu_count()
# Limit threads to max 3
# Choose threads: default 2, max 3, but not more than available cores
threads = min(1, min(3, num_cores))
threads = 1

# pandas-ta==0.3.14b #https://dashboard.stablebuild.com/pypi-deleted-packages/pkg/pandas-ta/0.3.14b

os.environ["OPENBLAS_NUM_THREADS"] = str(threads)  # '2'
os.environ["MKL_NUM_THREADS"] = str(threads)
os.environ["NUMEXPR_NUM_THREADS"] = str(threads)
os.environ["OMP_NUM_THREADS"] = str(threads)

print(
    f"Using {threads} threads for numerical libraries, available cores {num_cores}")


def ensure_llvmlite_numba_by_file():
    """Checks if libllvmlite.so exists in the Pybroker39zz virtual environment.
    If not, installs specific versions of llvmlite and numba.
    """
    lib_file = "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/llvmlite/binding/libllvmlite.so"

    if os.path.isfile(lib_file):
        print(f"{lib_file} exists. Skipping installation.")
    else:
        print(f"{lib_file} not found. Installing llvmlite and numba...")
        packages = [
            "llvmlite==0.45.0",
            "numba==0.62.0",
        ]
        cmd = [sys.executable, "-m", "pip", "install",
               "--no-cache-dir", "--force-reinstall"] + packages
        try:
            subprocess.check_call(cmd)
            print("Successfully installed llvmlite and numba.")
        except subprocess.CalledProcessError as e:
            print(f"Error installing packages: {e}")

# ensure_llvmlite_numba_by_file()


# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")

file_path = "/home/rizpython236/BT5/screener-outputs/Tickerdata.zip"
if os.path.exists(file_path):
    1 + 1
    # os.remove(file_path)
# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
# sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages')


print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")
# import pandas as pd
# pd.options.mode.copy_on_write = True  # Enable CoW for the entire session
warnings.simplefilter(action="ignore", category=FutureWarning)
# Pandas version: 1.3.5
# Numpy version: 1.21.6
# pd.options.compute.use_bottleneck = True  # Enable bottleneck
# Check if bottleneck is installed and enabled
print(f"Bottleneck acceleration: {pd.options.compute.use_bottleneck} "
      "(Faster NaN-aware operations like mean(), median())")
# Check if numexpr is installed and enabled
# pd.options.compute.use_numexpr = True     # Enable numexpr
print(f"Numexpr acceleration: {pd.options.compute.use_numexpr} "
      "(Optimizes arithmetic/boolean operations)")
# pd.options.mode.string_storage = "pyarrow"  # For pandas 2.0+
print(f"PyArrow string storage: {pd.options.mode.string_storage} "
      "(Reduces memory usage for text columns by 50-80%)")
# pd.options.mode.dtype_backend = "pyarrow"  # Not "dtype="
# print(f"PyArrow dtype backend: {pd.options.mode.dtype_backend} "
#       "(Uses Arrow types for all columns - experimental in Pandas 2.0+)")
# pd.options.compute.use_numba = True
print(f"Numba JIT compilation: {pd.options.compute.use_numba} "
      "(Speeds up rolling/groupby operations - requires numba install)")
np.set_printoptions(precision=6, suppress=True)
pd.set_option("display.precision", 6)
# pd.set_option("mode.chained_assignment", "warn")  # Detects inefficiencies


matplotlib.use("agg")  # Must be set BEFORE importing plt


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")


yf.set_tz_cache_location("/home/rizpython236/.cache/py-yfinance")
# yf.enable_debug_mode()
# import yfinance_cache as yfc
# import shutil


# from functools import lru_cache, cache
# @lru_cache(maxsize=32)  # Stores up to 32 most recent calls
# np.__config__.show()

# from Valid_add_company_name import Valid_add_company_name,Validvlookup_and_merge,copyfile

# print(sys.prefix)
# print("sys.path before append:", sys.path)
# print("______________________________________________________________")
sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
# print("sys.path after append:", sys.path)
time.sleep(2)
# sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/pandas_ta/__init__.py")


# print(ta)
# import SME_


# _____________________________________
"""
import logging

# Create logger
logger = logging.getLogger(__name__)

# Set logger to capture all levels from DEBUG up
logger.setLevel(logging.DEBUG)

# Create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# Create console handler and set level to DEBUG
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)  # Handler level filters what actually gets displayed
ch.setFormatter(formatter)

fh = logging.FileHandler('trade_compiler_Logging.log')
fh.setLevel(logging.DEBUG)
fh.setFormatter(formatter)
logger.addHandler(fh)

# Add handler to the logger
logger.addHandler(ch)

# Example usage
logger.debug('This is a debug message')
logger.info('This is an info message')
logger.warning('This is a warning message')
logger.error('This is an error message')
logger.critical('This is a critical message')
"""
# _________________________________________________________


remove_ticker_data_csv_files()
cleanup_files()


# Start timing
Codestart_time = time.time()


def check_SMA_RSI(Index="^DJI", Name="Dow Jones"):
    try:
        SMAscrossover = B500sma = W500sma = A500sma = B200sma = W200sma = A200sma = RSI20 = RSI25 = RSI30 = RSI45 = RSI70 = RSI75 = ""

        IST_TIMEZONE = pytz.timezone("Asia/Kolkata")

        # today = datetime.now(IST_TIMEZONE).date()
        # yesterday = today - timedelta(days=1)
        # end_date = yesterday

        end_date = datetime.now(IST_TIMEZONE).date()  # - timedelta(weeks=2)

        # end_date = date.today()
        # start_date = end_date - timedelta(days=365)
        # 73 weekly  52+12 64   511+225
        start_date = end_date - timedelta(days=511 + 15)
        END_DATE = str(end_date)
        START_DATE = str(start_date)
        difference = start_date - end_date
        # print(difference)

        # Fetch historical data for Dow Jones Industrial Average (^DJI)
        hist = yf.download(
            Index,
            start=START_DATE,
            end=END_DATE,
            interval="1d",  # 1wk 1d
            rounding=True,
            threads=True,
            multi_level_index=False,
            progress=False,
            back_adjust=True,
            repair=False,  # Data repair is used to fill in missing or corrupted data
            keepna=False,  # removes any rows with missing data.
            actions=False,  # excludes dividend and stock split events from the dat
            auto_adjust=True,  # adjusted for corporate actions like stock splits and dividends
            # ignore_tz=True
        )

        # print(hist)
        # data = yf.Ticker(Index)
        # hist = data.history(period="511d")  # Fetch 511 days of data

        # Check for missing values in the 'Close' column
        # print(hist['Close'].isnull().sum())

        # Fill missing values (if any) using forward fill or interpolation
        hist["Close"] = hist["Close"].ffill()  # Forward fill

        data_no = len(hist) - 2

        # Calculate the 500-day and 200-day Simple Moving Averages (SMA)
        if len(hist) > 500:
            # hist['Close'].rolling(window=500).mean()  349
            hist["500_SMA"] = tb.SMA(hist["Close"], timeperiod=500)
        else:
            # hist['Close'].rolling(window=500).mean()  349
            hist["500_SMA"] = tb.SMA(hist["Close"], timeperiod=data_no)
        # hist['Close'].rolling(window=200).mean()
        hist["200_SMA"] = tb.SMA(hist["Close"], timeperiod=200)
        # hist['Close'].rolling(window=200).mean()
        hist["50_SMA"] = tb.SMA(hist["Close"], timeperiod=50)
        hist["RSI"] = tb.RSI(hist["Close"], timeperiod=14)

        # Get the latest close price, 500-day SMA, and 200-day SMA
        latest_close = hist["Close"].iloc[-1]
        if len(hist) > 500:
            latest_500_sma = round(hist["500_SMA"].iloc[-1] * 1, 2)
        else:
            latest_500_sma = round(hist["500_SMA"].iloc[-1] * .95, 2)
        latest_200_sma = round(hist["200_SMA"].iloc[-1], 2)
        prev_200_sma = round(hist["200_SMA"].iloc[-3], 2)
        latest_50_sma = round(hist["50_SMA"].iloc[-1], 2)
        prev_50_sma = round(hist["50_SMA"].iloc[-3], 2)
        latest_RSI = round(hist["RSI"].iloc[-1], 2)

        # print(len(hist))
        # hist.to_csv(f"{Name}_historical_data.csv",index=False)

        # Calculate the percentage difference between the latest close and the 500-day SMA
        percent_diff_500 = (
            (latest_close - latest_500_sma) / latest_500_sma) * 100

        # Calculate the percentage difference between the latest close and the 200-day SMA
        percent_diff_200 = (
            (latest_close - latest_200_sma) / latest_200_sma) * 100

        if latest_50_sma > latest_200_sma and prev_50_sma < prev_200_sma:
            SMAscrossover = "UPNow"
        elif latest_50_sma < latest_200_sma and prev_50_sma > prev_200_sma:
            SMAscrossover = "DNNow"
        elif latest_50_sma > latest_200_sma:
            SMAscrossover = "UP"
        elif latest_50_sma < latest_200_sma:
            SMAscrossover = "DN**"
        else:
            SMAscrossover = ""

        # Check conditions for 500-day SMA
        if latest_close < latest_500_sma:
            P500sma = B500sma = f"-{abs(percent_diff_500):.2f}% < **"
            result_500 = f"*** -{abs(percent_diff_500):.2f}% < 500-daySMA."
        elif latest_500_sma * 0.95 <= latest_close <= latest_500_sma * 1:
            P500sma = W500sma = f"{percent_diff_500:.2f}% range"
            result_500 = f"**97% & 100% of 500-daySMA ({percent_diff_500:.2f}% below)."
        elif latest_close > latest_500_sma:
            P500sma = A500sma = f"{percent_diff_500:.2f}% >"
            result_500 = f"{percent_diff_500:.2f}% > 500-daySMA."
        else:
            P500sma = result_500 = ""

        # Check conditions for 200-day SMA
        if latest_close < latest_200_sma:
            P200sma = B200sma = f"-{abs(percent_diff_200):.2f}% < **"
            result_200 = f"*** -{abs(percent_diff_200):.2f}% < 200-daySMA."
        elif latest_200_sma * 0.95 <= latest_close <= latest_200_sma * 1:
            P200sma = W200sma = f"{percent_diff_200:.2f}% range"
            result_200 = f"**98% & 100% of 200-daySMA ({percent_diff_200:.2f}% below)."
        elif latest_close > latest_200_sma:
            P200sma = A200sma = f"{percent_diff_200:.2f}% >"
            result_200 = f"{percent_diff_200:.2f}% > 200-daySMA."
        else:
            P200sma = result_200 = ""

        # Check conditions for RSI
        if latest_RSI < 20:
            CRSI = RSI20 = f"{latest_RSI} <20***"
            RSIcheck = f"***RSI {latest_RSI}: < 20.RSI Very low"
        elif latest_RSI < 25:
            CRSI = RSI25 = f"{latest_RSI} <25**"
            RSIcheck = f"**RSI {latest_RSI}: < 25.RSI low"
        elif latest_RSI < 30:
            CRSI = RSI30 = f"{latest_RSI} <30*"
            RSIcheck = f"*RSI {latest_RSI}: < 30."
        elif 45 <= latest_RSI <= 55:
            CRSI = RSI45 = f"{latest_RSI} (45-55)"
            RSIcheck = f"RSI {latest_RSI}: between 45 & 55."
        elif latest_RSI > 75:
            CRSI = RSI75 = f"{latest_RSI} >75***"
            RSIcheck = f"**RSI {latest_RSI}: > 75.RSI Very high"
        elif latest_RSI > 70:
            CRSI = RSI70 = f"{latest_RSI} >70**"
            RSIcheck = f"***RSI {latest_RSI}: > 70.RSI high"
        else:
            CRSI = RSIcheck = ""

        # Combine results into a single multi-line string
        price_statement = (
            f"Latest {Name} Close: {latest_close:.2f}\n"
            f"500-daySMA: {latest_500_sma:.2f}\n"
            f"200-daySMA: {latest_200_sma:.2f}\n"
            f"{result_500}\n"
            f"{result_200}\n"
            f"SMA crossover {SMAscrossover}\n"
            f"{RSIcheck}"
        )

        # print(price_statement)
        # post_telegram_message(price_statement)
        time.sleep(2)
        # return price_statement
        return {
            "Index Name": Name,
            "Price": int(latest_close),
            "200DSMA": int(latest_200_sma),
            "500DSMA": int(latest_500_sma),
            "SMACross": SMAscrossover,
            "%500DSMA": P500sma,
            "%200DSMA": P200sma,
            "RSI": CRSI,

            # "<500DSMA": B500sma,
            # "97range500DSMA": W500sma,
            # ">500DSMA": A500sma,
            # "<200DSMA": B200sma,
            # "98range200DSMA": W200sma,
            # ">200DSMA": A200sma,

            # "RSI<20": RSI20 ,
            # "RSI<25": RSI25 ,
            # "RSI<30": RSI30 ,
            # "RSI45&55": RSI45 ,
            # "RSI>70": RSI70 ,
            # "RSI>75": RSI75 ,
            # "RSI Level": latest_RSI
        }

    except Exception as e:
        print(f"⚠️Error occurred: {e!s}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        # print("Error type:", e.__class__.__name__)
        # print("Error message:", str(e))
        # print("Traceback:\n", traceback_str)

# Example usage
# check_SMA_RSI(Index='^NSEI', Name= 'NIFTY50check')


# Dictionary of indices and their names
indicesforcheck = {
    "NIFTY50": "^NSEI",
    "NIFTY500": "^CRSLDX",
    "NIFTY Midcap 100": "^CRSMID",
    "NIFTY CONSUMPTION": "^CNXCONSUM",
    "BANK NIFTY": "^NSEBANK",
    "Nifty Financial Serv": "NIFTY_FIN_SERVICE.NS",
    "Nifty Private Bank": "NIFTY_PVT_BANK.NS",
    "Nifty PSU Bank": "^CNXPSUBANK",
    "NIFTY IT": "^CNXIT",
    "NIFTY AUTO": "^CNXAUTO",
    "NIFTY METAL": "^CNXMETAL",
    "NIFTY PHARMA": "^CNXPHARMA",
    "Nifty Healthcare": "NIFTY_HEALTHCARE.NS",
    "NIFTY REALTY": "^CNXREALTY",
    "NIFTY MEDIA": "^CNXMEDIA",
    "NIFTY FMCG": "^CNXFMCG",
    "Nifty Consumer Durables": "NIFTY_CONSR_DURBL.NS",
    "NIFTY INFRA": "^CNXINFRA",
    "Nifty Oil & Gas": "NIFTY_OIL_AND_GAS.NS",
    "BSE CAPITAL GOODS": "BSE-CG.BO",
    "BSE POWER": "BSE-POWER.BO",
    "BSE Industrials": "INDSTR.BO",
    "BSE Telecom": "TELCOM.BO",
    "Nifty Commodities": "CNXCMDT",
    "Nifty EV & New Age Auto": "EVINDIA.NS",
    "Nifty Defence": "MODEFENCE.NS",
    "NIFTY INDIA MFG": "NIFTY_INDIA_MFG.NS",
    "Nifty Bank PSU": "DSPPSBKETF.NS",
    "Dow Jones": "^DJI",
    "NASDAQ": "^IXIC",
    "NYSE FANG+": "^NYFANG",
    "Bitcoin": "BTC-USD",
    "China SSE Index": "000001.SS",
    "HK HANG SENG Index": "^HSI",
    "SPDR Gold Shares": "GLD",
}


# Iterate over the dictionary and run the function for each index
# for name, index in indicesforcheck.items():
#    print(f"Analyzing {name} ({index}):")
#    result = check_SMA_RSI(Index=index, Name=name)
#    print("-" * 50)  # Separator for readability


def create_Index_analysis_csv(indicesforcheck, filename="/home/rizpython236/BT5/screener-outputs/Index_analysis.csv"):
    data = []
    for name, index in indicesforcheck.items():
        # print(f"Analyzing {name} ({index}):")
        result = check_SMA_RSI(Index=index, Name=name)
        if result:
            data.append(result)
        print("-" * 50)

    df = pd.DataFrame(data)

    # Drop columns where all values are NaN or empty strings, except "Index Name"
    columns_to_drop = []
    for col in df.columns:
        if col == "Index Name":
            continue  # Skip the "Index Name" column
        if df[col].isna().all() or (df[col] == "").all():
            1 + 1
            # columns_to_drop.append(col)

    df.drop(columns=columns_to_drop, inplace=True)
    df.to_csv(filename, index=False)
    print(df)
    time.sleep(4)
    # post_telegram_file('/home/rizpython236/BT5/screener-outputs/Index_analysis.csv')
    # Replace with your CSV file
    input_csv_file = "/home/rizpython236/BT5/screener-outputs/Index_analysis.csv"
    # Replace with desired output PDF file
    output_pdf_file = "/home/rizpython236/BT5/screener-outputs/Index_analysis.pdf"
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file, pageA4=False)
    time.sleep(5)
    post_telegram_file(
        "/home/rizpython236/BT5/screener-outputs/Index_analysis.pdf")
    print(f"index_analysis saved to {filename}")


# create_Index_analysis_csv(indicesforcheck, filename="/home/rizpython236/BT5/screener-outputs/Index_analysis.csv")


def Vix_alert(symbol="^INDIAVIX"):
    IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
    end_date = datetime.now(IST_TIMEZONE).date()
    start_date = end_date - timedelta(weeks=160)  # 75 weekly
    END_DATE = str(end_date)
    START_DATE = str(start_date)
    start_dateVIX = end_date - timedelta(days=1)  # 75 weekly
    START_DATEVIX = str(start_dateVIX)
    print(START_DATEVIX, END_DATE)
    try:
        # ticker = yf.Ticker(symbol)
        # history = ticker.history(period="1d") #['Close'].iloc[0]
        # history = ticker.history(period='1d',auto_adjust=True)
        # print(history)
        # last_price = history['Close'].iloc[-1]
        # print(last_price)
        VIX = yf.download(symbol, start=START_DATEVIX, end=END_DATE, interval="1d", rounding=True, repair=False,
                          multi_level_index=False, threads=True, back_adjust=True, keepna=False, actions=False, auto_adjust=True)  # , timeout=10
        print(VIX)
        VIX = VIX["Close"].iloc[0]
        VIXDate = END_DATE  # VIX['Date'] #END_DATE
        print(f"Date: {VIXDate}, VIX: {VIX}")
        # print(f"VIX: {VIX}")
        post_telegram_message(f"Date: {VIXDate}, VIX: {VIX}")
    except Exception as e:
        print(f"⚠️Error occurred for VIX: {e!s}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        # print("Error type:", e.__class__.__name__)
        # print("Error message:", str(e))
        # print("Traceback:\n", traceback_str)

# Vix_alert(symbol='WIPRO.NS')


"""
import zipper
#time.sleep(5)
#post_telegram_file('/home/rizpython236/BT5/BT5.zip')
#os.remove('/home/rizpython236/BT5/BT5.zip')
kkk
"""


"""
try:
    import cleanup
    import datadownload15yr
    #delete_large_files('/home/rizpython236/', 100000)
    ###import relative_performance15yr
    ####import data_downloader
    ####import relative_performance

    input_file = '/home/rizpython236/BT5/Final.csv'
    #input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
    output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
    copyfile1(input_file, output_file)

    input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
    output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
    update_output_file(input_file, output_file)
    import BTmombroker
    #import csv15yrs_short #csv15yrs
    import pybrokerBT #momentu
    #import wkly_candle
except Exception as e:
    print(f"⚠️bt_screener2 error: {e}")
    traceback_str = traceback.format_exc()
    print(traceback_str)
hhh
"""


"""
input_file = '/home/rizpython236/BT5/Final.csv'
#input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
copyfile1(input_file, output_file)

input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
update_output_file(input_file, output_file)
import datadownload15yr
import relative_performance15yr
import csv15yrs_short #csv15yrs
kkk
"""


def attempt_import(folder_paths, module_name, max_attempts=10, delay=5):
    """Attempt to import a module from specified folder paths in a loop until successful.

    Parameters
    ----------
        folder_paths (list): The paths to the folders containing the module.
        module_name (str): The name of the module to import.
        max_attempts (int): The maximum number of attempts to import the module.
        delay (int): The delay (in seconds) between each attempt.

    Returns
    -------
        module: The imported module if successful, None otherwise.

    """
    attempts = 0

    while attempts < max_attempts:
        for i in range(1, 10):  # folder_path in folder_paths:
            time.sleep(delay)
            try:
                sys.path.append(folder_path)
                module = __import__(module_name)
                # print(f"{module_name} imported successfully from {folder_path}.")
                return module
            except Exception as e:
                print(f"Attempt {attempts + 1} failed from {folder_path}: {e}")
                traceback.print_exc()  # Print the full traceback
                # Remove the path to avoid conflicts
                sys.path.remove(folder_path)

        attempts += 1
        # time.sleep(delay)

    print(f"Failed to import {module_name} after {max_attempts} attempts.")
    return None


def delete_pdfs(file_path):
    """Deletes all PDF files within a specified folder.

    Args:
      file_path: Path to the folder containing the PDF files.

    """
    if not os.path.exists(file_path):
        print(f"Folder '{file_path}' does not exist.")
        return

    # Loop through all files in the folder
    for filename in os.listdir(file_path):
        file_path_full = os.path.join(file_path, filename)
        # if filename.endswith((".pdf", ".png","csv")): #filename.endswith(".pdf") or filename.endswith(".png"):
        # filename.endswith(".pdf") or filename.endswith(".png"):
        if filename.endswith((".pdf", ".png")):
            try:
                os.remove(file_path_full)
                print(f"Deleted PDF file: {filename}")
            except PermissionError:
                print(f"⚠️Error deleting {filename}: Permission denied.")
            except FileNotFoundError:
                print(f"⚠️Error deleting {filename}: File not found.")


"""
# Define the path to the specific folder and module name
folder_path = "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/"
#folder_path1 = "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/pandas_ta/__init__.py"
folder_paths = [
    "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/",
    "/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/pandas_ta/__init__.py"
]
module_name = "pandas_ta"

# Attempt to import the module
ta = attempt_import(folder_path, module_name)

"""
if ta:
    # Verify that pandas_ta has been imported successfully
    # print(ta)
    # print("sys.modules before import:", sys.modules.keys())
    print("______________________________________________________________")
    print(f"pandas_ta imported successfully from \n{sys.path}.")
else:
    print("Failed to import pandas_ta.from \n{sys.path}.")


# import asyncio
# import logging
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)  # Adjust logging level as needed (e.g., DEBUG, WARNING)

# if account_is_in_tarpit_state():  # Replace with your logic to check tarpit state
#    logger.info("Account entered tarpit state. Printing 'abc'.")

"""
Security Code,Issuer Name,Security Id,Security Name,Status,Group,Face Value,ISIN No,Industry,Instrument,Sector Name,Industry New Name,Igroup Name,ISubgroup Name
500002,ABB India Limited,ABB,ABB India Limited,Active,A ,2.00,INE117A01022,Heavy Electrical Equipment,Equity,Industrials,Capital Goods,Electrical Equipment,Heavy Electrical Equipment
"""


# import cleanup
# input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
# output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
# update_output_file(input_file, output_file)


print("Python version:", sys.version)

# Replace with your actual folder path
delete_pdfsfile_path = "/home/rizpython236/BT5/screener-outputs/"
# file_path = "/home/rizpython236/"  # Replace with your actual folder path
# delete_pdfs(delete_pdfsfile_path)


def if_Sunday(weekday):
    if weekday == "Sunday":
        try:
            # import cleanup
            # import BSENSEtickerdownloader
            # import symbol_copy
            input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
            output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
            update_output_file(input_file, output_file)
            output_file = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
            vlookup_and_merge(output_file)
        except Exception as e:
            print(f"⚠️Error occurred if_Sunday {e!s}")
            traceback_str = traceback.format_exc()
            # Print detailed error information
            print("Error type:", e.__class__.__name__)
            print("Error message:", str(e))
            print("Traceback:\n", traceback_str)
            # post_telegram_message("momNSE750 error")
    else:
        1 + 1


"""
import BSENSEtickerdownloader
time.sleep(2)
input_file = '/home/rizpython236/BT5/Final.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
copyfile1(input_file, output_file)
time.sleep(2)

input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
add_company_names_and_industry(input_file, output_file)
time.sleep(2)
input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
copyfile1(input_file, output_file)
print("End")

found = (data['Close'].iloc[-1] == data['Close'].iloc[-24:].rolling(window=24).min()).any() & (rsi > 60)
ffhhhhhh
"""
# import datetime


def print_on_first_business_day():
    """Prints "abc" on the 1st day of the every month (if applicable)."""
    IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
    now = datetime.now(IST_TIMEZONE)
    # day1=now.day
    # print(day1)

    # Check if today is already the 1st business day
    if now.weekday() == 4 and 1 <= now.day <= 7:  # Monday is 0 and Sunday is 6
        # if now.day == 1:
        print("Run momNSE750")
        try:
            time.sleep(2)
        except Exception as e:
            print(f"⚠️Error occurred momNSE750 {e!s}")
            traceback_str = traceback.format_exc()
            # Print detailed error information
            print("Error type:", e.__class__.__name__)
            print("Error message:", str(e))
            print("Traceback:\n", traceback_str)
            post_telegram_message("momNSE750 error")
    else:
        print("Do not run momNSE750")


Monday = True
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today = datetime.now(IST_TIMEZONE).date()
ISTnow = datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")

current_datetimeUTC = datetime.now()
weekdayUTC = datetime.now().strftime("%A")

formatted_datetimeUTC = current_datetimeUTC.strftime("%d %b %Y %I:%M %p")
formatted_datetimeIST = ISTnow.strftime("%d %b %Y %I:%M %p")

day = today.weekday() == 1

if weekday == "Tuesdayxxx" or weekday == "Wednesday" or weekday == "Thursdayxxx":
    post_telegram_message(f"Pybroker Scan started {weekday}")
else:
    post_telegram_message(f"Scan started {weekday}")


time.sleep(3)
print(f"Now IST Date & Time: {formatted_datetimeIST} {weekday}")
post_telegram_message(
    f"Now IST Date & Time: {formatted_datetimeIST} {weekday}")

# print(weekday)


# if_Sunday(weekday)


while False:
    if weekday == "Tuesday":  # today.weekday() == 1:  # 0 represents Monday Tuesday
        try:

            post_telegram_message("Monday screener wont run")
            try:
                # Vix_alert(symbol='^INDIAVIX')
                # create_Index_analysis_csv(indicesforcheck, filename="/home/rizpython236/BT5/screener-outputs/Index_analysis.csv")

                # import smemigration
                # import ipodata
                # import Alert
                1 + 1
            except Exception as e:
                print(f"⚠️MRPPlot error: {e}")
            # os.remove('/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.pdf')
            dir6 = "/home/rizpython236/BT5/ticker_daily1yr"
            for f in os.listdir(dir6):
                os.remove(os.path.join(dir6, f))
            dir5 = "/home/rizpython236/BT5/ticker_15yr"
            for f in os.listdir(dir5):
                os.remove(os.path.join(dir5, f))

            try:
                1 + 1
            except Exception as e:
                print(f"⚠️BSENSEtickerdownloader error: {e}")

            time.sleep(1)
            # import symbol_copy

            # /home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv
            input_file = "/home/rizpython236/BT5/Final.csv"
            time.sleep(5)
            # input_file = '/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv'
            output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
            copyfile1(input_file, output_file)

            # import datadownload15yr
            # import relative_performance15yr
            # time.sleep(2)
            # import csv15yrs_short #csv15yrs
            # import Drawdownchart15yr
            dir6 = "/home/rizpython236/BT5/ticker_15yr"
            for f in os.listdir(dir6):
                os.remove(os.path.join(dir6, f))

            # import datadownload1yrdaily
            # import relative_performance_daily
            # import csv15yrsconvertedtodaily #csvVXdaily

            time.sleep(2)
            input_file = "/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv"
            # input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
            input_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
            output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
            add_company_names_and_industry(input_file, output_file)
            time.sleep(2)

            clean_memory(deep=False, verbose=True)
            # print_on_first_business_day()  # 1 yr daily
            # input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
            # output_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
            # copyfile1(input_file, output_file)

            try:
                1 + 1
                # import MRPPlot
            except Exception as e:
                print(f"⚠️MRPPlot error: {e}")

            try:
                # import momNSE750  # 1 yr daily
                dir6 = "/home/rizpython236/BT5/ticker_daily1yr"
                for f in os.listdir(dir6):
                    os.remove(os.path.join(dir6, f))
                # import csv_file2copy
            except Exception as e:
                print(f"⚠️csv_file2copy error: {e}")
            # import BToutputindustry

            # /home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv
            input_file = "/home/rizpython236/BT5/Final.csv"
            output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
            # copyfile1(input_file, output_file)
            time.sleep(2)
            input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
            output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
            # update_output_file(input_file, output_file)
            time.sleep(2)

            clean_memory(deep=False, verbose=True)

            dir5 = "/home/rizpython236/BT5/ticker_15yr"
            for f in os.listdir(dir5):
                os.remove(os.path.join(dir5, f))

            input_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
            # /home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv
            output_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
            # copyfile1(input_file, output_file)
            try:
                delete_large_files("/home/rizpython236/", 10000)
                # import relative_performance15yr
                # ensure_llvmlite_numba_by_file()

                # clean_pandas_memory()
                clean_memory(deep=True, verbose=True)
                # ensure_llvmlite_numba_by_file()
                dir5 = "/home/rizpython236/BT5/ticker_15yr"
                for f in os.listdir(dir5):
                    1 + 1
                    # os.remove(os.path.join(dir5, f))
            except Exception as e:
                traceback_str = traceback.format_exc()
                print("Traceback:\n", traceback_str)
                print(f"⚠️csv15yrs error: {e}")
            # clean_pandas_memory()
            clean_memory(deep=False, verbose=True)
            manage_user_variables(
                delete_top_n=0, delete_threshold="2MB", confirm=True)

            update_exclude_list(
                exclude_file="/home/rizpython236/BT5/exclude_tickers.csv")
            # update_include_tickers(include_file="/home/rizpython236/BT5/include_tickers.csv")
            # import dividend
            post_telegram_message("Code stopped its Monday")
            print("Code stopped its Monday")
            shutdown_bot()
            sys.exit(1)
            while True:
                print("Code stopped")
                time.sleep(900)
            1 + 1
        except Exception as e:
            print(f"⚠️Error occurred monday: {e!s}")
            traceback_str = traceback.format_exc()
            # Print detailed error information
            print("Error type:", e.__class__.__name__)
            print("Error message:", str(e))
            print("Traceback:\n", traceback_str)
            # post_telegram_message("Traceback:\n", traceback_str)
            break
    else:
        break


# asyncio.run(post_telegram_message("Scan started!"))

# post_telegram_message(message=Scan started)

# print("Nifty PE, PB, Dividend Yield Stats")
# import nifty_pe_downloader


print("Now Date & Time in UTC:", formatted_datetimeUTC)
print(f"UTC: Today is {weekdayUTC}...")

print("Now Date & Time in IST:", formatted_datetimeIST)
print(f"IST: Today is {weekday}...")
# post_telegram_message(f"Now IST Date & Time: {formatted_datetimeIST}")

time.sleep(1)


try:
    1 + 1
    import_user_module(base_dir_module, "cleanup")
    import_user_module(base_dir_module, "SME_")
    # Vix_alert(symbol='^INDIAVIX')
except Exception as e:
    print(f"⚠️cleanup error: {e}")
    traceback_str = traceback.format_exc()

try:
    import_user_module(base_dir_module, "Mktcap2GDP")
    time.sleep(2)
except Exception as e:
    print(f"⚠️Mktcap2GDP error: {e}")
    traceback_str = traceback.format_exc()

try:
    1 + 1
    # import smemigration
    # import ipodata
except Exception as e:
    print(f"⚠️smemigration error: {e}")
    traceback_str = traceback.format_exc()

try:
    import_user_module(base_dir_module, "MMI_index")
    time.sleep(1)
except Exception as e:
    print(f"⚠️MMI_index chart error: {e}")
    traceback_str = traceback.format_exc()

try:
    1 + 1
    # create_Index_analysis_csv(indicesforcheck, filename="/home/rizpython236/BT5/screener-outputs/Index_analysis.csv")
except Exception as e:
    print(f"⚠️MMI_index chart error: {e}")
    traceback_str = traceback.format_exc()


try:
    if weekday == "Tuesdayxxx" or weekday == "Wednesday" or weekday == "Thursdayxxx":
        # import Alert
        time.sleep(1)
except Exception as e:
    print(f"⚠️Alert error: {e}")
    traceback_str = traceback.format_exc()


try:
    # import tradebookanalysis
    import_user_module(base_dir_module, "BSENSEtickerdownloader")
    time.sleep(1)
    import_user_module(base_dir_module, "symbol_copy")
    # if_Sunday(weekday)
except Exception as e:
    print(f"⚠️BSENSEtickerdownloader error: {e}")
    traceback_str = traceback.format_exc()


if 1 == 1:  # weekday != "Tuesdayxxx" or weekday != "Wednesday" or weekday != "Thursdayxxx":
    input_file = "/home/rizpython236/BT5/Final.csv"
    # input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
    output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
    copyfile1(input_file, output_file)
else:
    1 + 1

try:
    if True:  # weekday == "Thursday":
        input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
        # input_file = '/home/rizpython236/BT5/Final.csv'
        output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
        update_output_file(input_file, output_file)
except Exception as e:
    print(f"⚠️valid_tickers copy error: {e}")
    traceback_str = traceback.format_exc()

try:
    if weekday == "Tuesdayxxx" or weekday == "WednesdayXXXXXX" or weekday == "Thursdayxxx":
        import_user_module(base_dir_module, "data_downloader")
        import_user_module(base_dir_module, "relative_performance")
        delete_large_files("/home/rizpython236/", 100000)
        clean_memory(deep=True, verbose=True)
        # import BTmombroker
except Exception as e:
    print(f"⚠️data_downloader weekly error: {e}")
    traceback_str = traceback.format_exc()


try:
    if 1 == 1:  # weekday != "Tuesdayxxx" or weekday != "Wednesday" or weekday != "Thursdayxxx":
        import_user_module(base_dir_module, "datadownload15yr")
        # import basic_ticker_data_check
        delete_large_files("/home/rizpython236/", 100000)
        # import relative_performance15yr
        # ensure_llvmlite_numba_by_file()
        import_user_module(base_dir_module, "BTmombroker")
        manage_zip("zip")
        time.sleep(3)
        # ensure_llvmlite_numba_by_file()
        # import csv15yrs_short #csv15yrs
        # import Drawdownchart15yr
        clean_memory(deep=True, verbose=True)
        dir6 = "/home/rizpython236/BT5/ticker_15yr"
        for f in os.listdir(dir6):
            1 + 1
            # os.remove(os.path.join(dir6, f))
        1 + 1
except Exception as e:
    print(f"⚠️datadownload15yr error: {e}")
    traceback_str = traceback.format_exc()
    print(traceback_str)
    sys.exit(1)

time.sleep(2)
# clean_pandas_memory()

delete_all_files_and_folders("/tmp")


try:
    if 1 != 1:  # True: #weekday == "Thursday":
        input_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
        output_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
        update_output_file(input_file, output_file)
except Exception as e:
    print(f"⚠️valid_tickers copy error: {e}")
    traceback_str = traceback.format_exc()

try:
    import_user_module(base_dir_module, "nse500")
except Exception as e:
    print(f"⚠️nse500 error: {e}")
    traceback_str = traceback.format_exc()


time.sleep(2)

# input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
# output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
# add_company_names_and_industry(input_file, output_file)


#############


# new
# output_file='/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
# Validvlookup_and_merge(output_file)
# time.sleep(2)
# input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
# output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
# Valid_add_company_name(input_file, output_file)
# time.sleep(2)
input_file = "/home/rizpython236/BT5/screener-outputs/valid_tickers.csv"
output_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
# copyfile1(input_file, output_file)

delete_pdfs(delete_pdfsfile_path)
time.sleep(1)

# import csv_file
try:
    # import datadownload1yrdaily
    # time.sleep(1)
    # import relative_performance_daily
    time.sleep(1)
    # import MRPPlot
except Exception as e:
    print(f"⚠️datadownload1yrdaily error: {e}")
    traceback_str = traceback.format_exc()

try:
    time.sleep(1)
    # import csv15yrsconvertedtodaily #csvVXdaily
    abc = 123565
except Exception as e:
    print(f"⚠️csvVXdaily error: {e}")
    traceback_str = traceback.format_exc()
    abc = 123


manage_user_variables(delete_top_n=0, delete_threshold="2MB", confirm=True)
print("BT")

try:
    if 1 == 1:  # weekday == "Tuesdayxxx" or weekday == "Wednesday" or weekday == "Thursdayxxx":
        # import csv_file2copy
        try:
            1 + 1
            # import BTmomNSE750 dont use
            # import BTmombroker
        except Exception as e:
            print(f"⚠️BTmomNSE750 error: {e}")
            traceback_str = traceback.format_exc()
        # import bt_screener2 #momentum
        # ensure_llvmlite_numba_by_file()
        import_user_module(base_dir_module, "pybrokerBT")
        # import wkly_candle
        clean_memory(deep=True, verbose=True)
        1 + 1
    xyz = 123565
except Exception as e:
    print(f"⚠️bt_screener2 error: {e}")
    traceback_str = traceback.format_exc()
    print(traceback_str)
    xyz = 123
    sys.exit(1)

# clean_pandas_memory()
delete_all_files_and_folders("/tmp")


try:
    if 1 == 1:  # weekday == "Tuesdayxxx" or weekday == "Wednesday" or weekday == "Thursdayxxx":
        time.sleep(2)
        output_file = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
        vlookup_and_merge(output_file)
except Exception as e:
    print(f"⚠️vlookup_and_merge error: {e}")
    traceback_str = traceback.format_exc()


try:
    1 + 1

    try:
        1 + 1
        import_user_module(base_dir_module, "Drawdownchart")
    except Exception as e:
        print(f"⚠️Drawdownchart chart error: {e}")
        traceback_str = traceback.format_exc()
    import_user_module(base_dir_module, "CCIST")
    import_user_module(base_dir_module, "EMASMA")
    # import Drawdownchart15yr
    if xyz == 123565:
        dir6 = "/home/rizpython236/BT5/ticker-csv-files"
        for f in os.listdir(dir6):
            # os.remove(os.path.join(dir6, f))
            1 + 1
    else:
        1 + 1
except Exception as e:
    traceback_str = traceback.format_exc()
    print(f"⚠️EMASMA chart error: {e}")
    if xyz == 123565:
        dir6 = "/home/rizpython236/BT5/ticker-csv-files"
        for f in os.listdir(dir6):
            # os.remove(os.path.join(dir6, f))
            1 + 1

delete_pdfs(delete_pdfsfile_path)
delete_all_files_and_folders("/tmp")

try:
    if True:
        # print_on_first_business_day()
        1 + 1
except Exception as e:
    print(f"⚠️momNSE750 error: {e}")
    traceback_str = traceback.format_exc()


if abc == 123565:
    dir6 = "/home/rizpython236/BT5/ticker_daily1yr"
    for f in os.listdir(dir6):
        os.remove(os.path.join(dir6, f))
else:
    1 + 1

# clean_pandas_memory()
clean_memory(deep=False, verbose=True)

try:
    # or weekday != "Wednesday1111" or weekday != "Thursdayxxx":
    if weekday == "Tuesdayxxx":

        delete_large_files("/home/rizpython236/", 100000)
        time.sleep(3)
        # import Drawdownchart15yr
        clean_memory(deep=True, verbose=True)
        dir6 = "/home/rizpython236/BT5/ticker_15yr"
        for f in os.listdir(dir6):
            os.remove(os.path.join(dir6, f))
        1 + 1
except Exception as e:
    print(f"⚠️datadownload15yr error: {e}")
    traceback_str = traceback.format_exc()

# clean_pandas_memory()


try:
    if 1 == 1:  # weekday == "Tuesdayxxx" or weekday == "Wednesday" or weekday == "Thursdayxxx":

        # import sectorupdate
        time.sleep(2)
        # import sector_rotation
        # import csv_file2 time.sleep(2)
except Exception as e:
    print(f"⚠️sector signal error: {e}")
    traceback_str = traceback.format_exc()
    post_telegram_message("sector signal failed!")

delete_pdfs(delete_pdfsfile_path)
delete_all_files_and_folders("/tmp")

# post_telegram_message("weekly Scan started!")
# import new_screener
try:
    1 + 1
    # import order_common # holding signal
except Exception as e:
    print(f"⚠️order_common error: {e}")
    traceback_str = traceback.format_exc()
    post_telegram_message("order_common failed!")

# clean_pandas_memory()
clean_memory(deep=False, verbose=True)


######################
# Calculate elapsed time
elapsed_seconds = time.time() - Codestart_time

# Convert to hours, minutes, seconds
hours = int(elapsed_seconds // 3600)
remaining_seconds = elapsed_seconds % 3600
minutes = int(remaining_seconds // 60)
seconds = remaining_seconds % 60
print(f"Execution time: {hours}h {minutes}m {seconds:.2f}s")
# post_telegram_message(f"Execution time: {hours}h {minutes}m {seconds:.2f}s")
###############################

"""
BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
if os.path.exists(BT_FILE_PATH):
    #if 123565 == 123565:
    #dir6 = "/home/rizpython236/BT5/ticker_daily1yr"
    dir6 = "/home/rizpython236/BT5/ticker_15yr"
    for f in os.listdir(dir6):
        os.remove(os.path.join(dir6, f))
else:
    1+1
"""

"""
try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf'
    if os.path.exists(output_pdf_file):
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.pdf')
except Exception as e:
    print(f"Error in ruuning DDPCTdatadaily pdf- {e}")
    pass

try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.pdf'
    if os.path.exists(output_pdf_file):
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.pdf'  # Replace with desired output PDF fill
        create_pdf(input_csv_file, output_pdf_file, pageA4 =False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.pdf')
except Exception as e:
    print(f"Error in ruuning DDPCTdataWkly pdf- {e}")
    pass

"""

delete_pdfs(delete_pdfsfile_path)
delete_large_files("/home/rizpython236/", 10000)
manage_user_variables(delete_top_n=0, delete_threshold="2MB", confirm=True)


BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
df_trade_list_BT_Screener = pd.read_csv(BT_FILE_PATH)
df_trade_list_BT_Screener = df_trade_list_BT_Screener[[
    "Score", "N750", "ticker", "dir", "datein", "pricein", "Company", "Industry"]]
df_trade_list_BT_Screener.sort_values(by=["dir", "Industry", "N750", "Score"], ascending=[
                                      True, True, False, True], inplace=True)
df_trade_list_BT_Screener.to_csv(BT_FILE_PATH, index=False)

time.sleep(5)
# Replace with desired output PDF file
output_pdf_file = "/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf"
# create_pdf(BT_FILE_PATH, output_pdf_file,pageA4= True)
# time.sleep(5)
# post_telegram_file("/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf")
bt_data = pd.read_csv(BT_FILE_PATH)
holding_file = "/home/rizpython236/BT5/myholding.csv"
holding_file = pd.read_csv(holding_file)

filtered = bt_data[bt_data["ticker"].isin(holding_file["Symbol"])]
filtered.sort_values(by=["dir", "Industry", "N750", "Score"], ascending=[
                     True, True, False, True], inplace=True)
filtered.to_csv(
    "/home/rizpython236/BT5/screener-outputs/filteredBT.csv", index=False)
time.sleep(2)
BT_FILE_PATH_filtered = "/home/rizpython236/BT5/screener-outputs/filteredBT.csv"

# Replace with desired output PDF file
output_pdf_file = "/home/rizpython236/BT5/screener-outputs/filteredBT.pdf"
create_pdf(BT_FILE_PATH_filtered, output_pdf_file, pageA4=True)
time.sleep(5)
post_telegram_file("/home/rizpython236/BT5/screener-outputs/filteredBT.pdf")


BT_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + BT_SCREENER_CSV
TALIB_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + TALIB_SCREENER_CSV
CURRENT_DAY_SCREENER_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
TRADEBOOK_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + TRADEBOOK_CSV
TODAYS_DATE = date.today()
empty_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/emptyscreener.csv"


dir6 = "/home/rizpython236/BT5/ticker-csv-files"
for f in os.listdir(dir6):
    # os.remove(os.path.join(dir6, f))
    1 + 1

BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
if os.path.exists(BT_FILE_PATH):
    # if 123565 == 123565:
    # dir6 = "/home/rizpython236/BT5/ticker_daily1yr"
    dir6 = "/home/rizpython236/BT5/ticker_15yr"
    for f in os.listdir(dir6):
        # os.remove(os.path.join(dir6, f))
        1 + 1
else:
    1 + 1


######################
# Calculate elapsed time
elapsed_seconds = time.time() - Codestart_time

# Convert to hours, minutes, seconds
hours = int(elapsed_seconds // 3600)
remaining_seconds = elapsed_seconds % 3600
minutes = int(remaining_seconds // 60)
seconds = remaining_seconds % 60
print(f"Execution time: {hours}h {minutes}m {seconds:.2f}s")
post_telegram_message(f"Execution time: {hours}h {minutes}m {seconds:.2f}s")
###############################


with open(BT_FILE_PATH) as f:
    reader = csv.reader(f)
    header = next(reader)
    data = [row for row in reader]
    if not data:
        print("NO_NEW_SIGNALS_FOUND_MSG")
        post_telegram_message("NO_NEW_SIGNALS_FOUND_MSG")
        src_path = empty_FILE_PATH
        dst_path = BT_FILE_PATH
        # shutil.copy2(src_path, dst_path)
        # shutil.copy2(trade_list_BT_Screener.csv, trade_list_Talib_Screener.csv)
        # print("The file has no data under the header column.")
    else:
        # post_telegram_message("BT_file_has_screener_data")
        print("BT file has screener data")
        # continue
        # shutil.copy2(BT_FILE_PATH.csv, empty_FILE_PATH)
        # Continue with the rest of the code here

bt_data = pd.read_csv(BT_FILE_PATH)
talib_data = pd.read_csv(TALIB_FILE_PATH)
# new_screener_data = pd.read_csv(NEW_FILE_PATH)
tradebook = pd.read_csv(TRADEBOOK_FILE_PATH)


"""
Checking if the BT-data is empty or not and
triggering a mail if it's empty.
"""
if len(bt_data) == 0:
    print(EMPTY_BT_SCREENER_MSG)
    trigger_generic_email(msg=EMPTY_BT_SCREENER_MSG)
    sys.exit()


bt_tickers = list(bt_data["ticker"].unique())
talib_tickers = list(talib_data["ticker"].unique())


active_tradebook = tradebook[tradebook["status"] == "active"]
active_tradebook_tickers = list(active_tradebook["ticker"].unique())


def fetch_talib_results_for_ticker(ticker):

    talib_record = {"talib_date": "", "talib_signal": "", "talib_price": ""}

    if ticker not in talib_tickers:
        return talib_record

    talib_record["talib_date"] = talib_data.loc[
        talib_data["ticker"] == ticker, "datein",
    ].iloc[0]
    talib_record["talib_signal"] = talib_data.loc[
        talib_data["ticker"] == ticker, "dir",
    ].iloc[0]
    talib_record["talib_price"] = talib_data.loc[
        talib_data["ticker"] == ticker, "pricein",
    ].iloc[0]

    return talib_record


def trigger_compilation():

    new_trades = []
    signal_changed_messages = []

    for row in range(len(bt_data)):

        ticker = bt_data["ticker"][row]
        generated_signal = bt_data["dir"][row]

        ticker_date = bt_data.loc[bt_data["ticker"]
                                  == ticker, "datein"].iloc[0]
        ticker_signal = bt_data.loc[bt_data["ticker"] == ticker, "dir"].iloc[0]
        ticker_price = bt_data.loc[bt_data["ticker"]
                                   == ticker, "pricein"].iloc[0]
        ticker_Company = bt_data.loc[bt_data["ticker"]
                                     == ticker, "Company"].iloc[0]
        ticker_Industry = bt_data.loc[bt_data["ticker"]
                                      == ticker, "Industry"].iloc[0]
        ticker_Score = bt_data.loc[bt_data["ticker"]
                                   == ticker, "Score"].iloc[0]
        pnl_percentage = None

        if ticker in active_tradebook_tickers:
            # print("Ticker already present, checking for active signal ...")
            active_signal = active_tradebook.loc[
                active_tradebook["ticker"] == ticker, "signal",
            ].iloc[0]

            if active_signal == generated_signal:
                # signal has not changed, hence continue
                continue
            print(
                f"Signal changed for => {ticker}. Updating status to {generated_signal}...")
            message = f"Signal changed {ticker}."
            signal_changed_messages.append(message)
            time.sleep(2)
            post_telegram_message(
                f"Signal changed for => {ticker}. Updating status to {generated_signal}")
            trade_id = active_tradebook.loc[
                active_tradebook["ticker"] == ticker, "trade_id",
            ].iloc[0]
            old_trade_price = active_tradebook.loc[
                active_tradebook["trade_id"] == trade_id, "price",
            ].iloc[0]

            tradebook.loc[
                (tradebook["trade_id"] == trade_id), ["status"],
            ] = "closed"
            tradebook.loc[
                (tradebook["trade_id"] == trade_id), ["trade_updated_on"],
            ] = str(TODAYS_DATE)

            if active_signal == "BUY" and generated_signal == "SELL":
                print(
                    f"Buy + Sell completed for {ticker}, calculating PnL.",
                )
                pnl_percentage = round(
                    ((ticker_price - old_trade_price) /
                     old_trade_price) * 100, 2,
                )
                # tradebook.loc[
                #     active_tradebook["trade_id"] == trade_id, "pnl"
                # ] = pnl_percentage

        talib_data_dict = fetch_talib_results_for_ticker(ticker)
        # new_screener_dict = fetch_new_screener_dict(ticker)

        record = {
            "trade_logged_on": str(TODAYS_DATE),
            "trade_id": str(uuid.uuid4()),
            "status": "active",
            "date": ticker_date,
            "ticker": ticker,
            "signal": ticker_signal,
            "price": ticker_price,
            "Company": ticker_Company,
            "Industry": ticker_Industry,
            "Score": ticker_Score,
        }

        if pnl_percentage:
            record.update({"pnl": pnl_percentage})

        record.update(talib_data_dict)
        # record.updated(new_screener_dict)
        new_trades.append(record)
        record = {}

    try:
        for i in range(0, len(signal_changed_messages), 35):
            block = signal_changed_messages[i:i + 35]
            print("\n".join(block))
            time.sleep(3)
            # post_telegram_message("\n".join(block))
    except Exception as e:
        print(f"⚠️signal_changed_messages error: {e}")
        post_telegram_message("signal_changed_messages error")

    return new_trades


def cleanup_files():

    print("-" * 50)
    print("Removing the files ...")
    print("-" * 50)

    # remove BT Screener Output
    print("Deleting BT Screener Output File.")
    if os.path.exists(BT_FILE_PATH):
        os.remove(BT_FILE_PATH)

    # remove Talib Output
    print("Deleting Talib Screener Output File.")
    if os.path.exists(TALIB_FILE_PATH):
        os.remove(TALIB_FILE_PATH)

    # remove Talib Output
    print("Deleting Last Saved Screener Output File.")
    if os.path.exists(CURRENT_DAY_SCREENER_FILE_PATH):
        # os.remove(CURRENT_DAY_SCREENER_FILE_PATH)
        1 + 1

    # remove valid, invalid and incomplete ticker csvs
    print("Emptying valid, invalid and incomplete ticker output files.")
    dir1 = SCREENER_OUTPUT_FOLDER_PATH
    for f in os.listdir(dir1):
        ff = dir1 + "/" + f
        temp_df = pd.read_csv(ff)
        temp_df.drop(temp_df.index, inplace=True)
        temp_df.to_csv(ff, index=False)
        # os.remove(os.path.join(dir1, f))

    # remove Symbol list
    # print("Emptying Symbol List")
    # sym_df = pd.read_csv(SYMBOLS_CSV)
    # sym_df.drop(sym_df.index, inplace=True)
    # sym_df.to_csv(SYMBOLS_CSV, index=False)

    # ff = "./screener-outputs/valid_tickers.csv"
    # temp_df = pd.read_csv(ff)
    # temp_df.drop(temp_df.index, inplace=True)
    # temp_df.to_csv(ff, index=False)

    # remove ticker data csv files
    print("Deleting all the ticker data csv files.")
    dir2 = TICKER_CSV_DATA_FOLDER_PATH
    for f in os.listdir(dir2):
        # os.remove(os.path.join(dir2, f))
        1 + 1

    print("Deleting Nifty Weekly Avg Stats Image")
    if os.path.exists(NIFTY_WEEKLY_AVG_STATS_IMAGE):
        os.remove(NIFTY_WEEKLY_AVG_STATS_IMAGE)

    # folder = TICKER_CSV_DATA_FOLDER_PATH
    # for filename in os.listdir(folder):
    #    file_path = os.path.join(folder, filename)
    #    try:
    #        if os.path.isfile(file_path) or os.path.islink(file_path):
    #            os.unlink(file_path)
    #        elif os.path.isdir(file_path):
    #            shutil.rmtree(file_path)
    #    except Exception as e:
    #        print("Failed to delete %s. Reason: %s" % (file_path, e))


def generate_notifications(new_trades):

    if not new_trades:
        print("No new signals for today!")
        # trigger_generic_email(msg=NO_NEW_SIGNALS_FOUND_MSG)
        post_telegram_message(message=NO_NEW_SIGNALS_FOUND_MSG)
        # cleanup_files()
        return

    new_trades_df = pd.DataFrame(data=new_trades)
    # here we are sorting based on BT signal type - column = "signal"
    new_trades_df = new_trades_df.sort_values("signal")
    updated_tradebook = pd.concat([tradebook, new_trades_df], axis=0)
    updated_tradebook.to_csv(TRADEBOOK_FILE_PATH, index=False)

    FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/Finalnse.csv")
    FinalMicrocap250symbols = FinalMicrocap250["Symbol"].tolist()[:]
    # NSE570symbols = list(dict.fromkeys(symbols))
    FinalMicrocap250symbols = list(set(FinalMicrocap250symbols))

    """
    Scoretickersall = pd.read_csv("/home/rizpython236/BT5/trade-logs/Scoretickersall.csv")
    Scoretickersall = Scoretickersall.drop(columns=['Company'])
    # Merge on ticker symbol
    new_trades_df = new_trades_df.merge(Scoretickersall, left_on='ticker', right_on='Ticker', how='left')
    # Drop duplicate 'Ticker' column (optional)
    new_trades_df = new_trades_df.drop(columns=['Ticker'])
    """

    new_trades_df["N750"] = new_trades_df["ticker"].apply(
        lambda x: "Y" if x in FinalMicrocap250symbols else "")
    # date ticker signal price Company Industry  N750
    new_trades_df = new_trades_df[[
        "date", "N750", "ticker", "signal", "price", "Company", "Industry", "Score"]]
    new_trades_df.sort_values(by=["signal", "Industry", "N750", "Score"], ascending=[
                              True, True, False, True], inplace=True)
    new_trades_file_path = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
    new_trades_df.to_csv(new_trades_file_path, index=False)

    # trigger_email_notification()
    time.sleep(1)
    trigger_telegram_notifications()

    # cleanup_files()
    # import cleanup


def main():

    new_trades = trigger_compilation()

    try:
        generate_notifications(new_trades)

        folder_path = "/home/rizpython236/BT5/ticker-csv-files/"
        folder_path = "/home/rizpython236/BT5/ticker_15yr"
        filepathpdf = "/home/rizpython236/BT5/screener-outputs/screener_output_Charts.pdf"
        screenercsv_path = "/home/rizpython236/BT5/trade-logs/screener-output.csv"
        addchartspdf(screenercsv_path=screenercsv_path,
                     folder_path=folder_path, filepathpdf=filepathpdf)
    except Exception as e:
        print(f"⚠️ generate_notifications error: {e}")


    try:
        BT_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
        # Replace with desired output PDF file
        output_pdf_file = "/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf"
        create_pdf(BT_FILE_PATH, output_pdf_file, pageA4=True)
        time.sleep(5)
        post_telegram_file(
            "/home/rizpython236/BT5/screener-outputs/Full_BT_Screener.pdf")
    except Exception as e:
        print(f"⚠️ Full_BT_Screener error: {e}")

    try:
        filepathBTpdf = "/home/rizpython236/BT5/screener-outputs/BTbuy_Charts.pdf"
        screenercsvBT_path = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
        addchartspdf(screenercsv_path=screenercsvBT_path,
                     folder_path=folder_path, filepathpdf=filepathBTpdf)
    except Exception as e:
        print(f"⚠️ BTbuy_Charts error: {e}")

    try:
        base_dir_module = "/home/rizpython236/BT5"
        import_user_module(base_dir_module, "tradebookanalysis")
    except Exception as e:
        print(f"⚠️ tradebookanalysis error: {e}")
        # post_telegram_message("signal_changed_messages error")

    time.sleep(3)
    filepathBTpdf = "/home/rizpython236/BT5/screener-outputs/OpentradebookCharts.pdf"
    # screenercsvBT_path = "/home/rizpython236/BT5/screener-outputs/Opentradebook.csv"
    screenercsvBT_path = "/home/rizpython236/BT5/trade-logs/Opentradebook.csv"
    # addchartspdf(screenercsv_path=screenercsvBT_path,
    #             folder_path=folder_path, filepathpdf=filepathBTpdf)

    try:
        filepathBTpdf = "/home/rizpython236/BT5/screener-outputs/Top_score.pdf"
        # screenercsvBT_path = "/home/rizpython236/BT5/screener-outputs/Opentradebook.csv"
        screenercsvBT_path = "/home/rizpython236/BT5/screener-outputs/Top_score.csv"
        addchartspdf(screenercsv_path=screenercsvBT_path,
                     folder_path=folder_path, filepathpdf=filepathBTpdf)
    except Exception as e:
        print(f"⚠️ Top_score error: {e}")

    print("__________-----_______")

    dir6 = "/home/rizpython236/BT5/ticker_15yr"
    for f in os.listdir(dir6):
        os.remove(os.path.join(dir6, f))
    time.sleep(2)
    # manage_zip(mode="unzip")
    # import csv15yrs_short
    # import csv15yrs
    dir6 = "/home/rizpython236/BT5/ticker-csv-files"
    for f in os.listdir(dir6):
        # os.remove(os.path.join(dir6, f))
        1 + 1

    # import datadownload15yr
    # import relative_performance15yr
    # time.sleep(1)
    # import csv15yrs
    # import Drawdownchart15yr
    # import tradebookanalysis
    post_telegram_message("That was all for today!")
    dir6 = "/home/rizpython236/BT5/ticker_15yr"
    for f in os.listdir(dir6):
        # os.remove(os.path.join(dir6, f))
        1 + 1
    # shutdown_bot()
    # atexit.register(shutdown_bot)
    shutdown_bot()
    sys.exit(1)


MAX_RETRIES = 1

while MAX_RETRIES:
    try:
        main()
        MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(10)
        print("💀Operation Failed! Retrying...")
        print(traceback.format_exc())
        print(exc)
        print("-" * 50)
        sys.exit(1)
        MAX_RETRIES -= 1
