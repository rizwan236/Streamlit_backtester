import os
import sys
import time


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
import pandas as pd


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
from datetime import date, datetime, timedelta

from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    NIFTY_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    SYMBOLS_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    VALID_TICKERS_CSV,
)
import yfinance as yf


print("Initiating Data Downloader!")
end_date = date.today()
# start_date = end_date - timedelta(days=365)
start_date = end_date - timedelta(weeks=52)
END_DATE = str(end_date)
START_DATE = str(start_date)

# ticker_symbols_file = "symbol.csv"
tickers_df = pd.read_csv(SYMBOLS_CSV)
tickers_list = list(tickers_df["Symbol"].unique())[:]


# # Downloading data
print("-" * 100)
print("Starting download for data from {} to {}.".format(start_date, end_date))
print("-" * 100)

invalid_tickers = []
for symbol in tickers_list:

    # detecting invalid tickers
    ticker = yf.Ticker(symbol)
    ticker_info = None
    try:
        ticker_info = ticker.info
        reg_mp = ticker_info.get("regularMarketPrice")
        if not reg_mp:
            invalid_tickers.append(symbol)
            continue
    except:
        invalid_tickers.append(symbol)
        print("Invalid ticker - {}".format(symbol))
        continue

    print("Downloading data for => {}".format(symbol))
    data = yf.download(
        symbol,
        start=START_DATE,
        end=END_DATE,
        interval="1wk",
        rounding=True,
        threads=True,
        multi_level_index=False
    )
    ticker_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
    data.to_csv(ticker_csv_file_path)
    time.sleep(0.25)



print("Data download task completed.")
print("Validating data and removing incomplete ticker-data files.")


def get_filepaths(directory):
    """
    This function lists all the file names present in directory.
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)  # Add it to the list.

    return file_paths


# Filtering data based on missing weeks

files_to_process = get_filepaths(TICKER_CSV_DATA_FOLDER_PATH)

nifty_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + NIFTY_CSV
nifty_df = pd.read_csv(nifty_file_path)
nifty_df.dropna(inplace=True)
nifty_rows = len(nifty_df)
# print(nifty_rows)

nifty_start_date, nifty_end_date = nifty_df["Date"][0], nifty_df["Date"][nifty_rows - 1]
nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()

incomplete_data_tickers = []
valid_tickers = []


for file in files_to_process:
    """folder\\BHARTIAIRTEL.NS.csv"""
    ticker_name =file.split("/")[-1:][0]# file.split("\\")[1]
    ticker_name = ticker_name.split(".csv")[0]

    #print("Validating {} file".format(ticker_name))
    ticker_df = pd.read_csv(file)
    # print(len(ticker_df))

    # Drops rows where OHLC = 0 or value = NA
    ticker_df.dropna(inplace=True)
    ticker_df = ticker_df[ticker_df.Open != 0]
    ticker_df = ticker_df[ticker_df.High != 0]
    ticker_df = ticker_df[ticker_df.Low != 0]
    ticker_df = ticker_df[ticker_df.Close != 0]

    ticker_df.reset_index(drop=True, inplace=True)
    # print(len(ticker_df))
    ticker_df["Date"] = pd.to_datetime(ticker_df["Date"]).dt.date

    # Delete rows earlier than nifty start-date
    # ticker_df = ticker_df[ticker_df["Date"] >= nifty_start_date_obj]
    # Delete rows if any present after nifty end date
    ticker_df = ticker_df[ticker_df["Date"] <= nifty_end_date_obj]

    # print(len(ticker_df))

    # DECIDE - HOW TO FILTER

    # Only check if the total rows are atleast 52
    if len(ticker_df) >= 52:

        # Check if either rows are atleast 52 or atleast >= nifty-rows
        # if len(ticker_df) >= 52 or len(ticker_df) >= nifty_rows:

        valid_tickers.append(ticker_name)
        ticker_df.to_csv(file, index=False)
    else:
        incomplete_data_tickers.append(ticker_name)
        # deleting the incomplete ticker data file
        print(
            "Incomplete Data Ticker => {} with total rows => {}".format(
                ticker_name, len(file)
            )
        )
        # if os.path.exists(file):
        #     os.remove(file)

invalid_tickers_df = pd.DataFrame()
invalid_tickers_df["invalid_ticker"] = invalid_tickers
INVALID_TICKERS_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + INVALID_TICKERS_FILE
invalid_tickers_df.to_csv(INVALID_TICKERS_FILE_PATH, index=False)

valid_tickers_df = pd.DataFrame()
valid_tickers_df["Symbol"] = valid_tickers
vt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + VALID_TICKERS_CSV
valid_tickers_df.to_csv(vt_file_path, index=False)

incomplete_data_tickers_df = pd.DataFrame()
incomplete_data_tickers_df["Symbol"] = incomplete_data_tickers
idt_file_path = SCREENER_OUTPUT_FOLDER_PATH + "/" + INCOMPLETE_TICKERS_CSV
incomplete_data_tickers_df.to_csv(idt_file_path, index=False)
