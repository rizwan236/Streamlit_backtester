import os
import re
import sys
import time

#sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
#sys.path.insert(0, '/home/rizpython236/.virtualenvs/Pybroker39r/lib/python3.9/site-packages')
import numpy as np  #numpy-1.26.4   1.21.6   2.0.2
import pandas as pd
import pytz


print(f"Pandas version: {pd.__version__}")
print(f"Numpy version: {np.__version__} ")
#sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
from datetime import date, datetime, timedelta
import traceback

from custum_index import (
    calculate_custom_index,
    load_index_constituents_from_csv,
    plot_index_close_prices,
)
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
from settings import (
    INCOMPLETE_TICKERS_CSV,
    INVALID_TICKERS_FILE,
    NIFTY_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    SYMBOLS_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    VALID_TICKERS_CSV,
)

#from scipy.stats import gmean
#sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message
import yfinance as yf


def get_filepaths(directory):
    """
    This function lists all the file names present in directory.
    """
    file_paths = []  # List which will store all of the full filepaths.

    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)  # Add it to the list.

    return file_paths


valid_tickers =[]
SYMBOLS_CSV= "/home/rizpython236/BT5/symbol_list.csv"
ticker_csv_file_path = "/home/rizpython236/BT5/ticker_15yr"
TICKER_CSV_DATA_FOLDER_PATH ="/home/rizpython236/BT5/ticker_15yr"

files_to_process = get_filepaths(TICKER_CSV_DATA_FOLDER_PATH)
nifty_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + NIFTY_CSV
nifty_df = pd.read_csv(nifty_file_path )#, parse_dates=["Date"])
nifty_df.dropna(inplace=True)
nifty_rows = len(nifty_df)


'''
nifty_start_date, nifty_end_date = nifty_df["Date"][0], nifty_df["Date"][nifty_rows - 1]

if len(nifty_start_date) == 10:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date,"%Y-%m-%d").date()
elif len(nifty_start_date) == 25:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d %H:%M:%S%z").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d %H:%M:%S%z").date()
else:
    nifty_start_date_obj = datetime.strptime(nifty_start_date, "%Y-%m-%d").date()
    nifty_end_date_obj = datetime.strptime(nifty_end_date, "%Y-%m-%d").date()
'''
nifty_df["Date"] = pd.to_datetime(nifty_df["Date"], errors="coerce")

for file in files_to_process:
    """folder\\BHARTIAIRTEL.NS.csv"""
    ticker_name = file.split("/")[-1:][0]     #file.split("\\")[1]
    ticker_name = ticker_name.split(".csv")[0]

    #print("Validating {} file".format(ticker_name))
    ticker_df = pd.read_csv(file , parse_dates=["Date"])
    # print(len(ticker_df))

    # Drops rows where OHLC = 0 or value = NA
    ticker_df.dropna(inplace=True)
    ticker_df = ticker_df[ticker_df.Open != 0]
    ticker_df = ticker_df[ticker_df.High != 0]
    ticker_df = ticker_df[ticker_df.Low != 0]
    ticker_df = ticker_df[ticker_df.Close != 0]
    #ticker_df = ticker_df[ticker_df.Volume != 0] #
    #ticker_df = ticker_df[ticker_df.Close != ticker_df.Open] #
    ticker_df['Volume'] = ticker_df['Volume'].replace(0, 2)
    ticker_df['Volume'] = ticker_df['Volume'].fillna(1)

    ticker_df.reset_index(drop=True, inplace=True)
    Ticker_rows = len(ticker_df)
    # print(len(ticker_df))
    #ticker_df["Date"] = pd.to_datetime(ticker_df["Date"]).dt.date
    ticker_df["Date"] = pd.to_datetime(ticker_df["Date"], errors="coerce")

    ## Delete rows earlier than nifty start-date
    # ticker_df = ticker_df[ticker_df["Date"] >= nifty_start_date_obj]
    ## Delete rows if any present after nifty end date
    #########ticker_df = ticker_df[ticker_df["Date"] <= nifty_end_date_obj]

    #print(len(ticker_df),nifty_rows)
    # Keep only rows where Date is also in df2
    ticker_df = ticker_df[ticker_df["Date"].isin(nifty_df["Date"])]

    #print(len(ticker_df),nifty_rows)
    #print("_________")

    if len(ticker_df) >= nifty_rows: #>= 255:# and check_data_continuity:#  and is_data_rows_equals_nifty == True: #and check_data_continuity


        # Check if either rows are atleast 52 or atleast >= nifty-rows
        # if len(ticker_df) >= 52 or len(ticker_df) >= nifty_rows:
        #print(
        #    "Complete Data Ticker => {} with total rows => {} vs Nifty {} rows".format(
        #        ticker_name, Ticker_rows,nifty_rows
        #    )
        #)
        valid_tickers.append(ticker_name)
        ticker_df.to_csv(file, index=False)
    else:
        #incomplete_data_tickers.append(ticker_name)
        ###df_exclude = pd.concat([df_excludeold, pd.DataFrame({"Symbol": [ticker_name]})], ignore_index=True)
        #print('xxx')
        # deleting the incomplete ticker data file
        #print(
        #    "Incomplete Data Ticker => {} with total rows => {} vs Nifty {} rows".format(
        #        ticker_name, len(file),nifty_rows
        #    )
        #)
        if os.path.exists(file):
            1+1
            os.remove(file)


print("Total valid 15yr symbols: {}".format(len(valid_tickers)))
post_telegram_message("Total valid 15yr weekly symbols: {}".format(len(valid_tickers)))

