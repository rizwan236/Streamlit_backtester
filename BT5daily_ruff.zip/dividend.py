import sys
import time
import traceback

# sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.9/site-packages/")
import pandas as pd
import yfinance as yf

from PDFconvert import create_pdf
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")


# import requests

'''
from requests_ratelimiter import LimiterMixin, MemoryQueueBucket
from pyrate_limiter import Duration, RequestRate, Limiter

# Define the rate limit: 10 requests per minute
rate = RequestRate(10, Duration.MINUTE)
limiter = Limiter(rate)

# Create a custom session with a rate limiter
class RateLimitedSession(LimiterMixin):
    def __init__(self):
        # Initialize with a memory queue bucket and rate limiter
        super().__init__(limiter=limiter, bucket_class=MemoryQueueBucket)

# Replace yfinance's session with the rate-limited session
yf.shared._requests_session = RateLimitedSession()


from requests_ratelimiter import LimiterMixin, MemoryQueueBucket
from pyrate_limiter import Duration, RequestRate, Limiter
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from requests_cache import CachedSession

# Step 1: Set up the rate limiter
# Yahoo Finance may enforce strict limits on the number of API calls per IP.
# Here, we define a rate of 30 requests per hour (~1 request every 2 minutes).
rate = RequestRate(10, Duration.MINUTE)  # 30 requests/hour
limiter = Limiter(rate)  # Create the rate limiter instance

# Step 2: Create a custom session to enforce rate limiting
class RateLimitedSession(LimiterMixin):
    """
    A custom requests session that integrates a rate limiter.
    All requests made using this session will adhere to the defined rate limits.
    """
    def __init__(self):
        # Initialize with the specified limiter and a memory-based bucket
        super().__init__(limiter=limiter, bucket_class=MemoryQueueBucket)

# Step 3: Configure retries with exponential backoff
# This ensures the program retries a failed request (e.g., due to a 429 error)
# with increasing wait times between retries.
retry_strategy = Retry(
    total=3,  # Retry up to 5 times before failing
    backoff_factor=4,  # Wait 1, 2, 4, 8, etc., seconds between retries
    status_forcelist=[429, 500, 502, 503, 504],  # Retry only for specific HTTP errors
)
adapter = HTTPAdapter(max_retries=retry_strategy)

# Step 4: Add caching to minimize redundant API calls
# CachedSession will store responses locally for a set duration (e.g., 1 hour).
# If the same request is made again within this duration, the cached response is used.
#cached_session = CachedSession("yfinance_cache", expire_after=3600)  # Cache responses for 1 hour
cached_session = CachedSession(backend="memory", expire_after=3600)

# Mount the retry adapter to the cached session
cached_session.mount("https://", adapter)

# Replace yfinance's default session with our enhanced session
yf.shared._requests_session = RateLimitedSession()  # Add rate limiting
yf.shared._requests_session = cached_session       # Add caching

'''


# time.sleep(15*60)

# Load tickers from CSV file
tickers_df = pd.read_csv("/home/rizpython236/BT5/Final.csv")
# tickers_df = pd.read_csv('/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv')
tickers = tickers_df["Symbol"].tolist()
tickers = list(dict.fromkeys(tickers))[:]
# tickers = ["RELIANCE.NS","CERA.NS","WIPRO.NS","TCS.NS"]

# Create a DataFrame to store the dividends
dividends_df = pd.DataFrame(columns=["Symbol", "Dividend"])

# tickers =["ZYDUSLIFE.NS","AEGISLOG.BO"]

counter = 0

# Loop through tickers and get dividends
for ticker in tickers:
    try:
        counter += 1
        # Every 400 tickers, pause for 15 minutes (900 seconds)
        if counter % 200 == 0:
            print(f"Processed {counter} tickers. Pausing for 5 minutes...")
            time.sleep(5 * 60)  # Sleep for 15 minutes
        # Get the stock data from Yfinance
        # try:
        stock = yf.Ticker(ticker)
        # Get the annual dividend
        # industry = ticker.info.get('industry')
        # print(industry)
        # sector = ticker.info.get('sector')
        # print(sector)
        dividend1 = stock.info.get("dividendRate", 0)
        """
        except requests.exceptions.HTTPError as e:
            print(e)
            # Check if the error is a 429 error
            if 'Too Many Requests' in str(e):
                #print(e)
                print(f"Received 429 Too Many Requests for {ticker}. Pausing for 15 minutes...")
                time.sleep(15 * 60)  # Sleep for 15 minutes
                stock = yf.Ticker(ticker)
                dividend1 = stock.info.get('dividendRate',0)
                #continue  # Retry the current ticker after the sleep
            else:
                print(f"An error occurred for {ticker}: {e}")
                #continue  # Skip this ticker and move to the next one
        """

        dividend2 = 0  # stock.info.get('lastDividendValue',0)
        if dividend1 == 0:
            dividend3 = stock.info.get("trailingAnnualDividendRate", 0)
        else:
            dividend3 = 0  # stock.info.get('trailingAnnualDividendRate',0)
        dividend4 = 0  # stock.info.get("forwardAnnualDividendRate",0)
        # print(dividend1,"  ",dividend2,"  " ,dividend3,"  ",dividend4)
        dividend = max(dividend1, dividend2, dividend3, dividend4)
        print(ticker, " ", dividend, "--", dividend1, " ",
              dividend2, " ", dividend3, " ", dividend4)
        # ghghg
        # Append the ticker and dividend to the DataFrame
        if dividend > -0.1:
            dividends_df = dividends_df.append(
                {"Symbol": ticker, "Dividend": dividend}, ignore_index=True)
    except Exception as e:
        # ghgh
        # print(f"Error getting dividend for {ticker}")
        print(f"Error getting dividend for {ticker}: {type(e).__name__} - {e}")


valid_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df["Symbol"], valid_df["Company"]))


dividends_dfold = pd.read_csv(
    "/home/rizpython236/BT5/trade-logs/dividends.csv")

# Save the dividends to CSV file
dividends_df.to_csv(
    "/home/rizpython236/BT5/trade-logs/dividends.csv", index=False)
dividends_df = pd.read_csv("/home/rizpython236/BT5/trade-logs/dividends.csv")
# cached_session.clear()

"""
dividends_df = pd.DataFrame({
    'Symbol': ['Company A', 'Company B', 'Company C'],
    'Dividend': [1.2, 3.4, 2.5]
})

dividends_dfold = pd.DataFrame({
    'Symbol': ['Company A', 'Company B', 'Company F'],
    'Dividend': [1.0, 3.0, 2.5]
})

"""
"""
# Fill missing values in both DataFrames with np.nan
dividends_df['Symbol'].fillna(np.nan, inplace=True)
dividends_dfold['Symbol'].fillna(np.nan, inplace=True)

dividends_df['Symbol'] = dividends_df['Symbol'].astype(str)
dividends_dfold['Symbol'] = dividends_dfold['Symbol'].astype(str)

# Fill missing values with np.nan
dividends_dfold['Symbol'].fillna(np.nan, inplace=True)
# Set missing value indicator to a specific value (e.g., 'NA')
missing_value = 'NA'
#dividends_dfold.set_index('Symbol', inplace=True)  # Set Symbol as index
#dividends_dfold = dividends_dfold.reindex(dividends_df['Symbol'], fill_value=missing_value)  # Reindex with missing value indicator
dividends_dfold.reset_index(inplace=True)  # Reset index

# Check for missing values using isnull() or notnull()
print(dividends_dfold['Symbol'].isnull().any())  # Check for missing values
print(dividends_dfold['Symbol'].notnull().all())  # Check for all non-missing values
print(dividends_dfold['Symbol'].duplicated().any())


merged_df = pd.merge(dividends_df, dividends_dfold, on='Symbol',  how='left',suffixes=('_new', '_old'))
print(merged_df)

"""


# dividends_df['Symbol'].fillna(np.nan, inplace=True)
# dividends_dfold['Symbol'].fillna(np.nan, inplace=True)

# dividends_dfold['Company'] = dividends_dfold['Symbol'].map(symbol_to_company)
# dividends_df['Company'] = dividends_df['Symbol'].map(symbol_to_company)

dividends_df["Symbol"] = dividends_df["Symbol"].astype(str)
dividends_dfold["Symbol"] = dividends_dfold["Symbol"].astype(str)


# Ensure that 'Dividend' column exists in both DataFrames
if "Dividend" not in dividends_df.columns or "Dividend" not in dividends_dfold.columns:
    raise ValueError("'Dividend' column not found in one of the DataFrames")

# Fill NaN values in the 'Dividend' columns with 0
dividends_df["Dividend"].fillna(0.0, inplace=True)
dividends_dfold["Dividend"].fillna(0.0, inplace=True)


# Ensure the 'Dividend' columns are numeric, coercing any errors
dividends_dfold["Dividend"] = pd.to_numeric(
    dividends_dfold["Dividend"], errors="coerce")
dividends_df["Dividend"] = pd.to_numeric(
    dividends_df["Dividend"], errors="coerce")

# Drop rows with missing or NaN values in 'Dividend' columns
# dividends_df.dropna(subset=['Dividend'], inplace=True)
# dividends_dfold.dropna(subset=['Dividend'], inplace=True)

# print(dividends_dfold.columns)
# print(type(dividends_dfold))


# dividends_dfold = dividends_dfold.drop(columns=['Symbol'])
# dividends_df= dividends_df.drop(columns=['Symbol'])

# print(dividends_dfold)
# print(dividends_df)

# Merge the DataFrames on the 'Company' column
merged_df = pd.merge(dividends_df, dividends_dfold, on="Symbol", suffixes=(
    "_new", "_old"), how="left")  # indicator=True)


# Calculate the percentage increase in the dividend
merged_df["Dividend Chg (%)"] = round(
    ((merged_df["Dividend_new"] - merged_df["Dividend_old"]) / merged_df["Dividend_old"]) * 100, 2)

# print(merged_df)

# Filter companies with dividend increase greater than 50%
filtered_df = merged_df[merged_df["Dividend Chg (%)"] > 30]

filtered_dfdecline = merged_df[merged_df["Dividend Chg (%)"] < -20]

filtered_df = pd.concat([filtered_df, filtered_dfdecline])
filtered_df = filtered_df.sort_values(by="Dividend Chg (%)", ascending=False)


try:
    if len(filtered_df) > 0:
        # print(filtered_df)
        # Select the desired columns for the final DataFrame
        # result_df = filtered_df[['Symbol', 'Dividend_new', 'Dividend_old', 'Dividend Chg (%)']]

        # Map the 'Company' column in result_df to get the 'Ticker' using the dictionary created
        filtered_df["Company"] = filtered_df["Symbol"].map(symbol_to_company)
        filtered_df = filtered_df[[
            "Company", "Dividend_new", "Dividend_old", "Dividend Chg (%)"]]

        # Display or save the resulting DataFrame
        print(filtered_df)

        # Optionally, save the result to a new CSV file
        filtered_df.to_csv(
            "/home/rizpython236/BT5/screener-outputs/dividend_increase_over_50.csv", index=False)

        print("dividend_increase_over_50.csv saved successfully in folder_path")
        # Replace with your CSV file
        input_csv_file = "/home/rizpython236/BT5/screener-outputs/dividend_increase_over_50.csv"
        # Replace with desired output PDF file
        output_pdf_file = "/home/rizpython236/BT5/screener-outputs/dividend_increase_over_50.pdf"
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file, pageA4=False)
        time.sleep(10)
        post_telegram_file(
            "/home/rizpython236/BT5/screener-outputs/dividend_increase_over_50.pdf")
    else:
        print("No data found to write to dividend_increase_over_50.csv")
        post_telegram_message("No data found dividend_increase_over_50.csv")
except Exception as e:
    print(f"Error in pdf dividend_increase_over_50- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)


print("__________________________________________________________")
