from datetime import datetime

import backtrader as bt
import numpy as np
import pandas as pd
from scipy import stats


# regression slope of the past 90 days,top 20% momentum ranking, 100 day Mvg avg  https://teddykoker.com/2019/05/momentum-strategy-from-stocks-on-the-move-in-python/
class Momentum(bt.Indicator):
    lines = ("trend",)
    # params = (('period', 18),('upperband', 40),('lowerband', 0),)
    params = (("period", 8),)  # 18 weeks is 90 days, 12-60 days

    """def _plotinit(self):
        self.plotinfo.plotyhlines = [self.params.upperband, self.params.lowerband]"""

    def __init__(self):
        self.addminperiod(self.params.period)

    def next(self):
        returns = np.log(self.data.get(size=self.p.period))
        x = np.arange(len(returns))
        ##slope, _, r_value, _, _ = stats.linregress(x, returns)
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, returns)
        #slope, intercept, r_value, p_value, std_err = stats.linregress(x, ts)
        #annualized_slope =  (np.power((1 + slope), 50)-1)*100 # (np.power(np.exp(slope), 50) - 1) * 100  # 50 weeks in a 252 day year
        #print(round(annualized_slope * (r_value ** 2), 0))
        #annualized_slope =  (1 + slope) ** 50)*100
        #annualized_slope = (np.power(np.exp(slope), 52) -1) *100  #52 or 252
        annualized_slope = (np.power((1+slope), 52)) *100
        #annualized_slope = (np.power((1+slope), 50) -1) *100

        #self.lines.trend[0] = round(annualized_slope,2)# * (r_value ** 2), 0)
        n = len(x)
        k = 1  # Number of predictors (independent variables)
        adj_r_squared = 1 - ((1 - r_value) * (n - 1) / (n - k - 1))

        annualized_slope_r_value = round(annualized_slope * (adj_r_squared ** 2),2)
        #rounded_annualized_slope = round(annualized_slope, 2)
        # Calculate the maximum of the two values
        #higher_value = max(annualized_slope_r_value, rounded_annualized_slope)
        self.lines.trend[0]=annualized_slope_r_value



