import csv
import time

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from telegram_bot import post_telegram_file


print("start sector_rotation chart")
"""
# Step 1: Read the valid CSV file
valid_file = '/home/rizpython236/BT5/screener-outputs/industry.csv'
valid_data = {}
with open(valid_file, 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        symbol = row['Symbol']
        industry = row['Industry']
        valid_data[symbol] = industry

# Step 2: Read the transaction CSV file
transaction_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
symbol_counts = {}
signal_counts = {}
with open(transaction_file, 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        symbol = row['ticker']
        signal = row['dir']
        symbol_counts[symbol] = symbol_counts.get(symbol, 0) + 1
        industry = valid_data.get(symbol)
        if industry:
            if industry not in signal_counts:
                signal_counts[industry] = {'BUY': 0, 'SELL': 0, 'NONE': 0}
            signal_counts[industry][signal] += 1

# Step 3: Calculate percentages and write the final CSV file
final_file = '/home/rizpython236/BT5/screener-outputs/sectorperf.csv'
with open(final_file, 'w', newline='') as file:
    fieldnames = ['Industry', 'BUY', 'SELL', 'NONE']
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()

    total_industries = len(signal_counts)
    for industry, counts in signal_counts.items():
        symbol_count = sum(symbol_counts.get(symbol, 0) for symbol in valid_data if valid_data[symbol] == industry)
        buy_percentage = counts['BUY'] / symbol_count * 100 if symbol_count else 0
        sell_percentage = counts['SELL'] / symbol_count * 100 if symbol_count else 0
        none_percentage = (symbol_count - sum(counts.values())) / symbol_count * 100 if symbol_count else 0

        writer.writerow({
            'Industry': industry,
            'BUY': f'{buy_percentage:.1f}%',
            'SELL': f'{sell_percentage:.1f}%',
            'NONE': f'{none_percentage:.1f}%'
        })

"""
"""
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
#today = datetime.now()
if today.day <= 7:
    transaction_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_mhtly_Screener.csv'
else:
    transaction_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
"""

# file_path= '/home/rizpython236/BT5/screener-outputs/trade_list_BT_mhtly_Screener.csv'
# if os.path.exists(file_path):
#    transaction_file = '/home/rizpython236/BT5/screener-outputs/Watchlist.csv'
# else:
#    1+1
#    #transaction_file = '/home/rizpython236/BT5/screener-outputs/trade_list_Talib_Screener.csv'  #trade_list_BT_Screener.csv'


# Step 1: Read the valid CSV file
valid_file = "/home/rizpython236/BT5/screener-outputs/industry.csv"
valid_data = {}
sector_counts = {}
with open(valid_file) as file:
    reader = csv.DictReader(file)
    for row in reader:
        symbol = row["Symbol"]
        industry = row["MYindustry"]  # row['Industry']
        valid_data[symbol] = industry
        if industry not in sector_counts:
            sector_counts[industry] = 0
        sector_counts[industry] += 1

# Print the count of symbols in each sector
for sector, count in sector_counts.items():
    1 + 1
    # print(f"Sector: {sector}, Symbol Count: {count}")


# Step 2: Read the transaction CSV file
transaction_file = "/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv"
symbol_counts = {}
signal_counts = {}
with open(transaction_file) as file:
    reader = csv.DictReader(file)
    for row in reader:
        symbol = row["ticker"]
        signal = row["dir"]
        symbol_counts[symbol] = symbol_counts.get(symbol, 0) + 1
        industry = valid_data.get(symbol)
        if industry:
            if industry not in signal_counts:
                signal_counts[industry] = {
                    "BUY": 0, "SELL": 0, "NONE": 0, "Sector Count": 0}
            signal_counts[industry][signal] += 1
            # signal_counts[industry]['Sector Count'] = sector_counts[industry]

# Step 3: Calculate percentages and write the final CSV file
final_file = "/home/rizpython236/BT5/screener-outputs/sectorperf.csv"
with open(final_file, "w", newline="") as file:
    fieldnames = ["Industry", "Sector Count", "BUY", "SELL", "NONE"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()

    total_industries = len(signal_counts)
    for industry, counts in signal_counts.items():
        # for industry, counts in signal_counts.items():
        # symbol_count = counts['Sector Count'] if 'Sector Count' in counts else 0
        # symbol_count=counts.get('Sector Count', 0)
        symbol_count = sector_counts[industry] if industry in sector_counts else 0
        buy_percentage = counts["BUY"] / \
            symbol_count * 100 if symbol_count else 0
        sell_percentage = counts["SELL"] / \
            symbol_count * 100 if symbol_count else 0
        none_percentage = (symbol_count - sum(counts.values())) / \
            symbol_count * 100 if symbol_count else 0

        writer.writerow({
            "Industry": industry,
            "Sector Count": symbol_count,
            "BUY": f"{buy_percentage:.2f}%",
            "SELL": f"{sell_percentage:.2f}%",
            "NONE": f"{none_percentage:.2f}%",
        })

print("completed 1st part")
# print(final_file)


# Read the CSV file into a pandas DataFrame
data = pd.read_csv("/home/rizpython236/BT5/screener-outputs/sectorperf.csv")


# Remove the '%' symbol from the data
data = data.replace("%", "", regex=True)
data["BUY"] = pd.to_numeric(data["BUY"], errors="coerce")
data = data.sort_values("BUY", ascending=False)
"""
# Create the table plot
fig, ax = plt.subplots(figsize=(10, 6))
ax.axis('off')
table = ax.table(cellText=data.values, colLabels=data.columns, loc='center', cellLoc='center')

# Set the table properties
table.auto_set_font_size(False)
table.set_fontsize(12)
#table.scale(1.2, 1.2)

# Set column width to fit content
for i, key in enumerate(data.columns):
    col_width = max([len(str(val)) for val in data[key]])
    table.auto_set_column_width([i])
    table[0, i].set_width(col_width * 1.2)  # Adjust the multiplier as needed for better spacing

# Increase padding in the last 3 columns
last_three_columns = data.columns[-3:]
padding_value = 5  # Adjust the padding value as needed
for col in last_three_columns:
    col_index = data.columns.get_loc(col)
    for row in range(1, len(data) + 1):  # Start from 1 to skip header row
        cell_text = table[row, col_index].get_text().get_text()
        table[row, col_index].get_text().set_text(f"{cell_text:>{col_width + padding_value}}")

# Save the table as a PNG file
plt.savefig('/home/rizpython236/BT5/screener-outputs/industry_table.png', bbox_inches='tight', pad_inches=0.5, dpi=300)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/industry_table.png')
#os.remove('/home/rizpython236/BT5/screener-outputs/industry_table.png')
#os.remove('/home/rizpython236/BT5/screener-outputs/industry.csv')
#os.remove(final_file)
print("completed sector image")
"""

##############################
# Read the CSV file into a pandas DataFrame
data = pd.read_csv("/home/rizpython236/BT5/screener-outputs/sectorperf.csv")


# Remove the '%' symbol from the data
data = data.replace("%", "", regex=True)
data["BUY"] = pd.to_numeric(data["BUY"], errors="coerce")
data["SELL"] = pd.to_numeric(data["SELL"], errors="coerce")
data["NONE"] = pd.to_numeric(data["NONE"], errors="coerce")

data["Sector Count"] = data["Sector Count"].astype(int)
data["Industry"] = data["Industry"] + "-" + data["Sector Count"].astype(str)

data = data.sort_values("Sector Count", ascending=False)
data = data[data["Industry"] != "-###-"]

"""
# Calculate the total for each industry
data['Total'] = data['BUY'] + data['SELL'] + data['NONE']

# Calculate the percentages for 'BUY' and 'SELL' within each industry
data['Buy_Percentage'] = round((data['BUY'] / data['Total']) * 100,1)
data['Sell_Percentage'] = round((data['SELL'] / data['Total']) * 100,1)
print(data)
"""
"""
# Plot the histogram
plt.figure(figsize=(18, 8))
sns.barplot(x='Industry', y='BUY', data=data, color='green', label='BUY')
sns.barplot(x='Industry', y='SELL', data=data, color='red', bottom=data['BUY'], label='SELL')
sns.barplot(x='Industry', y='NONE', data=data, color='yellow', label='HOLD')

plt.title('100% Stacked Histogram of Signal based on all valid tickers ')
plt.xlabel('Industry with count')
plt.ylabel('Percentage')
plt.legend(title='Signal')
plt.xticks(rotation=90, ha='right')
plt.subplots_adjust(wspace=0.1, hspace=0.1)
#plt.grid(axis='y', linestyle='--', alpha=0.7)
# Set grid properties
#plt.yticks(range(0, 101, 10))
plt.grid(axis='y', linestyle='--', alpha=0.7, linewidth=1, color='black')
# Add a permanent horizontal grid line at 50
#plt.axhline(y=50, color='black', linestyle='-', linewidth=2)
plt.legend(loc='upper left', bbox_to_anchor=(0, 1))
#plt.legend(loc='upper right', bbox_to_anchor=(1.15, 1))
plt.tight_layout()
chart_path = '/home/rizpython236/BT5/screener-outputs/sectorperf.png'
#plt.savefig(chart_path)
#time.sleep(2)
#post_telegram_file(chart_path)

#print('done')
"""

# 3
plt.figure(figsize=(18, 8))

# Use Seaborn's barplot for 'BUY'
ax = sns.barplot(x="Industry", y="BUY", data=data, color="green", label="BUY")

# Use Seaborn's barplot for 'SELL' on top of 'BUY'
ax = sns.barplot(x="Industry", y="SELL", data=data,
                 color="red", bottom=data["BUY"], label="SELL")

# Use Seaborn's barplot for 'HOLD' on top of 'SELL'
ax = sns.barplot(x="Industry", y="NONE", data=data, color="yellow",
                 bottom=data["BUY"] + data["SELL"], label="HOLD")

plt.title("Stacked Bar Chart with Grouping of Signal based on all valid tickers")
plt.xlabel("Industry with count")
plt.ylabel("Percentage")
plt.legend(title="Signal")
plt.axhline(y=50, color="black", linestyle="-", linewidth=2)
plt.xticks(rotation=90, ha="right")
plt.subplots_adjust(wspace=0.1, hspace=0.1)
plt.grid(axis="y", linestyle="--", alpha=0.7, linewidth=1, color="black")

# Set the legend inside the chart in the top-left corner
plt.legend(loc="upper left", bbox_to_anchor=(0, 1))

plt.tight_layout()
chart_path = "/home/rizpython236/BT5/screener-outputs/sectorperf.png"
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)

print("done")
