import os
import sys
import time

import pytz


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
import numpy as np
import pandas as pd
import yfinance as yf


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
import talib


sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.13/site-packages/")
from datetime import datetime, timedelta
import traceback

import pandas_ta as ta
from telegram_bot import post_telegram_message




'''
source virtualenvwrapper.sh && workon rizenv && python /home/rizpython236/BT5/trade_compiler.py
source /home/rizpython236/.virtualenvs/rizenv/bin/activate && python /home/rizpython236/BT5/scheduler2.py

pip install python-telegram-bot==12.8
pip install python-telegram-bot==13.15
deactivate
rmvirtualenv rizenv
rm -rf ~/.cache/
mkvirtualenv --python=python3.7 rizenvnew
pip cache purge
https://help.pythonanywhere.com/pages/RebuildingVirtualenvs
mkvirtualenv myvirtualenv --python=/usr/bin/python3.10
pip freeze > /home/rizpython236/BT5/requirements.txt



START_DATE = "2022-01-01"
END_DATE = "2022-01-31"

ticker_symbol = "MSFT"

try:
    nifty_data = yf.download(ticker_symbol, start=START_DATE, end=END_DATE, interval="1d", rounding=True, repair=False)
    print(nifty_data)
except Exception as e:
    print("An error occurred while fetching data for", ticker_symbol, ":", e)
'''

print("Python version:", sys.version)

def calculate_mrp(data, Nifty):
    # Load stock and index data from CSV files
    stock_data = data
    index_data = Nifty

    stock_data['Close'] = stock_data['Close'].pct_change()
    index_data['Close'] = index_data['Close'].pct_change()

    stock_data['Stock_Cumulative_Return'] = 100*(1 + stock_data['Close']).cumprod()
    index_data['Dow_Cumulative_Return'] = 100*(1 + index_data['Close']).cumprod()

    # Adjust initial value calculation
    stock_data1 = pd.DataFrame()
    index_data1 = pd.DataFrame()
    initial_value = 1
    stock_data1['Close'] = initial_value * stock_data['Stock_Cumulative_Return']
    index_data1['Close'] = initial_value * index_data['Dow_Cumulative_Return']

    # Calculate Relative Performance (RP)
    RP = (stock_data1["Close"] / index_data1["Close"]) * 1
    RP=round(RP,4)
    RP = RP.reset_index(drop=True)


    # Calculate RP52W (Simple Moving Average over 52 weeks)
    #RP52W = RP.ewm(span=3).mean()  #RP.rolling(window=60).mean()

    # Calculate Mansfield Relative Performance (MRP)
    #MRP = ((RP / RP52W) - 1) * 100

    # Add MRP values to the stock data
    stock_data["MRP"] = RP


    #print(type(stock_data))
    #print(type(RP))
    #print(stock_data.columns)
    #print(RP.columns)
    #print(RP.head())
    #RP = RP.reset_index()

    # Save the updated stock data to a new CSV file
    #stock_data = pd.merge(stock_data, RP, how='left')# on='common_column_name')
    stock_data = pd.concat([stock_data.reset_index(drop=True), RP], axis=1)
    #stock_data.to_csv(data, index=False)
    #print(stock_data)
    return stock_data


def calculate_mrp1(data, Nifty):  #chatgpt
    # Load stock and index data from CSV files
    stock_data = data
    index_data = Nifty

    # Calculate daily percentage change
    stock_data['Close'] = stock_data['Close'].pct_change()
    index_data['Close'] = index_data['Close'].pct_change()

    # Calculate cumulative returns
    stock_data['Stock_Cumulative_Return'] = 100 * (1 + stock_data['Close']).cumprod()
    index_data['Dow_Cumulative_Return'] = 100 * (1 + index_data['Close']).cumprod()

    # Adjust initial value calculation
    initial_value = 1
    stock_data1 = pd.DataFrame({'Close': initial_value * stock_data['Stock_Cumulative_Return']})
    index_data1 = pd.DataFrame({'Close': initial_value * index_data['Dow_Cumulative_Return']})

    # Calculate Relative Performance (RP)
    RP = (stock_data1["Close"] / index_data1["Close"]).round(4)

    # Convert RP Series to DataFrame
    RP_df = RP.reset_index(drop=True)  # Resetting index to ensure alignment
    RP_df.columns = ['MRP']  # Rename the column for clarity

    # Add MRP values to the stock data
    stock_data = pd.concat([stock_data.reset_index(drop=True), RP_df], axis=1)

    # Optionally save the updated stock data to a new CSV file
    # stock_data.to_csv('updated_stock_data.csv', index=False)
    #print(stock_data)
    return stock_data



IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
end_date = datetime.now(IST_TIMEZONE).date()
start_date = end_date - timedelta(weeks=160) #75 weekly
END_DATE = str(end_date)
START_DATE = str(start_date)



# List of stocks to load
Benchamrk=["^NSEI"]
stock_symbols = ["RELIANCE.NS","TATATECH.NS","BAJAJHFL.NS","PAUSHAKLTD.BO","BORORENEW.NS","TATVA.NS","TARSONS.NS","POLYCAB.NS","RAJRATAN.NS","RHIM.NS","JSWSTEEL.NS","COSMOFIRST.NS","POLYPLEX.NS","XELPMOC.NS","^NSEI","BSE-500.BO","^NSEBANK","^CRSLDX","PSUBNKBEES.BO","^CNXAUTO","^CNXREALTY" ,"^CNXCMDT","^CNXMETAL","^CNXINFRA","PHARMABEES.NS","NIFTY_FIN_SERVICE.NS","^CNXFMCG","^CNXCONSUM","^CNXMEDIA","^CNXIT","HNGSNGBEES.NS","MAHKTECH.NS","EEM","^DJI","^IXIC","BTC-USD","GOLDBEES.NS"]
#stock_symbols=['MPHASIS.NS',"RELIANCE.NS"]


# Set the Exchange to use.
# Available Exchanges: "ASX", "BMF", "DIFX", "FWB", "HKE", "JSE", "LSE", "NSE", "NYSE", "NZSX", "RTS", "SGX", "SSE", "TSE", "TSX"
#ta.exchange = "NSE"
start_dateVIX = end_date - timedelta(days=1) #75 weekly
START_DATEVIX = str(start_dateVIX)
try:
    VIX = yf.download('^INDIAVIXzzzz', start=START_DATEVIX, end=END_DATE,interval="1d",rounding=True,repair=False,multi_level_index=False) #, timeout=10
    print(VIX)
    VIX = VIX['Close'].iloc[0]
    VIXDate = END_DATE#VIX['Date'] #END_DATE
    print(f"Date: {VIXDate}, VIX: {VIX}")
    #print(f"VIX: {VIX}")
    post_telegram_message(f"Date: {VIXDate}, VIX: {VIX}")
except Exception as e:
    print(f"Error occurred for VIX: {str(e)}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass



Nifty = yf.download(Benchamrk, start=START_DATE, end=END_DATE,interval="1d",rounding=True,repair=False,multi_level_index=False)
#print(Nifty)
Nifty = Nifty[Nifty.Open != 0]
Nifty = Nifty[Nifty.High != 0]
Nifty = Nifty[Nifty.Low != 0]
Nifty = Nifty[Nifty.Close != 0]
#data = data[data.Volume != 0] #
#data = data[data.Close != data.Open] #
Nifty.reset_index(drop=True, inplace=True)
Nifty_close = Nifty['Close']



for symbol in stock_symbols:
    try:
        time.sleep(1)
        strings=[]
        # Load price volume data for each stock
        data = yf.download(symbol, start=START_DATE, end=END_DATE,interval="1d",rounding=True,repair=False,multi_level_index=False)
        #print(data)
        # Check for 0 or NaN values
        if 1==0: #data.isnull().values.any() or (data == 0).any().any():
            print(f"Data quality is not good for {symbol}. Missing or zero values detected.")
        else:
            data.dropna(inplace=True)
            data = data[data.Open != 0]
            data = data[data.High != 0]
            data = data[data.Low != 0]
            data = data[data.Close != 0]
            #data = data[data.Volume != 0] #
            #data = data[data.Close != data.Open] #
            data.reset_index(drop=True, inplace=True)

            calculate_mrp(data, Nifty)
            latestMRP=round(data['MRP'].iloc[-1],2)


            #print(latestMRP)


            # Calculate 200-day simple moving average (SMA)
            close_prices = data['Close']
            MRP_level =data['MRP']
            latest_price = close_prices.iloc[-1]
            open_prices = data['Open']
            low_prices = data['Low']
            high_prices = data['High']
            volume_prices = data['Volume']
            sma_90MRP = talib.EMA(np.array(MRP_level), timeperiod=200)
            sma_30MRP = talib.EMA(np.array(MRP_level), timeperiod=90)
            #close_prices = np.array(close_prices).flatten()
            sma_200 = talib.SMA(np.array(close_prices).flatten(), timeperiod=200)
            sma_100 = talib.SMA(np.array(close_prices).flatten(), timeperiod=100)
            sma_50 = talib.SMA(np.array(close_prices).flatten(), timeperiod=50)
            ema_200 = talib.EMA(np.array(close_prices).flatten(), timeperiod=200)
            ema_100 = talib.EMA(np.array(close_prices).flatten(), timeperiod=100)
            ema_50 = talib.EMA(np.array(close_prices).flatten(), timeperiod=50)
            ema_20 = talib.EMA(np.array(close_prices).flatten(), timeperiod=20)
            cci = talib.CCI(np.array(high_prices).flatten(), np.array(low_prices).flatten(), np.array(close_prices).flatten(), timeperiod=34*5)
            #supertrend = ta.supertrend(high=data['High'],low=data['Low'],close=data['Close'])
            yrlow1 = talib.MIN(np.array(close_prices).flatten(), timeperiod=252)
            yrhigh1 = talib.MAX(np.array(close_prices).flatten(), timeperiod=252)
            pos1yr= round((latest_price-yrlow1[-1])*100/(yrhigh1[-1]-yrlow1[-1]),2)
            yrlow3 = talib.MIN(np.array(close_prices).flatten(), timeperiod=366*2)
            yrhigh3 = talib.MAX(np.array(close_prices).flatten(), timeperiod=366*2)
            pos3yr= round((latest_price-yrlow3[-1])*100/(yrhigh3[-1]-yrlow3[-1]),2)
            #vwma50 = ta.vwma(np.array(close_prices), np.array(volume_prices), length=50)
            #vwma20 = ta.vwma(np.array(close_prices), np.array(volume_prices), length=20)
            # Combine stock and benchmark data into a single DataFrame
            close_prices = np.array(close_prices).flatten()  # Ensure it's a one-dimensional array
            Nifty_close = np.array(Nifty_close).flatten()    # Ensure it's a one-dimensional array


            #df = pd.DataFrame({'Stock': close_prices, 'Benchmark': Nifty_close}).dropna()
            #RS = ta.rsi(np.array(close_prices), length=55) / ta.rsi(np.array(Nifty_close), length=55)
            #RS55 = ta.rsi(df['Stock'], length=55) / ta.rsi(df['Benchmark'], length=55)

            close_prices = pd.Series(close_prices)  # Convert to Pandas Series
            #cci = pd.Series(cci)  # Convert to Pandas Series
            # Get the latest data
            latest_price = close_prices.iloc[-1]
            latest_cci = cci[-1]
            CCIx=round(cci[-1],0)
            #latest_RS55 = RS55[-1]
            print(f"{symbol}, Price {latest_price},CCI {round(CCIx,0)},Ema_200 {round(ema_200[-1],1)},Ema_100 {round(ema_100[-1],1)},wk52pos {pos1yr}%")

            # Check for CCI crossover
            #print(f"CCI {round(cci[-1],1)},{symbol}")
            if cci[-3] < 50 and cci[-1] > 50:
                #print(f"CCI crossover for {symbol}. CCI crossed above zero.")
                strings.append(f"↺▲ CCI crossover for {symbol} {CCIx}. Above 50.")
            elif cci[-3] > 50 and cci[-1] < 50:
                #print(f"CCI crossover for {symbol}. CCI crossed below zero.")
                strings.append(f"↺▼ CCI crossover for {symbol} {CCIx}. Below 50.")
            else:
                1+1
                #print(f"No CCI crossover detected for {symbol}.")

            #print(f"CCI {round(cci[-1],1)},{symbol}")
            if  cci[-1] > 50:
                print(f"CCI for {symbol}. CCI crossed above 50.")
                strings.append(f"▲ CCI {symbol} {CCIx}. Above 50.")
            elif cci[-1] < 0:
                print(f"CCI  for {symbol}. CCI crossed below zero.")
                strings.append(f"▼ CCI {symbol} {CCIx}. Below zero.")
            else:
                1+1
                #print(f"No CCI crossover detected for {symbol}.")


            #time.sleep(1)
            # Check for EMA crossover
            if ema_50[-3] < sma_200[-3] and ema_50[-1] > sma_200[-1]:
                #print(f"EMA crossover for {symbol}. 50 EMA crossed above 200 SMA.")
                strings.append(f"↺▲ {symbol} 50 EMA crossover above 200 SMA.")
            elif ema_50[-3] > sma_200[-3] and ema_50[-1] < sma_200[-1]:
                #print(f"EMA crossover for {symbol}. 50 EMA crossed below 200 SMA.")
                strings.append(f"↺▼ {symbol} 50 EMA crossover below 200 SMA.")
            else:
                1+1
                #print(f"No 200EMA crossover detected for {symbol}.")
                #post_telegram_message(f"No SMA crossover detected for {symbol}.")

            if ema_50[-1] > sma_200[-1]:
                print(f"EMA for {symbol}. 50 EMA  above 200 SMA.")
                #strings.append(f"▲ {symbol} 50 EMA above 200 SMA.")
            elif ema_50[-1] < sma_200[-1]:
                print(f"EMA for {symbol}. 50 EMA  below 200 SMA.")
                #strings.append(f"▼ {symbol} 50 EMA below 200 SMA.")
            else:
                1+1

            #time.sleep(1)
            # Check for EMA crossover
            if ema_50[-3] < sma_100[-3] and ema_50[-1] > sma_100[-1]:
                #print(f"EMA crossover for {symbol}. 50 EMA crossed above 100 SMA.")
                strings.append(f"↺▲ {symbol} 50 EMA crossover above 100 SMA.")
            elif ema_50[-3] > sma_100[-3] and ema_50[-1] < sma_100[-1]:
                #print(f"EMA crossover for {symbol}. 50 EMA crossed below 100 SMA.")
                strings.append(f"↺▼ {symbol} 50 EMA crossover below 100 SMA.")
            else:
                1+1
                #print(f"No 100EMA crossover detected for {symbol}.")
                #post_telegram_message(f"No SMA crossover detected for {symbol}.")

            #time.sleep(1)
            # Check for EMA crossover
            if ema_20[-3] < sma_100[-3] and ema_20[-1] > sma_100[-1]:
                print(f"EMA crossover for {symbol}. 20 EMA crossed above 100 SMA.")
                #strings.append(f"↺▲ {symbol} 20 EMA crossover above 100 SMA.")
            elif ema_20[-3] > sma_100[-3] and ema_20[-1] < sma_100[-1]:
                print(f"EMA crossover for {symbol}. 20 EMA crossed below 100 SMA.")
                #strings.append(f"↺▼ {symbol} 20 EMA crossover below 100 SMA.")
            else:
                1+1
                #print(f"No 100EMA crossover detected for {symbol}.")

            # Check for EMA crossover
            if ema_100[-3] < sma_200[-3] and ema_100[-1] > sma_200[-1]:
                #print(f"EMA crossover for {symbol}. 100 EMA crossed above 200 SMA.")
                strings.append(f"↺▲ {symbol} 100 EMA crossover above 200 SMA.")
            elif ema_100[-3] > sma_200[-3] and ema_100[-1] < sma_200[-1]:
                #print(f"EMA crossover for {symbol}. 100 EMA crossed below 200 SMA.")
                strings.append(f"↺▼ {symbol} 100 EMA crossover below 200 SMA.")
            else:
                1+1
                #print(f"No 100EMA crossover detected for {symbol}.")

            if ema_100[-1] > sma_200[-1]:
                print(f"EMA  for {symbol}. 100 EMA crossed above 200 SMA.")
                #strings.append(f"▲ {symbol} 100 EMA above 200 SMA.")
            elif ema_100[-1] < sma_200[-1]:
                print(f"EMA for {symbol}. 100 EMA crossed below 200 SMA.")
                #strings.append(f"▼ {symbol} 100 EMA below 200 SMA.")
            else:
                1+1

            #time.sleep(1)
            # Check if the latest price is at a 52-week low or high
            if latest_price <= yrlow1[-2]:
                #print(f"The latest price for {symbol} is at a 1yr low.")
                strings.append(f"▼ {symbol} at a 1yr low.")
            elif latest_price >= yrhigh1[-2]:
                #print(f"The latest price for {symbol} is at a 1yr high.")
                strings.append(f"▲ {symbol} at a 1yr high.")
            else:
                #wk52pos=round((latest_price/yrhigh1[-1])*100,2)
                print(f"1yr position for {symbol} is {pos1yr}%")
                #strings.append(f"1yr pos {symbol} is {pos1yr}%")
                #post_telegram_message(f"52wk position for {symbol} is {wk52pos}%")

            time.sleep(1)
            # Check if the latest price is at a 3 year low or high
            if latest_price <= yrlow3[-3]:
                #print(f"↓ The latest price for {symbol} is at a 2yr low.")
                strings.append(f"▼ {symbol} at a 2yr low.")
            elif latest_price >= yrhigh3[-3]:
                #print(f"The latest price for {symbol} is at a 2yr high.")
                strings.append(f"▲ {symbol} at a 2yr high.")
            else:
                #pos3yr = pd.Series(pos3yr)
                #symbol = pos3yr.index[0]  # This gets the first (and only) index
                #value = pos3yr[symbol]
                #print(f"2yr position for {symbol} is {value}")

                #yr3pos=round((latest_price/yrhigh3[-1])*100,2)
                print(f"2yr position for {symbol} is {pos3yr}%")
                #strings.append(f"2yr position for {symbol} is {pos3yr}%")
                if True==True:# pos3yr >-1:
                    1+1
                    #print(pos3yr)
                    #strings.append(f"3yr pos {symbol} is {pos3yr}%")
                    #post_telegram_message(f"3-yr position for {symbol} is {yr3pos}%")
                else:
                    1+1

            #time.sleep(1)
            # Check if the latest price is at a 52-week low or high
            if sma_90MRP[-1]*1.05 < sma_30MRP[-1] and sma_90MRP[-5] > sma_30MRP[-5]*1.05:
                #print(f"latestMRP {symbol} is {latestMRP}")
                strings.append(f"↺▲ MRP30 > MRP200 crossover {symbol} is {latestMRP}")
            elif sma_90MRP[-1] > sma_30MRP[-1]*1.05 and sma_90MRP[-5]*1.05 < sma_30MRP[-5]:
                #print(f"latestMRP {symbol} is {latestMRP}")
                strings.append(f"↺▼ MRP30 < MRP200 crossover {symbol} is {latestMRP}")
            else:
                1+1

            '''
            time.sleep(1)
            # Check for vwma crossover
            if vwma20[-2] < vwma50[-2] and vwma20[-1] > vwma50[-1]*1.02:
                print(f"vwma crossover for {symbol}. 20 vwma crossed above 50 vwma.")
                post_telegram_message(f"vwma50 crossover for {symbol}. 20 vwma crossed above 50 vwma.")
            elif vwma20[-2] > vwma50[-2] and vwma20[-1]*1.02 < vwma50[-1]:
                print(f"vwma crossover for {symbol}. 20 vwma crossed below 50 vwma.")
                post_telegram_message(f"vwma crossover for {symbol}. 20 vwma crossed below 50 vwma.")
            else:
                print(f"No vwma crossover detected for {symbol}.")



            # Check if 200 SMA < latest price
            if sma_200[-1] < latest_price:
                print(f"200 SMA is less than the latest price for {symbol}.")
                post_telegram_message(START_DATE)
            else:
                print(f"200 SMA is greater than or equal to the latest price for {symbol}.")
                post_telegram_message(START_DATE)
            '''
        time.sleep(2)
        post_telegram_message('\n'.join(strings))
        print('\n'.join(strings))

    except Exception as e:
        print(f"Error occurred for {symbol}: {str(e)}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass

#post_telegram_message('\n'.join(strings))
#time.sleep(2)
#post_telegram_message('\n'.join(yr3strings))
#time.sleep(2)
#post_telegram_message('\n'.join(yr1high))
#time.sleep(2)
#post_telegram_message('\n'.join(yr1low))
#time.sleep(2)
#post_telegram_message('\n'.join(yr3high))
#time.sleep(2)
#post_telegram_message('\n'.join(yr3low))

print("done")


