import os
import pandas as pd
import pytz
import numpy as np
from scipy import stats
import time
from telegram_bot import post_telegram_message, post_telegram_file
import sys
import talib as tb
import traceback
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates
import pandas_market_calendars as mcal
from datetime import datetime, timedelta
from PDFconvert import create_pdf, delete_file

# Constants and Configuration
class Config:
    IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
    BASE_PATH = "/home/rizpython236/BT5/"
    TICKER_15YR_PATH = os.path.join(BASE_PATH, "ticker_15yr/")
    SCREENER_OUTPUTS = os.path.join(BASE_PATH, "screener-outputs/")
    TRADE_LOGS = os.path.join(BASE_PATH, "trade-logs/")
    SYMBOL_LIST = os.path.join(BASE_PATH, "symbol_list.csv")
    NSEI_FILE = os.path.join(TICKER_15YR_PATH, "^NSEI.csv")
    TJI_INDEX_FILE = os.path.join(TRADE_LOGS, "TJI_index.csv")
    NSE570_FILE = os.path.join(BASE_PATH, "Finalnse.csv")
    VALID_TICKERS = os.path.join(TRADE_LOGS, "valid_tickers.csv")

# Helper Functions
class MarketUtils:
    @staticmethod
    def is_market_day(date):
        nse_calendar = mcal.get_calendar('NSE')
        schedule = nse_calendar.schedule(
            start_date=f'{date.year}-01-01', 
            end_date=f'{date.year}-12-31'
        )
        return date in schedule['market_open'].notna().index.date

    @staticmethod
    def get_current_datetime():
        return datetime.now(Config.IST_TIMEZONE)

    @staticmethod
    def get_weekday():
        return MarketUtils.get_current_datetime().strftime("%A")

class TechnicalIndicators:
    @staticmethod
    def get_roc30_2yrH_index(df):
        mask = df["Close"].iloc[-7:] < df["2yrH"].iloc[-1]*1.0
        mask90 = df["Close"].iloc[-22:-6] == df["2yrH"].iloc[-1]

        row_indices = mask[mask].index if mask.all() else []
        row_indices90 = mask90[mask90].index if mask90.any() else []

        if (len(row_indices) > 0 and len(row_indices90) > 0 and 
            df["OBV"].loc[row_indices90[0]]*.95 > df["OBV"].iloc[-1] and 
            mask90.any() and mask.all()):
            roc = int(((df["Close"].iloc[-1] - df["2yrH"].iloc[-1]) / df["2yrH"].iloc[-1])*100)
            obv_condition_met = round(df["OBV"].iloc[-1]/df["OBV"].loc[row_indices90[0]], 2)
            return roc, obv_condition_met
        return 0, 0

    @staticmethod
    def get_roc30_2yrL_index(df):
        mask = df["Close"].iloc[-7:] > df["2yrL"].iloc[-1]*1.0
        mask90 = df["Close"].iloc[-22:-6] == df["2yrL"].iloc[-1]

        row_indices = mask[mask].index if mask.all() else []
        row_indices90 = mask90[mask90].index if mask90.any() else []

        if (len(row_indices) > 0 and len(row_indices90) > 0 and 
            df["OBV"].loc[row_indices90[0]]*1.05 < df["OBV"].iloc[-1] and 
            mask90.any() and mask.all()):
            roc = int(((df["Close"].iloc[-1] - df["2yrL"].iloc[-1]) / df["2yrL"].iloc[-1])*100)
            obv_condition_met = round(df["OBV"].iloc[-1]/df["OBV"].loc[row_indices90[0]], 2)
            return roc, obv_condition_met
        return 0, 0

    @staticmethod
    def calculate_exponential_linear_regression(df, period=12):
        returns = np.log(df['Close'])
        x = np.arange(len(returns))
        
        slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
        annualized_slope = (np.power((1+slope), 252)) * 100
        r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
        
        r_squared = r_value
        n = len(x)
        k = 1
        adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
        annualized_slope_r_value = round(annualized_slope * (adj_r_squared ** 2), 2)
        
        return annualized_slope_r_value

    @staticmethod
    def calculate_mrp(stock_csv_file):
        index_csv_file = Config.NSEI_FILE
        stock_data = pd.read_csv(stock_csv_file, usecols=['Close'])
        index_data = pd.read_csv(index_csv_file, usecols=['Close'])

        stock_returns = stock_data['Close'].pct_change()
        index_returns = index_data['Close'].pct_change()

        stock_cumreturns = (1+stock_returns).rolling(window=252).apply(np.prod)-1
        index_cumreturns = (1+index_returns).rolling(window=252).apply(np.prod)-1
        mrp = ((1+stock_cumreturns)/(1+index_cumreturns)).ffill()

        stock_data['MRPcsv15yrs'] = mrp.round(3)
        return stock_data['MRPcsv15yrs']

class DataProcessor:
    def __init__(self):
        self.today = MarketUtils.get_current_datetime().date()
        self.yesterday = self.today - timedelta(days=1)
        self.weekday = MarketUtils.get_weekday()
        
        # Load symbol lists
        self.symbols = self._load_symbols()
        self.indices = self._load_indices()
        self.NSE570symbols = self._load_NSE570_symbols()
        self.symbol_to_company = self._load_symbol_to_company_mapping()
        
        # Initialize result containers
        self.results = {
            'greater': [],
            'lower': [],
            'roc30_2yrL': [],
            'roc30_2yrH': [],
            'minervini': [],
            'tji': [],
            'mr_higher_lower': [],
            'higher_high': [],
            'l2yr30_roc': [],
            'ddpct': [],
            'pos1yr_high': [],
            'pos1yr_low': [],
            'max_vx': [],
            'mrp_cross': [],
            'sma_cross': []
        }

    def _load_symbols(self):
        ticker_df = pd.read_csv(Config.SYMBOL_LIST)
        symbols = ticker_df['Symbol'].tolist()
        
        # Add TJI index symbols
        tji_df = pd.read_csv(Config.TJI_INDEX_FILE)
        tji_symbols = tji_df['Symbol'].tolist()
        
        return list(dict.fromkeys(symbols + tji_symbols))

    def _load_indices(self):
        return [
            '^NSEI', 'BSE-500.BO', '^NSEMDCP50', 'NIFTYSMLCAP250.NS', 
            'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'BTC-USD', 'GOLDBEES.NS',
            '^NSEBANK', 'PSUBNKBEES.BO', '^CNXPSUBANK', 'NIFTYPVTBANK.NS',
            'NIFTY_FIN_SERVICE.NS', '^CNXAUTO', '^CNXREALTY', '^CNXCMDT',
            '^CNXMETAL', '^CNXINFRA', 'ICICIINFRA.NS', 'PHARMABEES.NS',
            '^CNXPHARMA', '^CNXFMCG', '^CNXCONSUM', '^CNXIT', '^CNXENERGY',
            '^CRSLDX', 'MON100.NS', 'MAFANG.NS', 'HNGSNGBEES.NS', 'MAHKTECH.NS',
            'SBIGETS.BO', 'AXISCETF.NS'
        ]

    def _load_NSE570_symbols(self):
        nse_df = pd.read_csv(Config.NSE570_FILE)
        return list(set(nse_df['Symbol'].tolist()))

    def _load_symbol_to_company_mapping(self):
        valid_df = pd.read_csv(Config.VALID_TICKERS)
        return dict(zip(valid_df['Symbol'], valid_df['Company']))

    def process_files(self):
        total_files = 0
        minervini_tickers = []
        
        nifty_data = pd.read_csv(Config.NSEI_FILE)
        nifty_data["EMA_200"] = tb.EMA(nifty_data['Close'], timeperiod=200)
        nifty_data["EMA_50"] = tb.EMA(nifty_data['Close'], timeperiod=50)

        for file_name in os.listdir(Config.TICKER_15YR_PATH):
            if file_name.endswith('.csv'):
                file_path = os.path.join(Config.TICKER_15YR_PATH, file_name)
                total_files += 1
                base_name = os.path.splitext(file_name)[0]

                if base_name in self.symbols:
                    try:
                        self.process_single_file(file_path, base_name, nifty_data, minervini_tickers)
                    except Exception as e:
                        print(f"Error processing {base_name}: {str(e)}")
                        traceback.print_exc()

        self.save_results()
        self.generate_charts(minervini_tickers)

    def process_single_file(self, file_path, base_name, nifty_data, minervini_tickers):
        df = pd.read_csv(file_path)
        dfexp = df
        dataR = df
        data52 = df[-295:]

        # Calculate indicators
        cal252_mrp = TechnicalIndicators.calculate_mrp(file_path)
        
        # Add technical indicators
        self.add_technical_indicators(df, data52, cal252_mrp)
        
        # Process different screening criteria
        self.process_greater_lower_screenings(df, base_name, cal252_mrp)
        
        if base_name in self.NSE570symbols:
            self.process_NSE570_screenings(df, base_name, cal252_mrp, nifty_data, minervini_tickers)

    def add_technical_indicators(self, df, data52, cal252_mrp):
        df["EMA_14cal252_mrp"] = tb.EMA(cal252_mrp, timeperiod=22)
        df["CCI"] = tb.CCI(data52['High'], data52['Low'], data52['Close'], timeperiod=34*5)
        df["CCImovavgL"] = tb.EMA(df["CCI"], timeperiod=14)
        df["CCImovavgS"] = tb.EMA(df["CCI"], timeperiod=7)
        df["macd"], df["macdsignal"], df["macdhist"] = tb.MACDEXT(
            data52['Close'], fastperiod=12, fastmatype=0, 
            slowperiod=26, slowmatype=0, signalperiod=9, signalmatype=0
        )
        df["ADX"] = tb.ADX(data52['High'], data52['Low'], data52['Close'], timeperiod=34)
        df["ADXavg"] = tb.EMA(df["ADX"], timeperiod=14)
        df["RSI"] = tb.RSI(data52['Close'], timeperiod=34)
        df["RSIavg"] = tb.EMA(df["RSI"], timeperiod=7)
        df["RSI14"] = tb.RSI(data52['Close'], timeperiod=14)
        df["RSI14avg"] = tb.EMA(df["RSI"], timeperiod=32)
        df["OBV"] = tb.OBV(data52['Close'], data52['Volume'])
        df["obvmovavg"] = tb.EMA(df["OBV"], timeperiod=14)
        df["MaxOBV30"] = tb.MAX(df['OBV'], timeperiod=22)
        df["MinOBV30"] = tb.MIN(df['OBV'], timeperiod=22)

        supertrend_values = ta.supertrend(
            high=df['High'], low=df['Low'], close=df['Close'], 
            length=10, multiplier=4.0
        )
        df['ST'] = supertrend_values['SUPERT_10_4.0']
        
        df["SMA_50"] = tb.SMA(data52['Close'], timeperiod=50)
        df["SMA_200"] = tb.SMA(data52['Close'], timeperiod=200)
        df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
        df["SMA_150"] = tb.SMA(data52['Close'], timeperiod=150)
        df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
        df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
        df["SMA_200_15"] = tb.SMA(df['SMA_200'], timeperiod=60)
        df["EMA_30"] = tb.EMA(data52['Close'], timeperiod=30)
        
        df['Exp_lin_reg'] = TechnicalIndicators.calculate_exponential_linear_regression(data52, period=120)
        df['Exp_lin_regslow'] = TechnicalIndicators.calculate_exponential_linear_regression(data52, period=180)
        
        df['ROC_2'] = tb.ROCP(data52['Close'], timeperiod=1)*100
        df['ROC_30'] = tb.ROCP(data52['Close'], timeperiod=22)*100
        df['ROC_5'] = tb.ROCP(data52['Close'], timeperiod=5)*100
        df["ROC_2movavg"] = tb.SMA(df["ROC_2"], timeperiod=5)
        df["ROC_22movavg"] = tb.SMA(df["ROC_2"], timeperiod=22)
        
        df["SMA_V40"] = tb.SMA(data52['Volume'], timeperiod=20)
        df["SMA_V7"] = tb.SMA(data52['Volume'], timeperiod=7)
        
        # Price action indicators
        df["High_higher12"] = df['High'].iloc[-3:].shift(0) > df['High'].iloc[-3:].shift(1)
        df["High_higher"] = df['Close'].iloc[-3:].shift(0) > df['Close'].iloc[-3:].shift(1)
        df["Low_higher"] = df['Low'].iloc[-3:].shift(0) > df['Low'].iloc[-3:].shift(1)
        df["High_Lower"] = df['Close'].iloc[-3:].shift(0) < df['Close'].iloc[-3:].shift(1)
        df["Low_lower"] = df['Low'].iloc[-3:].shift(0) < df['Low'].iloc[-3:].shift(1)
        df["High_lower12"] = df['High'].iloc[-3:].shift(0) < df['High'].iloc[-3:].shift(1)
        
        try:
            df["SMA_91MRP"] = df["SMA_30MRP"] = tb.EMA(data52['MRP'], timeperiod=30)
            df["SMA_200MRP"] = df["SMA_90MRP"] = tb.EMA(data52['MRP'], timeperiod=200)
            df["EMA_14MRP"] = tb.EMA(data52['MRP'], timeperiod=14)
            df["EMA_30MRP"] = tb.EMA(data52['MRP'], timeperiod=30)
        except Exception:
            pass
            
        df["MaxcloseH"] = tb.MAX(df['Close'], timeperiod=252*2)
        df["MaxcloseL"] = tb.MIN(df['Close'])
        df["52wkH"] = tb.MAX(data52['Close'], timeperiod=252)
        df["52wkL"] = tb.MIN(data52['Close'], timeperiod=252)
        df["2yrL"] = tb.MIN(data52['Close'], timeperiod=252+(252*0))
        df["2yrH"] = tb.MAX(data52['Close'], timeperiod=252+(252*0))
        df["MaxVx22"] = tb.MAX(df['Volume'], timeperiod=958)
        
        quantile = ta.quantile(close=df['Volume'], length=958, q=.7, offset=None)
        df['quantile'] = quantile
        df["SMA_V3yr"] = tb.SMA(df['Volume'], timeperiod=958)
        
        # Calculate derived metrics
        MaxVx = round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-7]*.6), 2)
        MaxVxM = round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-10]), 2)
        pos1yr = round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]), 2)
        DD_PCT = int(df["DD_PCT"].iloc[-1])
        DD15yr = f"{int(DD_PCT)}%"
        
        return MaxVx, MaxVxM, pos1yr, DD_PCT, DD15yr

    def process_greater_lower_screenings(self, df, base_name, cal252_mrp):
        Base_name = self.symbol_to_company.get(base_name, base_name)
        NSE570s = "Y" if base_name in self.NSE570symbols else ""
        
        if (df["EMA_14cal252_mrp"].iloc[-1] < cal252_mrp.iloc[-1] > 1.8 and 
            (df["ADX"].iloc[-1] > 28 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] or 
             df["RSI"].iloc[-1] > 55 or df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1]) and 
            df["ST"].iloc[-1] < df['Close'].iloc[-1] and 
            df['EMA_30'].iloc[-1] > df['EMA_100'].iloc[-1]):
            
            self.results['greater'].append([
                Base_name, NSE570s, cal252_mrp.iloc[-1], 
                round(df['MRP'].iloc[-1], 3), int(df["ADX"].iloc[-1]), 
                int(df["RSI"].iloc[-1]), int(df["CCI"].iloc[-1])
            ])

        if (df["EMA_14cal252_mrp"].iloc[-1] > cal252_mrp.iloc[-1] < 1.5 and 
            (df["ADX"].iloc[-1] < 24 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1]*100 or 
             df["ADXavg"].iloc[-1]*100 < df["ADX"].iloc[-1] or 
             df["RSI"].iloc[-1] < df["RSIavg"].iloc[-1] or df["RSI"].iloc[-1] < 50) and 
            df["ST"].iloc[-1] > df['Close'].iloc[-1] and 
            df['EMA_30'].iloc[-1] < df['EMA_100'].iloc[-1]):
            
            self.results['lower'].append([
                Base_name, NSE570s, cal252_mrp.iloc[-1], 
                round(df['MRP'].iloc[-1], 3), int(df["ADX"].iloc[-1]), 
                int(df["RSI"].iloc[-1]), int(df["CCI"].iloc[-1])
            ])

        roc30_2yrL = TechnicalIndicators.get_roc30_2yrL_index(df)
        if len(df) > 0 and roc30_2yrL[0] > 0:
            self.results['roc30_2yrL'].append([
                Base_name, NSE570s, roc30_2yrL[0], roc30_2yrL[1], 
                cal252_mrp.iloc[-1], round(df['MRP'].iloc[-1], 3), 
                int(df["ADX"].iloc[-1]), int(df["RSI"].iloc[-1]), 
                int(df["CCI"].iloc[-1]), DD15yr, pos1yr
            ])

        roc30_2yrH = TechnicalIndicators.get_roc30_2yrH_index(df)
        if len(df) > 0 and roc30_2yrH[0] < 0:
            self.results['roc30_2yrH'].append([
                Base_name, NSE570s, roc30_2yrH[0], roc30_2yrH[1], 
                cal252_mrp.iloc[-1], round(df['MRP'].iloc[-1], 
                int(df["ADX"].iloc[-1]), int(df["RSI"].iloc[-1]), 
                int(df["CCI"].iloc[-1]), DD15yr, pos1yr
            ])

    def process_NSE570_screenings(self, df, base_name, cal252_mrp, nifty_data, minervini_tickers):
        Base_name = self.symbol_to_company.get(base_name, base_name)
        NSE570s = "Y" if base_name in self.NSE570symbols else ""
        
        # Calculate common metrics
        DD_PCT = int(df["DD_PCT"].iloc[-1])
        DD_PCT_str = f"{int(DD_PCT)}%"
        VX = round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8], 2)
        RSI = int(df["RSI"].iloc[-1])
        ADX = int(df["ADX"].iloc[-1])
        CCI = int(df["CCI"].iloc[-1])
        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
        ROC_14 = int(df['ROC_30'].iloc[-1])
        
        OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5], 2)
        OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5], 2)
        OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
        
        LNEXP20 = int(df['Exp_lin_reg'].iloc[-1])
        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
        MRP = f"{round(df['MRP'].iloc[-1], 2)}"
        UD = f"{'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0 else ''}"
        ST = "UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
        CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100, 1)
        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""
        pos1yr = round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]), 2)
        
        # Minervini screening
        if (len(df) > 0 and 
            df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1] and 
            df["SMA_200"].iloc[-1] > df["SMA_200_15"].iloc[-1] and 
            df["Close"].iloc[-1] > df["52wkL"].iloc[-1]*1.25 and 
            df["Close"].iloc[-1] > df["52wkH"].iloc[-1]*.75 and 
            df["RSI14avg"].iloc[-5] < df["RSI14"].iloc[-1] > 70):
            
            M = "Y"
            minervini_tickers.append(file_name)
        else:
            M = ""
            
        data = {
            "Company": Base_name,
            "MV": M,
            "ROC_30": ROC_14,
            "MRP1yr": cal252_mrp.iloc[-1],
            "MRPS": "UP" if (df["EMA_14cal252_mrp"].iloc[-1] < cal252_mrp.iloc[-1] and 
                             nifty_data['EMA_200'].iloc[-1] < nifty_data['EMA_50'].iloc[-1] < 
                             nifty_data["Close"].iloc[-1] and RSI > 40) else "",
            "MRPL": UD,
            "RSI": RSI,
            "CCI": CCI,
            "ADX": ADX,
            "MACD": MACD,
            "ST": ST,
            "EXP50": LNEXP50,
            "MA200UP": SMA200UP,
            "OBVchg": OBVchg,
            "VX": VX,
            "CH52wk%": CH52wk,
            "Ps1yr": pos1yr,
            "DD%3yr": DD_PCT_str
        }
        self.results['tji'].append(data)

        # Other screening criteria would follow similar patterns...
        # (Additional screening criteria would be implemented here)

    def save_results(self):
        # Save each result type to CSV and PDF
        for result_type, data in self.results.items():
            if data:
                df = pd.DataFrame(data)
                
                # Sort data based on result type
                if result_type == 'greater':
                    df = df.sort_values(by=2, ascending=False)  # Sort by YMRPG
                elif result_type == 'lower':
                    df = df.sort_values(by=4, ascending=False)  # Sort by CCIL
                elif result_type == 'roc30_2yrL':
                    df = df.sort_values(by=3, ascending=False)  # Sort by OBV
                elif result_type == 'roc30_2yrH':
                    df = df.sort_values(by=3, ascending=True)   # Sort by OBV
                elif result_type in ['tji', 'minervini']:
                    df = df.sort_values(by="CH52wk%", ascending=False)
                
                # Save to CSV
                csv_path = os.path.join(Config.SCREENER_OUTPUTS, f"{result_type}.csv")
                df.to_csv(csv_path, index=False)
                
                # Create and post PDF
                pdf_path = os.path.join(Config.SCREENER_OUTPUTS, f"{result_type}.pdf")
                time.sleep(5)
                create_pdf(csv_path, pdf_path, pageA4=False)
                time.sleep(5)
                post_telegram_file(pdf_path)

    def generate_charts(self, minervini_tickers):
        filepathpdf = os.path.join(Config.SCREENER_OUTPUTS, "minervini_Charts.pdf")
        
        with PdfPages(filepathpdf) as pdf:
            for file_name in minervini_tickers:
                try:
                    file_path = os.path.join(Config.TICKER_15YR_PATH, file_name)
                    base_name = os.path.splitext(file_name)[0]
                    Base_name = self.symbol_to_company.get(base_name, base_name)
                    
                    dfM = pd.read_csv(file_path)
                    dfM['Date'] = pd.to_datetime(dfM['Date'])
                    
                    # Add indicators
                    dfM["CCI"] = tb.CCI(dfM['High'], dfM['Low'], dfM['Close'], timeperiod=34*5)
                    dfM["CCImovavgL"] = tb.EMA(dfM["CCI"], timeperiod=14)
                    dfM["RSI14"] = tb.RSI(dfM['Close'], timeperiod=14)
                    dfM["SMA_50"] = tb.SMA(dfM['Close'], timeperiod=50)
                    dfM["SMA_200"] = tb.SMA(dfM['Close'], timeperiod=200)
                    dfM["SMA_150"] = tb.SMA(dfM['Close'], timeperiod=150)
                    dfM["SMA_200_15"] = tb.SMA(dfM['SMA_200'], timeperiod=60)
                    dfM["OBV"] = tb.OBV(dfM['Close'], dfM['Volume'])
                    
                    # Create chart
                    fig_combined = plt.figure(figsize=(11, 8.5))
                    gs = fig_combined.add_gridspec(4, 1, height_ratios=[6, 1, 1.5, 1.5])
                    
                    # Price chart
                    ax1 = fig_combined.add_subplot(gs[0])
                    ax1.plot(dfM['Date'], dfM['Close'], label='Price', color='black', linewidth=1)
                    ax1.plot(dfM['Date'], dfM['SMA_50'], label='SMA 50', color='blue', linewidth=1.5)
                    ax1.plot(dfM['Date'], dfM['SMA_150'], label='SMA 150', color='orange', linewidth=1.5)
                    ax1.plot(dfM['Date'], dfM['SMA_200'], label='SMA 200', color='red', linewidth=1.5)
                    ax1.plot(dfM['Date'], dfM['SMA_200_15'], label='SMA 200(15)', color='purple', linewidth=1.5)
                    ax1.set_title(f'{Base_name} Price and Moving Averages', fontsize=14)
                    ax1.legend()
                    
                    # Volume chart with OBV
                    ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                    ax2.bar(dfM['Date'], dfM['Volume']/1000, color='blue', width=0.5, alpha=0.5, label='Volume')
                    ax2b = ax2.twinx()
                    ax2b.plot(dfM['Date'], dfM['OBV'], color='black', linewidth=1.5, label='OBV')
                    ax2.set_ylabel('Volume (K)', color='blue')
                    ax2b.set_ylabel('OBV', color='black')
                    ax2.tick_params(axis='y', colors='blue')
                    ax2b.tick_params(axis='y', colors='black')
                    lines, labels = ax2.get_legend_handles_labels()
                    lines2, labels2 = ax2b.get_legend_handles_labels()
                    ax2.legend(lines + lines2, labels + labels2, loc='upper left')
                    
                    # RSI chart
                    ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                    ax3.plot(dfM['Date'], dfM["RSI14"], color='purple', label='RSI')
                    ax3.axhline(70, color='red', linestyle='--', alpha=0.5)
                    ax3.axhline(30, color='green', linestyle='--', alpha=0.5)
                    ax3.fill_between(dfM['Date'], 70, dfM["RSI14"], where=(dfM["RSI14"] >= 70), color='red', alpha=0.3)
                    ax3.fill_between(dfM['Date'], 30, dfM["RSI14"], where=(dfM["RSI14"] <= 30), color='green', alpha=0.3)
                    ax3.set_title('RSI (14)', fontsize=12)
                    ax3.set_ylim(0, 100)
                    ax3.legend()
                    
                    # CCI chart
                    ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                    ax4.plot(dfM['Date'], dfM["CCI"], color='purple', label='CCI')
                    ax4.axhline(0, color='red', linestyle='--', alpha=0.5)
                    ax4.axhline(50, color='green', linestyle='--', alpha=0.5)
                    ax4.fill_between(dfM['Date'], 0, dfM["CCI"], where=(dfM["CCI"] <= 0), color='red', alpha=0.3)
                    ax4.fill_between(dfM['Date'], 50, dfM["CCI"], where=(dfM["CCI"] >= 50), color='green', alpha=0.3)
                    ax4.set_title('CCI (34)', fontsize=12)
                    ax4.set_ylim(-100, 150)
                    ax4.legend()
                    
                    # Format x-axis
                    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))
                    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
                    plt.xticks(rotation=90)
                    plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)
                    
                    # Save to PDF
                    pdf.savefig(fig_combined, bbox_inches='tight')
                    plt.close(fig_combined)
                    
                except Exception as e:
                    print(f"Error generating chart for {Base_name}: {str(e)}")
                    traceback.print_exc()
                    plt.close('all')
                    continue
        
        # Post the complete PDF
        time.sleep(5)
        post_telegram_file(filepathpdf)

# Main Execution
if __name__ == "__main__":
    # Check if today is a market day
    today = MarketUtils.get_current_datetime().date()
    yesterday = today - timedelta(days=1)
    weekday = MarketUtils.get_weekday()
    
    if not MarketUtils.is_market_day(yesterday):
        print("Yesterday was an NSE holiday.")
    else:
        print("Yesterday was a market day.")
    
    print("Start csv15yrs processing")
    processor = DataProcessor()
    processor.process_files()
    print("csv15yrs processing done")
    
    '''
    ######################
    def main():
        print(f"Starting csv15yrs on {weekday}")
        
        # Load ticker lists
        ticker_path = os.path.join(BASE_PATH, "symbol_list.csv")
        ticker_df = pd.read_csv(ticker_path)
        symbols = ticker_df['Symbol'].tolist()
        
        # ... rest of your main execution logic ...
        
        print("csv15yrs done")
    
    if __name__ == "__main__":
        main()
    '''    

    


from concurrent.futures import ThreadPoolExecutor
from functools import wraps
import threading
import traceback

@handle_errors
@timeit

# Decorators
def timeit(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} executed in {end-start:.2f}s")
        return result
    return wrapper

def handle_errors(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"Error in {func.__name__}: {str(e)}")
            traceback.print_exc()
            return None
    return wrapper
    
    
    
