import os
import sys
import time

import numpy as np
import pandas as pd
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.9/site-packages/")
import pandas_ta as ta
from PDFconvert import create_pdf


print("Start")

# Specify the folder path containing CSV files
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'  # Replace with the actual folder path
ticker_path = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()[:]
symbols = list(dict.fromkeys(symbols))
selected_files = []



# Initialize counters for MRP13 and MRP25
mrp13_count_less0 = 0
mrp13_count_more0 = 0
mrp25_count_less0 = 0
mrp25_count_more0 = 0
mrp13_countbothless0 = 0
mrp25_countbothmore0 = 0
volumeequal0 = 0
total_files = 0
file_names = []
Bullish = []
Bearish = []
Start_countmore0 = 0
mrp25_count_mores10 = 0
mrp25_mores10 = []
mrp25_count_M1L1 =[]
mrp25_count_M1L2 =[]
Exp_countM =0
Exp_countL =0
Exp_nameM=[]
Exp_nameL=[]

# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    if file_name.endswith('.csv'):
        file_path = os.path.join(folder_path, file_name)
        #total_files += 1
        base_name = os.path.splitext(file_name)[0]
        #file_names.append(base_name)
        #print(base_name)

        # Check if the base name exists in the symbols list
        if base_name in symbols:
            file_path = os.path.join(folder_path, file_name)
            selected_files.append(file_path)
            total_files += 1
            # Read the CSV file into a DataFrame
            df = pd.read_csv(file_path)

            #df['CCI'] = df.ta.cci(df['High'], df['Low'], df['Close'], window=34)
            df['CCI'] = tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34)
            df['CCIavg'] = tb.SMA(df['CCI'], timeperiod=12)
            df['ADX'] = tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
            #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
            #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
            df['macd'], df['macdsignal'], df['macdhist'] = tb.MACD(df['Close'], fastperiod=12, slowperiod=26, signalperiod=9)
            #df['ATR'] = tb.ATR(df['High'], df['Low'], df['Close'], timeperiod=10)
            #df['SuperTrend_Upper_Band'] = df['High'] + (3 * df['ATR'])
            #df['SuperTrend_Lower_Band'] = df['Low'] - (3 * df['ATR'])
            #df['SuperTrend'] = (df['SuperTrend_Upper_Band'] + df['SuperTrend_Lower_Band']) / 2



            df['VolumeSMA'] = tb.SMA(df['Volume'], timeperiod=14)
            #df['3BLACKCROWS'] = tb.CDL3BLACKCROWS(df['Open'], df['High'], df['Low'], df['Close']) # Bear
            #df['3WHITESOLDIERS'] = tb.CDL3WHITESOLDIERS(df['Open'], df['High'], df['Low'], df['Close']) # Bull
            #df['DARKCLOUDCOVER'] = tb.CDLDARKCLOUDCOVER(df['Open'], df['High'], df['Low'], df['Close'], penetration=.5) # Bear
            #df['EVENINGSTAR'] = tb.CDLEVENINGSTAR(df['Open'], df['High'], df['Low'], df['Close'], penetration=0.3)# Bear
            #df['HAMMER'] = tb.CDLHAMMER(df['Open'], df['High'], df['Low'], df['Close']) # Bull
            #df['Harami_Pattern'] = tb.CDLHARAMI(df['Open'], df['High'], df['Low'], df['Close']) # Bull Bear
            #df['INVERTEDHAMMER'] = tb.CDLINVERTEDHAMMER(df['Open'], df['High'], df['Low'], df['Close'])
            #df['MORNINGSTAR'] = tb.CDLMORNINGSTAR(df['Open'], df['High'], df['Low'], df['Close'], penetration=0.3) # Bull
            #df['SHOOTINGSTAR'] = tb.CDLSHOOTINGSTAR(df['Open'], df['High'], df['Low'], df['Close']) # Bear
            #df['Piercing_Pattern'] = tb.CDLPIERCING(df['Open'], df['High'], df['Low'], df['Close']) # Bull
            #df['Engulfing_Pattern'] = tb.CDLENGULFING(df['Open'], df['High'], df['Low'], df['Close']) # Bull Bear
            #df['CLOSINGMARUBOZU'] = tb.CDLCLOSINGMARUBOZU(df['Open'], df['High'], df['Low'], df['Close']) # Bull Bear
            #f['3LINESTRIKE'] = tb.CDL3LINESTRIKE(df['Open'], df['High'], df['Low'], df['Close']) # Bull Bear
            #   CDLABANDONEDBABY(df['Open'], df['High'], df['Low'], df['Close'], penetration=0.3)

            if len(df) > 0 and (df['MRP25'].iloc[-1] and df['MRP13'].iloc[-1] > 1) and 0 >= df['Exp'].iloc[-5] < df['Exp'].iloc[-3] < df['Exp'].iloc[-1] > 40 and 6000 > df['Close'].iloc[-1] > 30 and df['VolumeSMA'].iloc[-1] > 1000 and df['ADX'].iloc[-1] > 25 and df['CCI'].iloc[-1] > df['CCIavg'].iloc[-1] :
                Exp_countM += 1
                Exp_nameM.append(base_name)
            if len(df) > 0 and df['Exp'].iloc[-3] > df['Exp'].iloc[-2] > df['Exp'].iloc[-1] < 30 and 6000 > df['Close'].iloc[-1] > 30 and 1000 < df['VolumeSMA'].iloc[-1] < 2590000 and df['CCI'].iloc[-1] < 0 and df['macdhist'].iloc[-1] < 0 :
                Exp_countL += 1
                Exp_nameL.append(base_name)



            # Check if the last row's 'MRP13' value is both less than 0 and more than 0
            if len(df) > 0 and (df['Volume'].iloc[-1] == 0 or df['Volume'].iloc[-1] == np.nan):
                volumeequal0 += 1

            # Check if the last row's 'MRP13' value is both less than 0 and more than 0
            if len(df) > 0 and df['MRP13'].iloc[-1] < 0:
                mrp13_count_less0 += 1

            # Check if the last row's 'MRP13' value is both less than 0 and more than 0
            if len(df) > 0 and df['MRP13'].iloc[-1] > 0:
                mrp13_count_more0 += 1

            # Check if the last row's 'MRP25' value is both less than 0 and more than 0
            if len(df) > 0 and df['MRP25'].iloc[-1] < 0:
                mrp25_count_less0 += 1

            # Check if the last row's 'MRP25' value is both less than 0 and more than 0
            if len(df) > 0 and df['MRP25'].iloc[-1] > 0:
                mrp25_count_more0 += 1

            # Check if the last row's 'MRP13' value is both less than 0 and more than 0
            if len(df) > 0 and df['MRP13'].iloc[-1] < 0 and df['MRP25'].iloc[-1] < 0:
                mrp13_countbothless0 += 1

            # Check if the last row's 'MRP25' value is both less than 0 and more than 0
            if len(df) > 0 and df['MRP13'].iloc[-1] > 0 and df['MRP25'].iloc[-1] > 0:
                mrp25_countbothmore0 += 1


            # Check if the last row's 'MRP25' value is both less than 0 and more than 0
            if len(df) > 0 and 6000 > df['Close'].iloc[-1] > 30 and df['VolumeSMA'].iloc[-1] > 1000 and 1 < df['MRP25'].iloc[-5] < df['MRP25'].iloc[-3] < df['MRP25'].iloc[-1] > 5 and 2 < df['MRP13'].iloc[-5] < df['MRP13'].iloc[-3] < df['MRP13'].iloc[-1] > 4 and df['CCI'].iloc[-1] > 1 and df['ADX'].iloc[-1] > 28 :
                Start_countmore0 += 1
                file_names.append(base_name)

            # Check if the last row's 'MRP25' value is both less than 0 and more than 0
            #if len(df) > 0 and (df['3LINESTRIKE'].iloc[-1] == 1 or  df['CLOSINGMARUBOZU'].iloc[-1] == 1 or df['3WHITESOLDIERS'].iloc[-1] == 1 or df['HAMMER'].iloc[-1] == 1 or df['Harami_Pattern'].iloc[-1] == 1 or df['MORNINGSTAR'].iloc[-1] == 1 or df['Piercing_Pattern'].iloc[-1] == 1 or df['Engulfing_Pattern'].iloc[-1] == 1):
            #    Bullish.append(base_name)


            # Check if the last row's 'MRP25' value is both less than 0 and more than 0
            #if len(df) > 0 and (df['3LINESTRIKE'].iloc[-1] == -1 or  df['CLOSINGMARUBOZU'].iloc[-1] == -1 or df['3BLACKCROWS'].iloc[-1] == -1 or df['DARKCLOUDCOVER'].iloc[-1] == -1 or df['EVENINGSTAR'].iloc[-1] == -1 or df['Harami_Pattern'].iloc[-1] == -1 or df['SHOOTINGSTAR'].iloc[-1] == -1 or df['Engulfing_Pattern'].iloc[-1] == -1):
            #    Bearish.append(base_name)

            if len(df) > 0 and df['CCI'].iloc[-1] > 0 and df['ADX'].iloc[-1] > 28 and 6000 > df['Close'].iloc[-1] > 30 and df['VolumeSMA'].iloc[-1] > 1000 and 4 < df['MRP25'].iloc[-7] < df['MRP25'].iloc[-1] > 5 and df['MRP13'].iloc[-5] < df['MRP13'].iloc[-3] < df['MRP13'].iloc[-1]:
                mrp25_count_mores10 += 1
                mrp25_mores10.append(base_name)

            # Check if the last row's 'MRP25' value is both less than 0 and more than 0
            if len(df) > 0 and df['CCI'].iloc[-1] > 0 and df['MRP25'].iloc[-1] > 3 and df['MRP25'].iloc[-4] < -2 and 6000 > df['Close'].iloc[-1] > 30 and df['VolumeSMA'].iloc[-1] > 1000 :
                mrp25_count_M1L1.append(base_name)


# Calculate percentages
Exp_percentage_mores40 = (Exp_countM / total_files) * 100
#print(Exp_percentage_mores40)

mrp25_percentage_mores10 = (mrp25_count_mores10 / total_files) * 100
mrp13_percentageless0 = (mrp13_count_less0 / total_files) * 100
mrp13_percentagemore0 = (mrp13_count_more0 / total_files) * 100
mrp25_percentageless0 = (mrp25_count_less0 / total_files) * 100
mrp25_percentagemore0 = (mrp25_count_more0 / total_files) * 100
mrp25_percentagebothless0 = (mrp13_countbothless0 / total_files) * 100
mrp25_percentagebothmore0 = (mrp25_countbothmore0 / total_files) * 100
#df = pd.DataFrame({'RP': file_names})
#df = pd.DataFrame({'BullCandle': Bullish})
#df = pd.DataFrame({'BearCandle': Bearish})
max_length = max(len(file_names), len(Bullish), len(Bearish) , len(mrp25_mores10),len(mrp25_count_M1L1),len(Exp_nameM) )

data = {
    'RP24M5_12M4': file_names + ['--'] * (max_length - len(file_names)),
    'RP25_mores5': mrp25_mores10 + ['--'] * (max_length - len(mrp25_mores10)),
    #'BullCandle': Bullish + ['--'] * (max_length - len(Bullish)),
    #'BearCandle': Bearish + ['--'] * (max_length - len(Bearish)),
    'MRP25_Crossover': mrp25_count_M1L1 + ['--'] * (max_length - len(mrp25_count_M1L1)),
    'Exp_H35': Exp_nameM + ['--'] * (max_length - len(Exp_nameM))
}

df = pd.DataFrame(data)

print(Bullish)
print(Bearish)
df.to_csv('/home/rizpython236/BT5/screener-outputs/Relative_perf.csv', index=False)


def replace_values(sector_file, valid_file, output_file):
    # Read valid file to create a mapping of 'Symbol' to 'Company'
    valid_df = pd.read_csv(valid_file)
    symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

    # Read sector file
    sector_df = pd.read_csv(sector_file)

    print(sector_df)

    # Replace values in specified columns with corresponding 'Company' values
    columns_to_replace = ['RP24M5_12M4', 'RP25_mores5', 'MRP25_Crossover', 'Exp_H35']
    for col in columns_to_replace:
        sector_df[col] = sector_df[col].map(symbol_to_company)

    # Save the result to a new file
    sector_df.to_csv(output_file, index=False)

# Example usage:
sector_file = '/home/rizpython236/BT5/screener-outputs/Relative_perf.csv'
valid_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/Relative_perf.csv'
replace_values(sector_file, valid_file, output_file)

#print(df)
#print(Start_countmore0)
#df.to_csv('/home/rizpython236/BT5/screener-outputs/Relative_perf.csv', index=False)

time.sleep(2)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/Relative_perf.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Relative_perf.pdf'  # Replace with desired output PDF file

create_pdf(input_csv_file, output_pdf_file)
#print(f'PDF created: {output_pdf_file}')


# Print the results
print(f"Total Files: {total_files}")
print(f"Volume equal 0 files: {volumeequal0}")
print(f"Exp>40% : {Exp_countM} files ({Exp_percentage_mores40:.2f}%) have the last row more than 35% slope.")
print(f"MRP26>8: {mrp25_count_mores10} files ({mrp25_percentage_mores10:.2f}%) have the last row more than 8.")
print(f"MRP13<0: {mrp13_count_less0} files ({mrp13_percentageless0:.2f}%) have the last row less than 0.")
print(f"MRP13>0: {mrp13_count_more0} files ({mrp13_percentagemore0:.2f}%) have the last row more than 0.")
print(f"MRP26<0: {mrp25_count_less0} files ({mrp25_percentageless0:.2f}%) have the last row less than 0.")
print(f"MRP26>0: {mrp25_count_more0} files ({mrp25_percentagemore0:.2f}%) have the last row more than 0.")

print(f"MRP13&MRP26<0: {mrp13_countbothless0} files ({mrp25_percentagebothless0:.2f}%) have the last row both less than 0.")
print(f"MRP13&MRP26>0: {mrp25_countbothmore0} files ({mrp25_percentagebothmore0:.2f}%) have the last row both more than 0.")


#time.sleep(2)
post_telegram_message(f"Total Files: {total_files}\n"
      f"MRP13>8: {mrp25_count_mores10} files ({mrp25_percentage_mores10:.2f}%) > than 8.\n"
      f"MRP13<0: {mrp13_count_less0} files ({mrp13_percentageless0:.2f}%) < than 0.\n"
      f"MRP13>0: {mrp13_count_more0} files ({mrp13_percentagemore0:.2f}%) > than 0.\n"
      f"MRP26<0: {mrp25_count_less0} files ({mrp25_percentageless0:.2f}%) < than 0.\n"
      f"MRP26>0: {mrp25_count_more0} files ({mrp25_percentagemore0:.2f}%) > than 0.\n"
      f"MRP13&MRP26<0: {mrp13_countbothless0} files ({mrp25_percentagebothless0:.2f}%) both < than 0.\n"
      f"MRP13&MRP26>0: {mrp25_countbothmore0} files ({mrp25_percentagebothmore0:.2f}%) both > than 0.")
      #f"ExpH40% : {Exp_countM} files ({Exp_percentage_mores40:.2f}%) more than 35% slope.")

#post_telegram_message("Scan started")
post_telegram_file('/home/rizpython236/BT5/screener-outputs/Relative_perf.pdf')

print("done")
