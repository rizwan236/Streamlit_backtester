import os
import subprocess


def get_folder_size(folder_path):
    # Use du command to get the folder size in bytes
    result = subprocess.run(['du', '-sb', folder_path], capture_output=True, text=True)
    size_in_bytes = int(result.stdout.split()[0])
    print(result)
    # Convert bytes to megabytes
    size_in_mb = size_in_bytes / (1024 * 1024)
    return size_in_mb

# Replace 'your_folder_path' with the path to your folder
folder_path = '/home/rizpython236'
#folder_path = '/home'
size_in_mb = get_folder_size(folder_path)

print(f"Size of folder '{folder_path}': {size_in_mb:.2f} MB")

'''
#https://help.pythonanywhere.com/pages/DiskQuota/
#source /home/rizpython236/.virtualenvs/rizenvnew/bin/activate && python /home/rizpython236/BT5/scheduler2.py
https://help.pythonanywhere.com/pages/RebuildingVirtualenvs
tail -f var/log/alwayson-log-122718.log
pip cache purge
rm -rf ~/.cache/
rm -rf /tmp/*
pip install -r /home/rizpython236/BT5/requirements.txt
rmvirtualenv Pybroker39z
mkvirtualenv --python=pythonX.Y my-new-virtualenv-name
mkvirtualenv --python=python3.9 Pybroker39zz
pip install -r /home/rizpython236/requirements.txt
https://jovian.com/pknayak0707-job/minute-price-data-resampling-techniques


https://piotrpomorski.substack.com/p/data-pre-processing-for-equity-predictions
https://www.iditect.com/faq/python/converting-daily-stock-data-to-weeklybased-via-pandas-in-python.html

import pandas as pd
import yfinance as yf  # for fetching data from Yahoo Finance
from datetime import datetime, timedelta

# Fetching daily data from Yahoo Finance
ticker = 'AAPL'  # Example: Apple stock ticker
data = yf.download(ticker, start='2020-01-01', end='2021-01-01')

# Determine today's day of the week (0 = Monday, 6 = Sunday)
today = datetime.today().weekday()

# Calculate the offset for weekly resampling
# If today is Monday (0), use 'W-MON'; if Tuesday (1), use 'W-TUE', and so on
offset = 'W-' + ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'][today]

# Resampling daily to weekly OHLC with dynamic weekly offset
weekly_data = data.resample(offset).agg({
    'Open': 'first',
    'High': 'max',
    'Low': 'min',
    'Close': 'last',
    'Volume': 'sum'  # Optionally, sum volume
})

print(weekly_data)




    class Config:
        arbitrary_types_allowed = True
'''



'''

deactivate 2>/dev/null; \
rmvirtualenv Pybroker39zz 2>/dev/null; \
rm -rf ~/.cache/ /tmp/*; \
mkvirtualenv --python=python3.13 Pybroker39zz && \
pip install --upgrade pip && \
pip install -r /home/rizpython236/requirements.txt



deactivate 2>/dev/null → safely deactivate any active virtualenv (ignore errors).
rmvirtualenv Pybroker39zz 2>/dev/null → delete the old virtualenv (ignore errors if it doesn’t exist).
rm -rf ~/.cache/ /tmp/* → clear caches and temp files.
mkvirtualenv --python=python3.13 Pybroker39zz → create a new virtualenv using Python 3.13.
pip install --upgrade pip → make sure pip is up to date in the new environment.
pip install -r /home/rizpython236/requirements.txt → install all your packages from your requirements file.


#!/bin/bash

# Switch system image manually first to innit (Python 3.13)

# Step 1: Deactivate any active virtualenv
deactivate 2>/dev/null

# Step 2: Remove old virtualenv
echo "Removing old Pybroker39zz virtual environment..."
rmvirtualenv Pybroker39zz

# Step 3: Clear caches
echo "Clearing caches..."
rm -rf ~/.cache/
rm -rf /tmp/*

# Step 4: Create new virtualenv with Python 3.13
echo "Creating new Pybroker39zz virtual environment with Python 3.13..."
mkvirtualenv --python=python3.13 Pybroker39zz

# Step 5: Activate the new virtualenv
workon Pybroker39zz

# Step 6: Install packages from requirements.txt
REQ_FILE="/home/rizpython236/requirements.txt"
if [ -f "$REQ_FILE" ]; then
    echo "Installing packages from $REQ_FILE..."
    pip install -r $REQ_FILE
else
    echo "ERROR: $REQ_FILE not found!"
    exit 1
fi

# Step 7: Verify installation
echo "Python version:"
python --version
echo "Installed packages:"
pip list

echo "Migration to Python 3.13 complete!"


'''



