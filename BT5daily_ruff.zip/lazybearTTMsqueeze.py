from datetime import datetime

import backtrader as bt
import numpy as np
from pandas import DataFrame
import pandas_ta as ta


class LazyBearSqueezeIndicator(bt.Indicator):
    lines = ('squeeze', 'squeeze_on', 'squeeze_off', 'no_squeeze')

    params = (
        ('bb_length', 20),
        ('bb_std', 2),
        ('kc_length', 20),
        ('kc_scalar', 1.5),
        ('mom_length', 12),
        ('mom_smooth', 6),
        ('use_tr', True),
        ('mamode', 'sma'),
        ('lazybear', False),
        ('offset', 0)
    )

    def __init__(self):
        self.addminperiod(20)  # Ensure enough data points for calculations

    def prenext(self):
        # Do nothing until there is enough data for calculations
        pass

    def next(self):
        bb_length = int(self.params.bb_length)
        bb_std = float(self.params.bb_std)
        kc_length = int(self.params.kc_length)
        kc_scalar = float(self.params.kc_scalar)
        mom_length = int(self.params.mom_length)
        mom_smooth = int(self.params.mom_smooth)
        use_tr = self.params.use_tr
        mamode = self.params.mamode
        offset = self.params.offset

        # Calculate Result
        bbd = ta.bbands(self.data.close, length=bb_length, std=bb_std, mamode=mamode)
        kch = ta.kc(self.data.high, self.data.low, self.data.close, length=kc_length,
                    scalar=kc_scalar, mamode=mamode, tr=use_tr)

        if self.params.lazybear:
            highest_high = self.data.high.rolling(window=kc_length).max()
            lowest_low = self.data.low.rolling(window=kc_length).min()
            avg_ = 0.25 * (highest_high + lowest_low) + 0.5 * kch.b

            squeeze = ta.linreg(self.data.close - avg_, length=kc_length)

        else:
            momo = ta.mom(self.data.close, length=mom_length)
            if mamode.lower() == "ema":
                squeeze = ta.ema(momo, length=mom_smooth)
            else:  # "sma"
                squeeze = ta.sma(momo, length=mom_smooth)

        # Classify Squeezes
        squeeze_on = (bbd.l > kch.l) & (bbd.u < kch.u)
        squeeze_off = (bbd.l < kch.l) & (bbd.u > kch.u)
        no_squeeze = ~squeeze_on & ~squeeze_off

        # Offset
        squeeze = squeeze(-offset)
        squeeze_on = squeeze_on(-offset)
        squeeze_off = squeeze_off(-offset)
        no_squeeze = no_squeeze(-offset)

        # Set values for the lines
        self.lines.squeeze[0] = squeeze
        self.lines.squeeze_on[0] = squeeze_on
        self.lines.squeeze_off[0] = squeeze_off
        self.lines.no_squeeze[0] = no_squeeze

    @staticmethod
    def simplify_columns(df, n=3):
        df.columns = df.columns.str.lower()
        return [c.split("_")[0][n - 1:n] for c in df.columns]


