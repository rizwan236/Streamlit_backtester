import os
import sys
import time

import numpy as np
import pandas as pd
import pytz
from scipy import stats
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
from datetime import datetime

import pandas_ta as ta
from PDFconvert import create_pdf


Monday=True
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)


current_datetimeUTC = datetime.now()
weekdayUTC = datetime.now().strftime("%A")

formatted_datetimeUTC = current_datetimeUTC.strftime("%d %b %Y %I:%M %p")
formatted_datetimeIST = ISTnow.strftime("%d %b %Y %I:%M %p")

day=today.weekday() == 1



print("Start csv2")


def calculate_exponential_linear_regression(df,period=12):
    # Download historical data from yfinance
    data =  df # yf.download(stock_symbol, period="1y")
    #print(data)

    # Calculate the natural logarithm of returns
    returns = np.log(data['Close'])
    #print(returns)
    x = np.arange(len(returns))
    #print(x)

    slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
    annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100
    r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
    annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    #print(slope)
    #print(annualized_slope)

    # Calculate linear regression
    #slope, _, r_value, _, _ = stats.linregress(x, returns)

    # Calculate annualized slope
    #annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    # Calculate annualized_slope_r_value
    #annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Round the annualized slope and annualized_slope_r_value
    rounded_annualized_slope = round(annualized_slope, 2)

    # Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    higher_value = annualized_slope_r_value #np.maximum(annualized_slope_r_value, rounded_annualized_slope)

    return higher_value


# Specify the folder path containing CSV files
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'  # Replace with the actual folder path
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()[:]
symbols = list(dict.fromkeys(symbols))  #list(set(symbols))
indices= ['^NSEI', 'BSE-500.BO', '^NSEMDCP50', 'NIFTYSMLCAP250.NS', 'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'BTC-USD', 'GOLDBEES.NS', '^NSEBANK', 'PSUBNKBEES.BO', '^CNXPSUBANK', 'NIFTYPVTBANK.NS', 'NIFTY_FIN_SERVICE.NS', '^CNXAUTO', '^CNXREALTY', '^CNXCMDT', '^CNXMETAL', '^CNXINFRA', 'ICICIINFRA.NS', 'PHARMABEES.NS', '^CNXPHARMA', '^CNXFMCG', '^CNXCONSUM', '^CNXIT', '^CNXENERGY', '^CRSLDX', 'MON100.NS', 'MAFANG.NS','HNGSNGBEES.NS', 'MAHKTECH.NS', 'SBIGETS.BO', 'AXISCETF.NS']

NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(ticker_path)
NSE570symbols = ticker_df['Symbol'].tolist()[:]
NSE570symbols = list(dict.fromkeys(symbols))


selected_files = []

valid_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))


# Initialize counters for MRP13 and MRP25
CountBExp = 0
mrp13_count_more0 = 0
mrp25_count_less0 = 0
mrp25_count_more0 = 0
mrp13_countbothless0 = 0
mrp25_countbothmore0 = 0
CountS_DCH = 0
total_files = 0
file_names = []
Bullish = []
Bearish = []
Start_countmore0 = 0
mrp25_count_mores10 = 0
mrp25_mores10 = []
mrp25_count_M1L1 =[]
mrp25_count_M1L2 =[]
CountS_TTMSqueeze =0
CountS_fall =0
S_TTMSqueeze=[]
S_fall=[]
S_DCH =[]
CountS_EMA=0
S_EMS=[]
BExpShort=[]
CountBExplong=0
BExplong=[]
CountB52high =0
B52High=[]
CountBRSI = 0
BRSI =[]
CountBMRP = 0
BMRP =[]
CountBBTTM =0
BBBTTM = []
CountFinalSell=0
FinalSell=[]
CountFinalBUY=0
FinalBUY=[]
S_ROC =[]
S_DD_PCT_30 =[]
B_DD_PCT_30 =[]
expLonly =[]
expSonly =[]
indiceNOLONG=[]
indiceNOSHORT=[]
EFIU=[]
EFID=[]
SMA_V7SMA_V40=[]
_52wkH =[]
_52wkL =[]
SMAUP=[]
SMADWN=[]
RSIUP=[]
RSIDWN=[]
DDPCTlist=[]
MRPUP=[]
MRPDWN =[]

# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    if file_name.endswith('.csv'):
        file_path = os.path.join(folder_path, file_name)
        #total_files += 1
        base_name = os.path.splitext(file_name)[0]
        #file_names.append(base_name)
        #print(base_name)
        if base_name in symbols:
            file_path = os.path.join(folder_path, file_name)
            selected_files.append(file_path)
            total_files += 1

            # Read the CSV file into a DataFrame
            df = pd.read_csv(file_path)
            dfexp=df
            #print(df)

            #df['CCI'] = df.ta.cci(df['High'], df['Low'], df['Close'], window=34)
            #df['CCI'] = tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34)
            #df['CCIavg'] = tb.SMA(df['CCI'], timeperiod=12)
            #df['ADX'] = tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
            #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
            #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
            #df['macd'], df['macdsignal'], df['macdhist'] = tb.MACD(df['Close'], fastperiod=12, slowperiod=26, signalperiod=9)
            #df['ATR'] = tb.ATR(df['High'], df['Low'], df['Close'], timeperiod=10)
            #df['SuperTrend_Upper_Band'] = df['High'] + (3 * df['ATR'])
            #df['SuperTrend_Lower_Band'] = df['Low'] - (3 * df['ATR'])
            #df['SuperTrend'] = (df['SuperTrend_Upper_Band'] + df['SuperTrend_Lower_Band']) / 2
            #df['VolumeSMA'] = tb.SMA(df['Volume'], timeperiod=14)

            ###############################
            df["CCI"]=tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34)
            df["CCImovavgL"] = tb.SMA(df["CCI"], timeperiod=20
            )
            df["CCImovavgS"] = tb.SMA(df["CCI"], timeperiod=7)
            df["macd"], df["macdsignal"], df["macdhist"] = tb.MACDEXT(df['Close'], fastperiod=12, fastmatype=0, slowperiod=26, slowmatype=0, signalperiod=9, signalmatype=0)
            df["ADX"]= tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
            df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
            df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
            df["RSI"] = tb.RSI(df['Close'], timeperiod=10)
            df["OBV"] = tb.OBV(df['Close'], df['Volume'])
            df["obvmovavg"] = tb.SMA(df["OBV"], timeperiod=14)
            supertrend_values= ta.supertrend(high=df['High'], low=df['Low'], close=df['Close'], length=10, multiplier=3)#, offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
            df['ST'] = supertrend_values['SUPERT_10_3.0']
            df["EMA_26"] = tb.EMA(df['Close'], timeperiod=26)
            df["EMA_13"] = tb.EMA(df['Close'], timeperiod=8)
            df["SMA_200"] = tb.SMA(df['Close'], timeperiod=52)
            df["SMA_100"] = tb.SMA(df['Close'], timeperiod=25)
            df["SMA_12"] = tb.SMA(df['Close'], timeperiod=12)
            df["EMA_200"] = tb.EMA(df['Close'], timeperiod=52)
            df["EMA_7W"] = tb.EMA(df['Close'], timeperiod=7)
            df["EMA_5W"] = tb.EMA(df['Close'], timeperiod=5)
            df["52wkH"] = tb.MAX(df['Close'], timeperiod=52)
            df["52wkL"] = tb.MAX(df['Close'], timeperiod=52)
            #donchian_values=ta.donchian(df['High'], df['Low'], lower_length=20, upper_length=20, offset=None,)
            #df= pd.concat([df, donchian_values], axis=1)
            #df["DCH"]= ((df["DCU_20_20"] - df["DCL_20_20"]) / (df["DCU_20_20"] / 1)) * 100
            #df["DCHema"] = tb.SMA(df["DCH"], timeperiod=14)
            df['Exp_lin_reg']= exp12 = calculate_exponential_linear_regression(df,period=20)
            df['Exp_lin_regslow']= exp50 = calculate_exponential_linear_regression(df,period=50)
            #df["upperband"], df["middleband"], df["lowerband"] = tb.BBANDS(df['Close'], timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
            squeeze_pro=ta.squeeze_pro(df['High'], df['Low'], df['Close'], bb_length=20, bb_std=2, kc_length=20, kc_scalar_wide=2, kc_scalar_normal=1.5, kc_scalar_narrow=1, mom_length=12, mom_smooth=6,)# use_tr=None, mamode=None,)
            #print(squeeze_pro) # //WIDE SQUEEZE: ORANGE , NORMAL SQUEEZE: RED ,NARROW SQUEEZE: YELLOW ,FIRED WIDE SQUEEZE: GREEN ,NO SQUEEZE: BLUE
            df= pd.concat([df, squeeze_pro], axis=1)
            df['ROC_1']=tb.ROC(df['Close'], timeperiod=1)
            df['ROC_2']=tb.ROC(df['Close'], timeperiod=2)
            df['ROC_4']=tb.ROC(df['Close'], timeperiod=4)
            df['ROC_12']=tb.ROC(df['Close'], timeperiod=12)
            df['ROC_24']=tb.ROC(df['Close'], timeperiod=24)
            df['ROC_51']=tb.ROC(df['Close'], timeperiod=52)
            df["SMA_V200"] = tb.SMA(df['Volume'], timeperiod=52)
            #df["MAX_V200"] = tb.MAX(df['Volume'], timeperiod=51)
            df["SMA_V40"] = tb.SMA(df['Volume'], timeperiod=20)
            df["SMA_V7"] = tb.SMA(df['Volume'], timeperiod=7)
            df["SMA_V2"] = tb.SMA(df['Volume'], timeperiod=2)

            symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))



            #print(df['ROC_1'],df["SMA_V200"])



            #df["BBSqueezeavg"] = tb.SMA(df["BBSqueezeid"], timeperiod=12)
            #SQZPRO_20_2.0_20_2.0_1.5_1.0  SQZPRO_ON_WIDE  SQZPRO_ON_NORMAL  SQZPRO_ON_NARROW  SQZPRO_OFF  SQZPRO_NO


            #SELL
            #and ((self.inds[d]["BBSqueezeavg"][0] < 0 and self.inds[d]["BBSqueezeid"][0] < 0 and self.inds[d]["ADX"][0] < 35 and d.close[0] > 0)
            #or ((self.inds[d]["CCI"] < 0 or self.inds[d]["ST"][0] > d.close[0]) and self.inds[d]["EMA_5W"] > d.close[0] > 0)
            #or (self.inds[d]["ADX"][0] < 35 and d.close[0] > 0 and (self.inds[d]["DCH"] < self.inds[d]["DCHema"] or self.inds[d]["DCH"] < 30))
            #or ((self.inds[d]["EMA_200"] or self.inds[d]["SMA_200"]) > self.inds[d]["EMA_13"]))


            if len(df) > 0 and df["ROC_1"].iloc[-1] > df["ROC_2"].iloc[-1] > df["ROC_4"].iloc[-1] > df["ROC_12"].iloc[-1] > df["ROC_24"].iloc[-1] > df["ROC_51"].iloc[-1]:
                S_ROC.append(base_name)
            elif len(df) > 0 and df['Close'].iloc[-1] > 0 and df['ADX'].iloc[-1] < 35 and (df['SQZPRO_20_2.0_20_2.0_1.5_1.0'].iloc[-1] <= 0 or (df['SQZPRO_ON_NORMAL'].iloc[-1] and df['SQZPRO_ON_NARROW'].iloc[-1])  == 1) and df['CCI'].iloc[-1] < 0 : #df['CCI'].iloc[-1] < df['CCImovavg'].iloc[-1]
                CountS_TTMSqueeze += 1
                S_TTMSqueeze.append(base_name)
                FinalSell.append(base_name)
            #elif:
            elif len(df) > 0 and df['Close'].iloc[-1] > 0 and (df["CCI"].iloc[-1] < 0 or df["ST"].iloc[-1] > df['Close'].iloc[-1]) and df["EMA_5W"].iloc[-1] > df['Close'].iloc[-1] > 0:
                CountS_fall += 1
                S_fall.append(base_name)
                FinalSell.append(base_name)
            #elif:
            elif len(df) > 0 and df["ADX"].iloc[-1] < 35 and df['Close'].iloc[-1] > 0 and (df["DCH"].iloc[-1] < 10): #df["DCH"].iloc[-1] < df["DCHema"].iloc[-1] or
                CountS_DCH += 1
                S_DCH.append(base_name)
                FinalSell.append(base_name)
            else:
                if len(df) > 0 and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) > df["EMA_13"].iloc[-1]:
                    CountS_EMA += 1
                    S_EMS.append(base_name)
                    FinalSell.append(base_name)

            #print(df)


            if len(df) > 0 and df["DD_PCT"].iloc[-1] > 25 and (df["macdhist"].iloc[-1] < 0 or df['ADX'].iloc[-1] < 30 or df["CCI"].iloc[-1] < 0 or df["ST"].iloc[-1] > df['Close'].iloc[-1] or df["DCH"].iloc[-1] < 10 or df['SQZPRO_20_2.0_20_2.0_1.5_1.0'].iloc[-1] <= 0 or df['SQZPRO_ON_NARROW'].iloc[-1] == 1):
                #print(base_name)
                value_to_append = f"{base_name}-{round(df['DD_PCT'].iloc[-1], 1)}"
                S_DD_PCT_30.append(value_to_append)
                #print(value_to_append)
                FinalSell.append(value_to_append)


            #print(S_DD_PCT_30)
            # Sort S_DD_PCT_50 directly based on the number after the hyphen:
            S_DD_PCT_30.sort(key=lambda x: float(x.split('-')[-1]))
            #print(S_DD_PCT_30)

            # Sort S_DD_PCT_50 from lowest to highest
            #sorted_values = sorted([float(item.split('-')[1]) for item in S_DD_PCT_30])
            #S_DD_PCT_30 = [item for _, item in sorted(zip(sorted_values, S_DD_PCT_30))]
            #print(S_DD_PCT_30)


            #BUY
            #and ((self.inds[d]["Exp_lin_reg"][0] > 40 and self.inds[d]["CCI"] > 0 and d.close[0] > 0000000000000 )
            #or (self.inds[d]["Exp_lin_regslow"] > 40 and self.inds[d]["CCI"] > 0 and d.close[0] > 000000000000000000)
            #or ((self.inds[d]["BBSqueezeavg"][-2] < 0 or self.inds[d]["BBSqueezeavg"][-2] < 0 or self.inds[d]["BBSqueezeavg"][-2] < 0 or self.inds[d]["BBSqueezeavg"][-1] < 0) and  self.inds[d]["CCI"] > 0 and self.inds[d]["CCImovavg"] < self.inds[d]["CCI"] and d.close[0] > 00000000000000 and self.inds[d]["BBSqueezeid"][0] > 1 )
            #or ( 0 > d.MRP25[-4] < d.MRP25[0] > 2 and d.close[0] > 00000000000 and d.MRP13[-4] < d.MRP13[-2] < d.MRP13[0] > 2 and self.inds[d]["CCI"] > 0)
            #or (self.inds[d]["RSI"][0] > 55 and self.inds[d]["EMA_7W"] < d.close[0] and self.inds[d]["CCImovavg"] < self.inds[d]["CCI"] and d.close[0] > 00000000000)
            #or (self.inds[d]["CCImovavg"] < self.inds[d]["CCI"] and self.inds[d]["52wkH"][-1] < d.close[0] and self.inds[d]["CCI"] > 0 and self.inds[d]["EMA_200"] < self.inds[d]["EMA_26"] < self.inds[d]["EMA_13"] < d.close[0]))
            #and (self.inds[d]["EMA_200"] or self.inds[d]["SMA_200"]) < self.inds[d]["EMA_13"]
            #d.close[0] > 15
            #and self.inds[d]["ST"][0] < d.close[0]
            #and self.inds[d]["ADX"] > 25
            #and self.inds[d]["OBV"][0] > self.inds[d]["obvmovavg"][0]*1.05
            #and self.inds[d]["DIind"].plusDI > self.inds[d]["DIind"].minusDI
            #and (self.inds[d]["macdsignal"][0] < self.inds[d]["macd"][0] or self.inds[d]["macdH"][0] > 0)

            #if len(df) > 0 and (df["ST"].iloc[-1] < df['Close'].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and df['PLUS_DI'].iloc[-1] > df['MINUS_DI'].iloc[-1] and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and (df['SQZPRO_20_2.0_20_2.0_1.5_1.0'].iloc[-1] > 0 or (df['SQZPRO_OFF'].iloc[-1] or df['SQZPRO_NO'].iloc[-1])  == 1 and df["CCI"] > 0 and df["CCImovavg"] < df["CCI"] and df['Close'].iloc[-1] > 00000000000000 ):# and df["upperband"].iloc[-1]  < df['Close'].iloc[-1] ):
            #    CountBBTTM += 1
            #    BBBTTM.append(base_name)
            #    FinalBUY.append(base_name)
            # Check if the last row's 'MRP13' value is both less than 0 and more than 0

            '''
            #if base_name in indices:
            #    Base_name=symbol_to_company.get(base_name, base_name)
            #    value_to_append = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}--{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
            #    value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
            #    indiceNOSHORT.append(value_to_append)
            #    indiceNOLONG.append(value_to_append1)
            #    #print(base_name)
            '''
            ##########################
            if len(df) > 0 and df["SMA_200"].iloc[-1] < df["SMA_12"].iloc[-1] and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df["SMA_V200"].iloc[-7]*1.5 < df['SMA_V7'].iloc[-1] and df["RSI"].iloc[-1] > 70:
                CountBExp += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                RSI = df["RSI"].iloc[-1]
                #print(Base_name)
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}***{round(RSI, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                RSIUP.append(value_to_append)
                #BExpShort.append(value_to_append1)
                #print(expSonly)
                FinalBUY.append(base_name)
            #elif:
            if len(df) > 0 and df["SMA_200"].iloc[-1] > df["SMA_12"].iloc[-1] and df["obvmovavg"].iloc[-1] > df["OBV"].iloc[-1] and df["RSI"].iloc[-1] < 30:
                CountBExplong += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                #print(Base_name)
                RSI = df["RSI"].iloc[-1]
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}***{round(RSI, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                RSIDWN.append(value_to_append)
                #BExplong.append(value_to_append1)
                FinalBUY.append(base_name)


            #########################
            if len(df) > 0 and df["52wkH"].iloc[-2] < df['Close'].iloc[-1] and df["SMA_V40"].iloc[-2] < df['Volume'].iloc[-1] and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df['Close'].iloc[-1] > 15 and df["RSI"].iloc[-1] > 55:
                CountBExp += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['Volume'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                #print(Base_name)
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                _52wkH.append(value_to_append)
                #BExpShort.append(value_to_append1)
                #print(expSonly)
                FinalBUY.append(base_name)
            if len(df) > 0 and df["52wkL"].iloc[-2] > df['Close'].iloc[-1] and df["SMA_V40"].iloc[-2] < df['Volume'].iloc[-1] and df["obvmovavg"].iloc[-1] > df["OBV"].iloc[-1] and df['Close'].iloc[-1] > 15 and df["RSI"].iloc[-1] < 45:
                CountBExp += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['Volume'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                #print(Base_name)
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                _52wkL.append(value_to_append)
                #BExpShort.append(value_to_append1)
                #print(expSonly)
                FinalBUY.append(base_name)

            ####################
            if len(df) > 0 and df['ROC_1'].iloc[-1] > 10 and df["SMA_V200"].iloc[-2]*4 < df['Volume'].iloc[-1] and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df['Close'].iloc[-1] > 0000000000000:
                CountBExp += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['Volume'].iloc[-1]/df["SMA_V200"].iloc[-2],1)
                #print(Base_name)
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                EFIU.append(value_to_append)
                #BExpShort.append(value_to_append1)
                #print(expSonly)
                FinalBUY.append(base_name)
            #elif:
            if len(df) > 0 and df['ROC_1'].iloc[-1] < -10 and df["SMA_V200"].iloc[-2]*3 < df['Volume'].iloc[-1] and df["obvmovavg"].iloc[-1] > df["OBV"].iloc[-1] and df['Close'].iloc[-1] > 0000000000000:
                CountBExplong += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['Volume'].iloc[-1]/df["SMA_V200"].iloc[-2],1)
                #print(Base_name)
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                EFID.append(value_to_append)
                #BExplong.append(value_to_append1)
                FinalBUY.append(base_name)
            if len(df) > 0 and df["SMA_V40"].iloc[-8]*3 < df["SMA_V7"].iloc[-1] and df["SMA_V40"].iloc[-8]*2 < df['Volume'].iloc[-1] and df['Close'].iloc[-1] > 0000000000000:
                CountBExplong += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],1)
                #print(Base_name)
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                SMA_V7SMA_V40.append(value_to_append)
                #BExplong.append(value_to_append1)
                FinalBUY.append(base_name)

            ##########################
            if len(df) > 0 and (df["MRP13"].iloc[-1] and df["MRP25"].iloc[-1])> 0 and df["RSI"].iloc[-1] > 55 and df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1] and df["CCI"].iloc[-1] > 0 and df["SMA_V200"].iloc[-8]*1.5 < df['SMA_V7'].iloc[-1]:
                CountBExp += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                RSI = df["RSI"].iloc[-1]
                #print(Base_name)
                MRPx= max(df["MRP13"].iloc[-1],df["MRP25"].iloc[-1])
                value_to_append = f"{Base_name}*{round(df['RSI'].iloc[-1], 1)}**{round(VX, 1)}***{round(MRPx, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                MRPUP.append(value_to_append)
                #BExpShort.append(value_to_append1)
                #print(expSonly)
                FinalBUY.append(base_name)
            #elif:
            if len(df) > 0 and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) < 0 and df["obvmovavg"].iloc[-1] > df["OBV"].iloc[-1] and df["CCI"].iloc[-1] < 0:
                CountBExplong += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                #print(Base_name)
                RSI = df["RSI"].iloc[-1]
                MRPx= min(df["MRP13"].iloc[-1],df["MRP25"].iloc[-1])
                value_to_append = f"{Base_name}*{round(df['RSI'].iloc[-1], 1)}**{round(VX, 1)}***{round(MRPx, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                MRPDWN.append(value_to_append)
                #BExplong.append(value_to_append1)
                FinalBUY.append(base_name)


            ##########################
            if len(df) > 0 and df["SMA_200"].iloc[-1] < df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] and df["EMA_26"].iloc[-1] < df["EMA_13"].iloc[-1] and df["SMA_V200"].iloc[-4]*1.5 < df['SMA_V2'].iloc[-1] and df["RSI"].iloc[-1] > 55:
                CountBExp += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                RSI = df["RSI"].iloc[-1]
                #print(Base_name)
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}***{round(RSI, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                SMAUP.append(value_to_append)
                #BExpShort.append(value_to_append1)
                #print(expSonly)
                FinalBUY.append(base_name)
            #elif:
            if len(df) > 0 and df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] and df["EMA_26"].iloc[-1] > df["EMA_13"].iloc[-1] and df["SMA_V200"].iloc[-4]*1.5 < df['SMA_V2'].iloc[-1] and df["RSI"].iloc[-1] < 45:
                CountBExplong += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-2],1)
                #print(Base_name)
                RSI = df["RSI"].iloc[-1]
                value_to_append = f"{Base_name}*{round(df['ROC_1'].iloc[-1], 1)}**{round(VX, 1)}***{round(RSI, 1)}"
                #value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                SMADWN.append(value_to_append)
                #BExplong.append(value_to_append1)
                FinalBUY.append(base_name)

            #########################

            if base_name in NSE570symbols:
                if len(df) > 0 and df["DD_PCT"].iloc[-1] > 20:
                    Base_name=symbol_to_company.get(base_name, base_name)
                    DD_PCT= df["DD_PCT"].iloc[-1]
                    #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                    value_to_append1 = f"{Base_name}*{round(df['RSI'].iloc[-1], 1)}*{round(df['CCI'].iloc[-1], 1)}**{round(DD_PCT, 1)}"
                    DDPCTlist.append(value_to_append1)
                    #indiceNOLONG.append(value_to_append1)


            #########################

            if base_name in indices:
                Base_name=symbol_to_company.get(base_name, base_name)
                value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                value_to_append1 = f"{Base_name}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                indiceNOSHORT.append(value_to_append)
                indiceNOLONG.append(value_to_append1)
                #print(base_name)

            if len(df) > 0 and (df["ST"].iloc[-1] < df["Close"].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and df['PLUS_DI'].iloc[-1] > df['MINUS_DI'].iloc[-1] and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and df["Exp_lin_reg"].iloc[-1]  > 40 and (df["CCI"].iloc[-1] > 0 or df["CCImovavgL"].iloc[-1] < df["CCImovavgS"].iloc[-1] < df["CCI"].iloc[-1]) and df['Close'].iloc[-1] > 0000000000000:
                CountBExp += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                #print(Base_name)
                value_to_append = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}--{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                value_to_append1 = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}"
                expSonly.append(value_to_append)
                BExpShort.append(value_to_append1)
                #print(expSonly)
                FinalBUY.append(base_name)
            #elif:
            if len(df) > 0 and (df["ST"].iloc[-1] < df['Close'].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and df['PLUS_DI'].iloc[-1] > df['MINUS_DI'].iloc[-1] and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and df["Exp_lin_regslow"].iloc[-1]  > 40 and (df["CCI"].iloc[-1] > 0 or df["CCImovavgL"].iloc[-1] < df["CCImovavgS"].iloc[-1] < df["CCI"].iloc[-1]) and df['Close'].iloc[-1] > 0000000000000:
                CountBExplong += 1
                Base_name=symbol_to_company.get(base_name, base_name)
                #print(Base_name)
                value_to_append = f"{Base_name}-{round(df['Exp_lin_reg'].iloc[-1], 1)}--{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                value_to_append1 = f"{Base_name}-{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                expLonly.append(value_to_append)
                BExplong.append(value_to_append1)
                FinalBUY.append(base_name)
                #if len(df) > 0 and (df["ST"].iloc[-1] < df['Close'].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and df['PLUS_DI'].iloc[-1] > df['MINUS_DI'].iloc[-1] and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and df["Exp_lin_regslow"].iloc[-1]  > 40 and df["CCI"].iloc[-1] > 0 and df['Close'].iloc[-1] > 0000000000000 :
                #    CountBExplong += 1
                #    BExplong.append(base_name)
            #elif:
            if len(df) > 0 and (df["ST"].iloc[-1] < df['Close'].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and df['PLUS_DI'].iloc[-1] > df['MINUS_DI'].iloc[-1] and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and (df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and df["52wkH"].iloc[-2] < df['Close'].iloc[-1] and df["CCI"].iloc[-1] > 0 and df["EMA_200"].iloc[-1] < df["EMA_26"].iloc[-1] < df["EMA_13"].iloc[-1] < df['Close'].iloc[-1]):
                CountB52high += 1
                B52High.append(base_name)
                FinalBUY.append(base_name)
            #elif:
            if len(df) > 0 and (df["ST"].iloc[-1] < df['Close'].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and (df["RSI"].iloc[-1] > 61 and df["EMA_7W"].iloc[-1] < df['Close'].iloc[-1] and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and df['Close'].iloc[-1] > 00000000000):
                CountBRSI += 1
                BRSI.append(base_name)
                FinalBUY.append(base_name)
            #elif:
            if len(df) > 0 and (df["ST"].iloc[-1] < df['Close'].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and df['PLUS_DI'].iloc[-1] > df['MINUS_DI'].iloc[-1] and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and ( 0 > df["MRP25"].iloc[-4] < df["MRP25"].iloc[-1] > 2 and df['Close'].iloc[-1] > 00000000000 and df["MRP13"].iloc[-4] < df["MRP13"].iloc[-2] < df["MRP13"].iloc[-1] > 2 and df["CCI"].iloc[-1] > 0):
                CountBMRP += 1
                BMRP.append(base_name)
                FinalBUY.append(base_name)
            else:
                if len(df) > 0 and (df["ST"].iloc[-1] < df['Close'].iloc[-1] and df["ADX"].iloc[-1] > 25 and df["OBV"].iloc[-1] > df["obvmovavg"].iloc[-1]*1.05 and df['PLUS_DI'].iloc[-1] > df['MINUS_DI'].iloc[-1] and (df["macdsignal"].iloc[-1] < df["macd"].iloc[-1] or df["macdhist"].iloc[-1] > 0) and (df["EMA_200"].iloc[-1] or df["SMA_200"].iloc[-1]) < df["EMA_13"].iloc[-1]) and (df['SQZPRO_20_2.0_20_2.0_1.5_1.0'].iloc[-1] > 0 or (df['SQZPRO_OFF'].iloc[-1] or df['SQZPRO_NO'].iloc[-1])  == 1 and df["CCI"] > 0 and df["CCImovavg"] < df["CCI"] and df['Close'].iloc[-1] > 00000000000000 ):# and df["upperband"].iloc[-1]  < df['Close'].iloc[-1] ):
                    CountBBTTM += 1
                    BBBTTM.append(base_name)
                    FinalBUY.append(base_name)

            if len(df) > 0 and df["DD_PCT"].iloc[-1] > 25 and (df["macdhist"].iloc[-1] > 0 and df['ADX'].iloc[-1] > 30 and df["CCI"].iloc[-1] > 0 and df["ST"].iloc[-1] < df['Close'].iloc[-1] ):
                #print(base_name)
                value_to_append = f"{base_name}-{round(df['DD_PCT'].iloc[-1], 1)}"
                B_DD_PCT_30.append(value_to_append)
                #print(value_to_append)
                #FinalSell.append(value_to_append)

expLonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
expSonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
EFIU.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
EFID.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
SMA_V7SMA_V40.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkL.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkH.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
SMAUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
SMADWN.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIDWN.sort(key=lambda x: float(x.split('***')[-1]), reverse=False) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
DDPCTlist.sort(key=lambda x: float(x.split('**')[-1]), reverse=True)
MRPUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True)
MRPDWN.sort(key=lambda x: float(x.split('***')[-1]), reverse=False)



#indiceNOSHORT.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOSHORT[0] = 'Indices Exp lin Short-Long'

#indiceNOLONG.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOLONG[0] = 'Indices Exp lin Long'

for i in range(0, len(indiceNOSHORT), 35):
        block = indiceNOSHORT[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        post_telegram_message('\n'.join(block))

for i in range(0, len(indiceNOLONG), 35):
        block = indiceNOLONG[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        #post_telegram_message('\n'.join(block))

# Calculate percentages
#Exp_percentage_mores40 = (S_TTMSqueeze / total_files) * 100
#print(Exp_percentage_mores40)

#mrp25_percentage_mores10 = (mrp25_count_mores10 / total_files) * 100
#mrp13_percentageless0 = (CountBExp / total_files) * 100
#mrp13_percentagemore0 = (mrp13_count_more0 / total_files) * 100
#mrp25_percentageless0 = (mrp25_count_less0 / total_files) * 100
#mrp25_percentagemore0 = (mrp25_count_more0 / total_files) * 100
#mrp25_percentagebothless0 = (mrp13_countbothless0 / total_files) * 100
#mrp25_percentagebothmore0 = (mrp25_countbothmore0 / total_files) * 100
#df = pd.DataFrame({'RP': file_names})
#df = pd.DataFrame({'BullCandle': Bullish})
#df = pd.DataFrame({'BearCandle': Bearish})
BUYmax_length = max(len(file_names), len(BExpShort), len(BExplong), len(B52High) , len(BRSI),len(BMRP),len(BBBTTM),len(B_DD_PCT_30) )
SELLmax_length = max(len(file_names), len(S_TTMSqueeze),len(S_ROC), len(S_fall), len(S_DCH) , len(S_EMS),len(S_DD_PCT_30),)

expmax_length = max(len(file_names), len(expSonly),len(expLonly),len(BExpShort),len(BExplong),len(EFIU),len(EFID))#,len(indiceNO))
VXmax_length = max(len(file_names), len(EFIU),len(EFID),len(SMA_V7SMA_V40))
_52wk_length = max(len(file_names), len(_52wkH),len(_52wkL))
SMA_length = max(len(file_names), len(SMAUP),len(SMADWN),len(SMADWN))
RSI_length = max(len(file_names), len(RSIUP),len(RSIDWN),len(RSIDWN))
DDPCTlist_length = max(len(file_names), len(DDPCTlist),len(DDPCTlist),len(DDPCTlist))
MRP_length = max(len(file_names), len(MRPDWN),len(MRPUP))

DDPCTlist_data = {
    'RSIUP*RSI*CCI*DDPCT>20': DDPCTlist + ['--'] * (DDPCTlist_length - len(DDPCTlist))
}

RSI_data = {
    'RSIUP*ROC**Vx***RSI': RSIUP + ['--'] * (RSI_length - len(RSIUP)),
    'RSIDWN*ROC**Vx***RSI': RSIDWN + ['--'] * (RSI_length - len(RSIDWN))
    #'52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

SMA_data = {
    'SMAUP*ROC**Vx***RSI': SMAUP + ['--'] * (SMA_length - len(SMAUP)),
    'SMADWN*ROC**Vx***RSI': SMADWN + ['--'] * (SMA_length - len(SMADWN))
    #'52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

_52wkdata = {
    '52wkH-ROC--UP': _52wkH + ['--'] * (_52wk_length - len(_52wkH)),
    '52wkL-ROC--DWN': _52wkL + ['--'] * (_52wk_length - len(_52wkL))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}



expdata = {
    'ExpShort-L--S': expSonly + ['--'] * (expmax_length - len(expSonly)),
    'ExpLong-S--L': expLonly + ['--'] * (expmax_length - len(expLonly))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

VXdata = {
    #'ExpShort-L--S': expSonly + ['--'] * (expmax_length - len(expSonly)),
    #'ExpLong-S--L': expLonly + ['--'] * (expmax_length - len(expLonly))
    'EFIUP-ROC--UP': EFIU + ['--'] * (VXmax_length - len(EFIU)),
    'EFIDWN-ROC--DWN': EFID + ['--'] * (VXmax_length - len(EFID)),
    'SMA_V7/V40-ROC--V': SMA_V7SMA_V40 + ['--'] * (VXmax_length - len(SMA_V7SMA_V40))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

BUYdata = {
    'TTM': BBBTTM + ['--'] * (BUYmax_length - len(BBBTTM)),
    #'ExpShort': BExpShort + ['--'] * (BUYmax_length - len(BExpShort)),
    #'Explong': BExplong + ['--'] * (BUYmax_length - len(BExplong)),
    'RSI': BRSI + ['--'] * (BUYmax_length - len(BRSI)),
    'DD_PCT_25': B_DD_PCT_30 + ['--'] * (BUYmax_length - len(B_DD_PCT_30)),
    '52High': B52High + ['--'] * (BUYmax_length - len(B52High)),
    'MRP': BMRP + ['--'] * (BUYmax_length - len(BMRP))
}

SELLdata = {
    'TTM': S_TTMSqueeze + ['--'] * (SELLmax_length - len(S_TTMSqueeze)),
    'ROC': S_ROC + ['--'] * (SELLmax_length - len(S_ROC)),
    'Fall': S_fall + ['--'] * (SELLmax_length - len(S_fall)),
    'DD_PCT_25': S_DD_PCT_30 + ['--'] * (SELLmax_length - len(S_DD_PCT_30)),
    'DCH': S_DCH + ['--'] * (SELLmax_length - len(S_DCH)),
    'SEMA200': S_EMS + ['--'] * (SELLmax_length - len(S_EMS))
}


dfBUY = pd.DataFrame(BUYdata)
dfSELL = pd.DataFrame(SELLdata)
dfexpdata = pd.DataFrame(expdata)
dfVXdata = pd.DataFrame(VXdata)
df52wkdata = pd.DataFrame(_52wkdata)
dfSMA_data = pd.DataFrame(SMA_data)
dfRSI_data = pd.DataFrame(RSI_data)
dfDDPCTlist_data =pd.DataFrame(DDPCTlist_data)

#print(dfBUY)
#print(dfSELL)
#print(dfexpdata)

def replace_values(sector_file, valid_file, output_file):
    # Read valid file to create a mapping of 'Symbol' to 'Company'
    valid_df = pd.read_csv(valid_file)
    symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

    # Read sector file
    sector_df = pd.read_csv(sector_file)

    print(sector_df)

    # Replace values in specified columns with corresponding 'Company' values
    columns_to_replace = ['RP24M5_12M4', 'RP25_mores8', 'MRP25_Crossover', 'Exp_H35']
    for col in columns_to_replace:
        sector_df[col] = sector_df[col].map(symbol_to_company)

    # Save the result to a new file
    sector_df.to_csv(output_file, index=False)

old52wkdataWkly_path = '/home/rizpython236/BT5/trade-logs/52wkdataWkly.csv'
old52wkdataWklydf = pd.read_csv(old52wkdataWkly_path)


dfBUY.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv', index=False)
dfSELL.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv', index=False)
dfexpdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv', index=False)
dfVXdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/screener-outputs/52wkdataWkly.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/trade-logs/52wkdataWkly.csv', index=False)
dfSMA_data.to_csv('/home/rizpython236/BT5/screener-outputs/200SMACrossWkly.csv', index=False)
dfRSI_data.to_csv('/home/rizpython236/BT5/screener-outputs/RSIdataWkly.csv', index=False)
dfDDPCTlist_data.to_csv('/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.csv', index=False)

# Example usage:
#sector_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#valid_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#replace_values(sector_file, valid_file, output_file)

if weekday != "Tuesday":
    dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
    dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
    dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
    print("Made copy of Old file")


input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/52wkdataWkly.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/52wkdataWkly.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossWkly.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossWkly.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/RSIdataWkly.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/RSIdataWkly.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)


time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf')
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf')
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf')
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistEFIWkly.pdf')
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/52wkdataWkly.pdf')
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCTdataWkly.pdf')
time.sleep(2)
if dfRSI_data.empty:
    print("RSI_data is empty")
else:
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/RSIdataWkly.pdf')
time.sleep(2)
if dfSMA_data.empty:
    print("SMA_data is empty")
else:
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/200SMACrossWkly.pdf')



#print(df)
#print(Start_countmore0)
#df.to_csv('/home/rizpython236/BT5/screener-outputs/Relative_perf.csv', index=False)

#time.sleep(2)

#input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  # Replace with your CSV file
#output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  # Replace with desired output PDF file

#create_pdf(input_csv_file, output_pdf_file)

##post_telegram_file('/home/rizpython236/BT5/screener-outputs/Relative_perf.pdf')




#######################

if 1==1:
#try:
    if weekday == "Wednesday":
        print("Running Chgwatchlist")
        try:
            Buyfile_path = '/home/rizpython236/BT5/OldwatchlistBUY.csv'
            Bolddf = pd.read_csv(Buyfile_path)

            Sellfile_path = '/home/rizpython236/BT5/OldwatchlistSELL.csv'
            Solddf = pd.read_csv(Sellfile_path)

            expfile_path = '/home/rizpython236/BT5/OldwatchlistExpLinR.csv'
            expdf = pd.read_csv(expfile_path)
        except Exception as e:
            print(f"file not found Oldgwatchlist- {e}")
            pass


        dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
        dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
        dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
        print("Made copy of Old file")


        new =dfBUY
        old = Bolddf
        change = pd.DataFrame()
        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])
        #new['DD_PCT_25'] = new['DD_PCT_25'].applymap(lambda x: x.rsplit('-', 1)[-1])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])


        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf')



        ####

        new =dfSELL
        old = Solddf
        change = pd.DataFrame()

        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf')


        ####

        new =dfexpdata
        old = expdf
        change = pd.DataFrame()

        new['ExpLong-S--L'] = new['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])
        old['ExpLong-S--L'] = old['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        old['ExpShort-L--S'] = old['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])
        new['ExpShort-L--S'] = new['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf')

        ##########
        new =df52wkdata
        old = old52wkdataWklydf
        change = pd.DataFrame()

        new['52wkH-ROC--UP'] = new['52wkH-ROC--UP'].apply(lambda x: x.split('*')[0])
        old['52wkH-ROC--UP'] = old['52wkH-ROC--UP'].apply(lambda x: x.split('*')[0])

        old['52wkL-ROC--DWN'] = old['52wkL-ROC--DWN'].apply(lambda x: x.split('*')[0])
        new['52wkL-ROC--DWN'] = new['52wkL-ROC--DWN'].apply(lambda x: x.split('*')[0])

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/Chg52wkWeekly.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkWeekly.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkWeekly.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/Chg52wkWeekly.pdf')

    else:
        1+1
#except Exception as e:
#    print(f"Error in ruuning Chgwatchlist- {e}")
#    pass


print("done")
