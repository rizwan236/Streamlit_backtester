import pandas as pd


print("filtersymbols")


def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df


bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")

# Get unique values in the 'gropp' column
unique_values = bse["Group"].unique()

# Print unique values
# print(unique_values)


bse.drop(
    columns=[
        # "Group",
        # "Face Value",
        # "ISIN No",
        "Industry",
        "Instrument",
        "Sector Name",
        "Industry New Name",
        "Igroup Name",
        "ISubgroup Name",
    ],
    inplace=True,
)

bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Status"] == "Active"]
accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]
bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("FUND")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("Fund")]
# bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
condition = bse["SYMBOL"].str.endswith("*")
bse.loc[condition, "SYMBOL"] = bse.loc[condition, "SYMBOL"].str[:-1]
# Filter dataframe
bse = bse[bse["Group"].isin(accepted_values)]


datanse.drop(
    columns=[
        " SERIES",
        " DATE OF LISTING",
        " PAID UP VALUE",
        " MARKET LOT",
        # " ISIN NUMBER",
        " FACE VALUE",
    ],
    inplace=True,
)

add_suffix_to_column(bse, "SYMBOL", ".BO")
add_suffix_to_column(datanse, "SYMBOL", ".NS")


# Get unique values in the 'gropp' column
unique_values = bse["Group"].unique()

# Print unique values
# print(unique_values)

# print(bse)
# print(datanse)


df_final = pd.read_csv("/home/rizpython236/BT5/Final.csv")
df_holding = pd.read_csv("/home/rizpython236/BT5/myholding.csv")
df_exclude = pd.read_csv("/home/rizpython236/BT5/exclude_tickers.csv")

# Replace with appropriate column name
holding_items = set(df_holding["Symbol"])
# Replace with appropriate column name
exclude_items = set(df_exclude["Symbol"])


# filter_fn = lambda row: (row['Symbol'] not in list(holding_items)) & (row['Symbol'] not in list(exclude_items))
# | (~df_final['Symbol'].isin(exclude_items))]
filtered_df = df_final[(~df_final["Symbol"].isin(holding_items))]
filtered_df1 = filtered_df[(~filtered_df["Symbol"].isin(exclude_items))]

combined_df = pd.concat([filtered_df, filtered_df1], ignore_index=True)
combined_df = combined_df.drop_duplicates()

# print(filtered_df1)


print(len(df_final), len(holding_items), len(exclude_items))
print(len(filtered_df), len(filtered_df1))

# filtered_final = pd.read_csv("/home/rizpython236/BT5/screener-outputs/filtered_Final.csv")
valid_tickers = pd.read_csv(
    "/home/rizpython236/BT5/trade-logs/valid_tickers.csv")
comp_tickers = pd.read_csv(
    "/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv")

# print(valid_tickers)
# combined_df['Symbol'].isna().sum()
# valid_tickers['Symbol'].isna().sum()
# combined_df = combined_df.dropna(subset=['Symbol'])
# valid_tickers = valid_tickers.dropna(subset=['Symbol'])


# merged_df = combined_df.merge(valid_tickers, on='Symbol', how='left')
# merged_df = pd.merge(left=combined_df, right=valid_tickers, on='Symbol', how='left')
merged_df = pd.merge(left=combined_df, right=comp_tickers,
                     on="Symbol", how="left")
# merged_df = pd.merge(combined_df, valid_tickers[['Symbol','Company', 'YFindustry', 'Industry']], left_on='Symbol', right_on='Symbol', how='left')
# print(merged_df)
# merged_df = merged_df.sort_values(by='Company')
merged_df = merged_df.sort_values(by="Price")
# merged_df.drop('Industry', axis=1, inplace=True)

# print(filtered_df)
# print(filtered_df1)

# INDdetails = pd.read_csv("/home/rizpython236/BT5/trade-logs/valid_tickers.csv")
# merged_df = merged_df.merge(INDdetails, on='Symbol', how='left')


# merged_df.drop('Industry', axis=1, inplace=True)
# merged_df.drop('LongName', axis=1, inplace=True)
# merged_df.drop('Company_x', axis=1, inplace=True)
# merged_df.drop('YFindustry_x', axis=1, inplace=True)


def sort_key(val):
    if pd.isna(val) or val == "Blank":
        return (1,)  # Put NaN and 'Blank' at the bottom
    return (0, val)  # Normal sorting for other values


merged_df = merged_df.sort_values(
    by=["Industry", "MarketCapCr", "LongName"],
    ascending=[True, True, True],
    na_position="last",
)

# mask = merged_df['LongName'].isna() | (merged_df['LongName'] == 'Blank')

# Sort by Industry, then by price, then by LongName with NaN/Blank at the bottom
# merged_df = merged_df.sort_values(
#    by=['Industry', 'Price', 'LongName'],
#    ascending=[True, True, True],
#    key=lambda col: col.where(col.notna() & (col != 'Blank'), np.inf)
# )


# Create mapping dictionaries
bse_mapping = pd.Series(bse["NAME OF COMPANY"].values,
                        index=bse["SYMBOL"]).to_dict()
nse_mapping = pd.Series(
    datanse["NAME OF COMPANY"].values, index=datanse["SYMBOL"]).to_dict()

# Fill NaN in LongName based on Symbol
for symbol in merged_df["Symbol"]:
    if pd.isna(merged_df.loc[merged_df["Symbol"] == symbol, "LongName"].values[0]):
        # Check BSE mapping
        if symbol in bse_mapping:
            merged_df.loc[merged_df["Symbol"] == symbol,
                          "LongName"] = bse_mapping[symbol]
        # Check NSE mapping
        elif symbol in nse_mapping:
            merged_df.loc[merged_df["Symbol"] == symbol,
                          "LongName"] = nse_mapping[symbol]

# Display the updated DataFrame
print(merged_df)


merged_df.to_csv(
    "/home/rizpython236/BT5/trade-logs/filtered_Final.csv", index=False)
