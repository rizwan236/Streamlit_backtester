import csv
from datetime import datetime
import os
import sys

#from scipy import stats
import time
import traceback

import numpy as np
import pandas as pd
from PDFconvert import create_pdf
import pytz

#import yfinance as yf
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


#sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
#import pandas_ta as ta

'''
use below strategy where the universe of stock ticker is in a csv file
1) 12 month , 6 month ,  3 month  Momentum Ratio =  Price return / σp  # [Price (M-1)/Price (M-13)]-1
2) σp = Annualised standard deviation of lognormal daily returns of the stock for 1 year
3) Z Score of the Momentum Ratio for 12 month , 6 month, 3 month where Z Score= (MR12 - µMR12)/σMR12
4) Weighted Average Z Score = 45% * (12 month Momentum Z Score) + 45% * (6 month Momentum Z Score) + 10% * (3 month Momentum Z Score)
5) Normalized Momentum Score = (1+ Wgt. Average Z score) if Wgt. Average Z score >=0  or (1- Weighted Average Z score)^-1 if Wgt. Average Z score < 0
6) The top 30 stocks with the highest Normalized Momentum Score are selected
The top 30 stocks with the highest Normalized Momentum Score are selected

MR12 is the 12 month Momentum Ratio of the stock
µMR12 is the mean of the 12 month Momentum Ratios of the eligible
universe
σMR12  is the std. deviation of the 12 month Momentum Ratios of the
eligible universe
'''

print("Start BTmomNSE750")
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)

#input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv'
def update_output_file(input_file, output_file):
    """
    Updates the output file with VLOOKUP logic for Symbol, Company, YFindustry, and Industry columns.
    Fills in missing data for symbols without VLOOKUP matches.

    Args:
        input_file (str): Path to the input CSV file.
        output_file (str): Path to the output CSV file.
    """

    df_input = pd.read_csv(input_file)
    df_output = output_file# pd.read_csv(output_file)

    # Sort dataframes before merging to improve performance
    df_input.sort_values('Symbol', inplace=True)
    df_output.sort_values('Symbol', inplace=True)

    # Reduce dataframe size by selecting only necessary columns
    df_input = df_input[['Symbol', 'Company', 'YFindustry', 'Industry']]

    # Perform VLOOKUP and merge using the correct join type (left join in this case)
    merged_data = pd.merge(df_output, df_input, on='Symbol', how='left')

    # Fill 'Company' with corresponding 'Symbol' if it's missing
    merged_data['Company'] = merged_data['Company'].fillna(merged_data['Symbol'])
    merged_data["YFindustry"].fillna("Blank", inplace=True)
    merged_data["Industry"].fillna("Blank", inplace=True)

    # Save the merged data to a new CSV file
    rankedTop30=merged_data
    #merged_data.to_csv(output_file, index=False)

def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].astype(str) + suffix
    #df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df

#folder_path = '/home/rizpython236/BT5/ticker_15yr/'  # Replace with the actual folder path  ticker_daily1yr58
folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
exclude_tickers = pd.read_csv('/home/rizpython236/BT5/exclude_tickers.csv')
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
#ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
#ticker_df = pd.read_csv(ticker_path)
#symbols = ticker_df['Symbol'].tolist()[:]
#symbols = list(dict.fromkeys(symbols))  #list(set(symbols))

#________________________

'''
NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(NSE570_path)
NSE570symbols1 = NSE570ticker_df['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols1))
symbols = list(dict.fromkeys(NSE570symbols1))
number=len(symbols)
print(number)
symbols= [symbol for symbol in NSE570symbols if symbol not in exclude_tickers["Symbol"]]
number=len(symbols)
print(number)
jj
'''

valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

#___________________________________

#NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'         #NSE750
#nse500 = pd.read_csv("/home/rizpython236/BT5/nse500.csv")  #NSE500
#nse500 = pd.read_csv(NSE570_path)   #NSE750
#add_suffix_to_column(nse500, "Symbol", ".NS")              # use with nse500.csv

nse500 = '/home/rizpython236/BT5/symbol_list.csv'
nse500 = pd.read_csv(nse500)
NSE570symbols1 = nse500['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols1))
symbols = list(dict.fromkeys(NSE570symbols1))
number=len(symbols)
print(number)

#symbols = symbols[~symbols["Symbol"].isin(exclude_tickers["Symbol"])]
#symbols = [symbol for symbol in symbols if symbol["Symbol"] not in exclude_tickers]
symbols= [symbol for symbol in NSE570symbols if symbol not in exclude_tickers["Symbol"]]
number=len(symbols)
print(number)

#_____________________________

rankedTop30 = []
selected_files=[]
all_stats = []
momentumratiosall=[]




FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/Finalnse.csv")
#FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/FinalMicrocap250.csv")
#NSE570ticker_df = pd.read_csv(nse500)
#add_suffix_to_column(FinalMicrocap250, "Symbol", ".NS")  #FinalMicrocap250.csv
FinalMicrocap250symbols = FinalMicrocap250['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
FinalMicrocap250symbols = list(set(FinalMicrocap250symbols))


def get_stock_csv_files(folder_path):
    return [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith(".csv")]

def downside_deviation_from_pricesaaa(log_returns, mar=0):
    # Calculate the returns that are below the minimum acceptable return (MAR)
    downside_returns = log_returns[log_returns < mar]

    # Square these returns
    squared_downside_returns = downside_returns ** 2

    # Calculate the mean of these squared returns
    mean_squared_downside = squared_downside_returns.mean()

    # Take the square root of the mean squared downside returns
    downside_deviation = np.sqrt(mean_squared_downside)
    #print(downside_deviation)

    return downside_deviation

def calculate_lognormal_daily_returns(prices):
    """Calculates lognormal daily returns of a stock.

    Args:
        prices (pandas.Series): Time series of closing prices.

    Returns:
        pandas.Series: Time series of lognormal daily returns.
    """

    log_returns = np.log(prices)-np.log(prices.shift(1))   #np.log(prices.pct_change() + 1)
    return log_returns

def nifty_momentum_backtest(file_path,data,Company,df,base_name,FinalMicrocap250symbols):
    """Backtests the Nifty momentum strategy with transaction costs.

    Args:
        start_date (str): Start date for backtesting in 'YYYY-MM-DD' format.
        end_date (str): End date for backtesting in 'YYYY-MM-DD' format.
        universe_file (str): Path to CSV file containing stock tickers.

    Returns:
        pandas.DataFrame: DataFrame containing backtesting results.
    """
    #df = pd.read_csv(file_path)
    data["SMA_30MRP"] = tb.EMA(data['MRP'], timeperiod=12)
    data["SMA_90MRP"] = tb.EMA(data['MRP'], timeperiod=52)
    data["SMA_30close"] = tb.EMA(data['Close'], timeperiod=12)
    data["SMA_90close"] = tb.EMA(data['Close'], timeperiod=52)
    data["OBV"] = tb.OBV(data['Close'], data['Volume'])
    data["obvmovavg"] = tb.EMA(data["OBV"], timeperiod=12)
    #data["CCI"] = tb.CCI(data['High'], data['Low'], data['Close'], timeperiod=34*5)
    #data["SMA100_cci"] = tb.SMA(data['CCI'], timeperiod=100)
    #data["SMA200_cci"] = tb.SMA(data['CCI'], timeperiod=200)
    if  (data['SMA_30MRP'].iloc[-1] > data['SMA_90MRP'].iloc[-1]*1.0 and  data['SMA_30close'].iloc[-1] > data['SMA_90close'].iloc[-1]*1.02) : # True:


        # Transaction cost (adjust as needed)
        #transaction_cost = 0.001  # 0.1% per trade

        # Read universe file
        #with open(universe_file, 'r') as f:
        #    tickers = f.readlines()
        #tickers = [ticker.strip() for ticker in tickers]

        # Download data for all tickers
        #data = yf.download(tickers, start=start_date, end=end_date)

        # Calculate daily returns and annualized standard deviation
        #daily_returns = data['Close'].pct_change()
        # data['ROC_6m'] = data['Close'].pct_change(periods=126) * 100
        #annualized_std = daily_returns.std(axis=0) * np.sqrt(252)
        lognormal_returns = calculate_lognormal_daily_returns(data['Close'][-52:])
        #annualized_lognormal_std = lognormal_returns.std(axis=0) #* np.sqrt(52)
        annualized_lognormal_std = lognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)

        #data['rolling_std'] = data['lognormal_returns'].rolling(window=252).std()
        #data['annualized_lognormal_std'] = data['rolling_std'] * np.sqrt(252)

        # Calculate momentum ratios (12 & 6 months)
        #momentum_ratio_12m = daily_returns.rolling(window=252).mean() / annualized_lognormal_std
        #momentum_ratio_6m = daily_returns.rolling(window=126).mean() / annualized_lognormal_std
        data['ROC_3m']=tb.ROC(data['Close'], timeperiod=12)
        data['ROC_6m']=tb.ROC(data['Close'], timeperiod=24)
        data['ROC_12m']=tb.ROC(data['Close'], timeperiod=52)

        momentum_ratio_12m = data['ROC_12m'].iloc[-1] / annualized_lognormal_std
        momentum_ratio_6m = data['ROC_6m'].iloc[-1]  / annualized_lognormal_std
        momentum_ratio_3m = data['ROC_3m'].iloc[-1]  / annualized_lognormal_std

        # Calculate Z-scores

        #z_score_12m = ta.zscore(momentum_ratio_12m)
        #z_score_6m = ta.zscore(momentum_ratio_6m)
        z_score_3m =  (momentum_ratio_3m -df['mean_momentum_3m'].iloc[-1]) / df['std_momentum_3m'].iloc[-1]
        z_score_6m =  (momentum_ratio_6m -df['mean_momentum_6m'].iloc[-1]) / df['std_momentum_6m'].iloc[-1]
        z_score_12m = (momentum_ratio_12m -df['mean_momentum_12m'].iloc[-1])/ df['std_momentum_12m'].iloc[-1]


        # Calculate weighted average Z-score
        #weighted_zscore = 0.5 * z_score_12m + 0.5 * z_score_6m
        weighted_zscore = 0.45 * z_score_12m + 0.45 * z_score_6m + 0.1 * z_score_3m

        # Calculate normalized momentum score
        normalized_score = (1 + weighted_zscore) * (weighted_zscore >= 0) + (1 / (1 - weighted_zscore))**(-1) * (weighted_zscore < 0)
        normalized_score =round(weighted_zscore,4)

        # Rank stocks by normalized score
        #ranked_data = pd.DataFrame({'Ticker': Company, 'Normalized Score': normalized_score.iloc[-1]})
        #ranked_data = ranked_data.sort_values(by='Normalized Score', ascending=False)
        #top_30 = ranked_data
        #normalized_score =data['normalized_score'].iloc[-1]
        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                #"Symbol": base_name,
                "Company": Company,
                "NSE750": NSE570s,
                "Score": normalized_score,
                }

        # Calculate daily returns for the top 30 stocks (assuming equal weights)
        #daily_returns_filtered = data['Close'][top_30['Ticker']].pct_change()

        # Simulate portfolio returns with transaction costs
        #portfolio_return = daily_returns_filtered.mean(axis=1)
        #gross_return = (1 + portfolio_return).prod() - 1
        #net_return = gross_return - transaction_cost * portfolio_return.sum()

        # Create results DataFrame
        #results = pd.DataFrame({
        #    'Start Date': start_date,
        #    'End Date': end_date,
        #    'Gross Return': gross_return,
        #    'Net Return': net_return
        #})

        rankedTop30.append(ranked_data1)


        last_row_index = data.index[-10:]
        data.loc[last_row_index, 'Score'] = normalized_score
        data.drop(columns=['ROC_3m','ROC_6m','ROC_12m','SMA_30MRP','SMA_90MRP', 'SMA_30close', 'SMA_90close','OBV','obvmovavg'], inplace=True)
        #data.to_csv(file_path, index=False)
        #print(data)
        #print(file_path)
        #return ranked_data
    else:
        normalized_score =0.001
        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                #"Symbol": base_name,
                "Company": Company,
                "NSE750": NSE570s,
                "Score": normalized_score,
                }
        rankedTop30.append(ranked_data1)

        last_row_index = data.index[-10:]
        data.loc[last_row_index, 'Score'] = normalized_score
        data.drop(columns=['SMA_30MRP','SMA_90MRP', 'SMA_30close', 'SMA_90close','OBV','obvmovavg'], inplace=True)
        #print(data)
        #print(file_path)
        #data.to_csv(file_path, index=False)
        1+1



def calculate_momentum_stats(folder_path,symbols):
    """
    Calculates mean and standard deviation of 6-month and 12-month momentum ratios
    across all CSV files in a specified folder.

    Args:
        folder_path (str): Path to the folder containing CSV files.

    Returns:
        dict: A dictionary containing the following statistics:
            - mean_momentum_6m (float): Mean of 6-month momentum ratios for all stocks.
            - std_momentum_6m (float): Standard deviation of 6-month momentum ratios.
            - mean_momentum_12m (float): Mean of 12-month momentum ratios for all stocks.
            - std_momentum_12m (float): Standard deviation of 12-month momentum ratios.
    """
    #nse500 = pd.read_csv("/home/rizpython236/BT5/nse500.csv")
    #NSE570ticker_df = pd.read_csv(nse500)
    #add_suffix_to_column(nse500, "Symbol", ".NS")
    #NSE570symbols1 = nse500['Symbol'].tolist()[:]
    #NSE570symbols = list(dict.fromkeys(symbols))
    #NSE570symbols = list(set(NSE570symbols1))
    #symbols = list(dict.fromkeys(NSE570symbols1))

    for file_name in os.listdir(folder_path):

        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            #total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)

            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                #print(file_path)
                data1 = pd.read_csv(file_path)

                # Calculate 6-month and 12-month ROC (Rate of Change)
                #data['ROC_6m'] = data['Close'].pct_change(periods=126) * 100  # Percentage change
                #data['ROC_12m'] = data['Close'].pct_change(periods=252) * 100  # Percentage change
                data1['ROC_3m']=tb.ROC(data1['Close'], timeperiod=12)
                data1['ROC_6m']=tb.ROC(data1['Close'], timeperiod=24)
                data1['ROC_12m']=tb.ROC(data1['Close'], timeperiod=52)

                lognormal_returns = calculate_lognormal_daily_returns(data1['Close'][-52:])

                #annualized_lognormal_std = lognormal_returns.std(axis=0) #* np.sqrt(52)
                annualized_lognormal_std = lognormal_returns.rolling(52).apply(downside_deviation_from_pricesaaa)

                #data1['rolling_std'] = data1['lognormal_returns'].rolling(window=252).std()
                #data1['annualized_lognormal_std'] = data1['rolling_std'] * np.sqrt(252)

                # Calculate momentum ratios (using ROC instead of TA-Lib for clarity)
                momentum_ratio_3m = data1['ROC_3m'].iloc[-1] / annualized_lognormal_std
                momentum_ratio_6m = data1['ROC_6m'].iloc[-1] / annualized_lognormal_std
                momentum_ratio_12m = data1['ROC_12m'].iloc[-1] / annualized_lognormal_std

                # Update statistics
                #momentum_stats['mean_momentum_6m'] += momentum_ratio_6m
                #momentum_stats['std_momentum_6m'] += momentum_ratio_6m**2
                #momentum_stats['mean_momentum_12m'] += momentum_ratio_12m
                #momentum_stats['std_momentum_12m'] += momentum_ratio_12m**2
                momentumratios ={
                    'Company': base_name,
                    'momentum_3m': momentum_ratio_3m,
                    'momentum_6m': momentum_ratio_6m,
                     #'std_momentum_6m': np.nan,  # Initialize with NaN (no calculation yet)
                    'momentum_12m': momentum_ratio_12m,
                    }
                #momentumratiosall.append(momentumratios)
                file_stats = {
                    'Company': base_name,
                    'momentum_3m': momentum_ratio_3m,
                    'momentum_6m': momentum_ratio_6m,
                    #'std_momentum_6m': np.nan,  # Initialize with NaN (no calculation yet)
                    'momentum_12m': momentum_ratio_12m,
                    #'std_momentum_12m': np.nan  # Initialize with NaN (no calculation yet)
                }

                all_stats.append(file_stats)
            else:
                print("No base name")
        else:
            print("No file name")
    if 1==1:
        #print(all_stats)
        df = pd.DataFrame(all_stats)  # Create DataFrame from stats list
        #dfmomentumratiosall = pd.DataFrame(momentumratiosall)
        #print(df)
        number= len(df['momentum_6m'])
        #df['Total'] = 'COMPANY'
        df['mean_momentum_3m'] = sum(df['momentum_3m'])/len(df['momentum_3m'])
        df['mean_momentum_6m'] = sum(df['momentum_6m'])/len(df['momentum_6m'])
        df['mean_momentum_12m'] = sum(df['momentum_12m'])/len(df['momentum_12m'])
        df['std_momentum_3m'] = tb.STDDEV(df['momentum_3m'], timeperiod=number, nbdev=1)
        df['std_momentum_6m'] = tb.STDDEV(df['momentum_6m'], timeperiod=number, nbdev=1) # Vectorized std calculation for 6m  df['momentum_6m'].pow(2).mean(axis=1)
        df['std_momentum_12m'] = tb.STDDEV(df['momentum_12m'], timeperiod=number, nbdev=1)  #df['momentum_12m'].pow(2).mean(axis=1)  # Vectorized std calculation for 12m

    else:
        df = pd.DataFrame(columns=['Company','mean_momentum_3m', 'mean_momentum_6m', 'mean_momentum_12m','std_momentum_3m','std_momentum_6m','std_momentum_12m'])
    print(df)
    #print(dfmomentumratiosall)
    return df



#ranked_data_Final = pd.DataFrame(columns=['Ticker', 'Normalized Score'])

universemomentum_stats= calculate_momentum_stats(folder_path,symbols)
#df['std_momentum_3m']=tb.STDDEV(df['momentum_3m'], timeperiod=number, nbdev=1)
#df['std_momentum_6m']= tb.STDDEV(df['momentum_6m'], timeperiod=number, nbdev=1)
#df['std_momentum_12m']= tb.STDDEV(df['momentum_12m'], timeperiod=number, nbdev=1)


for file_name in os.listdir(folder_path):

    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            #total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)


            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                #print(base_name)

                # Read the CSV file into a DataFrame
                data = pd.read_csv(file_path)
                #stock_folder_path = '/home/rizpython236/BT5/ticker-csv-files/'
                #stock_csv_files = get_stock_csv_files(stock_folder_path)
                #number= len(data1)
                #data=data[:]
                Company=symbol_to_company.get(base_name, base_name)
                nifty_momentum_backtest(file_path,data,Company,universemomentum_stats,base_name,FinalMicrocap250symbols)

                #ranked_data_Final['Ticker','Normalized Score'].append(ranked_data)
            else:
                1+1
        else:
            print("No data found to write to momNSE750")
    except Exception as e:
        print(f"Error in  momNSE750- {e}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass

print("__________________________________________________________")

try:
    rankedTop30.sort(key=lambda row: row["Score"], reverse=True)
except Exception as e:
    print(f"Error in  MedianBTmomNSE750- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

rankedTop30 = pd.DataFrame(rankedTop30)
rankedTop30.sort_values(by='Score', ascending=False)
rankedTop30 = rankedTop30.drop_duplicates(subset=['Company'])

valid_tickers = pd.read_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv')
rankedTop30 = pd.merge(rankedTop30, valid_tickers, left_on='Company', right_on='Company', how='left')
#rankedTop30.drop(columns=['Symbol'], inplace=True)
desired_order = ['Symbol','Company', 'Industry', 'NSE750','Score']
rankedTop30 = rankedTop30[desired_order]

rankedTop30.to_csv('/home/rizpython236/BT5/trade-logs/BTmomNSE750.csv', index=False)
time.sleep(5)
input_csv_file = '/home/rizpython236/BT5/trade-logs/BTmomNSE750.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/trade-logs/BTmomNSE750.pdf'  # Replace with desired output PDF file
time.sleep(5)
create_pdf(input_csv_file, output_pdf_file ,pageA4= True)
time.sleep(5)
post_telegram_file(output_pdf_file)


print('Done BTmomNSE750 1st part')


try:
    #valid_tickers = pd.read_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv')
    #valid_tickers.sort_values('Symbol', inplace=True)
    #rankedTop30.sort_values('Company', inplace=True)
    #valid_tickers = valid_tickers[['Symbol', 'Company', 'Industry']]

    # Perform VLOOKUP and merge using the correct join type (left join in this case)
    #rankedTop30 = pd.merge(rankedTop30, valid_tickers, left_on='Company', right_on='Company', how='left')
    #rankedTop30.drop(columns=['Symbol'], inplace=True)
    #desired_order = ['Company', 'Industry', 'NSE750','Score']
    #rankedTop30 = rankedTop30[desired_order]

    industry_scores = rankedTop30[:].groupby('Industry')['Score'].sum().reset_index()
    industry_scores['Count'] = rankedTop30[:].groupby('Industry')['Company'].count().reset_index()['Company']
    industry_scores = industry_scores[industry_scores['Count'] >= 1]
    industry_scores['Avg'] = round(industry_scores['Score'] / industry_scores['Count'],3)

    median_scores = rankedTop30.groupby('Industry')['Score'].median().reset_index()  # Calculate medians
    median_scores['Median'] = rankedTop30[:].groupby('Industry')['Score'].median().reset_index()['Score']
    median_scores['Median']=round(median_scores['Median'],3)
    median_scores.drop(columns=['Score'], inplace=True)
    #print(median_scores)
    industry_scores = industry_scores.merge(median_scores[['Industry', 'Median']], how='left', on='Industry')  # Merge DataFrames
    industry_scores.rename(columns={'Score': 'Sum_Score'}, inplace=True)
    industry_scores['Sum_Score'] =round(industry_scores['Sum_Score'],3)
    #industry_scoresM.rename(columns={'Score': 'Median'}, inplace=True)  # Rename column (optional)
    # Sort by sum of score (descending)
    industry_scores = industry_scores.sort_values(by='Median', ascending=False)

    industry_scores.to_csv('/home/rizpython236/BT5/trade-logs/MedianBTmomNSE750.csv', index=False)
    time.sleep(5)
    input_csv_file = '/home/rizpython236/BT5/trade-logs/MedianBTmomNSE750.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/trade-logs/MedianBTmomNSE750.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= True)
    time.sleep(5)
    post_telegram_file(output_pdf_file)
except Exception as e:
    print(f"Error in  MedianBTmomNSE750- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print('Done BTmomNSE750 Final part')

