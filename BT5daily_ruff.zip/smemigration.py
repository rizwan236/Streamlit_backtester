from datetime import date
import re
import time

#import pytz
import traceback

from add_company_name import (
    add_company_names_and_industry,
    copyfile1,
    update_output_file,
    vlookup_and_merge,
)
import pandas as pd
from PDFconvert import create_pdf
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from telegram_bot import post_telegram_file, post_telegram_message


'''
from webdriver_manager.chrome import ChromeDriverManager

current_chromedriver_version = webdriver.Chrome().capabilities['version']
print(f"Current ChromeDriver version: {current_chromedriver_version}")

# Update ChromeDriver if needed (using webdriver_manager)
driver = webdriver.Chrome(ChromeDriverManager().install())
current_chromedriver_version = webdriver.Chrome().capabilities['version']
print(f"Current ChromeDriver version: {current_chromedriver_version}")

driver.quit()

'''

print("smemigration")

csv_filename = '/home/rizpython236/BT5/trade-logs/sme-migrated-mainboard.csv'
old_df = pd.read_csv(csv_filename)


#print(old_df)


# Set up Chrome options
chrome_options = Options()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--window-size=1920,1080")
chrome_options.add_argument("--disable-blink-features=AutomationControlled")
chrome_options.add_argument("--enable-unsafe-swiftshader")

chrome_options.add_experimental_option("prefs", {
    #"download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True
})

# Initialize WebDriver
driver = webdriver.Chrome(options=chrome_options)


attempt = 0
max_attempts = 2
success = False

while attempt < max_attempts and not success:
    try:
        # Open the webpage
        url = "https://www.chittorgarh.com/report/sme-migrated-mainboard/123/"
        driver.get(url)

        # Wait for the export button to be clickable
        export_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.ID, "export_btn"))
        )

        # Scroll into view
        driver.execute_script("arguments[0].scrollIntoView(true);", export_button)

        # Use JavaScript to click if needed
        driver.execute_script("arguments[0].click();", export_button)

        # Wait for the file to download
        time.sleep(5)

        # Step 4: Load the downloaded CSV into a pandas DataFrame
        download_dir = '/home/rizpython236/BT5'
        csv_filename = f'{download_dir}/sme-migrated-mainboard.csv'
        new_df = pd.read_csv(csv_filename)

        input_file = '/home/rizpython236/BT5/sme-migrated-mainboard.csv'
        output_file = '/home/rizpython236/BT5/trade-logs/sme-migrated-mainboard.csv'
        copyfile1(input_file, output_file)

        # Print and/or save the DataFrame as needed
        print(new_df.head())

        # Identify new companies not in old DataFrame
        new_companies = new_df[~new_df['Company name'].isin(old_df['Company name'])]


        print(new_companies)

        if not new_companies.empty:
            print("New Items Found NSE_SMEmigration:")
            post_telegram_message("NSE_SMEmigration Items")
            new_companies['Company name'] = new_companies['Company name'].str.replace("Limited", "", regex=False)
            new_companies['Company name'] = new_companies['Company name'].str.replace("Ltd", "", regex=False)
            print(new_companies[['Company name', 'Migration Date', 'CMP (Rs)']])

            #new_companies = new_companies.drop(old_df.columns[0], axis=1)
            # Replace "Limited" with an empty string in the second column of old_df
            #new_companies[new_companies.columns[1]] = new_companies[new_companies.columns[1]].str.replace("Limited", "", regex=False)

            time.sleep(3)
            # Print each row in a single line
            for _, row in new_companies[['Company name', 'Migration Date', 'CMP (Rs)']].iterrows():
                print(f"{row['Company name']}, {row['Migration Date']}, {row['CMP (Rs)']}")
                post_telegram_message(f"{row['Company name']}, {row['Migration Date']}, {row['CMP (Rs)']}")
                time.sleep(3)

            # Append these new entries to abc.csv
            file_path = '/home/rizpython236/BT5/trade-logs/NEWsmemigratedmainboard.csv'
            try:
                # Check if the file already exists
                existing_df = pd.read_csv(file_path)
                existing_df = existing_df[['Company name', 'Migration Date', 'CMP (Rs)']]
                updated_df = pd.concat([existing_df, new_companies[['Company name', 'Migration Date', 'CMP (Rs)']]], ignore_index=True)
                # Save updated DataFrame back to CSV
                updated_df.to_csv(file_path, index=False)
                print(f"New entries appended to {file_path}")
            except FileNotFoundError:
                # If the file doesn't exist, use the new entries as the starting content
                #updated_df = new_companies
                1+1

        else:
            print("No new items found.")
            post_telegram_message("NO NSE_SMEmigration Items")
        # If successful, mark success as True to stop retrying
        success = True
        print("Download and processing successful NSE_smemigratedmainboard.")

        #except Exception as e:
        #    print(f"Error occurred: {e}")
        #    post_telegram_message("SMEmigration Error")

    except (TimeoutException, Exception) as e:
        attempt += 1
        print(f"Attempt {attempt} failed: {str(e)}")
        if attempt < max_attempts:
            print("Retrying...")
        else:
            print("Max attempts reached. Failed to NSE_smemigratedmainboard CSV.")
            post_telegram_message("NSE_SMEmigration Error")

    finally:
        # Close the browser
        driver.quit()



# BSE

def get_table_from_url(url, css_selector):
  """
  Extracts the table specified by the given CSS selector from the HTML content of the URL.

  Args:
    url: The URL of the webpage containing the table.
    css_selector: The CSS selector to locate the desired table within the HTML.

  Returns:
    A list of lists, where each inner list represents a row in the table,
    and each element within the inner list represents a cell in the row.
    Returns None if the table cannot be found or an error occurs.
  """

  try:
    # Initialize WebDriver (replace with your preferred browser)
    driver = webdriver.Chrome(options=chrome_options)  # Use webdriver.Firefox() or other browsers as needed
    driver.get(url)

    # Scroll into view
    #driver.execute_script("arguments[0].scrollIntoView(true);", export_button)
    time.sleep(5)
    # Find the table element using CSS selector
    table = driver.find_element(By.CSS_SELECTOR, css_selector)

    # Extract table data (assuming basic HTML table structure)
    rows = table.find_elements(By.TAG_NAME, "tr")
    table_data = []
    for row in rows:
      cols = row.find_elements(By.TAG_NAME, "td")
      row_data = [col.text for col in cols]
      table_data.append(row_data)

    new_df = pd.DataFrame(table_data, columns=['Sr. No.', 'Scrip Code', 'Scrip Name'])
    new_df = new_df.dropna()
    # Add 'Migration Date' column with today's date
    today = date.today().strftime('%Y-%m-%d')
    new_df['Migration Date'] = today
    new_df = new_df.astype(str)
    print(new_df)
    new_df.to_csv('/home/rizpython236/BT5/trade-logs/BSE_sme-migrated-mainboard.csv', index=False)
    driver.quit()  # Close the browser
    #return table_data
    return new_df

  except Exception as e:
    print(f"Error: {e}")
    driver.quit()  # Close the browser in case of an error
    return None



#table_data = get_table_from_url(url, css_selector)

#if table_data:
#  for row in table_data:
#    print(row)


attempt = 0
max_attempts = 1
success = False

# Initialize WebDriver
#driver = webdriver.Chrome(options=chrome_options)

old_df = pd.read_csv('/home/rizpython236/BT5/trade-logs/BSE_sme-migrated-mainboard.csv')
old_df = old_df.astype(str)

while attempt < max_attempts and not success:
    try:
        # Example usage:
        url = "https://www.bsesme.com/markets/Migrated.aspx"  # Replace with the actual URL
        css_selector = "#ContentPlaceHolder1_grdvwStreamer"
        new_df = table_data = get_table_from_url(url, css_selector)

        # Identify new companies not in old DataFrame
        new_companies = new_df[~new_df['Scrip Code'].isin(old_df['Scrip Code'])]
        new_companies = new_companies.dropna()
        new_companies = new_companies.astype(str)
        #new_companies= new_companies[['Scrip Code', 'Scrip Name','Migration Date']]
        #new_companies = new_companies.drop('Sr. No.', axis=1)

        if not new_companies.empty:
            print("New Items Found BSE_SMEmigration:")
            post_telegram_message("New Items Found BSE_SMEmigration")

            # Add 'Migration Date' column with today's date
            #today = date.today().strftime('%Y-%m-%d')
            #new_companies['Migration Date'] = today

            new_companies['Scrip Name'] = new_companies['Scrip Name'].str.replace("Limited", "", regex=False)
            new_companies['Scrip Name'] = new_companies['Scrip Name'].str.replace("Ltd", "", regex=False)
            #print(new_companies[['Scrip Code', 'Scrip Name','Migration Date']])
            #print(new_companies)

            #new_companies = new_companies.drop(old_df.columns[0], axis=1)
            # Replace "Limited" with an empty string in the second column of old_df
            #new_companies[new_companies.columns[1]] = new_companies[new_companies.columns[1]].str.replace("Limited", "", regex=False)

            # Print each row in a single line
            #for _, row in new_companies[['Scrip Code', 'Scrip Name','Migration Date']].iterrows():
            #    print(f"{row['Scrip Code']}, {row['Scrip Name']}, {row['Migration Date']}")
            #    ####post_telegram_message(f"{row['Company name']}, {row['Migration Date']}")
            #    time.sleep(3)

            print(new_companies)

            #for row in new_companies.itertuples(index=False):
            #    #print(f"{row.Scrip Code}, {row.Scrip Name}, {row.Migration Date}")
            #    print(", ".join(map(str, row)))

            # Append these new entries to abc.csv
            file_path = '/home/rizpython236/BT5/trade-logs/NEW_BSE_smemigratedmainboard.csv'
            try:
                # Check if the file already exists
                existing_df = pd.read_csv(file_path)
                existing_df = existing_df.dropna()
                existing_df = existing_df.astype(str)
                #existing_df = existing_df[['Scrip Code', 'Scrip Name','Migration Date']]
                #existing_df = existing_df[['Company name', 'Migration Date', 'CMP (Rs)']]
                #updated_df = pd.concat([existing_df, new_companies[['Scrip Code','Company name', 'Migration Date']]], ignore_index=True)
                updated_df = pd.concat([existing_df, new_companies], ignore_index=True)
                # Save updated DataFrame back to CSV
                updated_df.to_csv(file_path, index=False)

                new_companies.to_csv('/home/rizpython236/BT5/screener-outputs/DailyNEW_BSE_smemigratedmainboard.csv', index=False)
                input_csv_file = '/home/rizpython236/BT5/screener-outputs/DailyNEW_BSE_smemigratedmainboard.csv'  # Replace with your CSV file
                output_pdf_file = '/home/rizpython236/BT5/screener-outputs/NEW_BSE_smemigratedmainboard.pdf'  # Replace with desired output PDF file
                create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
                time.sleep(10)
                post_telegram_file('/home/rizpython236/BT5/screener-outputs/NEW_BSE_smemigratedmainboard.pdf')
                print(f"New entries appended to {file_path}")
            except FileNotFoundError:
                # If the file doesn't exist, use the new entries as the starting content
                #updated_df = new_companies
                traceback.print_exc()

        else:
            print("No new items found BSE_SMEmigration.")
            post_telegram_message("NO BSE_SMEmigration Items")
        # If successful, mark success as True to stop retrying
        success = True
        print("Download and processing successful BSE_smemigratedmainboard.")

        #except Exception as e:
        #    print(f"Error occurred: {e}")
        #    post_telegram_message("SMEmigration Error")

    except (TimeoutException, Exception) as e:
        traceback.print_exc()
        attempt += 1
        print(f"Attempt {attempt} failed: {str(e)}")
        if attempt < max_attempts:
            print("Retrying...")
        else:
            print("Max attempts reached. Failed to BSE_smemigratedmainboard CSV.")
            post_telegram_message("BSE_SMEmigration Error")

    finally:
        # Close the browser
        driver.quit()





