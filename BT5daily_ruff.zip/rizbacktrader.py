import csv
from datetime import datetime  # library
import webbrowser

import backtrader as bt  # library
from backtrader.indicators.smma import SmoothedMovingAverage

#from _52wk import MinMaxFn
from Baranalysis1 import BarAnalysis
from BBSqueeze import BBSqueeze
from calmar import Calmar  # custum analyzer
from Chaikin_Money_Flow import ChaikinMoneyFlow  # custum indicator
from Donchain_Channels import DonchianChannels  # custum indicator
from drawdowns import DrawdownPercents  # custum observer
from exp_ln_reg_Momentum import Momentum  # custum observer
from klingerocs import KlingerOsc
from limited_test_report import LimitedTestReport  # custum analyzer
import numpy

# https://community.backtrader.com/topic/2506/how-to-create-pyfolio-round-trip-tearsheet
import pandas as pd  # library
from quantstat import CashMarket  # used for quantstat tearsheet

# from backtrader.sizers import PercentSizer  # inbuilt sizer
import quantstats as qs  # library
from realsupertrend import SuperTrend  # custum indicator
from tabulate import tabulate

# from drawdowns import DrawdownDollars   # custum observer
# from drawdowns import DrawdownLength     # custum observer
import talib  # library
from trade_list import trade_list  # custum analyzer
from Zscore1 import Z_score


#from zigzagind import ZigZag
#from fastbbzigzag import bbzigzag
# https://community.backtrader.com/topic/1274/closed-trade-list-including-mfe-mae-analyzer
# https://github.com/ab-trader/backtrader_addons/tree/master/backtrader_addons/analyzers
# https://algotrading101.com/learn/backtrader-for-backtesting/


class firstStrategy(bt.Strategy):
    def __init__(self):
        # self.addminperiod(100)
        self.ST = SuperTrend(period=10, multiplier=3)
        self.macd = bt.indicators.MACD(self.data, period_me1=12, period_me2=26, period_signal=9,plot=False)
        self.macdH = bt.indicators.MACDHisto()
        self.RSI = bt.indicators.RSI(period=14)
        #self.RSI = bt.talib.RSI(self.data.close, timeperiod=14, upperband=70, lowerband=30)
        self.ADX = bt.indicators.AverageDirectionalMovementIndex(
            self.data, period=14, plotname="ADX", plot=True)
        self.ATR = bt.talib.ATR(
            self.data.high, self.data.low, self.data.close, timeperiod=14, plotname='ATR')
        self.atrmovavg = bt.talib.EMA(self.ATR, timeperiod=7)
        #self.NATR = bt.talib.NATR(self.data.high,self.data.low,self.data.close,timeperiod=14)
        # self.natrmovavg = bt.talib.EMA(self.NATR, timeperiod=9)
        # self.PSAR = bt.indicators.ParabolicSAR(self.data,period=2,af=0.02,afmax=0.2,plotname='PSAR')
        # self.MACD = bt.indicators.MACD(self.data.close,period_me1=12,period_me2=26,period_signal=9,plot=False)
        # self.MACDHisto = bt.indicators.MACDHisto(self.data.close,period_me1=12,period_me2=26,period_signal=9)
        # self.TEMA = bt.indicators.TripleExponentialMovingAverage(self.data.close,period=30,plotname='TEMA')
        # self.Stochastic = bt.indicators.Stochastic(self.data,period=14,period_dfast=3,upperband=80,lowerband=20,period_dslow=3)
        self.CCI = bt.indicators.CommodityChannelIndex(
            self.data, period=20, factor=0.015, upperband=100, lowerband=-100, plotname="CCI", plot=True,)
        # self.HT_TRENDLINE = bt.talib.HT_TRENDLINE(self.data.close)
        self.EMA_SLOW = bt.talib.EMA(self.data.close, timeperiod=12)
        self.EMA_FAST = bt.talib.EMA(self.data.close, timeperiod=4)
        #self.EMA_S = bt.indicators.EMA(period=20, plot=False)
        #self.EMA_F = bt.indicators.EMA(period=10, plot=False)
        self.DCH = DonchianChannels(period=14)
        #self.Ldch = bt.talib.MIN(
        #    self.DCH, timeperiod=7, plotname='Ldch', plot=True)
        #self.Hdch = bt.talib.MAX(
        #    self.DCH, timeperiod=7, plotname='Hdch', plot=True)
        self.DCHema = bt.talib.EMA(self.DCH, timeperiod=14)
        # self.FIBpivotPt = bt.indicators.FibonacciPivotPoint(self.data1,_autoplot=False,plotname='FIBpp') # the resampled data1
        # self.PivotPt = bt.indicators.PivotPoint(self.data1,_autoplot=False,plotname='PVTpt') # the resampled data1
        self.OBV = bt.talib.OBV(self.data.close, self.data.volume)
        self.obvmovavg = bt.talib.EMA(self.OBV, timeperiod=14)
        # self.ChaikinADline = bt.talib.AD(self.data.high,self.data.low,self.data.close,self.data.volume)
        # self.ChaikinADosc = bt.talib.ADOSC(self.data.high,self.data.low,self.data.close,self.data.volume,fastperiod=3, slowperiod=10)
        # self.CMF = ChaikinMoneyFlow(self.data,plotname='CMF') #float division by zero for deepak nitrate
        # self.MFI = bt.talib.MFI(self.data.high,self.data.low,self.data.close,self.data.volume,timeperiod=14)
        # self.BOP = bt.talib.BOP(self.data.open,self.data.high,self.data.low,self.data.close)
        # self.WILLR = bt.talib.WILLR(self.data.high,self.data.low,self.data.close,timeperiod=14)
        # self.MOM = bt.talib.MOM(self.data.close,timeperiod=10)
        # self.mommovavg = bt.talib.EMA(self.MOM, timeperiod=9)
        # self.KAMA = bt.talib.KAMA(self.data.close,timeperiod=30)
        # self.MAMA = bt.talib.MAMA(self.data.close,fastlimit=0,slowlimit=0)
        # self.DRAGONFLYDOJI = bt.talib.CDLDRAGONFLYDOJI(self.data.open, self.data.high, self.data.low, self.data.close)
        self.Exp_lin_reg = Momentum(self.data.close, period=18, subplot=True)
        #self.Exp_lin_reg_movavg = bt.talib.EMA(self.Exp_lin_reg, timeperiod=7)
        #self.Nifty_ema200 = bt.talib.EMA(self.nifty.close, timeperiod=25)
        #self.SMA_V = bt.talib.SMA(self.data.volume, timeperiod=7, plot=False)
        #self.HeikinAshi = bt.indicators.HeikinAshi(self.data.open,self.data.high,self.data.low,self.data.close)
        #self.HaDelta = bt.indicators.haDelta(autoheikin=True,period=3,subplot=False)
        #self.zscore = Z_score(period=14, plot=True)
        #self.zscoremovavg3 = bt.talib.EMA(self.zscore, timeperiod=7)
        #self.zscoremovavg5 = bt.talib.EMA(self.zscoremovavg3, timeperiod=5)
        self.BBS = BBSqueeze(period=14, bbdevs=2,
                             kcdevs=1.5, movav=bt.ind.MovAv.Simple)
        self.BBSavg = bt.talib.EMA(self.BBS, timeperiod=7)
        self.max52 = bt.talib.MAX(
            self.data.high, timeperiod=50, plotname='wk52H', plot=False)
        self.min52 = bt.talib.MIN(
            self.data.low, timeperiod=50, plotname='wk52L', plot=False)
        #self.Bema200 = bt.talib.EMA(
        #    self.data1.close, timeperiod=42, plotname='Bema52')
        #self.Bema30 = bt.talib.EMA(
        #    self.data1.close, timeperiod=12, plotname='Bema30')
        #self.KLosc = KlingerOsc(self.data,plot=True)
        self.EFI = bt.indicators.ExponentialMovingAverage(self.datas[0].volume(
            0)*(self.datas[0].close(0)-self.datas[0].close(-1)), period=13, subplot=True, plotname='EFI')
        self.EFIavg = bt.talib.EMA(self.EFI, timeperiod=14, plotname='EFIavg')
        #self.ZZ= ZigZag()
        #self.bbzigzagl = bbzigzag()
        

    def next(self):
        if not self.position:
            if (
                self.ST < self.data.close
                # and self.data[2].close > 50
                # and self.Bema200 < self.Bema30
                # and self.max52*.4 < self.data.close
                and self.ADX > 28
                and self.RSI > 30
                and self.EMA_SLOW < self.EMA_FAST
                #and self.macd > self.macd.signal
                and self.macdH > 0
                and self.EFI > self.EFIavg
                # and self.CCI > -90
                # and self.max52[-7]*.60 < self.data.close[0]
                #and self.DCHema > 20
                #and self.DCH > self.DCHema
                # and self.SMA_V > 1000
                # and self.EMA_F > self.EMA_S
                and self.OBV > self.obvmovavg
                #and self.BBS > self.BBSavg
                # and self.ATR > self.atrmovavg
                # and self.zscore > self.zscoremovavg3
                # and self.l.width > self.l.EMA
                and self.Exp_lin_reg > 30
                # and self.Exp_lin_reg[-1] < self.Exp_lin_reg[0]
                # and (self.data.open != self.data.low and self.data.high != self.data.close)
            ):  # and self.MFI < 20:
                self.buy()
        else:
            if len(self.data) == (self.data.buflen()-1):
                self.position.size != 0
                self.order = self.order_target_size(target=0)
            else:
                if (
                    self.ST > self.data.close
                    # and self.SMA_V > 1000
                    and self.ADX > 28
                    #and self.RSI > 70
                    and self.macdH < 0
                    #and self.EFI < self.EFIavg
                    # and self.CCI < 90
                    and self.OBV < self.obvmovavg
                    # and self.DCHema < 20
                    # and (self.data.open != self.data.high and self.data.low != self.data.close)
                    #and self.BBS < self.BBSavg
                    # and self.close < self.EMA_S
                    # and self.zscore < self.zscoremovavg3
                    # and (self.data.open != self.data.high and self.data.low != self.data.close)
                ):
                    self.sell(order_target_percent=0)
                else:
                    if self.max52*.04 > self.data.close:
                        self.sell(order_target_percent=0)
                    else:
                        if(
                            self.ST > self.data.close
                            and self.ADX < 28
                            and self.DCHema < 30
                            and self.DCH < self.DCHema
                        ):
                            self.sell(order_target_percent=0)
                        


'''
def stop(self):
    if len(self.data) == (self.data.buflen()-1):
        self.position.size != 0
        targetsize = 0 
        self.order = self.order_target_size(target=targetsize)
'''


def printTradeAnalysis(
    analyzer,
):  # https://backtest-rookies.com/2017/06/11/using-analyzers-backtrader/

    # Function to print the Technical Analysis results in a nice format.

    # Get the results we are interested in
    total_open = analyzer.total.open
    total_closed = analyzer.total.closed
    total_won = analyzer.won.total
    total_lost = analyzer.lost.total
    win_streak = analyzer.streak.won.longest
    lose_streak = analyzer.streak.lost.longest
    pnl_net = round(analyzer.pnl.net.total, 2)
    strike_rate = round((total_won / total_closed) * 100, 2)
    # Designate the rows
    h1 = ["Total Open", "Total Closed", "Total Won", "Total Lost"]
    h2 = ["Strike Rate", "Win Streak", "Losing Streak", "PnL Net"]
    r1 = [total_open, total_closed, total_won, total_lost]
    r2 = [strike_rate, win_streak, lose_streak, pnl_net]
    # Check which set of headers is the longest.
    if len(h1) > len(h2):
        header_length = len(h1)
    else:
        header_length = len(h2)
    # Print the rows
    print_list = [h1, r1, h2, r2]
    row_format = "{:<15}" * (header_length + 1)
    print("Trade Analysis Results:")
    for row in print_list:
        print(row_format.format("", *row))


def printSQN(analyzer):
    sqn = round(analyzer.sqn, 2)
    print("SQN: {}".format(sqn))


# Get Stock data from Yahoo Finance.
data = bt.feeds.YahooFinanceData(
    dataname="DEEPAKNTR.NS",
    timeframe=bt.TimeFrame.Weeks,  # Weeks,Days,Months
    fromdate=datetime(2010, 1, 1),
    todate=datetime(2021, 10, 15),
    compression=1,
    buffered=True,
    calendar='BSE',
    adjclose=True,
    decimals=2,
    plot=True,
)
'''
feed = bt.feeds.YahooFinanceData(
    dataname="^NSEI",  # "^NSEI",
    timeframe=bt.TimeFrame.Weeks,  # Weeks,Days,Months
    fromdate=datetime(2012, 1, 1),
    todate=datetime(2021, 2, 15),
    compression=1,
    buffered=True,
    calendar='BSE',
    adjclose=True,
    decimals=2,
    plot=False,
)'''
'''
data3 = bt.feeds.YahooFinanceData(
    dataname= "VINATIORGA.NS",            #"^NSEI",
    timeframe=bt.TimeFrame.Months,  # Weeks,Days,Months
    fromdate=datetime(2012, 1, 1),
    todate=datetime(2021, 8, 15),
    compression =1,
    buffered=True,
    calendar='BSE',
    adjclose =True,
    decimals =2,
    plot=True,
)
'''
'''




data = bt.feeds.Quandl(
    dataname='TSLA',
    timeframe=bt.TimeFrame.Days, #Weeks,Days,Months
    apikey='QBb7Ym7AFLYZ3CkamXys',
    fromdate = datetime(2010,1,6),
    todate = datetime(2021,2,15),
    buffered= True
    )

'''
# Variable for our starting cash
startcash = 10000

# Create an instance of cerebro
cerebro = bt.Cerebro()  # runonce=False

# Filter the data
# data.addfilter(bt.filters.HeikinAshi(data))

# Slippage
# cerebro.broker = bt.brokers.BackBroker(slip_perc=0.05)  # 1% or slip_fixed

# Add the data to Cerebro
cerebro.adddata(data)
#cerebro.adddata(feed)  # add Nifty 50 Index
# cerebro.resampledata(data, timeframe = bt.TimeFrame.Months ,compression =1,bar2edge=True, adjbartime=True,rightedge=True,boundoff=0) #for FibPivot & pivotpt indicators
# cerebro.adddata(data3)
#d1.plotinfo.plotmaster = data
#d1.plotinfo.sameaxis = True

# Set our desired cash start
cerebro.broker.setcash(startcash)

cerebro.addcalendar("BSE")

# add the sizer
cerebro.addsizer(
    bt.sizers.PercentSizerInt, percents=98
)  # PercentSizer,FixedSize,AllInSizer,PercentSizerInt,AllInSizerInt

# set commission scheme
cerebro.broker.setcommission(
    commission=0.005, margin=False
)  # 0.5% of the operation value

# Add our strategy
cerebro.addstrategy(firstStrategy)

cerebro.addwriter(bt.WriterFile, csv=True, rounding=1)

cerebro.addanalyzer(trade_list, _name="trade_list")
# cerebro.addanalyzer(LimitedTestReport, _name='LimitedTestReport')
cerebro.addobserver(bt.observers.FundValue)
# cerebro.addobserver(bt.observers.DrawDown)
# cerebro.addanalyzer(bt.analyzers.TimeReturn)
cerebro.addobserver(DrawdownPercents)
# cerebro.addobserver(DrawdownDollars)
# cerebro.addobserver(DrawdownLength)
cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name="ta")
cerebro.addanalyzer(bt.analyzers.PeriodStats)
cerebro.addanalyzer(
    bt.analyzers.PositionsValue
)  # ,timeframe = bt.TimeFrame.Years,compression = 52,data=data,Cash=True)
cerebro.addanalyzer(bt.analyzers.Transactions)
cerebro.addanalyzer(bt.analyzers.SQN, _name="sqn")
cerebro.addanalyzer(bt.analyzers.SharpeRatio,
                    _name="mysharpe", riskfreerate=0.07)
# cerebro.addanalyzer(bt.TimeFrameAnalyzerBase.Calmar)
cerebro.addanalyzer(bt.analyzers.DrawDown, _name="drawdown")
cerebro.addanalyzer(bt.analyzers.TimeDrawDown)
cerebro.addanalyzer(bt.analyzers.AnnualReturn)
cerebro.addanalyzer(bt.analyzers.Returns)
# cerebro.addanalyzer(bt.analyzers.VWR)
cerebro.addanalyzer(
    bt.analyzers.TimeReturn,
    fund=True,
    timeframe=bt.TimeFrame.Years,
    data=data,
    _name="Timereturns",
)  # https://www.backtrader.com/docu/observer-benchmark/benchmarking/


cerebro.addanalyzer(CashMarket, _name="cashmarket")  # for quantstat tear sheet
cerebro.addanalyzer(BarAnalysis, _name="bar_data")

# cerebro.addanalyzer(bt.analyzers.BasicTradeStats, filter = 'all')

# Run over everything
# cerebro.run()    #cerebro.plot(style='candlestick',iplot=True,)
# TH for quantstat tearsheet #runonce=False
results = cerebro.run(tradehistory=True)
firstStrat = results[0]

for strat in results:
    print("=" * 79)
    print(strat.__class__.__name__)

#printTradeAnalysis(firstStrat.analyzers.ta.get_analysis())  # copied from above
# firstStrat.analyzers.sqn.print()
# firstStrat.analyzers.mysharpe.print()

trade_list = results[0].analyzers.trade_list.get_analysis()
print(tabulate(trade_list, headers="keys"))

"""
LimitedTestReport = results[0].analyzers.LimitedTestReport.get_analysis()
print (tabulate(LimitedTestReport, headers="keys"))
"""
# Get final portfolio Value
portvalue = cerebro.broker.getvalue()
pnl = round(portvalue - startcash, 1)

# Print out the final result
# print('Final Portfolio Value: ${}'.format(portvalue))
print("Final Portfolio Value: %.2f" % cerebro.broker.getvalue())
print(
    "Final value is %.2f times the initial investment"
    % (cerebro.broker.getvalue() / startcash)
)  # /initial cash
print("P/L: ${}".format(pnl))



# https://community.backtrader.com/topic/2506/how-to-create-pyfolio-round-trip-tearsheet/17?page=1
# quantstat tear sheet
# ---- Format the values from results ----
df_values = pd.DataFrame(
    results[0].analyzers.getbyname("cashmarket").get_analysis()).T
df_values = df_values.iloc[:, 1]
returns = qs.utils.to_returns(df_values)
returns.index = pd.to_datetime(returns.index)
# ----------------------------------------
'''
# ---- Format the benchmark from SPY.csv ----
with open('^BSESN.csv', mode='r') as infile:
  reader = csv.reader(infile)
  mydict = {
    datetime.strptime(rows[0],'%Y-%m-%d'): float(rows[4]) for rows in reader
  }

benchmark = (
  pd.DataFrame.from_dict(mydict, orient="index")
)
returns_bm = qs.utils.to_returns(benchmark)
returns_bm.index = pd.to_datetime(returns_bm.index)
# -------------------------------------------

Benchmark1 = pd.DataFrame(qs.utils.download_returns("SPY"))
Benchmark1 = Benchmark1.iloc[:, 1]
Benchmark1.index = pd.to_datetime(Benchmark1.index)
'''

# make html file
qs.extend_pandas()

qs.reports.html(returns,output="qs.html", rf=0,
                title="RIZ Strategy Tearsheet")
url = (
    "file:///C:/Users/Abdul Qadir/Documents/Python/Projects/backtrader --Final/qs.html"
)
# webbrowser.open(url, new=2)  # open in new tab

"""
#https://community.backtrader.com/topic/2506/how-to-create-pyfolio-round-trip-tearsheet/17?page=1
#gives ValueError: time data 'Date' does not match format '%Y-%m-%d'
# code C/P from above website
#quantstat tear sheet
# ---- Format the values from results ----
df_values = pd.DataFrame(results[0].analyzers.getbyname("cashmarket").get_analysis()).T
df_values = df_values.iloc[:, 1]
returns = qs.utils.to_returns(df_values)
returns.index = pd.to_datetime(returns.index)
# ----------------------------------------

# ---- Format the benchmark from SPY.csv ----
with open('^BSESN.csv', mode='r') as infile:
  reader = csv.reader(infile)
  mydict = {
    datetime.strptime(rows[0],'%Y-%m-%d'): float(rows[4]) for rows in reader
  }

benchmark = (
  pd.DataFrame.from_dict(mydict, orient="index")
)
returns_bm = qs.utils.to_returns(benchmark)
returns_bm.index = pd.to_datetime(returns_bm.index)
# -------------------------------------------

# make html file
qs.extend_pandas()
qs.reports.html(returns, benchmark=benchmark, output="qs.html", rf=0, title='RIZ Strategy Tearsheet')
url = 'file:///C:/Users/Abdul Qadir/Documents/Python/Projects/backtrader --Final/qs.html'
webbrowser.open(url, new=2)  # open in new tab
"""

# pip install git+https://github.com/mementum/backtrader.git#egg=backtrader

bar_data_res = results[0].analyzers.bar_data.get_analysis()
df = pd.DataFrame(bar_data_res)
df.to_csv("bar_data_res.csv")
#print(df)

# Save trade list.
trade_list = results[0].analyzers.getbyname("trade_list").get_analysis()
df = pd.DataFrame(trade_list)
#df = df.drop(['pnl', 'pnl/bar', 'ticker'], axis=1)
df.to_csv("trade_list.csv")

# Finally plot the end results
cerebro.plot(
    iplot=False, numfigs=1
)  # style='candlestick' , start=datetime.date(2005, 7, 1), end=datetime.date(2006, 1, 31)