"""Refactored and optimized version of tradebook analysis.
- Better structure: functions, constants, clear I/O.
- Avoids expensive per-row loops where possible.
- Uses vectorized merges and mapping for price updates.
- Safer yfinance downloads handling single vs multiple tickers.
- Clearer XIRR/XNPV functions with fallbacks.
- Logging-friendly prints (simple for now).

NOTE: adjust FILE_* constants to your environment.
"""
from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
import sys
import time
import traceback

import numpy as np
import numpy_financial as npf
import pandas as pd

# External helpers (assumed available in original environment)
from PDFconvert import create_pdf
import pytz
from scipy.optimize import newton
from telegram_bot import post_telegram_file, post_telegram_message
import yfinance as yf
from custum_index import addchartspdf

print("START tradebookanalysis")

# ---------------------------
# Configuration / Constants
# ---------------------------
FILE_TRADEBOOK = Path("/home/rizpython236/BT5/trade-logs/tradebook.csv")
open_TRADEBOOK = Path(
    "/home/rizpython236/BT5/screener-outputs/Opentradebook.csv")
FILE_LATEST_PRICE = Path(
    "/home/rizpython236/BT5/trade-logs/trade_list_BT_ScreenerINDfullbsenseFinal.csv",
)
OUT_DIR = Path("/home/rizpython236/BT5/screener-outputs")
OUT_DIR.mkdir(parents=True, exist_ok=True)

REMOVE_TICKERS = {
    "TJI_BK", "TJI_psuBK", "TJI_pvtBK", "TJI_Hsg Fn", "TJI_INSR", "TJI_LFINSR",
    "TJI_GenINSR", "TJI_ASMGMT", "TJI_CapMk", "TJI_RTGAGY", "TJI_Jewl", "TJI_BVRG",
    "TJI_Tobac", "TJI_Alcoh", "TJI_FMCG", "TJI_Pkg", "TJI_MSF", "TJI_QSR",
    "TJI_RTLCH", "TJI_INNWR", "TJI_Lethr", "TJI_MDENT", "TJI_HOTL", "TJI_AVTN",
    "TJI_IT", "TJI_LGTS", "TJI_comEQP", "TJI_TELC", "TJI_ELAPP", "TJI_CMNT",
    "TJI_RLEST", "TJI_PLY", "TJI_TLS", "TJI_PWR", "TJI_Transf", "TJI_PNT",
    "TJI_cOIL", "TJI_oREF", "TJI_FERT", "TJI_cGAS", "TJI_agCHE", "TJI_alkCHE",
    "TJI_DyesPig", "TJI_Spl_CHEM", "TJI_HOSP", "TJI_DIAGC", "TJI_PHARM",
    "TJI_ApiCram", "TJI_Metal", "TJI_Refac", "TJI_Pipe", "TJI_mPIP", "TJI_pPIP",
    "TJI_Railw", "TJI_Cable", "TJI_autoOem", "TJI_AutoAnc", "TJI_BRG", "TJI_Abars",
    "TJI_Pumps", "TJI_TYR", "TJI_DryC", "TJI_Defence", "TJI_shipB", "TJI_ports",
    "TJI_PAer", "TJI_SUG", "TJI_TEX", "TJI_TEACOF", "TJI_DATAC",
}

REMOVE_TICKERS= {}


THRESHOLD_PERCENT = -15  # -23.0  # threshold used for historical price correction
MIN_HOLD_DAYS = 12
IST_TZ = pytz.timezone("Asia/Kolkata")

# ---------------------------
# Utility / Finance helpers
# ---------------------------


def xnpv(rate: float, cashflows: list[tuple[datetime, float]]) -> float:
    if rate <= -1:
        return float("inf")
    t0 = cashflows[0][0]
    return sum(cf / (1 + rate) ** ((t - t0).days / 365.0) for t, cf in cashflows)


def xirr(cashflows: list[tuple[datetime, float]], guess: float = 0.1) -> float | None:
    if not cashflows:
        return None
    try:
        # try numpy_financial's irr on amounts only (fast) then verify
        amounts = [amt for (_d, amt) in cashflows]
        irr_npf = npf.irr(amounts)
        if np.isfinite(irr_npf) and abs(irr_npf) <= 10:
            return irr_npf
    except Exception:
        pass

    # fallback to date-aware Newton method
    try:
        return newton(lambda r: xnpv(r, cashflows), guess)
    except Exception:
        return None


# ---------------------------
# Data loading / preprocessing
# ---------------------------

def load_tradebook(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["date"])
    return df


def filter_unwanted(df: pd.DataFrame, remove_tickers: set[str]) -> pd.DataFrame:
    return df[~df["ticker"].isin(remove_tickers)].copy()


# ---------------------------
# Trade matching
# ---------------------------

def pair_trades(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (realized_df, open_positions_df).

    Strategy: for each ticker, pair buys to the next sell chronologically using a queue.
    """
    df = df.sort_values("date").copy()
    buys = df[df["signal"] == "BUY"].copy()
    sells = df[df["signal"] == "SELL"].copy()

    realized = []
    # process ticker-by-ticker to avoid cross-ticker pairing
    for ticker, group in df.groupby("ticker"):
        g_buys = group[group["signal"] == "BUY"].sort_values("date")
        g_sells = group[group["signal"] == "SELL"].sort_values("date")

        sell_idx = 0
        for _, buy_row in g_buys.iterrows():
            # find first sell after this buy
            while sell_idx < len(g_sells) and g_sells.iloc[sell_idx]["date"] <= buy_row["date"]:
                sell_idx += 1
            if sell_idx < len(g_sells):
                sell_row = g_sells.iloc[sell_idx]
                realized.append(
                    {
                        "ticker": ticker,
                        "Company": buy_row.get("Company", np.nan),
                        "Industry": sell_row.get("Industry", np.nan),
                        "buy_date": buy_row["date"],
                        "buy_price": buy_row["price"],
                        "sell_date": sell_row["date"],
                        "sell_price": sell_row["price"],
                    },
                )
                sell_idx += 1

    realized_df = pd.DataFrame(realized)
    if not realized_df.empty:
        realized_df["pnl_amt"] = (
            realized_df["sell_price"] - realized_df["buy_price"]).round(2)
        realized_df["pnl_pct"] = (
            (realized_df["pnl_amt"] / realized_df["buy_price"]) * 100).round(2)
        realized_df = realized_df.sort_values(
            "pnl_pct", ascending=False).reset_index(drop=True)
    else:
        realized_df = pd.DataFrame(columns=["ticker", "Company", "Industry",
                                   "buy_date", "buy_price", "sell_date", "sell_price", "pnl_amt", "pnl_pct"])

    # open positions = buys that were not matched (by ticker + buy_date)
    matched = set(zip(realized_df.get("ticker", []),
                  realized_df.get("buy_date", [])))
    buys["buy_key"] = list(zip(buys["ticker"], buys["date"]))
    open_positions = buys[~buys["buy_key"].isin(
        matched)].drop(columns=["buy_key"]).copy()

    # print(open_positions)
    # tradebookedited = Path("/home/rizpython236/BT5/trade-logs/tradebookedited.csv")
    # open_positions.to_csv(tradebookedited, index=False)
    # ff
    print(open_positions.columns)
    open_positions= df.groupby("ticker").tail(1).query("signal=='BUY'" )

    return realized_df, open_positions


# ---------------------------
# Prices / Market data
# ---------------------------

def load_latest_prices(path: Path) -> pd.DataFrame:
    lp = pd.read_csv(path)
    lp = lp.rename(columns=lambda c: c.strip())
    lp["Symbol"] = lp["Symbol"].str.strip()
    lp["Price"] = pd.to_numeric(lp["Price"], errors="coerce")
    return lp[["Symbol", "Price"]]


def update_open_with_latest(open_positions: pd.DataFrame, latest_prices: pd.DataFrame) -> pd.DataFrame:
    if open_positions.empty:
        return open_positions

    merged = open_positions.merge(
        latest_prices, left_on="ticker", right_on="Symbol", how="left")
    # prefer yfinance later; for now keep 'Price' column from latest_prices
    merged = merged.rename(
        columns={"Price": "Latest Price", "price": "BUY Price"})
    merged["Latest Price"] = merged["Latest Price"].astype(float)
    return merged


def yf_fetch_latest(tickers: list[str]) -> dict[str, float]:
    """Fetch latest close price for a list of tickers. Returns dict ticker->price.
    Handles single ticker case used by yfinance.
    """
    if not tickers:
        return {}
    # yfinance behaves differently for single vs multiple tickers
    try:
        if len(tickers) == 1:
            data = yf.download(tickers[0], period="5d",
                               progress=False, auto_adjust=True)
            if data.empty:
                return {}
            price = float(data["Close"].iloc[-1])
            return {tickers[0]: round(price, 2)}

        # multiple tickers: get last close row
        data = yf.download(tickers, period="1d", progress=False,
                           auto_adjust=True, rounding=True)
        if data.empty:
            return {}
        # 'Close' column could be top-level or DataFrame with columns per ticker
        close = data["Close"]
        if isinstance(close, pd.Series):
            # single row - when only one day returned
            return {col: round(close[col], 2) for col in close.index}
        # if DataFrame with tickers as columns
        last_row = close.iloc[-1]
        return {col: (round(last_row[col], 2) if not pd.isna(last_row[col]) else None) for col in last_row.index}
    except Exception:
        traceback.print_exc()
        return {}


# ---------------------------
# Historical price correction
# ---------------------------

def correct_buy_prices(open_positions: pd.DataFrame, threshold_pct: float = THRESHOLD_PERCENT) -> pd.DataFrame:
    """For rows where the historical close around buy date differs more than threshold, update buy price.
    This keeps the function vectorized at a per-ticker level but still fetches history when needed.
    """
    if open_positions.empty:
        return open_positions

    # ensure 'date' is datetime
    open_positions = open_positions.copy()
    open_positions["date"] = pd.to_datetime(
        open_positions["date"]).dt.normalize()
    # print(open_positions)

    if "BUY Price" in open_positions.columns:
        original_prices = open_positions["BUY Price"].copy()
    # else:
        # original_prices = open_positions["price"].copy()

    for i, row in open_positions.iterrows():
        original_prices = open_positions["BUY Price"].copy()
        ticker = row["ticker"]
        buy_date = row["date"]
        old_price = row.get("price", row.get("BUY Price", np.nan))
        if pd.isna(old_price):
            continue

        start_fetch = (buy_date - timedelta(days=5)).strftime("%Y-%m-%d")
        end_fetch = (buy_date + timedelta(days=3)).strftime("%Y-%m-%d")
        try:
            hist = yf.download(ticker, start=start_fetch,
                               end=end_fetch, progress=False, auto_adjust=True)
            if ticker == "GICL.NS":
                # print(hist)
                1+1

            if hist.empty:
                # no data to compare
                print(
                    f"[{ticker}] No historical data available around {buy_date.date()}. Keeping original price: {old_price}")
                continue

            # pick the row on or after buy_date (the first available >= date)
            hist.index = pd.to_datetime(hist.index).normalize()
            ge_dates = hist.loc[hist.index >= buy_date]
            if ge_dates.empty:
                selected_close = float(hist["Close"].iloc[-1])  # old_price #
                selected_date = hist.index[-1]
                print(
                    f" ge_dates.empty Corrected {ticker} buy price from {old_price} -> {selected_close} (as of {selected_date.date()})")
            else:
                # selected_close = float(ge_dates["Close"].iloc[0])
                # selected_close = float(ge_dates["Close"].iat[0])   # fastest
                # selected_close = float(ge_dates["Close"].values[0])
                selected_close = float(ge_dates["Close"].values[0].item())
                selected_date = ge_dates.index[0]

            price_diff_pct = ((selected_close - old_price) / old_price) * 100
            if price_diff_pct < threshold_pct:
                open_positions.at[i, "price"] = round(selected_close, 2)
                # print(f"Corrected {ticker} buy price from {old_price} -> {selected_close} (as of {selected_date.date()})")
                print(
                    f"[{ticker}] Corrected BUY price {old_price} → {selected_close} "
                    f"(date={selected_date.date()}, diff={price_diff_pct:.2f}%)",
                )
            else:
                # print(
                #    f"[{ticker}] Kept original BUY price {old_price} "
                #    f"(historical={selected_close}, diff={price_diff_pct:.2f}%)"
                # )
                1+1
            try:
                open_positions["price"] = open_positions["price"].fillna(original_prices)
            except Exception:
                1+1

        except Exception:
            traceback.print_exc()
            continue

    print(open_positions.columns)
    print(open_positions)
    try:
        1+1
        #open_positions["price"] = open_positions["price"].fillna(original_prices)
    except Exception:
        #open_positions["price"] = open_positions["price"].fillna(0)
        print("Warning: fillna with original_prices failed, used 0 instead.")
    # lookup_original = open_positions["ticker"].map(original_prices)
    # open_positions["price"] = open_positions["price"].fillna(lookup_original)

    # print(open_positions)
    # ff

    return open_positions


# ---------------------------
# Reporting utilities
# ---------------------------

def compute_unrealized(open_positions: pd.DataFrame) -> pd.DataFrame:
    df = open_positions.copy()
    df["Latest Price"] = df["Latest Price"].fillna(
        df.get("price") if "price" in df.columns else df.get("BUY Price"))
    df["unrealised_pnl_amt"] = (
        df["Latest Price"] - df.get("price", df.get("BUY Price"))).round(2)
    df["unrealised_pnl_pct"] = (
        (df["unrealised_pnl_amt"] / df.get("price", df.get("BUY Price"))) * 100).round(2)
    return df


def compute_realized(realized_df: pd.DataFrame) -> pd.DataFrame:
    df = realized_df.copy()
    df["Latest Price"] = df["Latest Price"].fillna(
        df.get("price") if "price" in df.columns else df.get("BUY Price"))
    df["realised_pnl_amt"] = (
        df["Latest Price"] - df.get("price", df.get("BUY Price"))).round(2)
    df["realised_pnl_pct"] = (
        (df["realised_pnl_amt"] / df.get("price", df.get("BUY Price"))) * 100).round(2)
    return df

# ---------------------------
# High-level orchestration
# ---------------------------


def run_analysis():
    #print("Start tradebook analysis")

    trades = load_tradebook(FILE_TRADEBOOK)
    trades = filter_unwanted(trades, REMOVE_TICKERS)

    realized_df, open_positions = pair_trades(trades)

    # load latest prices file and merge
    latest_prices = load_latest_prices(FILE_LATEST_PRICE)
    open_positions = update_open_with_latest(open_positions, latest_prices)

    # try fetching fresh prices via yfinance for open tickers
    tickers = open_positions["ticker"].dropna().unique().tolist()
    yf_prices = yf_fetch_latest(tickers)
    if yf_prices:
        # map into Latest Price when available
        open_positions["Latest Price"] = open_positions["ticker"].map(
            yf_prices).combine_first(open_positions.get("Latest Price"))

    # historical correction if necessary
    open_positions = correct_buy_prices(open_positions, THRESHOLD_PERCENT)

    # compute unrealized PnL
    open_positions = compute_unrealized(open_positions)

    # IRR realized
    cashflows = []
    for _, r in realized_df.iterrows():
        cashflows.append(
            (pd.to_datetime(r["buy_date"]), -float(r["buy_price"])))
        cashflows.append(
            (pd.to_datetime(r["sell_date"]), float(r["sell_price"])))

    irr_result = xirr(cashflows) if cashflows else None

    # Open positions XIRR (using today as inflow date)
    today = datetime.now(IST_TZ).date()
    open_cashflows = []
    for _, r in open_positions.iterrows():
        if pd.notna(r.get("Latest Price")):
            open_cashflows.append(
                (pd.to_datetime(r["date"]), -float(r.get("price", r.get("BUY Price")))))
            open_cashflows.append(
                (pd.to_datetime(today), float(r["Latest Price"])))
    open_xirr = xirr(open_cashflows) if open_cashflows else None

    # Summaries (kept similar to original but using safer guards)
    print("=== ✅ Realized Long Trades ===")
    if not realized_df.empty:
        # Add Holding Duration for realized trades
        realized_df["holding_duration_days"] = (
            realized_df["sell_date"] - realized_df["buy_date"]).dt.days
        print(realized_df[["ticker", "Company", "Industry", "buy_date", "buy_price", "sell_date",
              "sell_price", "pnl_amt", "pnl_pct", "holding_duration_days"]].to_string(index=False))
    else:
        print("No realized trades found.")

    print("\n=== 🔓 Open Long Positions ===")
    if not open_positions.empty:
        _today = pd.Timestamp.today().normalize()
        open_positions["holding_duration_days"] = (
            _today - open_positions["date"]).dt.days
        out_cols = [c for c in ["ticker", "Company", "Industry", "date", "price", "Latest Price",
                                "unrealised_pnl_amt", "unrealised_pnl_pct", "holding_duration_days"] if c in open_positions.columns]
        # Filter positions with holding duration > 30 days
        open_positions = open_positions[open_positions["holding_duration_days"] > 0] #MIN_HOLD_DAYS
        open_positions.to_csv(open_TRADEBOOK, index=False)

        open_TRADEBOOK1 = Path(
            "/home/rizpython236/BT5/trade-logs/Opentradebook.csv")
        open_positions.to_csv(open_TRADEBOOK1, index=False)
        print(open_positions[out_cols].sort_values(
            "unrealised_pnl_pct", ascending=False).to_string(index=False))

        filtered_df = open_positions[open_positions['ticker'].str.upper().str.endswith('.BO', na=False)]
        filtered_df['date'] = pd.to_datetime(filtered_df['date'], errors='coerce')
        desired_cols = ['ticker', 'Company', 'Industry', 'date', 'price', 'Latest Price',
                'unrealised_pnl_amt', 'unrealised_pnl_pct', 'holding_duration_days']

        try:
            print(filtered_df[desired_cols].sort_values("date", ascending=False).to_string(index=False))
        except Exception:
            1+1

        time.sleep(3)
        folder_path = "/home/rizpython236/BT5/ticker_15yr"
        filepathBTpdf = "/home/rizpython236/BT5/screener-outputs/OpentradebookCharts.pdf"
        # screenercsvBT_path = "/home/rizpython236/BT5/screener-outputs/Opentradebook.csv"
        screenercsvBT_path = "/home/rizpython236/BT5/trade-logs/Opentradebook.csv"
        addchartspdf(screenercsv_path=screenercsvBT_path,
                     folder_path=folder_path, filepathpdf=filepathBTpdf)

    else:
        print("No open positions.")

    if irr_result is not None:
        print(
            f"\n=== 📈 IRR on Realized Long Trades: {irr_result * 100:.2f}% ===")
    else:
        print("\n⚠️ No valid IRR calculated on realized trades.")

    if open_xirr is not None:
        print(
            f"\n=== 🧮 XIRR on Open Long Positions: {open_xirr * 100:.2f}% ===")
    else:
        print("\n⚠️ No valid XIRR for open positions.")

    # Export CSV/PDF and send via telegram
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # realized_csv = OUT_DIR / f"TradebookRealized_PNL_{timestamp}.csv"
    realized_csv = OUT_DIR / "TradebookRealized_PNL_.csv"
    realized_pdf = realized_csv.with_suffix(".pdf")
    # realized_df.to_csv(realized_csv, index=False)
    # create_pdf(str(realized_csv), str(realized_pdf), pageA4=False)
    # post_telegram_file(str(realized_pdf))
    if irr_result is not None:
        post_telegram_message(
            f"📈 XIRR Realized Long Trades: {irr_result * 100:.2f}%")
        1+1

    # open_csv = OUT_DIR / f"TradebookOpenPositions_PNL_{timestamp}.csv"
    open_csv = OUT_DIR / "TradebookOpenPositions_PNL_.csv"
    open_pdf = open_csv.with_suffix(".pdf")
    # open_positions.to_csv(open_csv, index=False)
    # create_pdf(str(open_csv), str(open_pdf), pageA4=False)
    # post_telegram_file(str(open_pdf))
    if open_xirr is not None:
        post_telegram_message(
            f"🧮 XIRR Open Long Positions: {open_xirr * 100:.2f}%")

    # abbreviated analytics (keep as-is, but could be moved into separate functions)
    # ... compute distributions, profitability metrics etc. (omitted for brevity)

    # ------------------------------------------------------------
    # 📊 ADVANCED ANALYTICS
    # ------------------------------------------------------------
    print("\n================= 📊 ADVANCED TRADE ANALYTICS =================")

    # ---------------------------
    # REALIZED TRADE ANALYTICS
    # ---------------------------
    if not realized_df.empty:
        print("\n=== 📘 REALIZED TRADE ANALYTICS ===")

        pnl = realized_df["pnl_amt"]

        wins = realized_df[realized_df["pnl_amt"] > 0]
        losses = realized_df[realized_df["pnl_amt"] < 0]

        win_rate = len(wins) / len(realized_df) * \
            100 if len(realized_df) else 0
        profit_factor = (wins["pnl_amt"].sum() / abs(losses["pnl_amt"].sum())
                         if len(losses) else float("inf"))

        max_win = pnl.max()
        max_loss = pnl.min()

        avg_win = wins["pnl_amt"].mean() if not wins.empty else 0
        avg_loss = losses["pnl_amt"].mean() if not losses.empty else 0

        # Max Drawdown using cumulative PnL
        cum_pnl = pnl.cumsum()
        roll_max = cum_pnl.cummax()
        drawdown = (cum_pnl - roll_max)
        max_drawdown = drawdown.min()

        print(f"Total Realized Trades: {len(realized_df)}")
        print(f"Win Rate: {win_rate:.2f}%")
        print(f"Profit Factor: {profit_factor:.2f}")
        print(f"Average Win$: {avg_win:.2f}")
        print(f"Average Loss$: {avg_loss:.2f}")
        print(f"Largest Win$: {max_win:.2f}")
        print(f"Largest Loss$: {max_loss:.2f}")
        print(f"Max Drawdown: {max_drawdown:.2f}")

        print(f"Median PnL: {pnl.median():.2f}")
        print(f"Mean PnL: {pnl.mean():.2f}")

        # Holding duration
        realized_df["holding_duration_days"] = (
            realized_df["sell_date"] - realized_df["buy_date"]
        ).dt.days
        print(
            f"Avg Holding Duration (days): {realized_df['holding_duration_days'].mean():.1f}")
        print(
            f"Median Holding Duration (days): {realized_df['holding_duration_days'].median():.1f}")

        # Industry performance
        if "Industry" in realized_df.columns:
            print("\n--- Industry Performance (Median PnL %) ---")
            print(realized_df.groupby("Industry")[
                  "pnl_pct"].median().sort_values(ascending=False).to_string())
    else:
        print("\n⚠️ No realized trades for analytics.")

    # ---------------------------
    # OPEN POSITIONS ANALYTICS
    # ---------------------------
    print("\n=== 🔓 OPEN POSITIONS ANALYTICS ===")

    if not open_positions.empty:
        unreal = open_positions["unrealised_pnl_amt"]

        print(f"Open Positions Count: {len(open_positions)}")
        print(f"Total Unrealized PnL$: {unreal.sum():.2f}")
        print(f"Median Unrealized PnL$: {unreal.median():.2f}")
        print(f"Mean Unrealized PnL$: {unreal.mean():.2f}")

        # Exposure by industry
        if "Industry" in open_positions.columns:
            print("\n--- Industry Exposure (Count of Positions) ---")
            print(open_positions["Industry"].value_counts().to_string())

        # Holding duration
        if "holding_duration_days" in open_positions.columns:
            print(
                f"\nAvg Holding Duration (days): {open_positions['holding_duration_days'].mean():.1f}")
            print(
                f"Median Holding Duration (days): {open_positions['holding_duration_days'].median():.1f}")
    else:
        print("⚠️ No open position analytics.")

    print("\n================= END OF ANALYTICS =================\n")


#if __name__ == "__main__":
run_analysis()

# ===


# ===== Enhanced Open Position (Unrealized) Analytics =====


def compute_open_positions_analytics(df_open):
    df = df_open.copy()
    df["pnl_pct"] = df["unrealized_pnl"] / df["buy_value"] * 100

    analytics = {}

    # Summary
    analytics["summary"] = pd.DataFrame({
        "Open Positions": [len(df)],
        "Win Rate %": [(df["unrealized_pnl"] > 0).mean() * 100],
        "Avg Unrealized PnL %": [df["pnl_pct"].mean()],
        "Median Unrealized PnL %": [df["pnl_pct"].median()],
    })

    # PnL distribution
    bins = [-100, -20, -10, -5, 0, 5, 10, 20, 50, 100, 500]
    df["pnl_bucket"] = pd.cut(df["pnl_pct"], bins=bins)
    analytics["distribution"] = df.groupby(
        "pnl_bucket").size().reset_index(name="count")

    # Exposure by symbol
    analytics["exposure_by_symbol"] = (
        df.groupby("ticker")[["buy_value", "current_value", "unrealized_pnl"]]
        .sum()
        .reset_index()
        .sort_values("current_value", ascending=False)
    )

    # Concentration: top 5 exposures
    analytics["top_exposures"] = analytics["exposure_by_symbol"].head(5)

    return analytics
# (Re‑added) ---


def trade_distribution_realized(df_closed):
    df_closed = df_closed.copy()
    df_closed["pnl_pct"] = (df_closed["realized_pnl"] /
                            df_closed["buy_value"]) * 100
    bins = [-100, -10, -5, 0, 5, 10, 25, 50, 100, 500]
    df_closed["pnl_bucket"] = pd.cut(df_closed["pnl_pct"], bins=bins)
    return df_closed.groupby("pnl_bucket").size().reset_index(name="count")


def trade_distribution_unrealized(df_open):
    df_open = df_open.copy()
    df_open["pnl_pct"] = (df_open["unrealized_pnl"] /
                          df_open["buy_value"]) * 100
    bins = [-100, -10, -5, 0, 5, 10, 25, 50, 100, 500]
    df_open["pnl_bucket"] = pd.cut(df_open["pnl_pct"], bins=bins)
    return df_open.groupby("pnl_bucket").size().reset_index(name="count")


def trade_metrics_closed(df_closed):
    return pd.DataFrame({
        "Total Trades": [len(df_closed)],
        "Avg PnL %": [(df_closed["realized_pnl"] / df_closed["buy_value"] * 100).mean()],
        "Win Rate %": [(df_closed["realized_pnl"] > 0).mean() * 100],
        "Avg Holding (Days)": [df_closed["holding_days"].mean()],
    })


def trade_metrics_open(df_open):
    return pd.DataFrame({
        "Open Positions": [len(df_open)],
        "Avg Unrealized PnL %": [(df_open["unrealized_pnl"] / df_open["buy_value"] * 100).mean()],
        "Win Rate %": [(df_open["unrealized_pnl"] > 0).mean() * 100],
    })


print("END tradebookanalysis")
