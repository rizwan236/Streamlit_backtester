import os
import re
import shutil
import sys
import time
import traceback

import pandas as pd


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")
from symbol_copy import NSE_BSE_symbol_name_df
from telegram_bot import post_telegram_file, post_telegram_message
import yfinance as yf


def add_suffix_to_column(df, column_name, suffix):
    df[column_name] = df[column_name].astype(str) + suffix
    return df


def add_company_names_and_industry(input_file, output_file):
    try:
        df = pd.read_csv(input_file)
        print(len(df))

        # --- Precompute dictionaries for replacements ---
        company_replacements = {
            " Company Limited": "", " Corporation Limited": "", " (India) Limited": "", " India Limited": " India",
            " Pharmaceuticals Limited": " Pharma", " (Delhi) Limited": "", " (Maharashtra) Limited": "",
            " Ltd.": "", " Co. Ltd.": "", " (India) Ltd.": "", " Ltd": "", " Co.": ""," Commercial ":" Comm.",
            " Advanced ":" Adv."," Solutions ":" Solu."," Appliances ":" App."," Logistics ":" Logis."," Insurance ":" Insur."," Accessories ":" Accs."," Specialities ":" Spcl."," National ":" Nat."," Software ":" Soft."," Instrumental ":" Instr."," System ":" Sys."," Transformers ":" Transfor.",
            "ICICI Prudential ": "ICICI Pru", "Special Economic Zone": "Spl Eco Zone.", " Limited": "",
            " and ": " & ", " (India)": "", " Company": " Co.", " Infrastructure": " Infra.",
            " & ": " & ", " Corporation ": "Corp. ", " (Gujarat)": "", " (S.A.)": "",
            " And ": " & ", "Engineers": "Engrs.", " (Chennai)": "", " Infrastructures ": " Infra. ",
            " limited": "", "Technologies": "Tech.", " Infrastructure": " Infra.", " Infrastructures": " Infra.",
            " (Kalamandir)": "", " (Madras)": "", "Nippon India Mutual Fund ": "Nippon India ",
            "Nippon India ": "", " Financial ": " Fin. ", " Engineering ": " Eng. ",
            " Industries": " Ind.", " Industries ": " Ind. ", " International": " Intl.",
            " Engineering": " Eng.", "(International)": "", " Development ": " Dev. ",
            " Development": " Dev.", " International ": " Intl. ", " Technology": " Tech.",
            " Technology ": " Tech. ", " Services": " Srvs.", " Holding": " Hldg."," E-Governance": " e-Gov.",
            " Agricultural ": " Agri. ", " Management ": " Mgmt. ", " Investment ": " Invest. ",
            " Consolidated ": " Consol. ", " Chemicals ": " Chem. ", " Chemicals": " Chem.",
            " Fertilizers ": " Fert. ", " Fertilizers": " Fert.", " Biochemicals": " Biochem.",
            " Associated ": " Assoc. ", " Associated": " Assoc.", " Hospital": " Hosp.",
            " Hospital ": " Hosp. ", " Manufacturing": " Mfg.", " Manufacturing ": " Mfg. ",
            "The ": "", "General ": " Gen. ", " Ventures": " Vntrs.", " Enterprises": " Entp.",
            " Industrial ": " Ind. ", " Industrial": " Ind.", " International": " Int.",
            "(International)": "", " Technologies": " Tech.", " (Coimbatore)": "",
            " Petrochemicals": " petrochem.", "Petrochemical": "Petrochem.",
            " Petrochemicals ": " Petrochem.", " Fertilisers ": " Fert. ", " -$ ": ""," MARKET": " MKT.", " Laboratory": " Lab.", " Automobile": " Auto.",
            " Infrastructure": " Infra. "," Technologies": " Tech. "," Pharmaceuticals": " Pharma. "," Industries ": " Ind. "," Immunologicals ": " Immunog. "," Biologicals ": " Bio. "," Petroleum ": " Petro. "," Electronics ": " Electro. "," Telecommunications ": " Telec. "," Systems ": " Sys. "," Petroleum ": " Petro. "," Petroleum ": " Petro. ",
            " Institute ": " Inst. ", "Electricals": "Elect.", "Construction": "Constr.",
            "Systems": "Sys.", "Investments": "Invest.", "Management": "Mgmt.",
            "Exchange": "Exch.", " Fertilisers": " Fert.", "Housing Finance": "Hsg. Fin.","Procter & Gamble": "P&G ",
            "Housing": "Hsg.", "Motilal Oswal S&P": "Motilal Oswal", "Developers": "Develp.",
            " Corporation": "", " Standard": " Std.", " Manufactures": " Mfg..", " Laboratories": " Lab.",
            " Industry": " Ind.", " Estates": " Est.", " Communications": " comm."," Infrastructure": " Infra.",
            " Pharmaceutical": " Pharma."," Development": " Develp."," Equipment": " Equip."," Specialty": " Spl.",
            " Education": " Edu."," Chemicals": " Chem.","Indian Railway Catering & Tourism":"IRCTC","Renewable":"Renew","Corporate":"Corp.",
            "Products":"Prod.","Investment":"Invest.","Consultancy":"Consult.","Electrical":"Elect.","Performance":"Perf.","Consolidated":"Consol.",
            "Intermediaries":"intermeds.","Automotive":"Auto.","Entertainment":"Entmt.","Institute":"Inst.","Limited":"","Company":"Compy.","of India":"",
        }

        industry_replacements = {
            "Corporation of India": "Corp. of India", "Drug Manufacturers—General": "Pharma-General",
            "Engineering & Construction": "Engr./Constr", "Agricultural": "Agri.",
            "Chemicals": "Chem.", "Financial": "Fin.", "Estate": "Est.",
            " - Regional": "", "Drug Manufacturers—Specialty & Generic": "Pharma-Specialty/Generic",
            "Regional": "", "Drug Manufacturers - Specialty & Generic": "Pharma-Specialty/Generic",
            "Drug Manufacturers - General": "Pharma-General", "Farm & Heavy Construction Machinery": "Farm/Heavy Mach.",
            "Information Technology ": "IT ", " Equipment ": " Equip ", " Equipment": " Equip",
            "Other Industrial Metals & Mining": "Other Metals/Mining", "Pharmaceutical ": "Pharma ",
            " Infrastructure": " Infra", "Independent": "", "Infrastructure ": "Infra ",
            "Lodging": "Hotel", "Medical Care Facilities": "Hospital",
            "Integrated Freight & Logistics": "Freight/Logistics", " & ": "/",
            " - ": "-", " — ": "-", " and ": "/", "Manufacturing": "Mfg.",
            "Development": "Develp.", "Industrial": "Ind.", "Services": "Serv.",
            "Manufacturers": "Mfg.", "Electrical": "Elect.", "Manufacturing": "Mfg.",
            "Products": "prod.", "Machinery": "Mach.", "Communication": "Comm.",
            "Specialty": "Spl.", "Biotechnology": "Biotech", "Fabrication": "Fab.",
            "Production": "Prod.", "Conglomerates": "Conglo.", "Finance": "Fin.",
            "Management": "Mgmt.", "Packaged": "Pkg.", "Advertising": "Advert.",
            "Education": "Edu."
        }

        # Compile regex patterns for performance
        company_patterns = [(re.compile(rf"\s*{re.escape(old)}\s*", flags=re.IGNORECASE), new) for old, new in company_replacements.items()]
        industry_patterns = [(re.compile(rf"\s*{re.escape(old)}\s*", flags=re.IGNORECASE), new) for old, new in industry_replacements.items()]

        def clean_text(text, patterns):
            if not isinstance(text, str):
                return text
            for pat, repl in patterns:
                text = pat.sub(repl, text)
            return text

        # NSE/BSE symbol map
        sym_name_df = NSE_BSE_symbol_name_df()
        symbol_to_name = dict(zip(sym_name_df["SYMBOL"], sym_name_df["NAME OF COMPANY"]))

        # Fetch company/industry info
        results = []
        for idx, symbol in enumerate(df['Symbol']):
            try:
                stock = yf.Ticker(symbol)
                company_name = clean_text(symbol_to_name.get(symbol, symbol), company_patterns)

                # Override if unusually long
                if len(company_name) >= len("Garden Reach Shipbuilders & Engineers"):
                    company_name = symbol

                try:
                    yfindustry = stock.info.get("industry", "Blank")
                    industry = clean_text(yfindustry, industry_patterns)
                except Exception:
                    yfindustry, industry = "Blank", "Blank"

                results.append((company_name, yfindustry, industry))

            except Exception:
                results.append((symbol, "Blank", "Blank"))

            if (idx + 1) % 300 == 0:
                print(f"Processed {idx + 1} symbols. Pausing 4 minutes...")
                time.sleep(4 * 60)

        # Assign results
        df[["Company", "YFindustry", "Industry"]] = pd.DataFrame(results, index=df.index)

        # Map with MYindustry.csv
        myind = pd.read_csv('/home/rizpython236/BT5/MYindustry.csv')
        merged_data = df.drop(columns=["Industry"]).merge(myind, left_on="YFindustry", right_on="Industry", how="left")
        merged_data["MYindustry"].fillna("Blank", inplace=True)
        post_telegram_message(merged_data.loc[merged_data["MYindustry"] == "Blank", "YFindustry"].unique().tolist())
        merged_data = merged_data.drop(columns=["Industry"]).rename(columns={"MYindustry": "Industry"})

        # NSE/BSE reference files
        try:
            datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv").drop(
                columns=[" SERIES", " DATE OF LISTING", " PAID UP VALUE", " MARKET LOT", " FACE VALUE"], errors="ignore")
            datanse = add_suffix_to_column(datanse, "SYMBOL", ".NS")

            bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
            bse = bse[bse["Status"] == "Active"].rename(columns={"Security Id": "SYMBOL", "Security Name": "NAME OF COMPANY"})
            bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF|EXCHANGE TRADED|FUND", case=False, na=False)]
            bse.loc[bse['SYMBOL'].str.endswith('*'), 'SYMBOL'] = bse['SYMBOL'].str.rstrip('*')
            bse = bse[bse["Group"].isin(["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"])]
            bse = add_suffix_to_column(bse, "SYMBOL", ".BO")

            # Clean company names
            bse["NAME OF COMPANY"] = bse["NAME OF COMPANY"].apply(lambda x: clean_text(x, company_patterns))
            mapping = dict(zip(bse["SYMBOL"], bse["NAME OF COMPANY"]))
            merged_data["Company"] = merged_data["Company"].map(mapping).fillna(merged_data["Company"])

        except Exception:
            traceback.print_exc()

        # Append TJI index and save
        tji = pd.read_csv('/home/rizpython236/BT5/trade-logs/TJI_index.csv')
        merged_data = pd.concat([merged_data, tji], ignore_index=True)
        merged_data.to_csv(output_file, index=False)
        merged_data.to_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv', index=False)

    except Exception:
        traceback.print_exc()


import pandas as pd


def vlookup_and_merge(output_file):
    print("vlookup_and_merge trade_list_BT_Screener")

    try:
        # Read input files with only needed columns
        valid_tickers = pd.read_csv(
            '/home/rizpython236/BT5/trade-logs/valid_tickers.csv',
            usecols=["Symbol", "Company", "Industry", "YFindustry"],  # restrict columns
        )
        trade_list = pd.read_csv(
            '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
        )

        # Merge directly (sorting unnecessary since merge uses hashing)
        merged_data = trade_list.merge(
            valid_tickers, left_on="ticker", right_on="Symbol", how="left"
        )

        # Drop redundant columns safely
        merged_data.drop(columns=["Symbol", "YFindustry"], errors="ignore", inplace=True)

        # Fill missing values
        merged_data["Company"] = merged_data["Company"].fillna("Blank")

        # Save to CSV
        merged_data.to_csv(output_file, index=False)
        print(f"✅ Successfully merged data and saved to {output_file}")

    except Exception as e:
        print(f"❌ Error in vlookup_and_merge: {e}")


import pandas as pd


def update_output_file(input_file, output_file):
    """
    Updates the output file with VLOOKUP logic for Symbol, Company, YFindustry, and Industry.
    Fills missing data where no matches are found.

    Args:
        input_file (str): Path to the input CSV file.
        output_file (str): Path to the output CSV file.
    """

    try:
        # Read input with only required columns
        df_input = pd.read_csv(
            input_file, usecols=["Symbol", "Company", "YFindustry", "Industry"]
        )
        df_output = pd.read_csv(output_file)

        # Merge (left join on Symbol)
        merged_data = df_output.merge(df_input, on="Symbol", how="left", suffixes=("", "_y"))

        # Fill Company: fallback to Symbol if missing
        merged_data["Company"] = merged_data["Company"].fillna(merged_data["Symbol"])

        # Fill other missing fields with "Blank"
        for col in ["YFindustry", "Industry"]:
            merged_data[col] = merged_data[col].fillna("Blank")

        # Drop duplicate columns created by merge (if any)
        dup_cols = [c for c in merged_data.columns if c.endswith("_y")]
        merged_data.drop(columns=dup_cols, inplace=True, errors="ignore")

        # Save updated data
        merged_data.to_csv(output_file, index=False)
        print(f"✅ Successfully updated {output_file} with VLOOKUP logic")

    except Exception as e:
        print(f"❌ Error in update_output_file: {e}")


import os
import shutil


def copyfile1(input_file, output_file):
    """
    Copies a file from input_file to output_file.

    Args:
        input_file (str): Path to the source file.
        output_file (str): Path to the destination file.
    """
    try:
        if not os.path.exists(input_file):
            print(f"❌ Source file does not exist: {input_file}")
            return

        # Ensure destination directory exists
        os.makedirs(os.path.dirname(output_file), exist_ok=True)

        shutil.copy2(input_file, output_file)  # copy2 preserves metadata
        print(f"✅ File copied successfully → {output_file}")

    except Exception as e:
        print(f"❌ Error copying file: {e}")



# Example usage
#vlookup_and_merge(output_file)

# Example usage
input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
#update_output_file(input_file, output_file)


input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
##copyfile1(input_file, output_file)


input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
#update_output_file(input_file, output_file)

output_file = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv'
#vlookup_and_merge(output_file)

# Example usage:
input_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
input_file = '/home/rizpython236/BT5/trade-logs/fullbsenseFinal.csv'
input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'

input_file = '/home/rizpython236/BT5/Final.csv'
output_file = '/home/rizpython236/BT5/screener-outputs/valid_tickers.csv'
#add_company_names_and_industry(input_file, output_file)

print("done2")