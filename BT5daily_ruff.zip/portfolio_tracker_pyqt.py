"""
PyQt Portfolio Tracker (Threaded price fetch, adjustment snapshots, richer mapping suggestions)

This update implements:
- Background threaded price fetching using QThread with progress signals (UI remains responsive)
- Manual price entry dialog shown when any tickers fail to fetch
- Split/Bonus handling records an explicit 'Adjustment' transaction plus stores pre/post lot snapshots in model.adjustments
- Mapping editor improved with suggestion helpers from local mapping and an optional online lookup attempt
- Progress UI tied to the background worker

Run: python portfolio_tracker_pyqt.py

"""

import os
import sys
import math
import json
from datetime import datetime

from PyQt5 import QtCore, QtGui, QtWidgets
import pandas as pd
import numpy as np
import numpy_financial as npf
import yfinance as yf

from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

# -------------------- Constants --------------------
TXN_COLS = ["Company", "Date", "Type", "Units", "Price", "Ticker", "Ratio", "Notes"]
VALID_TYPES = ["Buy", "Sell", "Split", "Dividend", "Bonus", "Adjustment"]
MAPPING_COLS = ["Company", "Ticker", "Industry", "AssetType"]
VALID_ASSET_TYPES = ["Stock", "Mutual Fund"]

SAMPLE_DIR = os.path.join(os.getcwd(), 'sample_data')
TEST_DIR = os.path.join(os.getcwd(), 'tests')

# -------------------- Utilities --------------------

def ensure_sample_files():
    os.makedirs(SAMPLE_DIR, exist_ok=True)
    os.makedirs(TEST_DIR, exist_ok=True)
    tx_path = os.path.join(SAMPLE_DIR, 'transactions_sample.csv')
    map_path = os.path.join(SAMPLE_DIR, 'mapping_sample.csv')
    if not os.path.exists(tx_path):
        df = pd.DataFrame([
            {'Company':'Acme Corp','Date':'2023-01-10','Type':'Buy','Units':100,'Price':10.0,'Ticker':'ACME','Ratio':np.nan,'Notes':''},
            {'Company':'Acme Corp','Date':'2024-06-01','Type':'Split','Units':np.nan,'Price':np.nan,'Ticker':'ACME','Ratio':2,'Notes':'2-for-1 split'},
            {'Company':'Folio MF','Date':'2023-03-15','Type':'Buy','Units':10.5,'Price':100.0,'Ticker':'FOLIO','Ratio':np.nan,'Notes':''},
        ])
        df.to_csv(tx_path, index=False)
    if not os.path.exists(map_path):
        md = pd.DataFrame([
            {'Company':'Acme Corp','Ticker':'ACME','Industry':'Industrial','AssetType':'Stock'},
            {'Company':'Folio MF','Ticker':'FOLIO','Industry':'Mutual Funds','AssetType':'Mutual Fund'},
        ])
        md.to_csv(map_path, index=False)
    test_py = os.path.join(TEST_DIR, 'test_asset_rules.py')
    if not os.path.exists(test_py):
        with open(test_py, 'w') as f:
            f.write("""
import pandas as pd

# Placeholder test - expand as needed

def test_placeholder():
    assert True
""")

# -------------------- Core model --------------------
class PortfolioModel(QtCore.QObject):
    prices_updated = QtCore.pyqtSignal()

    def __init__(self):
        super().__init__()
        self.txn = pd.DataFrame(columns=TXN_COLS)
        self.txn['Date'] = pd.to_datetime(self.txn['Date'])
        self.mapping = pd.DataFrame(columns=MAPPING_COLS)
        self.prices = {}
        # adjustments: list of dicts {Company, Date, Ratio, PreLots, PostLots}
        self.adjustments = []

    # IO
    def load_txn_csv(self, path):
        df = pd.read_csv(path)
        for c in TXN_COLS:
            if c not in df.columns:
                df[c] = np.nan
        df = df[TXN_COLS]
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
        self.txn = df.sort_values('Date').reset_index(drop=True)

    def save_txn_csv(self, path):
        self.txn.to_csv(path, index=False)

    def load_mapping_csv(self, path):
        df = pd.read_csv(path)
        for c in MAPPING_COLS:
            if c not in df.columns:
                df[c] = np.nan
        if 'AssetType' not in df.columns:
            df['AssetType'] = 'Stock'
        df['AssetType'] = df['AssetType'].fillna('Stock')
        df.loc[~df['AssetType'].isin(VALID_ASSET_TYPES), 'AssetType'] = 'Stock'
        self.mapping = df[MAPPING_COLS].drop_duplicates().reset_index(drop=True)

    def save_mapping_csv(self, path):
        self.mapping.to_csv(path, index=False)

    # price fetch (kept synchronous here, but will be called from a QThread worker)
    def fetch_prices(self, tickers):
        prices = {}
        tickers = [t for t in tickers if isinstance(t, str) and t.strip()]
        if not tickers:
            return prices
        try:
            data = yf.download(tickers=tickers, period='1d', progress=False, threads=False)
            if isinstance(data.columns, pd.MultiIndex):
                if 'Adj Close' in data:
                    adj = data['Adj Close']
                    for t in adj.columns:
                        val = adj[t].dropna()
                        if len(val):
                            prices[t] = float(val.iloc[-1])
                elif 'Close' in data:
                    close = data['Close']
                    for t in close.columns:
                        val = close[t].dropna()
                        if len(val):
                            prices[t] = float(val.iloc[-1])
            else:
                if 'Adj Close' in data.columns:
                    val = data['Adj Close'].dropna()
                    if len(val):
                        prices[tickers[0]] = float(val.iloc[-1])
        except Exception:
            pass
        self.prices.update(prices)
        self.prices_updated.emit()
        return prices

    # helpers
    def get_ticker(self, company):
        r = self.mapping[self.mapping['Company']==company]
        if r.empty:
            return None
        return r.iloc[0]['Ticker']

    def get_asset_type(self, company):
        r = self.mapping[self.mapping['Company']==company]
        if r.empty:
            return 'Stock'
        return r.iloc[0]['AssetType']

    # validation
    def validate(self):
        issues = []
        # row-level
        for i, row in self.txn.iterrows():
            if pd.isna(row['Company']) or str(row['Company']).strip()=='':
                issues.append((i,'Missing company'))
            if pd.isna(row['Date']):
                issues.append((i,'Invalid date'))
            if row['Type'] not in VALID_TYPES:
                issues.append((i,f"Invalid type {row['Type']}"))
            if row['Type'] in ('Buy','Sell'):
                u = safe_float(row['Units'])
                p = safe_float(row['Price'])
                if math.isnan(u) or u<=0:
                    issues.append((i,'Units must be >0'))
                if math.isnan(p) or p<=0:
                    issues.append((i,'Price must be >0'))
            if row['Type'] in ('Split','Bonus'):
                r = safe_float(row['Ratio'])
                if math.isnan(r) or r<=0:
                    issues.append((i,'Invalid ratio'))
            if pd.isna(row['Ticker']) or str(row['Ticker']).strip()=='':
                # if mapping exists, ok, else report
                if self.mapping[self.mapping['Company']==row['Company']].empty:
                    issues.append((i,'Missing ticker mapping'))
        # portfolio-level: no shorts, integer enforcement for stocks
        running = {}
        tx_sorted = self.txn.copy().sort_values('Date').reset_index()
        for _, r in tx_sorted.iterrows():
            idx = int(r['index'])
            comp = r['Company']
            typ = r['Type']
            u = safe_float(r['Units'])
            asset = self.get_asset_type(comp)
            if comp not in running:
                running[comp]=0.0
            if typ=='Buy':
                running[comp]+= (u if not math.isnan(u) else 0)
                if asset=='Stock' and not is_integer_like(u):
                    issues.append((idx,'Fractional units not allowed for Stock on Buy'))
            elif typ=='Sell':
                if asset=='Stock' and not is_integer_like(u):
                    issues.append((idx,'Fractional units not allowed for Stock on Sell'))
                running[comp]-=(u if not math.isnan(u) else 0)
                if running[comp] < -1e-9:
                    issues.append((idx,'Sell would create short position'))
        return issues

    # holdings & FIFO
    def compute_holdings(self, as_of=None):
        tx = self.txn.copy().sort_values('Date')
        if as_of is not None:
            tx = tx[tx['Date']<=as_of]
        lots = {}
        realised = []
        dividends = []
        for idx, r in tx.iterrows():
            comp = r['Company']
            typ = r['Type']
            date = r['Date']
            u = safe_float(r['Units'])
            p = safe_float(r['Price'])
            ratio = safe_float(r['Ratio'])
            if comp not in lots:
                lots[comp]=[]
            if typ=='Buy':
                lots[comp].append({'units':u,'price':p,'date':date,'idx':idx})
            elif typ=='Sell':
                remaining = u
                total = sum(l['units'] for l in lots[comp])
                if remaining>total:
                    remaining = total
                while remaining>0 and lots[comp]:
                    lot = lots[comp][0]
                    take = min(lot['units'], remaining)
                    proceeds = take * p
                    cost = take * lot['price']
                    realised.append({'Company':comp,'Date':date,'Units':take,'SellPrice':p,'BuyPrice':lot['price'],'Proceeds':proceeds,'Cost':cost,'PL':proceeds-cost,'BuyDate':lot['date']})
                    lot['units']-=take
                    remaining-=take
                    if lot['units']==0:
                        lots[comp].pop(0)
            elif typ in ('Split','Bonus'):
                # record pre/post snapshots and append to adjustments
                pre = [{'units':l['units'],'price':l['price'],'date':str(l['date'])} for l in lots[comp]]
                new_lots = []
                for lot in lots[comp]:
                    lu = lot['units'] * ratio
                    lp = lot['price'] / ratio
                    new_lots.append({'units':lu,'price':lp,'date':lot['date'],'idx':lot['idx']})
                lots[comp] = new_lots
                post = [{'units':l['units'],'price':l['price'],'date':str(l['date'])} for l in lots[comp]]
                self.adjustments.append({'Company':comp,'Date':str(date),'Ratio':ratio,'PreLots':pre,'PostLots':post})
            elif typ=='Dividend':
                dividends.append({'Company':comp,'Date':date,'Amount':p})
            elif typ=='Adjustment':
                # Adjustment rows are informational; we already recorded snapshots when processing Split
                pass
        holdings = []
        for comp, lts in lots.items():
            units = sum(l['units'] for l in lts)
            cost = sum(l['units']*l['price'] for l in lts)
            avg = (cost/units) if units else np.nan
            ticker = self.get_ticker(comp)
            mprice = self.prices.get(ticker, np.nan)
            mvalue = mprice*units if not np.isnan(mprice) else np.nan
            upr = mvalue-cost if not np.isnan(mvalue) else np.nan
            uprp = (upr/cost*100) if cost and not np.isnan(upr) else np.nan
            holdings.append({'Company':comp,'Ticker':ticker,'Units':units,'AvgCost':avg,'TotalCost':cost,'MarketPrice':mprice,'MarketValue':mvalue,'UnrealPL':upr,'UnrealPL_Pct':uprp})
        return pd.DataFrame(holdings), pd.DataFrame(realised), pd.DataFrame(dividends)

    # xirr
    def compute_xirr(self, company=None, as_of=None):
        tx = self.txn.copy().sort_values('Date')
        if company:
            tx = tx[tx['Company']==company]
        if as_of is not None:
            tx = tx[tx['Date']<=as_of]
        cashflows = []
        for _, r in tx.iterrows():
            t = r['Type']
            d = r['Date']
            u = safe_float(r['Units'])
            p = safe_float(r['Price'])
            if t=='Buy':
                cashflows.append((d, -u*p))
            elif t=='Sell':
                cashflows.append((d, u*p))
            elif t=='Dividend':
                cashflows.append((d, p))
        if not cashflows:
            return np.nan
        try:
            rate = npf.xirr(list(zip([d for d,_ in cashflows],[a for _,a in cashflows])))
            return rate
        except Exception:
            return np.nan

# -------------------- Price fetch worker (QThread) --------------------
class PriceFetchWorker(QtCore.QThread):
    progress = QtCore.pyqtSignal(int, int)  # done, total
    finished = QtCore.pyqtSignal(dict)

    def __init__(self, model, tickers, batch_size=10):
        super().__init__()
        self.model = model
        self.tickers = tickers
        self.batch_size = batch_size

    def run(self):
        prices = {}
        total = len(self.tickers)
        done = 0
        # fetch in batches to allow progress updates
        for i in range(0, total, self.batch_size):
            batch = self.tickers[i:i+self.batch_size]
            try:
                data = yf.download(tickers=batch, period='1d', progress=False, threads=False)
                if isinstance(data.columns, pd.MultiIndex):
                    if 'Adj Close' in data:
                        adj = data['Adj Close']
                        for t in adj.columns:
                            val = adj[t].dropna()
                            if len(val):
                                prices[t] = float(val.iloc[-1])
                    elif 'Close' in data:
                        close = data['Close']
                        for t in close.columns:
                            val = close[t].dropna()
                            if len(val):
                                prices[t] = float(val.iloc[-1])
                else:
                    if 'Adj Close' in data.columns:
                        val = data['Adj Close'].dropna()
                        if len(val):
                            prices[batch[0]] = float(val.iloc[-1])
            except Exception:
                pass
            done += len(batch)
            self.progress.emit(min(done, total), total)
        # update model prices
        self.model.prices.update(prices)
        self.finished.emit(prices)

# -------------------- UI Components --------------------
class PandasModel(QtCore.QAbstractTableModel):
    def __init__(self, df=pd.DataFrame(), parent=None):
        super().__init__(parent)
        self._df = df

    def setDataFrame(self, df):
        self.beginResetModel()
        self._df = df.copy()
        self.endResetModel()

    def rowCount(self, parent=None):
        return len(self._df.index)

    def columnCount(self, parent=None):
        return len(self._df.columns)

    def data(self, index, role=QtCore.Qt.DisplayRole):
        if not index.isValid():
            return None
        value = self._df.iat[index.row(), index.column()]
        if role==QtCore.Qt.DisplayRole:
            return str(value) if not pd.isna(value) else ''
        return None

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role!=QtCore.Qt.DisplayRole:
            return None
        if orientation==QtCore.Qt.Horizontal:
            return self._df.columns[section]
        else:
            return str(self._df.index[section])

# Main Window
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Portfolio Tracker - PyQt (Threaded)')
        self.resize(1200,800)
        ensure_sample_files()
        self.model = PortfolioModel()
        try:
            self.model.load_mapping_csv(os.path.join(SAMPLE_DIR,'mapping_sample.csv'))
        except Exception:
            pass
        self._build_ui()

    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        layout = QtWidgets.QVBoxLayout(central)

        toolbar = QtWidgets.QHBoxLayout()
        btn_load_tx = QtWidgets.QPushButton('Load Transactions CSV')
        btn_load_tx.clicked.connect(self.load_txn)
        btn_save_tx = QtWidgets.QPushButton('Save Transactions CSV')
        btn_save_tx.clicked.connect(self.save_txn)
        btn_load_map = QtWidgets.QPushButton('Load Mapping CSV')
        btn_load_map.clicked.connect(self.load_map)
        btn_save_map = QtWidgets.QPushButton('Save Mapping CSV')
        btn_save_map.clicked.connect(self.save_map)
        btn_fetch = QtWidgets.QPushButton('Fetch Prices')
        btn_fetch.clicked.connect(self.fetch_prices_threaded)
        btn_validate = QtWidgets.QPushButton('Validate')
        btn_validate.clicked.connect(self.validate)
        toolbar.addWidget(btn_load_tx)
        toolbar.addWidget(btn_save_tx)
        toolbar.addWidget(btn_load_map)
        toolbar.addWidget(btn_save_map)
        toolbar.addWidget(btn_fetch)
        toolbar.addWidget(btn_validate)
        layout.addLayout(toolbar)

        splitter = QtWidgets.QSplitter()
        layout.addWidget(splitter)

        # left: txn table + controls
        left = QtWidgets.QWidget()
        llay = QtWidgets.QVBoxLayout(left)
        self.txn_view = QtWidgets.QTableView()
        self.txn_model = PandasModel(self.model.txn)
        self.txn_view.setModel(self.txn_model)
        self.txn_view.setSelectionBehavior(QtWidgets.QTableView.SelectRows)
        llay.addWidget(self.txn_view)
        hbtns = QtWidgets.QHBoxLayout()
        btn_add = QtWidgets.QPushButton('Add Txn')
        btn_add.clicked.connect(self.add_txn)
        btn_edit = QtWidgets.QPushButton('Edit Txn')
        btn_edit.clicked.connect(self.edit_txn)
        btn_del = QtWidgets.QPushButton('Delete Txn')
        btn_del.clicked.connect(self.delete_txn)
        hbtns.addWidget(btn_add); hbtns.addWidget(btn_edit); hbtns.addWidget(btn_del)
        llay.addLayout(hbtns)
        splitter.addWidget(left)

        # right: holdings + plot + adjustments
        right = QtWidgets.QWidget()
        rlay = QtWidgets.QVBoxLayout(right)
        self.holdings_view = QtWidgets.QTableView()
        self.holdings_model = PandasModel(pd.DataFrame())
        self.holdings_view.setModel(self.holdings_model)
        self.holdings_view.setSelectionBehavior(QtWidgets.QTableView.SelectRows)
        self.holdings_view.doubleClicked.connect(self.on_holding_double)
        rlay.addWidget(self.holdings_view)
        plot_btn = QtWidgets.QPushButton('Plot Selected Holding History')
        plot_btn.clicked.connect(self.plot_selected_holding)
        rlay.addWidget(plot_btn)
        self.adjustment_btn = QtWidgets.QPushButton('Show Adjustments')
        self.adjustment_btn.clicked.connect(self.show_adjustments)
        rlay.addWidget(self.adjustment_btn)
        splitter.addWidget(right)

        # status bar and progress
        self.status = QtWidgets.QStatusBar()
        self.setStatusBar(self.status)
        self.progress = QtWidgets.QProgressBar()
        self.progress.setVisible(False)
        self.status.addPermanentWidget(self.progress)

        # bottom: error list dock
        self.error_dock = QtWidgets.QDockWidget('Validation Issues', self)
        self.error_list = QtWidgets.QListWidget()
        self.error_dock.setWidget(self.error_list)
        self.addDockWidget(QtCore.Qt.BottomDockWidgetArea, self.error_dock)

        self.refresh_views()

    # File actions
    def load_txn(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, 'Open Transactions CSV', '', 'CSV Files (*.csv)')
        if not path:
            return
        try:
            self.model.load_txn_csv(path)
            self.refresh_views()
            self.status.showMessage(f'Loaded {path}')
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, 'Error', str(e))

    def save_txn(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Save Transactions CSV', '', 'CSV Files (*.csv)')
        if not path:
            return
        try:
            self.model.save_txn_csv(path)
            self.status.showMessage(f'Saved {path}')
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, 'Error', str(e))

    def load_map(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, 'Open Mapping CSV', '', 'CSV Files (*.csv)')
        if not path:
            return
        try:
            self.model.load_mapping_csv(path)
            self.status.showMessage(f'Loaded mapping {path}')
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, 'Error', str(e))

    def save_map(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Save Mapping CSV', '', 'CSV Files (*.csv)')
        if not path:
            return
        try:
            self.model.save_mapping_csv(path)
            self.status.showMessage(f'Saved mapping {path}')
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, 'Error', str(e))

    # txn editing
    def add_txn(self):
        dlg = TxnDialog(self)
        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            rows = dlg.get_result()
            # rows may be tuple of one or two (split + adjustment)
            for row in rows:
                self.model.txn = pd.concat([self.model.txn, pd.DataFrame([row])], ignore_index=True, sort=False)
            self.model.txn['Date'] = pd.to_datetime(self.model.txn['Date'], errors='coerce')
            self.model.txn = self.model.txn.sort_values('Date').reset_index(drop=True)
            self.refresh_views()

    def edit_txn(self):
        sel = self.txn_view.selectionModel().selectedRows()
        if not sel:
            QtWidgets.QMessageBox.warning(self, 'Select', 'Select a row to edit')
            return
        idx = sel[0].row()
        row = self.model.txn.loc[idx].to_dict()
        dlg = TxnDialog(self, txn=row)
        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            newrows = dlg.get_result()
            # replace the selected row with first returned row; append any additional (adjustment) rows
            first = newrows[0]
            for k,v in first.items():
                self.model.txn.at[idx,k]=v
            for extra in newrows[1:]:
                self.model.txn = pd.concat([self.model.txn, pd.DataFrame([extra])], ignore_index=True, sort=False)
            self.model.txn['Date']=pd.to_datetime(self.model.txn['Date'], errors='coerce')
            self.model.txn = self.model.txn.sort_values('Date').reset_index(drop=True)
            self.refresh_views()

    def delete_txn(self):
        sel = self.txn_view.selectionModel().selectedRows()
        if not sel:
            return
        idx = sel[0].row()
        if QtWidgets.QMessageBox.question(self, 'Delete', 'Delete selected transaction?')==QtWidgets.QMessageBox.StandardButton.Yes:
            self.model.txn = self.model.txn.drop(index=idx).reset_index(drop=True)
            self.refresh_views()

    # threaded price fetching
    def fetch_prices_threaded(self):
        tickers = list(self.model.mapping['Ticker'].dropna().unique()) if not self.model.mapping.empty else []
        if not tickers:
            QtWidgets.QMessageBox.warning(self, 'No tickers', 'No tickers in mapping')
            return
        # start worker
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.worker = PriceFetchWorker(self.model, tickers)
        self.worker.progress.connect(self.on_price_progress)
        self.worker.finished.connect(self.on_price_finished)
        self.worker.start()
        self.status.showMessage('Fetching prices in background...')

    def on_price_progress(self, done, total):
        pct = int(done/total*100) if total>0 else 0
        self.progress.setValue(pct)

    def on_price_finished(self, prices):
        self.progress.setValue(100)
        self.progress.setVisible(False)
        self.status.showMessage(f'Price fetch complete: {len(prices)} prices')
        # find missing tickers
        tickers = list(self.model.mapping['Ticker'].dropna().unique())
        missing = [t for t in tickers if t not in prices]
        if missing:
            dlg = ManualPriceDialog(self, missing)
            if dlg.exec_() == QtWidgets.QDialog.Accepted:
                for t,pr in dlg.get_prices().items():
                    if not math.isnan(pr):
                        self.model.prices[t]=pr
        self.refresh_views()

    # validation
    def validate(self):
        issues = self.model.validate()
        self.error_list.clear()
        if not issues:
            self.error_list.addItem('No validation issues')
            QtWidgets.QMessageBox.information(self, 'Valid', 'No validation issues found')
            return
        for idx,msg in issues:
            self.error_list.addItem(f'Row {idx}: {msg}')
        # auto prompt to fill missing tickers
        missing_companies = set()
        for idx,msg in issues:
            if 'Missing ticker mapping' in msg:
                comp = str(self.model.txn.at[idx,'Company'])
                missing_companies.add(comp)
        if missing_companies:
            if QtWidgets.QMessageBox.question(self, 'Fill tickers', f'{len(missing_companies)} companies missing tickers. Open mapping editor?')==QtWidgets.QMessageBox.StandardButton.Yes:
                dlg = MappingDialog(self, companies=list(missing_companies), model=self.model)
                if dlg.exec_()==QtWidgets.QDialog.Accepted:
                    self.refresh_views()

    def refresh_views(self):
        self.txn_model.setDataFrame(self.model.txn.fillna(''))
        holdings, realised, divs = self.model.compute_holdings()
        self.holdings_model.setDataFrame(holdings.fillna(''))
        self.status.showMessage(f'{len(self.model.txn)} txns, {len(holdings)} holdings')

    # holdings plot
    def on_holding_double(self, index):
        idx = index.row()
        comp = self.holdings_model._df.iloc[idx]['Company']
        self.show_history_for(comp)

    def plot_selected_holding(self):
        sel = self.holdings_view.selectionModel().selectedRows()
        if not sel:
            QtWidgets.QMessageBox.warning(self, 'Select', 'Select a holding')
            return
        comp = self.holdings_model._df.iloc[sel[0].row()]['Company']
        self.show_history_for(comp)

    def show_history_for(self, company):
        ticker = self.model.get_ticker(company)
        if not ticker:
            QtWidgets.QMessageBox.warning(self, 'No Ticker', 'No ticker for this company')
            return
        try:
            hist = yf.download(ticker, period='2y', progress=False)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, 'Error', f'yfinance error: {e}')
            return
        if hist.empty:
            QtWidgets.QMessageBox.information(self, 'No Data', 'No historical price data')
            return
        dlg = PlotDialog(self, ticker, hist)
        dlg.exec_()

    def show_adjustments(self):
        if not self.model.adjustments:
            QtWidgets.QMessageBox.information(self, 'Adjustments', 'No adjustments recorded')
            return
        dlg = AdjustmentsDialog(self, self.model.adjustments)
        dlg.exec_()

# Dialogs
class TxnDialog(QtWidgets.QDialog):
    def __init__(self, parent, txn=None):
        super().__init__(parent)
        self.setWindowTitle('Transaction')
        self.txn = txn
        self.model = parent.model
        self._build()
        if txn:
            self._load(txn)

    def _build(self):
        layout = QtWidgets.QFormLayout(self)
        self.company = QtWidgets.QLineEdit()
        self.date = QtWidgets.QDateEdit(QtCore.QDate.currentDate())
        self.date.setCalendarPopup(True)
        self.type = QtWidgets.QComboBox(); self.type.addItems(VALID_TYPES)
        self.units = QtWidgets.QLineEdit()
        self.price = QtWidgets.QLineEdit()
        self.ticker = QtWidgets.QLineEdit()
        self.ratio = QtWidgets.QLineEdit()
        self.notes = QtWidgets.QLineEdit()
        layout.addRow('Company', self.company)
        layout.addRow('Date', self.date)
        layout.addRow('Type', self.type)
        layout.addRow('Units', self.units)
        layout.addRow('Price', self.price)
        layout.addRow('Ticker', self.ticker)
        layout.addRow('Ratio', self.ratio)
        layout.addRow('Notes', self.notes)
        # suggestion helpers: dropdown of known tickers and lookup button
        sugg_layout = QtWidgets.QHBoxLayout()
        self.sugg_cb = QtWidgets.QComboBox(); self.sugg_cb.setEditable(True)
        # populate suggestions from mapping
        known = list(self.model.mapping['Ticker'].dropna().unique()) if not self.model.mapping.empty else []
        self.sugg_cb.addItems([str(x) for x in known])
        btn_lookup = QtWidgets.QPushButton('Lookup Online')
        btn_lookup.clicked.connect(self.lookup_online)
        sugg_layout.addWidget(self.sugg_cb); sugg_layout.addWidget(btn_lookup)
        layout.addRow('Ticker suggestions', sugg_layout)

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok|QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.on_accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def lookup_online(self):
        # naive attempt: try downloading a single-day history for the entered string
        candidate = self.company.text().strip() or self.sugg_cb.currentText().strip()
        if not candidate:
            QtWidgets.QMessageBox.information(self, 'Lookup', 'Enter company or ticker to lookup')
            return
        try:
            data = yf.download(candidate, period='1d', progress=False)
            if not data.empty:
                # assume candidate is a valid ticker
                self.sugg_cb.setCurrentText(candidate)
                QtWidgets.QMessageBox.information(self, 'Lookup', f'Found data for {candidate}; suggested as ticker')
            else:
                QtWidgets.QMessageBox.information(self, 'Lookup', f'No data found for {candidate}')
        except Exception:
            QtWidgets.QMessageBox.information(self, 'Lookup', f'Online lookup failed for {candidate}')

    def _load(self, txn):
        self.company.setText(str(txn.get('Company','')))
        if txn.get('Date') is not None:
            d = pd.to_datetime(txn.get('Date'))
            self.date.setDate(QtCore.QDate(d.year,d.month,d.day))
        self.type.setCurrentText(str(txn.get('Type','Buy')))
        self.units.setText(str(txn.get('Units','')))
        self.price.setText(str(txn.get('Price','')))
        self.ticker.setText(str(txn.get('Ticker','')))
        self.ratio.setText(str(txn.get('Ratio','')))
        self.notes.setText(str(txn.get('Notes','')))

    def on_accept(self):
        comp = self.company.text().strip()
        typ = self.type.currentText()
        try:
            units = float(self.units.text()) if self.units.text().strip()!='' else np.nan
        except Exception:
            QtWidgets.QMessageBox.critical(self, 'Invalid', 'Units invalid')
            return
        try:
            price = float(self.price.text()) if self.price.text().strip()!='' else np.nan
        except Exception:
            QtWidgets.QMessageBox.critical(self, 'Invalid', 'Price invalid')
            return
        ticker = self.sugg_cb.currentText().strip() or self.ticker.text().strip()
        try:
            ratio = float(self.ratio.text()) if self.ratio.text().strip()!='' else np.nan
        except Exception:
            ratio = np.nan
        asset = self.model.get_asset_type(comp)
        # integer enforcement for stocks
        if asset=='Stock' and not is_integer_like(units) and typ in ('Buy','Sell'):
            QtWidgets.QMessageBox.critical(self, 'Invalid', 'Stocks require integer units')
            return
        # prevent shorts by simulation
        if typ=='Sell':
            as_of = self.date.date().toPyDate()
            tmp = self.model.txn.copy()
            newrow = {'Company':comp,'Date':as_of.strftime('%Y-%m-%d'),'Type':typ,'Units':units,'Price':price,'Ticker':ticker,'Ratio':ratio,'Notes':self.notes.text()}
            tmp = pd.concat([tmp, pd.DataFrame([newrow])], ignore_index=True, sort=False)
            tmp['Date'] = pd.to_datetime(tmp['Date'], errors='coerce')
            tmp_model = PortfolioModel(); tmp_model.txn = tmp; tmp_model.mapping = self.model.mapping
            holdings,_,_ = tmp_model.compute_holdings(as_of=as_of)
            hr = holdings[holdings['Company']==comp]
            held = hr['Units'].iloc[0] if not hr.empty else 0
            if units>held+1e-9:
                QtWidgets.QMessageBox.critical(self,'Invalid','Sell would exceed holdings (shorts not allowed)')
                return
        # all ok
        row = {'Company':comp,'Date':self.date.date().toString('yyyy-MM-dd'),'Type':typ,'Units':int(round(units)) if asset=='Stock' and not math.isnan(units) else units,'Price':price,'Ticker':ticker,'Ratio':ratio,'Notes':self.notes.text()}
        # if Split, create an Adjustment row plus signal to record snapshots later in model.compute_holdings
        if typ=='Split' and not math.isnan(ratio) and ratio>0:
            adj = {'Company':comp,'Date':self.date.date().toString('yyyy-MM-dd'),'Type':'Adjustment','Units':np.nan,'Price':np.nan,'Ticker':ticker,'Ratio':ratio,'Notes':'Split adjustment recorded'}
            self.result_rows = (row, adj)
        else:
            self.result_rows = (row,)
        self.accept()

    def get_result(self):
        return self.result_rows

class ManualPriceDialog(QtWidgets.QDialog):
    def __init__(self, parent, tickers):
        super().__init__(parent)
        self.setWindowTitle('Manual Price Entry')
        self.tickers = tickers
        self.prices = {}
        layout = QtWidgets.QFormLayout(self)
        self.edits = {}
        for t in tickers:
            e = QtWidgets.QLineEdit()
            layout.addRow(t, e)
            self.edits[t]=e
        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok|QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    def get_prices(self):
        out = {}
        for t,e in self.edits.items():
            try:
                v = float(e.text())
            except Exception:
                v = np.nan
            out[t]=v
        return out

class MappingDialog(QtWidgets.QDialog):
    def __init__(self, parent, companies=None, model=None):
        super().__init__(parent)
        self.setWindowTitle('Mapping Editor (Suggestions)')
        self.model = model
        layout = QtWidgets.QVBoxLayout(self)
        self.table = QtWidgets.QTableWidget(0,4)
        self.table.setHorizontalHeaderLabels(MAPPING_COLS)
        layout.addWidget(self.table)
        if companies:
            for c in companies:
                row = self.table.rowCount(); self.table.insertRow(row)
                self.table.setItem(row,0, QtWidgets.QTableWidgetItem(c))
                self.table.setItem(row,1, QtWidgets.QTableWidgetItem(''))
                self.table.setItem(row,2, QtWidgets.QTableWidgetItem(''))
                self.table.setItem(row,3, QtWidgets.QTableWidgetItem('Stock'))
        # suggestion controls
        sugg_layout = QtWidgets.QHBoxLayout()
        self.search_input = QtWidgets.QLineEdit()
        self.search_input.setPlaceholderText('Type company name to search local mapping')
        btn_local = QtWidgets.QPushButton('Suggest Local')
        btn_local.clicked.connect(self.suggest_local)
        btn_online = QtWidgets.QPushButton('Try Online Lookup')
        btn_online.clicked.connect(self.suggest_online)
        sugg_layout.addWidget(self.search_input); sugg_layout.addWidget(btn_local); sugg_layout.addWidget(btn_online)
        layout.addLayout(sugg_layout)

        btns = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok|QtWidgets.QDialogButtonBox.Cancel)
        btns.accepted.connect(self.on_ok); btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def suggest_local(self):
        q = self.search_input.text().strip().lower()
        if not q:
            QtWidgets.QMessageBox.information(self, 'Suggest', 'Enter search term')
            return
        matches = self.model.mapping[self.model.mapping['Company'].str.lower().str.contains(q, na=False)]
        if matches.empty:
            QtWidgets.QMessageBox.information(self, 'Suggest', 'No local matches found')
            return
        # populate table with matches
        for _, r in matches.iterrows():
            row = self.table.rowCount(); self.table.insertRow(row)
            self.table.setItem(row,0, QtWidgets.QTableWidgetItem(str(r['Company'])))
            self.table.setItem(row,1, QtWidgets.QTableWidgetItem(str(r['Ticker'])))
            self.table.setItem(row,2, QtWidgets.QTableWidgetItem(str(r.get('Industry',''))))
            self.table.setItem(row,3, QtWidgets.QTableWidgetItem(str(r.get('AssetType','Stock'))))

    def suggest_online(self):
        q = self.search_input.text().strip()
        if not q:
            QtWidgets.QMessageBox.information(self, 'Lookup', 'Enter company name or ticker to try online')
            return
        try:
            # naive check: try treat q as ticker and download 1d history
            data = yf.download(q, period='1d', progress=False)
            if not data.empty:
                row = self.table.rowCount(); self.table.insertRow(row)
                self.table.setItem(row,0, QtWidgets.QTableWidgetItem(q))
                self.table.setItem(row,1, QtWidgets.QTableWidgetItem(q))
                self.table.setItem(row,2, QtWidgets.QTableWidgetItem(''))
                self.table.setItem(row,3, QtWidgets.QTableWidgetItem('Stock'))
                QtWidgets.QMessageBox.information(self, 'Lookup', f'Found data for {q}. Added suggestion')
            else:
                QtWidgets.QMessageBox.information(self, 'Lookup', f'No data for {q}')
        except Exception:
            QtWidgets.QMessageBox.information(self, 'Lookup', f'Online lookup failed for {q}')

    def on_ok(self):
        rows = []
        for r in range(self.table.rowCount()):
            comp = self.table.item(r,0).text() if self.table.item(r,0) else ''
            tick = self.table.item(r,1).text() if self.table.item(r,1) else ''
            ind = self.table.item(r,2).text() if self.table.item(r,2) else ''
            at = self.table.item(r,3).text() if self.table.item(r,3) else 'Stock'
            if at not in VALID_ASSET_TYPES:
                at = 'Stock'
            rows.append({'Company':comp,'Ticker':tick,'Industry':ind,'AssetType':at})
        self.model.mapping = pd.DataFrame(rows)[MAPPING_COLS]
        self.accept()

class PlotDialog(QtWidgets.QDialog):
    def __init__(self, parent, ticker, hist_df):
        super().__init__(parent)
        self.setWindowTitle(f'History: {ticker}')
        layout = QtWidgets.QVBoxLayout(self)
        fig = Figure(figsize=(8,4))
        self.canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)
        ax.plot(hist_df.index, hist_df['Adj Close'])
        ax.set_title(ticker)
        ax.set_xlabel('Date')
        ax.set_ylabel('Adj Close')
        layout.addWidget(self.canvas)
        btn = QtWidgets.QPushButton('Close'); btn.clicked.connect(self.accept)
        layout.addWidget(btn)

class AdjustmentsDialog(QtWidgets.QDialog):
    def __init__(self, parent, adjustments):
        super().__init__(parent)
        self.setWindowTitle('Adjustments (Pre/Post snapshots)')
        layout = QtWidgets.QVBoxLayout(self)
        self.list = QtWidgets.QListWidget()
        for a in adjustments:
            item = QtWidgets.QListWidgetItem(f"{a['Date']} - {a['Company']} ratio={a['Ratio']}")
            item.setData(QtCore.Qt.UserRole, a)
            self.list.addItem(item)
        self.list.currentItemChanged.connect(self.on_select)
        layout.addWidget(self.list)
        self.text = QtWidgets.QPlainTextEdit()
        self.text.setReadOnly(True)
        layout.addWidget(self.text)
        btn = QtWidgets.QPushButton('Close'); btn.clicked.connect(self.accept)
        layout.addWidget(btn)

    def on_select(self, cur, prev=None):
        if not cur:
            self.text.setPlainText('')
            return
        a = cur.data(QtCore.Qt.UserRole)
        pretty = json.dumps(a, indent=2)
        self.text.setPlainText(pretty)

# -------------------- Helpers --------------------

def safe_float(x):
    try:
        return float(x)
    except Exception:
        return np.nan

def is_integer_like(x):
    try:
        f = float(x)
        return abs(f - round(f)) < 1e-9
    except Exception:
        return False

# -------------------- Main --------------------

def main():
    app = QtWidgets.QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()


