
from datetime import date, datetime, timedelta
import sys
import time

import pandas as pd
import pytz
import talib


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
import backtrader as bt
from BT_relative_performance import MRPIndicator
from exp_ln_reg_Momentum import Momentum
from realsupertrend import SuperTrend  # custum indicator

# from backtrader.indicators.smma import SmoothedMovingAverage
from SCtrade_list import trade_list  # custum analyzer

# from Baranalysis1 import BarAnalysis
from settings import SCREENER_OUTPUT_FOLDER_PATH, TICKER_CSV_DATA_FOLDER_PATH

# from limited_test_report import LimitedTestReport  # custum analyzer
from tabulate import tabulate
import yfinance as yf


print('TB')


class firstStrategy(bt.Strategy):
    params = (("sma10", 40), ("oneplot", True))

    def __init__(self):


        self.inds = dict()
        index_data = pd.read_csv("/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv")

        for i, d in enumerate(self.datas):

            self.inds[d] = dict()
            #self.inds[d]["ST"] = SuperTrend(period=10, multiplier=3)
            # self.inds[d]["ENGULFING"] = bt.talib.CDLENGULFING(d.open, d.high, d.low, d.close)
            ##self.inds[d]["EVENINGSTAR"] = bt.talib.CDLEVENINGSTAR(d.open, d.high, d.low, d.close, penetration=0.3)
            ##self.inds[d]["MORNINGSTAR"] = bt.talib.CDLMORNINGSTAR(d.open, d.high, d.low, d.close, penetration=0.3)
            # self.inds[d]["PIERCING"] = bt.talib.CDLPIERCING(d.open, d.high, d.low, d.close)
            # self.inds[d]["HANGINGMAN"] = bt.talib.CDLHANGINGMAN(d.open, d.high, d.low, d.close)
            # self.inds[d]["3BLACKCROWS"] = bt.talib.CDL3BLACKCROWS(d.open, d.high, d.low, d.close)
            # self.inds[d]["3WHITESOLDIERS"] = bt.talib.CDL3WHITESOLDIERS(d.open, d.high, d.low, d.close)
            # self.inds[d]["3STARSINSOUTH"] = bt.talib.CDL3STARSINSOUTH(d.open, d.high, d.low, d.close)
            # self.inds[d]["3OUTSIDE"] = bt.talib.CDL3OUTSIDE(d.open, d.high, d.low, d.close)
            # self.inds[d]["BELTHOLD"] = bt.talib.CDLBELTHOLD(d.open, d.high, d.low, d.close)
            # self.inds[d]["BREAKAWAY"] = bt.talib.CDLBREAKAWAY(d.open, d.high, d.low, d.close)
            ##self.inds[d]["EVENINGSTAR"] = bt.talib.CDLEVENINGSTAR(d.open, d.high, d.low, d.close, penetration=0)
            # self.inds[d]["HAMMER"] = bt.talib.CDLHAMMER(d.open, d.high, d.low, d.close)
            # self.inds[d]["INVERTEDHAMMER"] = bt.talib.CDLINVERTEDHAMMER(d.open, d.high, d.low, d.close)
            # self.inds[d]["MATCHINGLOW"] = bt.talib.CDLMATCHINGLOW(d.open, d.high, d.low, d.close)
            # self.inds[d]["MORNINGDOJISTAR"] = bt.talib.CDLMORNINGDOJISTAR(d.open, d.high, d.low, d.close, penetration=0.3)
            # self.inds[d]["RISEFALL3METHODS"] = bt.talib.CDLRISEFALL3METHODS(d.open, d.high, d.low, d.close)
            # self.inds[d]["SEPARATINGLINES"] = bt.talib.CDLSEPARATINGLINES(d.open, d.high, d.low, d.close)
            # self.inds[d]["STICKSANDWICH"] = bt.talib.CDLSTICKSANDWICH(d.open, d.high, d.low, d.close)
            # self.inds[d]["TAKURI"] = bt.talib.CDLTAKURI(d.open, d.high, d.low, d.close)
            # self.inds[d]["UNIQUE3RIVER"] = bt.talib.CDLUNIQUE3RIVER(d.open, d.high, d.low, d.close)
            # self.inds[d]["XSIDEGAP3METHODS"] = bt.talib.CDLXSIDEGAP3METHODS(d.open, d.high, d.low, d.close)
            # self.inds[d]["EVENINGDOJISTAR"] = bt.talib.CDLEVENINGDOJISTAR(d.open, d.high, d.low, d.close, penetration=0.3)
            #self.inds[d]["ST"] = SuperTrend(period=10, multiplier=3)
            #self.inds[d]["SMA_SLOW"] = bt.talib.SMA(d.close, timeperiod=40) #bt.indicators.SMMA(
            #self.inds[d]["EMA_FAST"] = bt.talib.EMA(d.close, timeperiod=10)
            self.inds[d]["CCI"]=bt.talib.CCI(d.high, d.low, d.close, timeperiod=34)
            self.inds[d]["CCImovavg"] = bt.talib.SMA(self.inds[d]["CCI"], timeperiod=14)
            self.inds[d]["ST"] = SuperTrend(period=10, multiplier=3)
            self.inds[d]["ADX"] = bt.indicators.AverageDirectionalMovementIndex(d, period=14, plotname="ADX", plot=False)
            self.inds[d]["DIind"] = bt.indicators.DirectionalIndicator(d, period=14, plotname="-+DI", plot=False)
            self.inds[d]["Exp_lin_reg"] = Momentum(d.close, period=14, subplot=False) #18-90 days, 12-60 days  9wk
            self.inds[d]["Exp_lin_regslow"] = Momentum(d.close, period=50, subplot=False)   # 18wk
            #self.inds[d]["SMA_VOL"] = bt.talib.SMA(d.volume, timeperiod=12)

            #stock_data = d.Close
            #index_data=index_data["Close"]

            #self.inds[d]["MRP"] = MRPIndicator(stock_data,index_data,window=13)

            if i > 0:  # Check we are not on the first loop of data feed:
                if self.p.oneplot == True:
                    d.plotinfo.plotmaster = self.datas[0]

    def next(self):
        for i, d in enumerate(self.datas):
            dt, dn = self.datetime.date(), d._name
            pos = self.getposition(d).size
            # print(len(d))
            yesterday = len(d) == (d.buflen() - 1)
            # self.position(d):  # no market / no orders
            if yesterday and not pos:
                if (
                    #d.close[0] > d.close[-1]
                    #self.inds[d]["ST"][0] < d.close[0]
                    #self.inds[d]["EMA_FAST"] <self.inds[d]["SMA_SLOW"]
                    self.inds[d]["CCI"] > 0  #or self.inds[d]["CCI"] > self.inds[d]["CCImovavg"]
                    and self.inds[d]["ST"][0] < d.close[0]
                    and self.inds[d]["DIind"].plusDI > self.inds[d]["DIind"].minusDI
                    and self.inds[d]["ADX"][0] > 20
                    and (self.inds[d]["Exp_lin_reg"][0] > 40  or self.inds[d]["Exp_lin_regslow"] > 30)
                    #and self.inds[d]["MRP"] >0
                    #self.inds[d]["SMA_VOL"]>1
                    # and (self.inds[d]["ENGULFING"] == 100
                    # or self.inds[d]["MORNINGSTAR"]== 100
                    # or self.inds[d]["PIERCING"] == 100
                    # or self.inds[d]["3WHITESOLDIERS"] == 100
                    # or self.inds[d]["CDL3STARSINSOUTH"]== 100
                    # or self.inds[d]["CDL3OUTSIDE"]== 100
                    # or self.inds[d]["CDLBELTHOLD"]== 100
                    # or self.inds[d]["CDLBREAKAWAY"] == 100
                    # or self.inds[d]["CDLINVERTEDHAMMER"]== 100
                    # or self.inds[d]["CDLRISEFALL3METHODS"] == 100
                    # or self.inds[d]["CDLSTICKSANDWICH"] == 100)
                    # or self.inds[d]["MORNINGDOJISTAR"]== 100
                    # and self.macdH[0] > 0
                ):
                    self.buy(data=d, size=1)
                else:
                    if (
                        d.close[0] > 1
                        #d.close[0] < d.close[-1]
                        #self.inds[d]["ST"][0] > d.close[0]
                        #d.close[0]>self.inds[d]["EMA_FAST"]>self.inds[d]["SMA_SLOW"]
                        and self.inds[d]["CCI"] < 0 #or self.inds[d]["CCI"] < self.inds[d]["CCImovavg"]
                        #and self.inds[d]["ST"][0] > d.close[0]
                        #self.inds[d]["SMA_VOL"]<1
                        # and (self.inds[d]["ENGULFING"] == -100
                        # or self.inds[d]["EVENINGSTAR"]== -100
                        # or self.inds[d]["PIERCING"] == -100
                        # or self.inds[d]["HANGINGMAN"] == -100
                        # or self.inds[d]["3BLACKCROWS"] == -100
                        # or self.inds[d]["CDLBREAKAWAY"] -100
                        # or self.inds[d]["EVENINGDOJISTAR"]== -100
                        # or self.inds[d]["CDLMATCHINGLOW"]== -100
                        # or self.inds[d]["CDLRISEFALL3METHODS"] ==-100
                        # or self.inds[d]["CDLSTICKSANDWICH"] ==-100
                        # or self.inds[d]["CDL3OUTSIDE"]== -100
                        # or self.inds[d]["CDLSEPARATINGLINES"]== -100
                        # or self.inds[d]["CDLTAKURI"]== -100
                        # or self.inds[d]["CDLXSIDEGAP3METHODS"]== -100)
                    ):
                        self.sell(data=d, size=1)

    '''
    def notify_trade(self, trade):
        dt = self.data.datetime.date()
        if trade.isopen:
            print(
                "{} {} Opened: Price".format(
                    dt,
                    trade.data._name,
                )
            )
    '''
    """
    def next(self):
        if len(self.data) == (self.data.buflen()-1) and not self.position:
            if (
                #self.ADX[0] > 0
                d.close > 1000
                #and self.macdH[0] > 0
            ):
                self.buy()
            else:
                if(
                    #self.ADX[0] > 28
                    #and self.macdH[0] < 0
                    d.close < 1000
                    ):
                    self.sell()
                else:
                    if (
                        self.ADX[0] < 28
                        and self.RSI[0] > 80
                    ):
                        self.sell()
    """


"""
def printTradeAnalysis(
    analyzer,
):
    total_open = analyzer.total.open
    total_closed = analyzer.total.closed
    total_won = analyzer.won.total
    total_lost = analyzer.lost.total
    win_streak = analyzer.streak.won.longest
    lose_streak = analyzer.streak.lost.longest
    pnl_net = round(analyzer.pnl.net.total, 2)
    strike_rate = round((total_won / total_closed) * 100, 2)
    # Designate the rows
    h1 = ["Total Open", "Total Closed", "Total Won", "Total Lost"]
    h2 = ["Strike Rate", "Win Streak", "Losing Streak", "PnL Net"]
    r1 = [total_open, total_closed, total_won, total_lost]
    r2 = [strike_rate, win_streak, lose_streak, pnl_net]
    # Check which set of headers is the longest.
    if len(h1) > len(h2):
        header_length = len(h1)
    else:
        header_length = len(h2)
    # Print the rows
    print_list = [h1, r1, h2, r2]
    row_format = "{:<15}" * (header_length + 1)
    print("Trade Analysis Results:")
    for row in print_list:
        print(row_format.format("", *row))

len(d) == (d.buflen()-1) and

def printSQN(analyzer):
    sqn = round(analyzer.sqn, 2)
    print("SQN: {}".format(sqn))
"""


def get_stock_symbols_from_csv(csv_file_path):
    symbols_df = pd.read_csv(csv_file_path)
    symbols_column_name = "Symbol"
    symbols_list = list(symbols_df[symbols_column_name].unique())
    return symbols_list


cerebro = bt.Cerebro()

startcash = 1000000000



# symbol_list = ["UTIAMC.NS","GLAND.NS","WIPRO.NS", "KEC.NS", "TATASTEEL.NS", "RCOM.NS",]
symbol_list = get_stock_symbols_from_csv("/home/rizpython236/BT5/symbol_list.csv")[:]
valid_tickers_list = get_stock_symbols_from_csv("/home/rizpython236/BT5/screener-outputs/valid_tickers.csv")

IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
END_DATE = datetime.now(IST_TIMEZONE).replace(
    hour=0, minute=0, second=0, microsecond=0
) - timedelta(days=0)
TIME_DELTA_DAYS = 10
START_DATE = END_DATE - timedelta(days=TIME_DELTA_DAYS)

"""
dataj = yf.download("^NSEI", start=START_DATE.replace(tzinfo=None), end=END_DATE.replace(tzinfo=None))
dataj.to_csv("./{}.csv".format("^NSEI"))
datapath = ('./^NSEI.csv')
dataframe = pd.read_csv(datapath,
                            skiprows=0,
                            header=0,
                            parse_dates=True,
                            index_col=0
                            )
datak = bt.feeds.PandasData(dataname=dataframe)
cerebro.adddata(datak, name="NIFTY")
"""

"""
data = bt.feeds.YahooFinanceData(
        dataname="WIPRO.NS",
        timeframe=bt.TimeFrame.Days,
        fromdate=START_DATE.replace(tzinfo=None),
        todate=END_DATE.replace(tzinfo=None),
        compression=1,
        buffered=True,
        adjclose=True,
        decimals=2,
        plot=True,
)
"""
for symbol in symbol_list:

    if symbol not in valid_tickers_list:
        continue

    symbol_csv_file_path = TICKER_CSV_DATA_FOLDER_PATH + "/" + symbol + ".csv"
    data = bt.feeds.YahooFinanceCSVData(dataname=symbol_csv_file_path)
    '''
    data = bt.feeds.YahooFinanceData(
        dataname=symbol,
        timeframe=bt.TimeFrame.Days,
        fromdate=date.today()
        - timedelta(
            days=7
        ),  # datetime(2020, 1, 1),           #START_DATE.replace(tzinfo=None),
        todate=date.today(),  # datetime(2021, 10, 27),   #END_DATE.replace(tzinfo=None),
        compression=1,
        buffered=True,
        adjclose=True,
        decimals=2,
        plot=False,
    )
    time.sleep(5)
    '''
    cerebro.adddata(data, name=symbol)  # cerebro.adddata(data)

"""
feed = bt.feeds.YahooFinanceData(
    dataname="^NSEI",
    timeframe=bt.TimeFrame.Days,
    fromdate=START_DATE.replace(tzinfo=None),
    todate=END_DATE.replace(tzinfo=None),
    compression=1,
    buffered=True,
    adjclose=True,
    decimals=2,
    plot=False,
)
"""


"""
data3 = bt.feeds.YahooFinanceData(
    dataname= "VINATIORGA.NS",
    timeframe=bt.TimeFrame.Months,
    fromdate=datetime(2012, 1, 1),
    todate=datetime(2021, 8, 15),
    compression =1,
    buffered=True,
    calendar='BSE',
    adjclose =True,
    decimals =2,
    plot=True,
)
"""
"""
data = bt.feeds.Quandl(
    dataname='TSLA',
    timeframe=bt.TimeFrame.Days,
    apikey='QBb7Ym7AFLYZ3CkamXys',
    fromdate = datetime(2010,1,6),
    todate = datetime(2021,2,15),
    buffered= True
    )



Nifty_csv_file = "/home/rizpython236/BT5/ticker-csv-files/^NSEI.csv"
index_data = pd.read_csv(Nifty_csv_file)
# Add index data feed
index_feed = bt.feeds.YahooFinanceCSVData(dataname=index_data) #bt.feeds.PandasData(dataname=index_data, close="Close") #
cerebro.adddata(index_feed,name=Index) #cerebro.adddata(index_feed, name=symbol) #
"""

cerebro.addstrategy(firstStrategy, oneplot=True)
# cerebro = bt.Cerebro()
# cerebro.adddata(data)
# cerebro.adddata(feed)
cerebro.broker.setcash(startcash)
cerebro.addsizer(bt.sizers.FixedSize)
'''
cerebro.broker.setcommission(
    commission=0.000, margin=False
)
'''
cerebro.broker.set_shortcash(True)


# cerebro.addwriter(bt.WriterFile, csv=True, rounding=1)

# cerebro.addobserver(bt.observers.FundValue)
cerebro.addanalyzer(trade_list, _name="trade_list")
# cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name="ta")
# cerebro.addanalyzer(bt.analyzers.Transactions)
# cerebro.addanalyzer(BarAnalysis, _name="bar_data")

results = cerebro.run(tradehistory=True)
firstStrat = results[0]

for strat in results:
    print("=" * 79)
    print(strat.__class__.__name__)

trade_list = results[0].analyzers.trade_list.get_analysis()
print(tabulate(trade_list, headers="keys"))

"""
LimitedTestReport = results[0].analyzers.LimitedTestReport.get_analysis()
print (tabulate(LimitedTestReport, headers="keys"))
"""
portvalue = cerebro.broker.getvalue()
pnl = round(portvalue - startcash, 1)

print("Final Portfolio Value: %.2f" % cerebro.broker.getvalue())
print(
    "Final value is %.2f times the initial investment"
    % (cerebro.broker.getvalue() / startcash)
)
print("P/L: ${}".format(pnl))


"""
bar_data_res = results[0].analyzers.bar_data.get_analysis()
df = pd.DataFrame(bar_data_res)
df.to_csv("bar_data_res.csv")
"""

trade_list = results[0].analyzers.getbyname("trade_list").get_analysis()
df = pd.DataFrame(trade_list)
df=df.sort_values(by='dir')

SCREENER_OUTPUT_FILENAME = "trade_list_Talib_Screener.csv"
TALIB_SCREENER_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + SCREENER_OUTPUT_FILENAME
df.to_csv(TALIB_SCREENER_FILE_PATH, index=False)
print("ALL OVER")
# https://backtest-rookies.com/2017/08/22/backtrader-multiple-data-feeds-indicators/

# cerebro.plot(
#     iplot=False, numfigs=1, volume=False
#)
