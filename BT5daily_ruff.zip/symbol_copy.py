from collections import Counter
import gc
import importlib.util
import os
from pathlib import Path
import re
import sys
import time
import traceback
import zipfile

from github import Github
from github.GithubException import UnknownObjectException

# import types
import pandas as pd
import yfinance as yf

from settings import (
    EXCLUDE_TICKERS_CSV,
)
from telegram_bot import post_telegram_message


def upload_binary_file_to_github(
    token: str,
    repo_name: str,
    local_file_path: str,
    repo_file_path: str,
    commit_message: str,
    branch: str = "main",
):
    """Upload or update a binary file (PDF, Excel, image, etc.) in a GitHub repo.

    Parameters
    ----------
    token : str
        GitHub Personal Access Token
    repo_name : str
        Repository in 'owner/repo' format
    local_file_path : str
        Path to local binary file
    repo_file_path : str
        Path in the GitHub repo
    commit_message : str
        Commit message
    branch : str, optional
        Branch name (default: main)

    """
    g = Github(token)
    repo = g.get_repo(repo_name)

    file_path = Path(local_file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {local_file_path}")

    content = file_path.read_bytes()

    try:
        existing_file = repo.get_contents(repo_file_path, ref=branch)
        """
        repo.delete_file(
            path=existing_file.path,
            message=f"Delete old {repo_file_path}",
            sha=existing_file.sha,
            branch=branch,
        )
        print(f"🗑️ Deleted old file: {repo_file_path}")
        """

    except UnknownObjectException:
        # File does not exist → nothing to delete
        pass

    try:
        # Check if file already exists
        existing_file = repo.get_contents(repo_file_path, ref=branch)

        repo.update_file(
            path=existing_file.path,
            message=commit_message,
            content=content,
            sha=existing_file.sha,
            branch=branch,
        )

        print(f"✅ Updated file: {repo_file_path}")

    except UnknownObjectException:
        # File does not exist → create it

        repo.create_file(
            path=repo_file_path,
            message=commit_message,
            content=content,
            branch=branch,
        )

        print(f"🆕 Created file: {repo_file_path}")


# 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
"""
upload_binary_file_to_github(
    token="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",
    repo_name="rizwan236/Streamlit_backtester",
    local_file_path="/home/rizpython236/BT5/BT5daily_ruff.zip",
    repo_file_path="BT5daily_ruff.zip",
    commit_message="Added file",
    branch="main",
)
"""


def import_user_module(base_dir, module_name):
    """Import a Python module (.py file) from a given base directory."""
    path = Path(base_dir) / f"{module_name}.py"
    if not path.exists():
        print(f"⚠️ Module not found: {path}")
        return None

    # Add base_dir to sys.path temporarily so imports inside the module work
    sys.path.insert(0, str(path.parent))
    try:
        spec = importlib.util.spec_from_file_location(module_name, str(path))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        print(f"✅ Imported: {module_name} from {base_dir}")
        return module
    except Exception as e:
        print(f"❌ Error importing {module_name}: {e}")
        traceback_str = traceback.format_exc()
        print(traceback_str)
        return None
    finally:
        # Clean up sys.path
        sys.path.pop(0)

# import_user_module("/home/rizpython236/BT5", "cleanup")


def fix_dates_fast(csv_folder, output_folderxx=""):
    """Simplified all-in-one version"""
    # Get all CSV files
    files = list(Path(csv_folder).glob("*.csv"))

    # Read all data
    data = {f.stem: pd.read_csv(f, parse_dates=["Date"]) for f in files}

    # Find most common dates
    target_dates = pd.Series(
        list(Counter(tuple(df["Date"]) for df in data.values()).most_common(1)[0][0]))
    print(
        f"Target_dates:-\nMin: {target_dates.min()}\nMax: {target_dates.max()}\nCount: {len(target_dates)}")
    post_telegram_message(
        f"Target_dates:-\nMin: {target_dates.min()}\nMax: {target_dates.max()}\nCount: {len(target_dates)}")

    # Create output folder
    # os.makedirs(output_folder, exist_ok=True)

    # Process each file
    fixed_count = 0
    fixed_names = []

    ticker_date_changes = {}
    # Containers for consolidated unique date changes
    all_added_dates = set()
    all_removed_dates = set()

    for name, df in data.items():
        # Compare current file's dates to target_dates
        current_dates = set(df["Date"])
        target_set = set(target_dates)

        # Identify missing/extra dates for this ticker
        added_dates = target_set - current_dates
        removed_dates = current_dates - target_set

        # if current_dates != target_set:
        # Determine what’s missing and what’s extra
        # added_dates = sorted(target_set - current_dates)
        # removed_dates = sorted(current_dates - target_set)

        # Only process files that don't match target dates
        if set(df["Date"]) != set(target_dates):
            # Single-line alignment and filling
            df_fixed = (df.set_index("Date")           # Set Date as index
                        .reindex(target_dates)         # Align to target dates
                        .bfill().ffill()               # Fill OHLC with bfill+ffill
                        # .assign(Volume=lambda x: x['Volume'].fillna(1) if 'Volume' in x.columns else x)  # Volume = 1
                        .assign(Volume=lambda x: (x["Volume"].fillna(x["Volume"].rolling(window=10, min_periods=10).median().iloc[-1]) if "Volume" in x.columns else x))
                        .reset_index()                 # Make Date a column again
                        .rename(columns={"index": "Date"}))
            fixed_count += 1
            fixed_names.append(name)
            # Update consolidated sets
            all_added_dates.update(added_dates)
            all_removed_dates.update(removed_dates)

            ticker_date_changes[name] = {
                "added": added_dates, "removed": removed_dates}

            df_fixed.to_csv(Path(csv_folder) / f"{name}.csv", index=False)
        else:
            df_fixed = df

        # Save result
        # df_fixed.to_csv(Path(output_folder) / f"{name}.csv", index=False)
        # df_fixed.to_csv(Path(csv_folder) / f"{name}.csv", index=False)

    # --- Consolidated summary ---
    all_added_dates = sorted(all_added_dates)
    all_removed_dates = sorted(all_removed_dates)

    added_ticker_count = len(
        {t for t, d in ticker_date_changes.items() if d["added"]})
    removed_ticker_count = len(
        {t for t, d in ticker_date_changes.items() if d["removed"]})

    consolidated_msg = (
        f"\n📅 Consolidated Summary of Unique Date Adjustments:\n"
        # f"Total Tickers names Fixed: {fixed_names}\n"
        f"Total Tickers names Fixed: {'|'.join(fixed_names)}\n"
        f"Total No: Tickers Fixed: {fixed_count}/{len(files)}\n"
        f"No: Tickers with Added Dates: {added_ticker_count}\n"
        f"No: Tickers with Removed Dates: {removed_ticker_count}\n"
        f"Total No: Unique Added Dates: {len(all_added_dates)}\n"
        f"Total No: Unique Removed Dates: {len(all_removed_dates)}\n"
        # f"Added Dates ({len(all_added_dates)}): {', '.join(map(str, all_added_dates)) if all_added_dates else '-'}\n"
        # f"Removed Dates ({len(all_removed_dates)}): {', '.join(map(str, all_removed_dates)) if all_removed_dates else '-'}\n"
    )

    # print(consolidated_msg)

    print(fixed_names)
    # print(f"Fixed {fixed_count}/{len(files)} files")
    # post_telegram_message(f"Fixed {fixed_count}/{len(files)} files")
    post_telegram_message(consolidated_msg)
    if fixed_count > 150:
        post_telegram_message(
            f"Total Tickers Fixed >150 hence sys exit: {fixed_count}/{len(files)}")
        # sys.exit(1)
    return fixed_count

# fix_dates_fast(csv_folder)


def fix_bse_column_names(filepath):
    import csv
    # Read CSV normally
    # filepath ='/home/rizpython236/BT5/Equity (5).csv'
    # Desired column names
    new_columns = [
        "Security Code",
        "Issuer Name",
        "Security Id",
        "Security Name",
        "Status",
        "Group",
        "Face Value",
        "ISIN No",
        "Instrument",
    ]

    # Read CSV safely
    rows = []
    with open(filepath, encoding="utf-8", errors="ignore") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) == 0:
                continue
            rows.append(row)

    # Create DataFrame
    bse = pd.DataFrame(rows)

    # Drop first row if it matches header
    first_row_values = [str(x).strip() for x in bse.iloc[0].tolist()]
    if all(h in first_row_values for h in new_columns):
        bse = bse.drop(0).reset_index(drop=True)

    # Assign column names
    if len(bse.columns) >= len(new_columns):
        extra_cols = [f"Extra_{i}" for i in range(
            len(bse.columns) - len(new_columns))]
        bse.columns = new_columns + extra_cols
    else:
        bse.columns = new_columns[:len(bse.columns)]

    bse.rename(
        columns={
            "Extra_0": "Industry",
            "Extra_1": "Sector Name",
            "Extra_2": "Industry New Name",
            "Extra_3": "Igroup Name",
            "Extra_4": "ISubgroup Name",
        },
        inplace=True,
    )

    print("✅ Column names replaced and duplicate header removed successfully.")
    print(bse.head())
    bse.to_csv("/home/rizpython236/BT5/Equity.csv", index=False)
    # return bse


filepath = "/home/rizpython236/BT5/Equity5.csv"
# fix_bse_column_names(filepath)


# Specify the paths for the input and output files
input_file_path = "/home/rizpython236/BT5/Final.csv"
output_file_path = "/home/rizpython236/BT5/symbol_list.csv"
exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)

# Load the CSV file into a DataFrame
df = pd.read_csv(input_file_path)
df2 = pd.read_csv(output_file_path)

# print("Final.csv rows:", len(df))
# print("symbol_list.csv rows:", len(df2))


# Check the number of rows in the DataFrame
num_rows = df.shape[0]

if num_rows > 1200:
    # Duplicate and save the file as "symbol.csv"
    # shutil.copy(input_file_path, output_file_path)
    # time.sleep(3)
    # df = pd.read_csv(output_file_path)
    df = df[~df["Symbol"].isin(exclude_tickers["Symbol"])]
    df = df.sort_values(by="Symbol")
    df = df.drop_duplicates()
    df.to_csv(output_file_path, index=False)
    print("EXCLUDE_TICKERS_CSV rows:", len(exclude_tickers))
    print("Final.csv rows:", len(df))
    print("symbol_list.csv rows:", len(df2))
    # shutil.copy(input_file_path, output_file_path)
    print(f"✅Duplicated {input_file_path} as {output_file_path}")
else:
    print(f"❌The file {input_file_path} does NOT have more than 1500 rows.")


def NSE_BSE_symbol_name_df():
    bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
    datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")
    # print(bse.columns)
    # print(datanse.columns)
    # gg
    bse.drop(
        columns=[
            # "Group",
            "Face Value",
            # "ISIN No",
            "Issuer Name",
            "Industry",
            "Instrument",
            "Sector Name",
            "Industry New Name",
            "Igroup Name",
            "ISubgroup Name",
        ],
        inplace=True, errors="ignore",
    )
    bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
    bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
    # bse.rename(columns={"ISIN No": "ISIN No BSE"}, inplace=True)
    # print(bse)
    datanse.drop(
        columns=[
            " SERIES",
            " DATE OF LISTING",
            " PAID UP VALUE",
            " MARKET LOT",
            # " ISIN NUMBER",
            " FACE VALUE",
        ],
        inplace=True,
    )
    # print(datanse)
    # datanse.rename(columns={" ISIN NUMBER": "ISIN No NSE"}, inplace=True)
    datansebse = pd.merge(datanse, bse, left_on=[" ISIN NUMBER"], right_on=[
                          "ISIN No"], how="right")
    common_symbols = bse[bse["ISIN No"].isin(
        datanse[" ISIN NUMBER"])]  # common isin
    # common_symbols = bse[bse["SYMBOL"].isin(datanse["SYMBOL"])]
    # print(len(common_symbols))
    Notcommon_symbols = bse[~bse["ISIN No"].isin(common_symbols["ISIN No"])]
    # print(len(Notcommon_symbols))

    def add_suffix_to_column(df, column_name, suffix):
        # Load the csv file into a Pandas DataFrame
        # df = pd.read_csv(file_name)
        # df = Dffile  # pd.read_csv(file_name)
        # Modify the specified column in-place
        df[column_name] = df[column_name].apply(lambda x: x + suffix)
        return df

    add_suffix_to_column(bse, "SYMBOL", ".BO")
    add_suffix_to_column(datanse, "SYMBOL", ".NS")
    result = pd.concat([bse, datanse], axis=0, ignore_index=True)

    # Replace variations of Ltd / Limited with empty string
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(consultancy|consultant)\b", "“Consult”", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(INDUSTRIES|INDUSTRY)\b", "IND.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(infrastructure)\b", "Infra.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(automobile|automobiles)\b", "Auto.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(and)\b", "&", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(company)\b", "Co.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(services|service)\b", "Serv.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(technologies|technology)\b", "Tech.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(corporation)\b", "Corp.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(international)\b", "int'l.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(engineering)\b", "Engr.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(enterprises|enterprise)\b", "Ent.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(financial|financials)\b", "fin.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(systems|system)\b", "Sys.", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\b(securities)\b", "SEC.", regex=True, case=False,
    ).str.strip()

    # only if they appear at the end
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\s+(Ltd|Limited)$", "", regex=True, case=False,
    ).str.strip()
    result["NAME OF COMPANY"] = result["NAME OF COMPANY"].str.replace(
        r"\s+(INDIA)$", "", regex=True, case=False,
    ).str.strip()

    df = result
    # Combine all names into one string
    all_text = " ".join(df["NAME OF COMPANY"])

    # Split into words, remove punctuation, and normalize case
    words = re.findall(r"\b\w+\b", all_text.lower())

    # Count word frequencies
    word_counts = Counter(words)

    # Get top 50
    top_50 = word_counts.most_common(50)

    # Print nicely
    for word, count in top_50:
        # print(f"{word}: {count}")
        1 + 1

    # print(result)
    return result

# NSE_BSE_symbol_name_df()


sys.path.append(
    "/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.9/site-packages/")


def update_exclude_list(exclude_file="/home/rizpython236/BT5/exclude_tickers.csv"):
    """Update exclude_tickers.csv based on latest Yahoo Finance data.
    Keeps a symbol in the exclude list if:
      - More than 1 row of data is returned
      - Latest close < 15
      - Symbol != '^INDIAVIX'
      - Latest volume is not NaN
    Otherwise, removes it from the exclude list.
    """
    print("update_exclude_list function Started")
    file_path = "/home/rizpython236/BT5/exclude_tickersmanual.csv"
    # Read only the headers
    df = pd.read_csv(file_path)
    # Create an empty DataFrame with same columns
    empty_df = pd.DataFrame(columns=df.columns)
    # Overwrite the CSV keeping only headers
    empty_df.to_csv(file_path, index=False)
    print(
        f"Cleared all rows from {file_path}, kept only headers: {list(df.columns)}")

    # Ensure file exists
    if not os.path.exists(exclude_file):
        print(f"{exclude_file} does not exist. Creating an empty file.")
        pd.DataFrame(columns=["Symbol"]).to_csv(exclude_file, index=False)

    # Load exclude list
    df_exclude = pd.read_csv(exclude_file)
    df_exclude = df_exclude.drop_duplicates(subset=["Symbol"])

    if "Symbol" not in df_exclude.columns:
        df_exclude = pd.DataFrame(columns=["Symbol"])

    Total = len(df_exclude)
    print(f"{Total} Items in exclude_tickers_csv.")
    updated_symbols = []
    removedlist = []
    errorlist = []
    symbol_len = []
    count = 0

    for symbol in df_exclude["Symbol"].unique():
        count += 1
        # time.sleep(1)
        if count % 250 == 0:
            print(f"Processed {count} tickers. Pausing for 5 minutes...")
            time.sleep(2 * 60)  # Sleep for 15 minutes
        try:
            data = yf.download(symbol, period="5d", interval="1d", progress=False, rounding=True, multi_level_index=False,
                               auto_adjust=True, actions=False, keepna=False, threads=False, back_adjust=True)  # get last few days to be safe

            if len(data) > 2:
                symbol_len.append({"Symbol": symbol, "Len": len(
                    data), "Close": data["Close"].iloc[-1]})

            if (
                len(data) > 2
                and data["Close"].iloc[-1] < 35
                and symbol != "^INDIAVIX"
                and not symbol.startswith("^")
                and not re.search(r"BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP", symbol)
                and not symbol.startswith("TJI_")
                # or pd.isna(data["Volume"].iloc[-1])
                # or pd.notna(data["Volume"].iloc[-1]))
            ):
                # keep in exclude list
                updated_symbols.append(symbol)
                # print(f"No: {count} ,Conditions met to add {symbol} to exclude list.")
            else:
                removedlist.append(symbol)
                # print(f"No: {count} ,Removing {symbol} from exclude list as Conditions NOT met.")
        except Exception as e:
            print(f"Error fetching {symbol}: {e}")
            # keep it if fetch fails

            errorlist.append(symbol)
            # print(f"No: {count} ,Added as Error fetching {symbol} to exclude list.")
            # updated_symbols.append(symbol)
        time.sleep(.2)

    # Save updated exclude list

    print("Number of symbols where conditions meet to ADD:", len(updated_symbols))
    print("Number of symbols REMOVED where conditions did NOT meet:", len(removedlist))
    print("Number of symbols with ERROR so Added:", len(errorlist))

    new_df = pd.DataFrame({"Symbol": updated_symbols})
    # Sort alphabetically A-Z
    new_df = new_df.sort_values("Symbol").reset_index(drop=True)
    # print(new_df)
    if len(new_df) > 1000:
        new_df.to_csv(exclude_file, index=False)
    print(
        f"Updated exclude list with {len(new_df)} items saved to {exclude_file}")

    df = pd.DataFrame(symbol_len)
    filtered_df35 = df.loc[df["Close"] < 35, ["Symbol", "Len"]].dropna()
    print(f"Symbols with Close < 35: ({len(filtered_df35)})")
    post_telegram_message(f"Symbols with Close < 35: ({len(filtered_df35)})")
    # print(filtered_df35)

    # EXCLUDE_TICKERS_manual_CSV1 = "/home/rizpython236/BT5/exclude_tickersmanual.csv"
    # EXCLUDE_TICKERS_manual_CSV = pd.read_csv(
    #    "/home/rizpython236/BT5/exclude_tickersmanual.csv")

    # new_df = pd.DataFrame({"Symbol": updated_symbols})
    # Sort alphabetically A-Z
    # new_df = new_df.sort_values("Symbol").reset_index(drop=True)
    # df_combined = (pd.concat([EXCLUDE_TICKERS_manual_CSV, unique_tickers_with_suffix_df],
    #               ignore_index=True).drop_duplicates(subset="Symbol", keep="first"))
    # df_combined.to_csv(EXCLUDE_TICKERS_manual_CSV1, index=False)

    """
    unique_tickers = (
        set(t.replace(".NS", "").replace(".BO", "") for t in tickers_list)
        - set(t.replace(".NS", "").replace(".BO", "") for t in updated_symbols)
        #- set(t.replace(".NS", "").replace(".BO", "") for t in exclude_list)
        # - set(t.replace('.NS', '').replace('.BO', '') for t in exclude_list)
    )

    # Preserve original suffixes (.NS or .BO)
    unique_tickers_with_suffix = [
        t for t in tickers_list
        if t.replace(".NS", "").replace(".BO", "") in unique_tickers
    ]

    EXCLUDE_TICKERS_manual_CSV1 = "/home/rizpython236/BT5/exclude_tickersmanual.csv"

    # exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)
    EXCLUDE_TICKERS_manual_CSV = pd.read_csv(
        "/home/rizpython236/BT5/exclude_tickersmanual.csv")

    # Convert your list to a DataFrame
    # unique_tickers_with_suffix_df = pd.DataFrame({"Symbol": unique_tickers_with_suffix})

    import random
    # Add 'xxx' at the end of the list
    #unique_tickers_with_suffix.append("xxx")
    # Add 'xxx' + random 3-digit number (e.g., xxx742)
    unique_tickers_with_suffix.append(f"xxx{random.randint(1, 999)}")

    # Create DataFrame from list and sort alphabetically
    unique_tickers_with_suffix_df = (
        pd.DataFrame({"Symbol": unique_tickers_with_suffix})
        #.sort_values(by="Symbol")
        .reset_index(drop=True)
    )

    df_combined = (pd.concat([EXCLUDE_TICKERS_manual_CSV, unique_tickers_with_suffix_df],
                   ignore_index=True).drop_duplicates(subset="Symbol", keep="first"))
    df_combined.to_csv(EXCLUDE_TICKERS_manual_CSV1, index=False)
    # exclude_tickers = df_combined
    # print(
    #    f"EXCLUDE_TICKERS_manual_CSV updated with {len(unique_tickers_with_suffix)} error symbols")
    post_telegram_message(
        f"Error Tickers ({len(unique_tickers_with_suffix)}): {', '.join(sorted(unique_tickers_with_suffix))}\n"
        f"EXCLUDE_TICKERS_manual_CSV updated with error symbols")

    """

# update_exclude_list(exclude_file="/home/rizpython236/BT5/exclude_tickers.csv")


def update_include_tickers(include_file="/home/rizpython236/BT5/include_tickers.csv"):
    """Update exclude_tickers.csv based on latest Yahoo Finance data.
    Keeps a symbol in the exclude list if:
      - More than 1 row of data is returned
      - Latest close < 15
      - Symbol != '^INDIAVIX'
      - Latest volume is not NaN
    Otherwise, removes it from the exclude list.
    """
    print("update_include_tickers function Started")
    # Ensure file exists
    if not os.path.exists(include_file):
        print(f"{include_file} does not exist. Creating an empty file.")
        pd.DataFrame(columns=["Symbol"]).to_csv(include_file, index=False)

    # Load exclude list
    df_include = pd.read_csv(include_file)
    df_include = df_include.drop_duplicates(subset=["Symbol"])
    if "Symbol" not in df_include.columns:
        df_include = pd.DataFrame(columns=["Symbol"])

    Total = len(df_include)
    print(f"{Total} Items in include_file_csv.")
    updated_symbols = []
    removedlist = []
    errorlist = []
    count = 0

    for symbol in df_include["Symbol"].unique():
        count += 1
        # time.sleep(1)
        if count % 250 == 0:
            print(f"Processed {count} tickers. Pausing for 5 minutes...")
            time.sleep(2 * 60)  # Sleep for 15 minutes
        try:
            data = yf.download(symbol, period="5d", interval="1d", progress=False, rounding=True, multi_level_index=False,
                               auto_adjust=True, actions=False, keepna=False, threads=False, back_adjust=True)  # get last few days to be safe
            # print(data)

            if (
                (len(data) > 1
                 and data["Close"].iloc[-1] > 10)
                or symbol == "^INDIAVIX"
                or symbol.startswith("^")
                or re.search(r"BEES|ETF|NIFTY|ICICI|HDFC|KOTAK|SBI|AXIS|SILVER|GOLD|DSP", symbol)
                or symbol.startswith("TJI_")
                # or pd.isna(data["Volume"].iloc[-1]))
            ):
                # keep in exclude list
                updated_symbols.append(symbol)

                # print(f"No: {count} ,Conditions met to add {symbol} {data['Close'].iloc[-1]} to include list.")
            else:
                removedlist.append(symbol)
                print(
                    f"No {count}, Removing {symbol} {data['Close'].iloc[-1]} from include list as Conditions NOT met.")
        except Exception as e:
            print(f"Error fetching {symbol}: {e}")
            # keep it if fetch fails
            errorlist.append(symbol)
            # print(f"No: {count},  Added as Error fetching {symbol} {data['Close'].iloc[-1]} to include list.")
            # updated_symbols.append(symbol)
        time.sleep(.2)

    # Save updated include list

    print("Number of symbols where conditions meet to ADD:", len(updated_symbols))
    print("Number of symbols REMOVED where conditions did NOT meet:", len(removedlist))
    print(removedlist)
    print("Number of symbols with ERROR so Added:", len(errorlist))
    print(errorlist)

    new_df = pd.DataFrame({"Symbol": updated_symbols})
    new_df = new_df.sort_values(by="Symbol").reset_index(drop=True)
    print(new_df)
    new_df.to_csv(include_file, index=False)
    print(f"Updated include list saved to {include_file}")


# update_include_tickers(include_file="/home/rizpython236/BT5/include_tickers.csv")


def manage_zip(mode="zip"):
    source_folder = "/home/rizpython236/BT5/ticker_15yr"
    zip_path = "/home/rizpython236/BT5/screener-outputs/Tickerdata.zip"
    extract_folder = "/home/rizpython236/BT5/ticker_15yr"

    if mode == "zip":
        csv_count = len([f for f in os.listdir(
            source_folder) if f.endswith(".csv")])
        if csv_count > 1300:
            if os.path.exists(zip_path):
                # ✅ Delete the zip file after extraction
                os.remove(zip_path)
                print(f"Deleted zip file {zip_path}")

        # ✅ Create a zip file from the source folder
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_folder):
                for file in files:
                    if file.startswith("TJI_") or file.endswith(".csv"):
                        file_path = os.path.join(root, file)
                        # relative path inside zip
                        arcname = os.path.relpath(file_path, source_folder)
                        zipf.write(file_path, arcname)
        print(f"Zipped contents of {source_folder} → {zip_path}")

    elif mode == "unzip":
        if os.path.exists(zip_path):
            # ✅ Extract back to target folder
            with zipfile.ZipFile(zip_path, "r") as zipf:
                zipf.extractall(extract_folder)
            print(f"Unzipped {zip_path} → {extract_folder}")

            if os.path.exists(zip_path):
                # ✅ Delete the zip file after extraction
                # os.remove(zip_path)
                print(f"Deleted zip file {zip_path}")

    else:
        raise ValueError("mode must be 'zip' or 'unzip'")

# manage_zip(mode="unzip")


#################################


def manage_user_variables(delete_top_n=None, delete_threshold=None, confirm=False):
    """List all user-defined variables sorted by size (descending).
    Options:
      - delete_top_n: deletes the top N largest variables
      - delete_threshold: deletes all variables larger than this threshold
                          (accepts bytes or strings like '1MB', '500KB', '2GB').
      - confirm: if True, ask user confirmation before deletion
    """
    gc.collect()  # force garbage collection

    def format_size(bytes_val):
        """Convert bytes into human-readable KB/MB/GB."""
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if bytes_val < 1024:
                return f"{bytes_val:.2f} {unit}"
            bytes_val /= 1024
        return f"{bytes_val:.2f} PB"

    def parse_size(size_str):
        """Convert string like '1MB', '500KB', '2GB' into bytes."""
        if isinstance(size_str, (int, float)):  # already numeric (bytes)
            return int(size_str)

        size_str = size_str.strip().upper()
        units = [("TB", 1024**4), ("GB", 1024**3),
                 ("MB", 1024**2), ("KB", 1024), ("B", 1)]

        for unit, factor in units:
            if size_str.endswith(unit):
                num = float(size_str.replace(unit, ""))
                return int(num * factor)

        raise ValueError(
            "Invalid size format. Use like '1MB', '500KB', '2GB'.")

    # Collect global variables (ignore dunders, modules, functions)
    all_vars = {
        k: v for k, v in globals().items()
        if not k.startswith("__")
        and not isinstance(v, type(sys))   # exclude imported modules
        and not callable(v)                # exclude functions
    }

    if not all_vars:
        print("No user-defined variables found.")
        return []

    # Get variable sizes
    var_info = []
    for name, val in all_vars.items():
        try:
            size = sys.getsizeof(val)
        except Exception:
            size = 0
        var_info.append((name, type(val).__name__, size))

    # Sort descending by size
    var_info.sort(key=lambda x: x[2], reverse=True)

    # Print table
    print(f"{'Name':<20} | {'Type':<15} | {'Size':<12}")
    print("-" * 55)
    for name, typ, size in var_info:
        print(f"{name:<20} | {typ:<15} | {format_size(size):<12}")

    # --- Deletion logic ---
    to_delete = []

    if delete_top_n is not None:
        to_delete.extend([name for name, _, _ in var_info[:delete_top_n]])

    if delete_threshold is not None:
        threshold_bytes = parse_size(delete_threshold)
        to_delete.extend(
            [name for name, _, size in var_info if size > threshold_bytes])

    to_delete = list(set(to_delete))  # remove duplicates

    if to_delete:
        if confirm:
            # answer = input(f"\n⚠️ About to delete: {to_delete}. Type 'yes' to confirm: ")
            answer = "yes"
            if answer.lower() != "yes":
                print("❌ Deletion cancelled.")
                return var_info

        for var in to_delete:
            del globals()[var]

        print(f"\n✅ Deleted variables: {to_delete}")

    return var_info


# big_list = list(range(2000000))  # ~16 MB
# small_list = list(range(10))     # ~112 B
# text = "hello" * 1000            # ~5 KB


# manage_user_variables(delete_top_n=0,delete_threshold="10MB", confirm=True)
