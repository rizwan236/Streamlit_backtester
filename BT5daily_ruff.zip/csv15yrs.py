import os
import sys
import time

import numpy as np
import pandas as pd
import pytz
from scipy import stats
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
import talib as tb


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39zz/lib/python3.13/site-packages/")
import csv
from datetime import datetime, timedelta
import re
import traceback

from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.dates as mdates

#import mplfinance as mpf
import matplotlib.pyplot as plt

#from statsmodels.tsa.stattools import adfuller
#from functools import lru_cache
#import subprocess
# Upgrade pandas-market-calendars using pip
#subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pandas-market-calendars"])
import pandas_market_calendars as mcal
import pandas_ta as ta

#import tulipy as ti
from PDFconvert import create_pdf, delete_file
from scipy.stats import linregress


nse_calendar = mcal.get_calendar('NSE')



'''
input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf')
ggg

'''
Monday=True
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
yesterday = today - timedelta(days=1)
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)


# Fetch NSE holidays for the current year
schedule = nse_calendar.schedule(start_date=f'{yesterday.year}-01-01', end_date=f'{today.year}-12-31')
#holidays = schedule[~schedule['market_open'].notna()].index.date
market_days = schedule['market_open'].notna().index.date

#print(holidays)
print(yesterday)

# Check if today is an NSE holiday
if yesterday not in market_days:
    print("Today is an NSE holiday.")
else:
    print("Today is NOTTT an NSE holiday.")


current_datetimeUTC = datetime.now()
weekdayUTC = datetime.now().strftime("%A")

formatted_datetimeUTC = current_datetimeUTC.strftime("%d %b %Y %I:%M %p")
formatted_datetimeIST = ISTnow.strftime("%d %b %Y %I:%M %p")

day=today.weekday() == 1



print("Start csv15yrs")


def detect_bollinger_squeeze_breakout1xxxxxxxxxxxxx(prices, bollinger_window=20, keltner_window=20,
                                     keltner_scalar=1.5, squeeze_threshold=0.5,
                                     breakout_multiplier=1.0, min_right_length=22):
    """
    Detects Bollinger Band squeeze ending on the left side and breakout on the right side,
    using squeeze_on/squeeze_off logic similar to LazyBear indicator.

    Parameters:
    - prices: Series of prices
    - bollinger_window: Window for Bollinger Band calculation
    - keltner_window: Window for Keltner Channel calculation
    - keltner_scalar: Scalar for Keltner Channel width
    - squeeze_threshold: Threshold for squeeze detection (lower = tighter squeeze)
    - breakout_multiplier: How far outside bands to consider a breakout
    - min_right_length: Minimum length required for right segment

    Returns:
    - True if pattern detected, False otherwise
    """
    prices = prices[:]
    pricesO = prices["Open"]
    pricesH = prices["High"]
    pricesL = prices["Low"]
    pricesC = prices["Close"]
    prices = prices["Close"]
      # Use last year of data
    total_length = len(prices)

    if total_length < bollinger_window * 2:
        return False  # Not enough data

    # Calculate Bollinger Bands
    rolling_mean = prices.rolling(window=bollinger_window).mean()
    rolling_std = prices.rolling(window=bollinger_window).std()
    upper_band = rolling_mean + (2 * rolling_std)
    lower_band = rolling_mean - (2 * rolling_std)
    bandwidth = (upper_band - lower_band) / rolling_mean


    def calculate_keltner_channels(high, low, close, window=14, atr_window=14, multiplier=1.5):
        """
        Correct Keltner Channels using ATR.

        Args:
            high (pd.Series): High prices.
            low (pd.Series): Low prices.
            close (pd.Series): Close prices.
            window (int): EMA window for the middle line (default 20).
            atr_window (int): ATR calculation window (default 20).
            multiplier (float): ATR multiplier for upper/lower bands (default 2).

        Returns:
            pd.DataFrame: Contains mid, upper, lower bands.
        """
        # Middle line = EMA of closing prices
        keltner_mid = close.ewm(span=window, adjust=False).mean()

        # True Range (TR) = max of:
        #   1. Current high - current low
        #   2. |Current high - previous close|
        #   3. |Current low - previous close|
        #prev_close = close.shift(1)
        #tr = pd.DataFrame({
        #    'high_low': high - low,
        #    'high_close': (high - prev_close).abs(),
        #    'low_close': (low - prev_close).abs()
        #}).max(axis=1)

        # ATR = EMA of TR
        #atr = tr.ewm(span=atr_window, adjust=False).mean()
        atr= prices["ATR"] = tb.ATR(high, low, close, timeperiod=14)

        # Keltner Channels
        keltner_upper = keltner_mid + (multiplier * atr)
        keltner_lower = keltner_mid - (multiplier * atr)

        '''
        return  pd.DataFrame({
            'keltner_mid': keltner_mid,
            'keltner_upper': keltner_upper,
            'keltner_lower': keltner_lower
        })
        '''

        keltner_mid = keltner_mid.fillna(0)
        keltner_upper = keltner_upper.fillna(0)
        keltner_lower = keltner_lower.fillna(0)

       # Create DataFrame with Keltner Channels
        keltner_df = pd.DataFrame({
            'keltner_mid': keltner_mid,
            'keltner_upper': keltner_upper,
            'keltner_lower': keltner_lower
        })

        #print(keltner_df)
        return keltner_df


    # Calculate Keltner Channel (simplified version)
    high = prices.rolling(window=keltner_window).max()
    low = prices.rolling(window=keltner_window).min()
    keltner_mid = prices.rolling(window=keltner_window).mean()
    keltner_upper = keltner_mid + (high - low) * keltner_scalar
    keltner_lower = keltner_mid - (high - low) * keltner_scalar

    #real = ATR(high, low, close, timeperiod=14)


    keltner= calculate_keltner_channels(pricesH, pricesL, pricesC, window=20, atr_window=14, multiplier=1.5)
    keltner_upper = keltner["keltner_upper"]
    keltner_lower = keltner["keltner_lower"]



    # Determine squeeze states
    squeeze_on = ((lower_band > keltner_lower) & (upper_band < keltner_upper)).astype(int)
    #squeeze_off = ((lower_band < keltner_lower) & (upper_band > keltner_upper)).astype(int)
    #noSqz = (~squeeze_on) & (~squeeze_off)


    '''
    # Calculate linear regression value
    highest_high = prices.rolling(window=keltner_window).max()
    lowest_low = prices.rolling(window=keltner_window).min()
    avg_high_low = (highest_high + lowest_low) / 2
    sma_close = prices.rolling(window=keltner_window).mean()
    avg_val = (avg_high_low + sma_close) / 2
    linreg_source = prices - avg_val

    # Linear regression calculation
    def linear_regression(series, length):
        x = np.arange(length)
        y = series.values[-length:]
        A = np.vstack([x, np.ones(length)]).T
        m, c = np.linalg.lstsq(A, y, rcond=None)[0]
        return m * (length - 1) + c


    val = pd.Series(index=prices.index, dtype=float)
    for i in range(keltner_window, len(prices)):
        val.iloc[i] = linear_regression(linreg_source.iloc[:i+1], keltner_window)


    # Calculate colors
    prev_val = val.shift(1)
    bcolor = np.where(val > 0,
                     np.where(val > prev_val, 'lime', 'green'),
                     np.where(val < prev_val, 'red', 'maroon'))

    scolor = np.where(noSqz, 'blue',
                     np.where(sqzOn, 'black', 'gray'))
    '''


    best_pattern = None
    best_score = 1
    #best_score = 0


    # Determine minimum valley index (left side must be at least as long as right side)
    min_valley_idx = int(total_length // 2)

    for valley_idx in range(min_valley_idx, total_length - min_right_length):
        left_length = valley_idx
        right_length = total_length - valley_idx

        if right_length < min_right_length:
            continue

        left_squeeze = squeeze_on.iloc[:valley_idx]
        left_squeeze = left_squeeze.iloc[-2:]
        left_squeeze_score = (left_squeeze == 1).all().astype(int)
        #print(left_squeeze_score)

        #left_squeeze =  val.iloc[:valley_idx]
        #left_squeeze = left_squeeze.iloc[-5:]
        #left_squeeze_score = left_squeeze.iloc[-1] # (left_squeeze == 1).all().astype(int)

        '''
        left_prices = prices.iloc[:valley_idx]
        right_prices = prices.iloc[valley_idx:]

        left_bandwidth = bandwidth.iloc[:valley_idx]
        right_bandwidth = bandwidth.iloc[valley_idx:]

        # Convert to numpy arrays for reliable indexing
        left_bw_values = left_bandwidth.values
        right_bw_values = right_bandwidth.values

        # Calculate squeeze score for left side
        recent_squeeze = np.nanmean(left_bw_values[-5:]) if len(left_bw_values) >= 5 else 1
        overall_squeeze = np.nanmean(left_bw_values[-22:])

        left_squeeze_score = (
            (1 - recent_squeeze / squeeze_threshold) +
            (1 - overall_squeeze / (squeeze_threshold * 1.5)))


        # Calculate breakout score for right side
        recent_price = right_prices.iloc[-1]
        recent_upper = upper_band.iloc[valley_idx:].iloc[-1]
        recent_lower = lower_band.iloc[valley_idx:].iloc[-1]

        upper_breakout = recent_price > recent_upper * (1 + breakout_multiplier * 0.01)
        lower_breakout = recent_price < recent_lower * (1 - breakout_multiplier * 0.01)

        # Bandwidth expansion calculation
        if len(right_bw_values) > 1:
            current_bw = right_bw_values[-1]
            early_bw_mean = np.nanmean(right_bw_values[:len(right_bw_values)//2])
            bandwidth_expansion = current_bw / early_bw_mean if early_bw_mean != 0 else 1
        else:
            bandwidth_expansion = 1

        breakout_score = (
            (upper_breakout or lower_breakout) * 1.0 +
            bandwidth_expansion
        )
        '''
        breakout_score = 0

        # Calculate overall pattern score
        score = left_squeeze_score * 1 + breakout_score * 0.
        #score = val * 1 + breakout_score * 0.

        if score <= best_score:
            best_score = score
            best_pattern = {
                'split_index': valley_idx,
                'left_length': left_length,
                'right_length': right_length,
                'left_squeeze_score': left_squeeze_score,
                'breakout_score': breakout_score,
                'total_score': score,
                #'upper_breakout': upper_breakout,
                #'lower_breakout': lower_breakout
            }

    #print(best_pattern)
    # Determine if we found a valid pattern
    if best_pattern is not None:
        min_squeeze_score = 0
        min_squeeze_score = 1
        min_breakout_score = 0.8

        if (best_pattern['left_squeeze_score'] >= min_squeeze_score):# and
            #best_pattern['breakout_score'] >= min_breakout_score):
            return True

    return False


#@lru_cache(maxsize=128)  # limit cache size to save memory
def detect_bollinger_squeeze_breakout(prices,Slope_threshold=0.02,allow_equal=True,left_ratio=0.7):
    try:
        prices =prices[-252:]
        prices = pd.to_numeric(prices, errors='coerce')  # Better conversion than astype
        prices = prices.dropna()  # Remove any NA/NaN values
        prices = prices.astype(float)

        def calc_regression_stats(y_values):
            """
            Calculate slope and R-squared for given y_values in one operation
            Returns: (slope, r_squared)
            """
            if len(y_values) < 2:
                return 0.0, 0.0

            try:
                x_values = np.arange(len(y_values))
                result = linregress(x_values, y_values)
                return result.slope, result.rvalue**2
            except Exception as e:
                print(f"Regression calculation failed: {str(e)}")
                return 0.0, 0.0



        def calc_slope(y_values):
            if len(y_values)<2:
                return 0
            x_values = np.arange(len(y_values))
            return np.polyfit(x_values,y_values,1)[0]

        def calc_r_sqr(y_values):
            if len(y_values)<2:
                return 0
            x_values = np.arange(len(y_values))
            slope, intercept =np.polyfit(x_values,y_values,1)
            y_pred=slope*x_values+intercept
            ss_res =np.sum((y_values-y_pred)**2)
            ss_tot=np.sum((y_values-np.mean(y_values))**2)
            return 1-(ss_res/ss_tot) if ss_tot != 0 else 0


        def last_sma_cross_above(prices):
            """
            Find the most recent index where 15-day SMA crosses above 150-day SMA.

            Args:
                prices: pandas DataFrame with price data (last 252 days)

            Returns:
                The most recent index where 15-day SMA > 150-day SMA,
                or None if no such crossover exists in the data
            """
            # Calculate SMAs
            sma15 = prices.rolling(window=15).mean()
            sma150 = prices.rolling(window=150).mean()

            # Find where SMA15 is above SMA150
            sma15_above = sma15 > sma150

            # Find crossovers (where the condition changes from False to True)
            crossovers = (sma15_above & ~sma15_above.shift(1)).dropna()

            if not crossovers.empty:
                # Get the most recent crossover
                last_crossover = crossovers[crossovers].last_valid_index()
                return last_crossover
            return None


        #last_sma_cross_above1 = last_sma_cross_above(prices)-10
        best_left_squeeze =None
        best_score = .8
        total_length=len(prices)

        #Leftside larger
        #1 fixed ratio
        min_valley_idx= int(total_length*left_ratio)

        #2 fixed min diff
        min_diff =max(10,total_length//4) #at least 10 data points or 25% diff
        min_valley_idx= int(total_length//2)+min_diff

        #3 pert based min diff
        min_pert_diff = 0.0 #leftside must be atleat 20%larger
        min_valley_idx= int(total_length*(.5+ min_pert_diff))


        if allow_equal:
            1+1
            #min_valley_idx =total_length//2
        else:
            1+1
            #only leftside longer
            #min_valley_idx = (total_length//2)+1



        #min_price_idx = prices.idxmin()  # This finds the index of the minimum price

        #pricesmax =prices.iloc[0:min_price_idx]
        #max_price_idx = pricesmax.idxmax()
        #diff_idx = min_price_idx - max_price_idx


        #if  diff_idx < 0 or max_price_idx > min_price_idx:
        #    return False

        #for valley_idx in range(min_price_idx-1, min_price_idx+1):
        #for valley_idx in range(min_price_idx, total_length):
        for valley_idx in range(min_valley_idx,total_length):
            left_length = valley_idx
            right_length =  total_length - valley_idx

            if right_length <= 22 and left_length < 44 and ( 66 >= right_length or right_length <= 22): # or left_length <= right_length:
                #return False
                continue

            #if left_length <= right_length:
            #    continue

            left_segment =prices.iloc[valley_idx-44:valley_idx]
            right_segment =prices.iloc[valley_idx:]
            #print(left_segment)

            #left_slope =calc_slope(left_segment.values)
            #right_slope =calc_slope(right_segment.values)
            #left_r2 =calc_r_sqr(left_segment.values)

            left_slope, left_r2 = calc_regression_stats(left_segment)
            right_slope, right_r2 = calc_regression_stats(right_segment)
            # Normalized standard deviation (relative to mean price)
            mean_price_left = np.mean(left_segment)
            std_dev_left = np.std(left_segment) / mean_price_left if mean_price_left != 0 else np.std(left_segment)

            # ADF test for stationarity
            #adf_result_left = adfuller(left_segment)  #adf_p_threshold=0.05, p_value <= p_threshold
            #p_value_left = adf_result_left[1]

            #adf_result_right = adfuller(right_segment)  #adf_p_threshold=0.05, p_value <= p_threshold
            #p_value_right = adf_result_right[1]

            '''
            Test Statistic:

            A negative number. The more negative, the stronger the rejection of the null hypothesis.

            p-value:

            If p-value ≤ threshold (e.g., 0.05), reject H₀ → series is stationary (range-bound).

            If p-value > threshold, fail to reject H₀ → series is non-stationary (trending).

            Critical Values:

            1%, 5%, and 10% confidence levels for comparison with the test statistic.
            '''

            if ( -.02 < left_slope < .02 and 0 <= left_r2 <= 0.3 < right_r2 and std_dev_left < 0.1  and right_slope > Slope_threshold  ): # and right_slope > 0 ):  0 ≤ R² ≤ ~0.3

                #left_r2 =calc_r_sqr(left_segment.values)
                #right_r2 =calc_r_sqr(right_segment.values)
                #symmetry = abs(abs(left_slope)-abs(right_slope))/max(abs(left_slope),abs(right_slope)) #0 perfect symmetry both sides equally steep

                length_ratio =left_length/right_length
                length_bonus = min(length_ratio/3,1) #bonus for longer left side capped to 1

                #score=(
                #    abs(left_slope)*abs(right_slope)*.65 + #slope strength weight
                #    (left_r2+right_r2)*.2 + #linear fit quality weight
                #    (1-symmetry)*.1 + #symmetry bonus weight
                #    length_bonus*.05  #lenght bonus weight
                #)

                #print(score)

                '''
                score = (
                    (np.tanh(abs(left_slope)) * (np.tanh(abs(right_slope))) * 0.6 +  # slopes in [0,1]
                    (max(0, left_r2) + max(0, right_r2)) * 0.2 +  # R² clamped to [0,1]
                    (1 - symmetry) * 0.15 +
                    length_bonus * 0.05
                )
                '''

                if  1==1: # left_slope < best_score and left_slope > -best_score:
                    best_score = left_slope
                    best_left_squeeze ={
                        'valley_index': valley_idx,
                        'valley_date': prices.index[valley_idx],
                        'valley_price': prices.iloc[valley_idx],
                        'left_length': left_length,
                        'right_length': right_length,
                        'length_ratio': length_ratio,
                        'left_percentage': (left_length/total_length)*100,
                        'right_percentage': (right_length/total_length)*100,
                        'total_length':total_length,
                        'left_slope':left_slope,
                        'right_slope':right_slope,
                        'left_r2': left_r2,
                        #'right_r2':right_r2,
                        #'symmetry':symmetry,
                        #'length_bonus':length_bonus,
                        #'score':score,
                        'left_segment':left_segment,
                        'right_segment':right_segment
                        }
                    #break
        #break

        if best_left_squeeze != None:
            #print(best_left_squeeze)
            #print('best_left_squeeze')
            return True
        else:
            return False
    except Exception as e:
        print(f"⚠️Error occurred for best_left_squeeze: {str(e)}")
        traceback_str = traceback.format_exc()
        return False
        # Print detailed error information
        #print("Error type:", e.__class__.__name__)
        #print("Error message:", str(e))
        #print("Traceback:\n", traceback_str)
        pass
        # Print detailed error information


#@lru_cache(maxsize=128)  # limit cache size to save memory
def detect_V_shape(prices,Slope_threshold=0.02,allow_equal=True,left_ratio=0.7):

    #prices =prices[-252:]

    def calc_regression_stats(y_values):
        """
        Calculate slope and R-squared for given y_values in one operation
        Returns: (slope, r_squared)
        """
        if len(y_values) < 2:
            return 0.0, 0.0

        try:
            x_values = np.arange(len(y_values))
            result = linregress(x_values, y_values)
            return result.slope, result.rvalue**2
        except Exception as e:
            print(f"Regression calculation failed: {str(e)}")
            return 0.0, 0.0


    def calc_slope(y_values):
        if len(y_values)<2:
            return 0
        x_values = np.arange(len(y_values))
        return np.polyfit(x_values,y_values,1)[0]
        #result = linregress(x_values, y_values)
        #return result.slope



    def calc_r_sqr(y_values):
        if len(y_values)<2:
            return 0
        x_values = np.arange(len(y_values))
        slope, intercept =np.polyfit(x_values,y_values,1)
        y_pred=slope*x_values+intercept
        ss_res =np.sum((y_values-y_pred)**2)
        ss_tot=np.sum((y_values-np.mean(y_values))**2)
        return 1-(ss_res/ss_tot) if ss_tot != 0 else 0

    best_V_pattern =None
    best_score =-1
    #best_score = -Slope_threshold
    total_length=len(prices)

    #Leftside larger
    #1 fixed ratio
    min_valley_idx= int(total_length*left_ratio)

    #2 fixed min diff
    min_diff =max(10,total_length//4) #at least 10 data points or 25% diff
    min_valley_idx= int(total_length//2)+min_diff

    #3 pert based min diff
    min_pert_diff = 0.0 #leftside must be atleat 20%larger
    min_valley_idx= int(total_length*(.5+ min_pert_diff))


    if allow_equal:
        1+1
        #min_valley_idx =total_length//2
    else:
        1+1
        #only leftside longer
        #min_valley_idx = (total_length//2)+1



    #min_price_idx = prices.idxmin()  # This finds the index of the minimum price

    #pricesmax =prices.iloc[0:min_price_idx]
    #max_price_idx = pricesmax.idxmax()
    #diff_idx = min_price_idx - max_price_idx
    #print(diff_idx,max_price_idx,min_price_idx)

    #if  diff_idx < 0 or max_price_idx > min_price_idx:
    #    return False
        #continue

    #for valley_idx in range(min_price_idx-1, min_price_idx+1):
    #for valley_idx in range(min_price_idx, total_length):
    for valley_idx in range(min_valley_idx,total_length):
        left_length = valley_idx
        right_length =  total_length - valley_idx

        if right_length <= 22 and left_length < 22 and ( 66 >= right_length or right_length <= 22) :# or left_length < right_length:
            #return False
            continue

        #if left_length <= right_length:
        #    continue

        left_segment =prices.iloc[0:valley_idx]
        right_segment =prices.iloc[valley_idx:]

        #left_slope =calc_slope(left_segment.values)
        #right_slope =calc_slope(right_segment.values)

        left_slope, left_r2 = calc_regression_stats(left_segment)
        right_slope, right_r2 = calc_regression_stats(right_segment)

        # ADF test for stationarity
        #adf_result_left = adfuller(left_segment)  #adf_p_threshold=0.05, p_value <= p_threshold
        #p_value_left = adf_result_left[1]

        #adf_result_right = adfuller(right_segment)  #adf_p_threshold=0.05, p_value <= p_threshold
        #p_value_right = adf_result_right[1]

        #0 ≤ R² < 0.1	No meaningful trend Range-bound
        #0.1 ≤ R² < 0.3	Weak trend (check slope/volatility) ️ Maybe range-bound
        #R² ≥ 0.3	Significant trend  Trending

        #print(left_slope)
        if (left_slope < -Slope_threshold and  right_slope > Slope_threshold and (left_r2 and right_r2 ) >= 0.2  ):

            #left_r2 =calc_r_sqr(left_segment.values)
            #right_r2 =calc_r_sqr(right_segment.values)
            symmetry = abs(abs(left_slope)-abs(right_slope))/max(abs(left_slope),abs(right_slope)) #0 perfect symmetry both sides equally steep

            length_ratio =left_length/right_length
            length_bonus = min(length_ratio/3,1) #bonus for longer left side capped to 1

            score=(
                abs(left_slope)*abs(right_slope)*.60 + #slope strength weight
                (left_r2+right_r2)*.4 + #linear fit quality weight
                (1-symmetry)*.0 + #symmetry bonus weight
                length_bonus*.0  #lenght bonus weight
            )

            #print(score)

            '''
            score = (
                (np.tanh(abs(left_slope)) * (np.tanh(abs(right_slope))) * 0.6 +  # slopes in [0,1]
                (max(0, left_r2) + max(0, right_r2)) * 0.2 +  # R² clamped to [0,1]
                (1 - symmetry) * 0.15 +
                length_bonus * 0.05
            )
            '''

            if score > best_score: #left_slope < best_score:
                best_score = score
                best_V_pattern ={
                    'valley_index': valley_idx,
                    'valley_date': prices.index[valley_idx],
                    'valley_price': prices.iloc[valley_idx],
                    'left_length': left_length,
                    'right_length': right_length,
                    'length_ratio': length_ratio,
                    'left_percentage': (left_length/total_length)*100,
                    'right_percentage': (right_length/total_length)*100,
                    'total_length':total_length,
                    'left_slope':left_slope,
                    'right_slope':right_slope,
                    'left_r2': left_r2,
                    'right_r2':right_r2,
                    'symmetry':symmetry,
                    'length_bonus':length_bonus,
                    'score':score,
                    'left_segment':left_segment,
                    'right_segment':right_segment
                    }
       #break

    if best_V_pattern != None:
        #print(best_V_pattern)
        #print('best_V_pattern')
        return True
    else:
        return False

'''
slope theshold =.02 min steepness slope required
.02 means min chg .02 price units per time peroid
eg price 100 to 99 over 50days
slope = -1/50 =-.02

100 to 95 price over 10 days
-5/10 =-5 much steeper

.05 very steep Vshapes
.01 gentler Vshapes
.001 detect almost any directional change
'''


def get_roc30_2yrH_index(df):
    """
    Function to find the first row index within the last 90 rows of the DataFrame where:
    - The 'Close' price equals the last value in the '2yrL' column.
    - The last value of 'obvmovavg' is less than the last value of 'OBV'.

    Parameters:
    df (pandas.DataFrame): The DataFrame containing 'Close', '2yrL', 'obvmovavg', and 'OBV' columns.

    Returns:
    int or str: The index (relative to the entire DataFrame) of the first row where the condition is met.
                Returns an empty string if no rows meet the condition or if the second condition is not met.
    """
    # Get the boolean mask where the condition is true within the last 90 rows
    mask = df["Close"].iloc[-7:] < df["2yrH"].iloc[-1]*1.0
    mask90 = df["Close"].iloc[-22:-6] == df["2yrH"].iloc[-1]

    # Find the row indices where the condition is true
    row_indices = mask[mask].index if mask.all() else []  # for mask90 (check if any True before indexing)
    row_indices90 = mask90[mask90].index if mask90.any() else []  # for mask90 (check if any True before indexing)

    # Check the second condition
    #if len(row_indices) > 0 and len(row_indices90) > 0:
    if len(row_indices) > 0 and len(row_indices90) > 0 and df["OBV"].loc[row_indices90[0]]*.95 > df["OBV"].iloc[-1] and mask90.any() and mask.all(): # if and df["OBV"].loc[row_indices90[0]] < df["OBV"].iloc[-1]  and mask.all():
        # Return the first row number relative to the entire DataFrame or an empty string
        #return df.index.get_loc(row_indices[0]) if not row_indices.empty else ""
        #return df.index.get_loc(row_indices90[0]) if not row_indices90.empty else ""  #df.index.get_loc(row_indices[-1])
        roc = int(((df["Close"].iloc[-1] - df["2yrH"].iloc[-1] ) / df["2yrH"].iloc[-1])*100)
        obv_condition_met = round( df["OBV"].iloc[-1]/df["OBV"].loc[row_indices90[0]],2)
        return roc,obv_condition_met
    else:
        return 0,0

def get_roc30_2yrL_index(df):
    """
    Function to find the first row index within the last 90 rows of the DataFrame where:
    - The 'Close' price equals the last value in the '2yrL' column.
    - The last value of 'obvmovavg' is less than the last value of 'OBV'.

    Parameters:
    df (pandas.DataFrame): The DataFrame containing 'Close', '2yrL', 'obvmovavg', and 'OBV' columns.

    Returns:
    int or str: The index (relative to the entire DataFrame) of the first row where the condition is met.
                Returns an empty string if no rows meet the condition or if the second condition is not met.
    """
    # Get the boolean mask where the condition is true within the last 90 rows
    mask = df["Close"].iloc[-7:] > df["2yrL"].iloc[-1]*1.0
    mask90 = df["Close"].iloc[-22:-6] == df["2yrL"].iloc[-1]

    # Find the row indices where the condition is true
    row_indices = mask[mask].index if mask.all() else []  # for mask90 (check if any True before indexing)
    row_indices90 = mask90[mask90].index if mask90.any() else []  # for mask90 (check if any True before indexing)

    # Check the second condition
    #if len(row_indices) > 0 and len(row_indices90) > 0:
    if len(row_indices) > 0 and len(row_indices90) > 0 and df["OBV"].loc[row_indices90[0]]*1.05 < df["OBV"].iloc[-1] and mask90.any() and mask.all(): # if and df["OBV"].loc[row_indices90[0]] < df["OBV"].iloc[-1]  and mask.all():
        # Return the first row number relative to the entire DataFrame or an empty string
        #return df.index.get_loc(row_indices[0]) if not row_indices.empty else ""
        #return df.index.get_loc(row_indices90[0]) if not row_indices90.empty else ""  #df.index.get_loc(row_indices[-1])
        roc = int(((df["Close"].iloc[-1] - df["2yrL"].iloc[-1] ) / df["2yrL"].iloc[-1])*100)
        obv_condition_met = round( df["OBV"].iloc[-1]/df["OBV"].loc[row_indices90[0]],2)
        return roc,obv_condition_met
    else:
        return 0,0


    # Check if mask90 is False and mask is True
    #if not mask90.any() and mask.any():
    #    if df["obvmovavg"].iloc[-20] < df["OBV"].iloc[-1]:
    #        return df.index.get_loc(mask.idxmax())  # Get the index of the first True value in mask
    #    else:
    #        return ""
    #else:
    #    return ""


def is_range_bound(dataR, window=100, slope_threshold=0.02):
  """
  Checks if a stock is range-bound based on price slope and historical volatility.

  Args:
    data: A pandas DataFrame containing OHLC (Open, High, Low, Close) data.
    window: Lookback window for slope calculation (default: 20 days).
    slope_threshold: Absolute value threshold for low slope (default: 0.02).

  Returns:
    True if the stock is considered range-bound, False otherwise.
  """

  # Calculate closing price slope
  data=dataR
  data["Slope"] = np.polyfit(range(window), data["Close"].iloc[-window:], 1)[0]

  # Calculate Average True Range (ATR)
  atr = data["High"].max(axis=0) - data["Low"].min(axis=0) - np.abs(
      data["Close"].shift(1) - data["Open"]
  )
  atr = atr.ewm(alpha=1 / window, min_periods=window).mean()

  #print((data["Slope"].iloc[-1]))
  # Check range-bound conditions
  return (data["Slope"].iloc[-1]) #<= slope_threshold #and np.mean(atr)*3 > 0.005

# Function to calculate adjusted R-squared
def adjusted_r_squared(y, x, slope, intercept,r_value):
    #y_pred = intercept + slope * x
    #ss_total = np.sum((y - np.mean(y)) ** 2)
    #ss_residual = np.sum((y - y_pred) ** 2)
    #r_squared = 1 - (ss_residual / ss_total)
    r_squared = r_value
    n = len(y)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    return adj_r_squared

def calculate_exponential_linear_regression(df,period=12):
    # Download historical data from yfinance
    data  = df.iloc[-(period+5):] # yf.download(stock_symbol, period="1y")
    data=df
    #print(data)

    # Calculate the natural logarithm of returns
    returns = np.log(data['Close'])
    #print(returns)
    x = np.arange(len(returns))
    #print(x)

    #slope, intercept, r_value, p_value, std_err = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x))
    #print(slope, intercept, r_value, p_value, std_err )
    slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
    #annualized_slope = (np.power(np.exp(slope), 252) - 1) * 100
    annualized_slope = (np.power((1+slope), 252)) *100
    r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
    r_squared = r_value
    n = len(x)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    annualized_slope_r_value = round(annualized_slope * (adj_r_squared ** 2), 2)

    #print(slope)
    #print(annualized_slope)

    # Calculate linear regression
    #slope, _, r_value, _, _ = stats.linregress(x, returns)

    # Calculate annualized slope
    #annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    # Calculate annualized_slope_r_value
    #annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Round the annualized slope and annualized_slope_r_value
    #rounded_annualized_slope = round(annualized_slope, 2)

    # Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    higher_value = annualized_slope_r_value #np.maximum(annualized_slope_r_value, rounded_annualized_slope)

    return higher_value


def calculate_mrp1(stock_csv_file):
    # Load stock and index data from CSV files using chunksize for large files
    chunksize = 10 ** 6 # Adjust based on available memory
    #stock_data = pd.concat(pd.read_csv(stock_csv_file, chunksize=chunksize))
    #index_data = pd.concat(pd.read_csv(index_csv_file, chunksize=chunksize))
    #print(stock_csv_file)

    index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
    stock_data = pd.read_csv(stock_csv_file)
    index_data = pd.read_csv(index_csv_file)
    #stock_data = stock_data.iloc[-252:]
    #index_data = index_data.iloc[-252:]

    MDD_df = stock_data.copy()

    stock_data1 = pd.DataFrame()
    index_data1 = pd.DataFrame()
    stock_data1['Close'] = stock_data['Close'].pct_change()
    index_data1['Close'] = index_data['Close'].pct_change()

    # Calculate cumulative returns
    stock_data['Stock_Cumulative_Return'] = round(100*(1 + stock_data1['Close']).cumprod(),5)
    index_data['Dow_Cumulative_Return'] = round(100*(1 + index_data1['Close']).cumprod(),5)

    # Adjust initial value calculation
    initial_value = 1
    stock_data1['Close'] = initial_value * stock_data['Stock_Cumulative_Return']
    index_data1['Close'] = initial_value * index_data['Dow_Cumulative_Return']

    # Calculate Relative Performance (RP)
    RP = stock_data1['Close'] / index_data1['Close']
    RP =round(RP,4)

    # Add MRP values to the stock data
    stock_data['MRP'] = RP.round(3) #round(RP, 3)

    # Assuming MDD_df1 is a DataFrame with relevant columns
    #stock_data = pd.concat([stock_data, MDD_df1], axis=1)
    # Save the updated stock data to a new CSV file
    print(stock_data['MRP'])

    return stock_data['MRP']

    #stock_data.to_csv(stock_csv_file, index=False)


def calculate_mrp(stock_csv_file):
    """
    Calculates the Market Relative Performance (MRP) for a given stock.

    Args:
        stock_csv_file (str): Path to the CSV file containing stock data.

    Returns:
        pandas.Series: Series containing the MRP values for the stock.
    """

    index_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"

    # Load stock and index data efficiently
    stock_data = pd.read_csv(stock_csv_file, usecols=['Close'])
    index_data = pd.read_csv(index_csv_file, usecols=['Close'])

    # Select the last 252 trading days
    #stock_data = stock_data.tail(270)
    #index_data = index_data.tail(270)

    # Calculate daily returns
    stock_returns = stock_data['Close'].pct_change()
    index_returns = index_data['Close'].pct_change()

    # Calculate cumulative returns
    #stock_cumulative_returns = (1 + stock_returns).cumprod()
    #index_cumulative_returns = (1 + index_returns).cumprod()

    # Calculate MRP
    #mrp = stock_cumulative_returns / index_cumulative_returns
    stock_cumreturns =(1+stock_returns).rolling(window=252).apply(np.prod)-1
    index_cumreturns=(1+index_returns).rolling(window=252).apply(np.prod)-1
    mrp=stock_data['MRPcsv15yrs']=((1+stock_cumreturns)/(1+index_cumreturns)).ffill()

    stock_data['MRPcsv15yrs'] = mrp.round(3)

    #print(stock_data['MRP'])
    return stock_data['MRPcsv15yrs']



#calculate_mrp("/home/rizpython236/BT5/ticker_15yr/SHAKTIPUMP.NS.csv")



TJI_IC_path = '/home/rizpython236/BT5/trade-logs/TJI_index.csv'
TJI_IC_path = pd.read_csv(TJI_IC_path)
TJI_IC_path = TJI_IC_path['Symbol'].tolist()[:]
TJI_IC_path = list(set(TJI_IC_path))



# Specify the folder path containing CSV files
folder_path = '/home/rizpython236/BT5/ticker_15yr/'  # Replace with the actual folder path
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
#ticker_path = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()[:]
symbols.extend(TJI_IC_path)
symbols = list(dict.fromkeys(symbols))  #list(set(symbols))
indices= ['^NSEI', 'BSE-500.BO', '^NSEMDCP50', 'NIFTYSMLCAP250.NS', 'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'BTC-USD', 'GOLDBEES.NS', '^NSEBANK', 'PSUBNKBEES.BO', '^CNXPSUBANK', 'NIFTYPVTBANK.NS', 'NIFTY_FIN_SERVICE.NS', '^CNXAUTO', '^CNXREALTY', '^CNXCMDT', '^CNXMETAL', '^CNXINFRA', 'ICICIINFRA.NS', 'PHARMABEES.NS', '^CNXPHARMA', '^CNXFMCG', '^CNXCONSUM', '^CNXIT', '^CNXENERGY', '^CRSLDX', 'MON100.NS', 'MAFANG.NS','HNGSNGBEES.NS', 'MAHKTECH.NS', 'SBIGETS.BO', 'AXISCETF.NS']

NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(NSE570_path)
NSE570symbols = NSE570ticker_df['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols))
#print(len(NSE570symbols))



symNo= len(symbols)



selected_files = []

valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))


# Initialize counters for MRP13 and MRP25
CountBExp = 0
mrp13_count_more0 = 0
mrp25_count_less0 = 0
mrp25_count_more0 = 0
mrp13_countbothless0 = 0
mrp25_countbothmore0 = 0
CountS_DCH = 0
total_files = 0
file_names = []
Bullish = []
Bearish = []
Start_countmore0 = 0
mrp25_count_mores10 = 0
mrp25_mores10 = []
mrp25_count_M1L1 =[]
mrp25_count_M1L2 =[]
CountS_TTMSqueeze =0
CountS_fall =0
S_TTMSqueeze=[]
S_fall=[]
S_DCH =[]
CountS_EMA=0
S_EMS=[]
BExpShort=[]
CountBExplong=0
BExplong=[]
CountB52high =0
B52High=[]
CountBRSI = 0
BRSI =[]
CountBMRP = 0
BMRP =[]
CountBBTTM =0
BBBTTM = []
CountFinalSell=0
FinalSell=[]
CountFinalBUY=0
FinalBUY=[]
S_ROC =[]
S_DD_PCT_30 =[]
B_DD_PCT_30 =[]
expLonly =[]
expSonly =[]
indiceNOLONG=[]
indiceNOSHORT=[]
EFIU=[]
EFID=[]
SMA_V7SMA_V40=[]
_52wkL= []
_52wkH= []
_52wkrange=[]
SMAUP=[]
SMADWN=[]
RSIUP=[]
RSIDWN=[]
DDPCTlist=[]
MRPUP=[]
MRPDWN =[]
Pos1yrHigh=[]
Pos1yrlow =[]
maxVx=[]
MRPcross=[]
SMAcross=[]
L2yr30_ROC=[]
HigerHigh=[]
MRHigerHigh=[]
results_listGreater=[]
results_listLower=[]
results_listget_roc30_2yrL_index=[]
results_listget_roc30_2yrH_index=[]
minervini=[]
TJI=[]
Candleslist =[]
minervinitickers=[]
Pos1yrHightickers =[]
TJItickers =[]
Scoretickers =[]
Scoretickersall =[]



def Candles(Candleslist =None,symbol_to_company=None,df=None,base_name=None,cal252_mrp=None,NSE570symbols=None):
    try:
        df=df[-6:]
        #Bullish
        if tb.CDLMARUBOZU(df['Open'], df['High'], df['Low'], df['Close']).iloc[-1] > 0:
            cand = "Bullish-Marubozu"
        elif tb.CDLCLOSINGMARUBOZU(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish-Closing Marubozu"
        elif tb.CDLKICKINGBYLENGTH(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish-Kicking longer Marubozu"
        #Bullish Contin..
        elif tb.CDLTASUKIGAP(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Cont-Tasuki Gap"
        elif tb.CDLINNECK(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Cont-In-Neck Pattern"
        #Bullish Reversal
        elif tb.CDLHAMMER(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Hammer"
        elif tb.CDLENGULFING(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Engulfing Pattern"
        elif tb.CDLDRAGONFLYDOJI(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Dragonfly Doji"
        elif tb.CDLINVERTEDHAMMER(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Inverted Hammer"
        elif tb.CDLPIERCING(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Piercing Pattern"
        elif tb.CDLMORNINGSTAR(df['Open'], df['High'], df['Low'], df['Close'], penetration=0)[-1] > 0:
            cand = "Bullish Reversal-Morning Star"
        elif tb.CDLHARAMI(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Harami Pattern"
        elif tb.CDLHARAMICROSS(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Harami Cross Pattern"
        elif tb.CDL3WHITESOLDIERS(df['Open'], df['High'], df['Low'], df['Close'])[-1] > 0:
            cand = "Bullish Reversal-Three Advancing White Soldiers"

        #Brearish
        elif tb.CDLMARUBOZU(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish-Marubozu"
        #Bearish cont..
        elif tb.CDLTASUKIGAP(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Cont-Tasuki"
        #bearish Reversal
        elif tb.CDLHANGINGMAN(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Reversal-Hanging Man"
        elif tb.CDLSHOOTINGSTAR(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Reversal-Shooting Star"
        elif tb.CDLIDENTICAL3CROWS(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Reversal- Identical Three Crows"
        elif tb.CDLGRAVESTONEDOJI(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Reversal-Gravestone Doji"
        elif tb.CDLDARKCLOUDCOVER(df['Open'], df['High'], df['Low'], df['Close'], penetration=0)[-1] < 0:
            cand = "Brearish Reversal-Dark Cloud Cover"
        elif tb.CDLHARAMI(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Reversal-Harami"
        elif tb.CDLHARAMICROSS(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Reversal-Harami Cross Pattern"
        elif tb.CDLENGULFING(df['Open'], df['High'], df['Low'], df['Close'])[-1] < 0:
            cand = "Brearish Reversal-Engulfing Pattern"
        elif tb.CDLABANDONEDBABY(df['Open'], df['High'], df['Low'], df['Close'], penetration=0)[-1] < 0:
            cand = "Brearish Reversal-Abandoned Baby"
        else:
            cand = ""


        Base_name=symbol_to_company.get(base_name, base_name)
        DD_PCT=int(df["DD_PCT"].iloc[-1])
        DD_PCT=f"{int(DD_PCT)}%"
        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-6],2)
        RSI = int(df["RSI"].iloc[-1])
        ADX = int(df["ADX"].iloc[-1])
        CCI = int(df["CCI"].iloc[-1])
        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
        #NSE570s = "Y" if base_name in NSE570symbols  else ""
        ROC_14= int(df['ROC_30'].iloc[-1])
        OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
        OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2)
        OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
        #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
        #ROC30_2yrL = get_roc30_2yrL_index(df)
        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
        #MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
        #MRP= f"{round(df['MRP'].iloc[-1], 2)}"
        MRP= cal252_mrp.iloc[-1]
        MRPD ="UP" if (df["EMA_14cal252_mrp"].iloc[-1] < cal252_mrp.iloc[-1] and nifty_data['EMA_200'].iloc[-1] < nifty_data['EMA_50'].iloc[-1] < nifty_data["Close"].iloc[-1] and RSI > 40) else ""
        #MRP = MRP.iloc[-1] if MRP.iloc[-1] is not Nan else MRP.iloc[-2]
        #print(Base_name,cal252_mrp)
        UD= "UP" if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else ""
        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
        CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,0)
        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""   # and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
        if len(df) > 0 and df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1] and df["SMA_200"].iloc[-1] > df["SMA_200_15"].iloc[-1] and df["Close"].iloc[-1] > df["52wkL"].iloc[-1]*1.25 and df["Close"].iloc[-1] > df["52wkH"].iloc[-1]*.75 and df["RSI14avg"].iloc[-5] < df["RSI14"].iloc[-1] > 60  :
            M = "Y"
        else:
            M =""
        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"

        data = {
                "Company": Base_name,
                "Candle": cand,
                "MV" : M,
                #"N570":NSE570s,
                "ROC_30": ROC_14,
                "MRP1yr": MRP,
                "MRPS":MRPD,
                "MRPL": UD,
                "RSI": RSI,
                "CCI": CCI,
                #"ADX": ADX,
                #"MACD":MACD,
                #"ROC_2": ROC_2,
                "ST":ST,
                #"EXP20":LNEXP20,
                #"EXP50":LNEXP50,
                "MA200UP":SMA200UP,
                "OBVchg":OBVchg,
                "VX": VX,
                "CH52wk%":CH52wk,
                "Ps1yr":pos1yr,
                "DD%3yr": DD_PCT
                }
                # Append the dictionary to DDPCTlist
        print(cand)
        print(data)
        Candleslist.append(data)
    except Exception as e:
        print(f"Error processing Candle {Base_name}: {str(e)}")
        traceback_str = traceback.format_exc()


def rolling_two_largest(x):
  # Convert window to pandas Series (recommended from previous solution)
  window_series = pd.Series(x)
  # Sort the window in descending order
  sorted_window = window_series.sort_values(ascending=False)
  # Fill with NaNs and replace top 2 with actual values
  result = pd.Series(np.nan * len(x))
  result.iloc[0:2] = sorted_window.head(2)
  #print(result)
  return result


nifty_csv_file = "/home/rizpython236/BT5/ticker_15yr/^NSEI.csv"
nifty_data = pd.read_csv(nifty_csv_file)
#nifty_data = nifty_data.iloc[:]
nifty_data["EMA_200"] = tb.EMA(nifty_data['Close'], timeperiod=200)
nifty_data["EMA_50"] = tb.EMA(nifty_data['Close'], timeperiod=50)
#nifty_data["SMA_200"] = tb.SMA(nifty_data['Close'], timeperiod=200)


# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)


            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                #total_files += 1

                # Read the CSV file into a DataFrame
                df = pd.read_csv(file_path)
                dfexp=df
                dataR=df
                data52 =df[-295:]
                df["SMA_V40"] = tb.SMA(data52['Volume'], timeperiod=20)
                if df["SMA_V40"].iloc[-1]  <=100:
                    continue

                #print(df)

                #df['CCI'] = df.ta.cci(df['High'], df['Low'], df['Close'], window=34)
                #df['CCI'] = tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34)
                #df['CCIavg'] = tb.SMA(df['CCI'], timeperiod=12)
                #df['ADX'] = tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['macd'], df['macdsignal'], df['macdhist'] = tb.MACD(df['Close'], fastperiod=12, slowperiod=26, signalperiod=9)
                #df['ATR'] = tb.ATR(df['High'], df['Low'], df['Close'], timeperiod=10)
                #df['SuperTrend_Upper_Band'] = df['High'] + (3 * df['ATR'])
                #df['SuperTrend_Lower_Band'] = df['Low'] - (3 * df['ATR'])
                #df['SuperTrend'] = (df['SuperTrend_Upper_Band'] + df['SuperTrend_Lower_Band']) / 2
                #df['VolumeSMA'] = tb.SMA(df['Volume'], timeperiod=14)

                ###############################
                cal252_mrp  =calculate_mrp(file_path)
                df["EMA_14cal252_mrp"] = tb.EMA(cal252_mrp, timeperiod=22)
                df["CCI"]=tb.CCI(data52['High'], data52['Low'], data52['Close'], timeperiod=120)
                df["CCImovavgL"] = tb.EMA(df["CCI"], timeperiod=14)
                df["CCImovavgS"] = tb.EMA(df["CCI"], timeperiod=7)
                df["macd"], df["macdsignal"], df["macdhist"] = tb.MACDEXT(data52['Close'], fastperiod=12, fastmatype=0, slowperiod=26, slowmatype=0, signalperiod=9, signalmatype=0)
                df["ADX"]= tb.ADX(data52['High'], data52['Low'], data52['Close'], timeperiod=34)
                df["ADXavg"] = tb.EMA(df["ADX"], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                df["RSI"] = tb.RSI(data52['Close'], timeperiod=34)
                df["RSIavg"] = tb.EMA(df["RSI"], timeperiod=7)
                df["RSI14"] = tb.RSI(data52['Close'], timeperiod=24)
                df["RSI14avg"] = tb.EMA(df["RSI14"], timeperiod=7)
                df["OBV"] = tb.OBV(data52['Close'], data52['Volume'])
                df["obvmovavg"] = tb.EMA(df["OBV"], timeperiod=14)
                df["MaxOBV30"] = tb.MAX(df['OBV'], timeperiod=34)
                df["MinOBV30"] = tb.MIN(df['OBV'], timeperiod=34)
                df["STDDEV90"] = tb.STDDEV(data52['Close'], timeperiod=90, nbdev=2)
                df["avgSTDDEV90"] = tb.SMA(df["STDDEV90"], timeperiod=34)

                supertrend_values= ta.supertrend(high=df['High'], low=df['Low'], close=df['Close'], length=10, multiplier=4)#, offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
                df['ST'] = supertrend_values['SUPERT_10_4.0']
                #df["SMA_20"] = tb.SMA(df['Close'], timeperiod=20)
                df["SMA_50"] = tb.SMA(data52['Close'], timeperiod=50)
                df["SMA_200"] = tb.SMA(data52['Close'], timeperiod=200)
                df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                df["SMA_150"] = tb.SMA(data52['Close'], timeperiod=150)
                df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                df["SMA_200_15"] = tb.SMA(df['SMA_200'], timeperiod=60)
                df["Score_18"] = tb.SMA(data52['Score'], timeperiod=5)
                #df["Score_7"] = tb.SMA(data52['Score'], timeperiod=7)

                df["EMA_30"] = tb.EMA(data52['Close'], timeperiod=30)
                #df["EMA_7W"] = tb.EMA(df['Close'], timeperiod=7)
                #df["EMA_5W"] = tb.EMA(df['Close'], timeperiod=5)
                #donchian_values=ta.donchian(df['High'], df['Low'], lower_length=20, upper_length=20, offset=None,)
                #df= pd.concat([df, donchian_values], axis=1)
                #df["DCH"]= ((df["DCU_20_20"] - df["DCL_20_20"]) / (df["DCU_20_20"] / 1)) * 100
                #df["DCHema"] = tb.SMA(df["DCH"], timeperiod=14)
                df['Exp_lin_reg']= exp12 = calculate_exponential_linear_regression(data52,period=120)
                df['Exp_lin_regslow']= exp50 = calculate_exponential_linear_regression(data52,period=180)
                #df["upperband"], df["middleband"], df["lowerband"] = tb.BBANDS(df['Close'], timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
                #squeeze_pro=ta.squeeze_pro(df['High'], df['Low'], df['Close'], bb_length=20, bb_std=2, kc_length=20, kc_scalar_wide=2, kc_scalar_normal=1.5, kc_scalar_narrow=1, mom_length=12, mom_smooth=6,)# use_tr=None, mamode=None,)
                ##print(squeeze_pro) # //WIDE SQUEEZE: ORANGE , NORMAL SQUEEZE: RED ,NARROW SQUEEZE: YELLOW ,FIRED WIDE SQUEEZE: GREEN ,NO SQUEEZE: BLUE
                #df= pd.concat([df, squeeze_pro], axis=1)
                #df['ROC_1']=tb.ROC(df['Close'], timeperiod=1)
                df['ROC_2'] = tb.ROCP(data52['Close'], timeperiod=1)*100
                df['ROC_30']=tb.ROCP(data52['Close'], timeperiod=22)*100
                df['ROC_5']=tb.ROCP(data52['Close'], timeperiod=5)*100
                df["ROC_2movavg"] = tb.SMA(df["ROC_2"], timeperiod=5)
                df["ROC_22movavg"] = tb.SMA(df["ROC_2"], timeperiod=22)
                #df['ROC_4']=tb.ROC(df['Close'], timeperiod=4)
                #df['ROC_12']=tb.ROC(df['Close'], timeperiod=12)
                #df['ROC_24']=tb.ROC(df['Close'], timeperiod=24)
                #df['ROC_51']=tb.ROC(df['Close'], timeperiod=51)
                #df["SMA_V200"] = tb.EMA(df['Volume'], timeperiod=200)
                #df["SMA_V200"] = tb.MAX(df['Volume'], timeperiod=51)
                #df["SMA_V50"] = tb.SMA(df['Volume'], timeperiod=50)
                ###df["SMA_V40"] = tb.SMA(data52['Volume'], timeperiod=20)
                df["SMA_V7"] = tb.SMA(data52['Volume'], timeperiod=7)
                #df["SMA_V4"] = tb.SMA(df['Volume'], timeperiod=4)

                df["High_higher12"] = df['High'].iloc[-3:].shift(0) > df['High'].iloc[-3:].shift(1)
                df["High_higher"] = df['Close'].iloc[-3:].shift(0) > df['Close'].iloc[-3:].shift(1) #close is highter than prev close
                df["Low_higher"] = df['Low'].iloc[-3:].shift(0) > df['Low'].iloc[-3:].shift(1)   #low is highter than prev close


                df["High_Lower"] = df['Close'].iloc[-3:].shift(0) < df['Close'].iloc[-3:].shift(1)    #high is lower than prev close
                df["Low_lower"] = df['Low'].iloc[-3:].shift(0) < df['Low'].iloc[-3:].shift(1)   #low is lower than prev close
                df["High_lower12"] = df['High'].iloc[-3:].shift(0) < df['High'].iloc[-3:].shift(1)



                #df["High_higher"] =df['Close'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] > max(x[:-1]),raw=True)
                #df["Low_higher"] =df['Low'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] > max(x[:-1]),raw=True)

                #df["High_Lower"] =df['High'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] < min(x[:-1]),raw=True)
                #df["Low_lower"] =df['Close'].iloc[-30:].rolling(window=15).apply(lambda x: x[-1] < min(x[:-1]),raw=True)

                try:
                    df["SMA_91MRP"] =df["SMA_30MRP"] = tb.EMA(data52['MRP'], timeperiod=30) #------------------
                    df["SMA_200MRP"] = df["SMA_90MRP"] = tb.EMA(data52['MRP'], timeperiod=200)
                    df["EMA_14MRP"] = tb.EMA(data52['MRP'], timeperiod=14)  #-------------
                    df["EMA_30MRP"] = tb.EMA(data52['MRP'], timeperiod=30)
                except Exception as e:
                    1+1
                df["2yrH"] =  df["MaxcloseH"] = tb.MAX(df['Close'])#, timeperiod=252*2)
                df["2yrL"] = df["MaxcloseL"] = tb.MIN(df['Close'])# timeperiod=252)
                df["52wkH"] = tb.MAX(data52['Close'], timeperiod=252)
                df["52wkL"] = tb.MIN(data52['Close'], timeperiod=252)
                #df["2yrL"] = tb.MIN(data52['Close'], timeperiod=252+(252*0))
                #df["2yrH"] = tb.MAX(data52['Close'], timeperiod=252+(252*0))
                df["MaxVx22"] = tb.MAX(df['Volume']) #, timeperiod=958) #252*3.5)
                quantile= ta.quantile(close=df['Volume'], length=252, q=.7, offset=None)#,
                df['quantile'] = quantile# ['QTL_958_0.75']
                df["SMA_V3yr"] = tb.SMA(df['Volume'], timeperiod=200) #252*3.5)
                MaxVx =round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-7]*.6),2)
                MaxVxM =round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-10]),2)
                pos1yr= round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]),2)
                #df["RangeBND"] = is_range_bound(dataR, window=200, slope_threshold=0.02)
                #print(df['Volume'].iloc[-1])
                #df["MaxVx"] = df['Volume'].rolling(window=25*3).apply(rolling_two_largest, raw=True).mean(axis=1)
                #try:
                #    df["MaxVx1"] = df['Volume'].rolling(window=252*3).max() #tb.MAX(df['Volume'], timeperiod=252*3)
                #    MaxVxmax = df["MaxVx1"].iloc[-7]*.70
                #    df["MaxVx"] = df['Volume'].rolling(window=(252*3)).apply(lambda x: x.nlargest(2).mean(), raw=True)
                #    MaxVx1 = round(df['Volume'].iloc[-1]/df["MaxVx"].iloc[-3],2)
                #    #print(df["MaxVx"].iloc[-1])
                #    print(df["MaxVx22"])
                #except Exception as e:
                #    MaxVx1 = 0
                #    #print(f"csvVXdaily error: {e}")
                #print(df['Volume'].iloc[-1])
                #print(df["MaxVx"]==df["MaxVx1"])

                DD_PCT=int(df["DD_PCT"].iloc[-1])
                DD15yr= f"{int(DD_PCT)}%"
                NSE570s = "Y" if base_name in NSE570symbols  else ""
                Base_name=symbol_to_company.get(base_name, base_name)
                if  df["Close"].iloc[-1] < 0 and df["EMA_14cal252_mrp"].iloc[-1] < cal252_mrp.iloc[-1] > 1.8 and (df["ADX"].iloc[-1] > 28 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] or df["RSI"].iloc[-1] > 55 or df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1]) and df["ST"].iloc[-1] < df['Close'].iloc[-1] and df['EMA_30'].iloc[-1] > df['EMA_100'].iloc[-1]:
                    #print(base_name,"MRP>4")
                    #print(f"{total_files} files {Base_name} cal252_mrp     >>>>>>>Greater 2.5  : {cal252_mrp.iloc[-1]}")
                    results_listGreater.append([Base_name,NSE570s, cal252_mrp.iloc[-1],round(df['MRP'].iloc[-1], 3),int(df["ADX"].iloc[-1]),int(df["RSI"].iloc[-1]),int(df["CCI"].iloc[-1])])


                if df["Close"].iloc[-1] < 0 and df["EMA_14cal252_mrp"].iloc[-1] > cal252_mrp.iloc[-1] < 1.5 and (df["ADX"].iloc[-1] < 24 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1]*100 or df["ADXavg"].iloc[-1]*100 < df["ADX"].iloc[-1] or df["RSI"].iloc[-1] < df["RSIavg"].iloc[-1] or df["RSI"].iloc[-1] < 50)  and df["ST"].iloc[-1] > df['Close'].iloc[-1] and df['EMA_30'].iloc[-1] < df['EMA_100'].iloc[-1]:
                    #print(base_name,"MRP<1")
                    #print(f"{total_files} files {Base_name} cal252_mrp   <<<<Lower 1  : {cal252_mrp.iloc[-1]}")
                    results_listLower.append([Base_name,NSE570s, cal252_mrp.iloc[-1],round(df['MRP'].iloc[-1], 3),int(df["ADX"].iloc[-1]),int(df["RSI"].iloc[-1]),int(df["CCI"].iloc[-1])])
                #print(df["ROC_2"])

                if df["Close"].iloc[-1] < 0 and len(df) > 0 and get_roc30_2yrL_index(df)[0] > 0 :
                    #print(f"{total_files} files {Base_name} -- ROC {get_roc30_2yrL_index(df)[0]} , OBV {get_roc30_2yrL_index(df)[1]} & cal252_mrp {cal252_mrp.iloc[-1]}")
                    results_listget_roc30_2yrL_index.append([Base_name,NSE570s, get_roc30_2yrL_index(df)[0], get_roc30_2yrL_index(df)[1], cal252_mrp.iloc[-1],round(df['MRP'].iloc[-1], 3),int(df["ADX"].iloc[-1]),int(df["RSI"].iloc[-1]),int(df["CCI"].iloc[-1]),DD15yr,pos1yr])

                if df["Close"].iloc[-1] < 0 and len(df) > 0 and get_roc30_2yrH_index(df)[0] < 0 :
                    #print(f"{total_files} files {Base_name} -- ROC {get_roc30_2yrH_index(df)[0]} , OBV {get_roc30_2yrH_index(df)[1]} & cal252_mrp {cal252_mrp.iloc[-1]}")
                    results_listget_roc30_2yrH_index.append([Base_name,NSE570s, get_roc30_2yrH_index(df)[0], get_roc30_2yrH_index(df)[1], cal252_mrp.iloc[-1],round(df['MRP'].iloc[-1], 3),int(df["ADX"].iloc[-1]),int(df["RSI"].iloc[-1]),int(df["CCI"].iloc[-1]),DD15yr,pos1yr])

                #Candles(Candleslist =Candleslist,symbol_to_company=symbol_to_company,df=df,base_name=base_name,cal252_mrp=cal252_mrp,NSE570symbols=NSE570symbols)

                if df["Score_18"].iloc[-1] < df["Score"].iloc[-1] > 1 and all(df['Score'].iloc[-2:] > 1) and len(df) > 0  :
                    Score = round(df["Score"].iloc[-1],1)
                    Base_name=symbol_to_company.get(base_name, base_name)
                    DD_PCT=int(df["DD_PCT"].iloc[-1])
                    DD_PCT=f"{int(DD_PCT)}%"
                    VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                    RSI = int(df["RSI"].iloc[-1])
                    ADX = int(df["ADX"].iloc[-1])
                    CCI = int(df["CCI"].iloc[-1])
                    #lower_bound = df["SMA_200"].iloc[-90] * 0.85 and df["SMA_200"].iloc[-180] * 0.85
                    #upper_bound = df["SMA_200"].iloc[-90] * 1.15 and df["SMA_200"].iloc[-180] * 1.15
                    current_value = df["SMA_200"].iloc[-30]
                    latest_value = df["SMA_200"].iloc[-1]
                    #Consolidation = "Y" if ((lower_bound <= current_value <= upper_bound) and (latest_value > current_value)) else ""

                    #lower_bound_90 = df["SMA_200"].iloc[-66] * 0.85
                    #lower_bound_180 = df["SMA_200"].iloc[-130] * 0.85
                    #upper_bound_90 = df["SMA_200"].iloc[-66] * 1.15
                    #upper_bound_180 = df["SMA_200"].iloc[-130] * 1.15
                    #Consolidation = "Y" if (
                    #    (lower_bound_90 <= current_value <= upper_bound_90) and
                    #    (lower_bound_180 <= current_value <= upper_bound_180) and
                    #    (latest_value > current_value)
                    #) else ""
                    #is_range_Consolidation = (df["avgSTDDEV90"].iloc[-90]  < 2.5) and (df["avgSTDDEV90"].iloc[-130:-90].max() < 2.5 * 1)
                    #Consolidation =  "C" if is_range_Consolidation == True  else ""

                    is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                    #Consolidation =  "C" if is_range_Consolidation == True  else ""
                    #print(f"'minervini' {Base_name} , {Consolidation}")
                    #try:
                    detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                    #print(f"'minervini V' {Base_name} , {detect_V_shape1}")
                    #Consolidation =  "V" if detect_V_shape1 == True  else ""
                    Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")
                    #print(f"'minervini Final' {Base_name} , {Consolidation}")
                    #except Exception as e:
                    #    print(f"Error processing detect_V_shape {Base_name}: {str(e)}")
                    #    traceback_str = traceback.format_exc()
                    #    # Print detailed error information
                    #    print("Error type:", e.__class__.__name__)
                    #    print("Error message:", str(e))
                    #    print("Traceback:\n", traceback_str)
                    #    pass
                    #print(f'{Base_name} , {Consolidation}')
                    MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                    NSE570s = "Y" if base_name in NSE570symbols  else ""
                    ROC_14= int(df['ROC_30'].iloc[-1])
                    OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-2],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
                    OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-2],2)
                    OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
                    #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
                    #ROC30_2yrL = get_roc30_2yrL_index(df)
                    LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                    #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                    LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                    #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                    #MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                    MRP= f"{round(df['MRP'].iloc[-1], 2)}"
                    UD= f"{'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0 else ''}"
                    ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                    CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,0)
                    data = {
                            "Company": Base_name,
                            "Score": Score,
                            "N570":NSE570s,
                            "C": Consolidation,
                            "ROC_30": ROC_14,
                            "MRP": MRP,
                            "U/D": UD,
                            "RSI": RSI,
                            "CCI": CCI,
                            "ADX": ADX,
                            "MACD":MACD,
                            #"ROC_2": ROC_2,
                            "ST":ST,
                            #"EXP20":LNEXP20,
                            #"EXP50":LNEXP50,
                            #"MA200UP":SMA200UP,
                            "OBVchg":OBVchg,
                            #"VX": VX,
                            "CH52wk%":CH52wk,
                            "Pos1yr":pos1yr,
                            "DD%15yr": DD_PCT
                            }
                        # Append the dictionary to DDPCTlist
                    Scoretickers.append(data)



                if  df["Score"].iloc[-1] > -99999 :
                    Score = round(df["Score"].iloc[-1],4)
                    Closex = round(df["Close"].iloc[-1],2)
                    Base_name=symbol_to_company.get(base_name, base_name)
                    AvgScore = "Y" if all(df['Score'].iloc[-2:] > 1) else "N"
                    ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                    CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,0)
                    data = {
                            "Company": Base_name,
                            "Ticker":  base_name,
                            "Close": Closex,
                            "52wkDD": round(df["DD_LOG"].iloc[-1],1),
                            "RSI24": int(df["RSI14"].iloc[-1]),
                            "CCI": int(df["CCI"].iloc[-1]),
                            "Supertrend": ST,
                            "CH52wk":CH52wk,
                            "Stock/Nifty": round(df["MRP"].iloc[-1],2),
                            "weighted_MR": round(df["weighted_MR"].iloc[-1],2),
                            "weighted_excessMR" : round(df["weighted_excessMR"].iloc[-1],2),
                            "Score": Score,
                            "AvgScore" : AvgScore
                            }
                        # Append the dictionary to DDPCTlist
                    Scoretickersall.append(data)





                    #Scoretickers.append([Base_name,NSE570s,cal252_mrp.iloc[-1],round(df['MRP'].iloc[-1], 3),int(df["ADX"].iloc[-1]),int(df["RSI"].iloc[-1]),int(df["CCI"].iloc[-1]),DD15yr,pos1yr])

                #if base_name in TJI_IC_path:
                if base_name in TJI_IC_path:  #base_name in NSE570symbols:
                    if len(df) > 0  and (pos1yr > .75 or pos1yr < .35) : #and df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1] and df["SMA_200"].iloc[-1] > df["SMA_200_15"].iloc[-1] and df["Close"].iloc[-1] > df["52wkL"].iloc[-1]*1.25 and df["Close"].iloc[-1] > df["52wkH"].iloc[-1]*.75 and df["RSI14avg"].iloc[-5] < df["RSI14"].iloc[-1] > 70  :  #df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0:and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        Score = round(df["Score"].iloc[-1],2)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        #NSE570s = "Y" if base_name in NSE570symbols  else ""
                        ROC_14= int(df['ROC_30'].iloc[-1])
                        OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
                        OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2)
                        OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
                        #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
                        #ROC30_2yrL = get_roc30_2yrL_index(df)
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                        detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                        #Consolidation =  "V" if detect_V_shape1 == True  else ""
                        Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")
                        if Consolidation != "":
                            TJItickers.append(file_name)
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        #MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        #MRP= f"{round(df['MRP'].iloc[-1], 2)}"
                        MRP= cal252_mrp.iloc[-1]
                        MRPD ="UP" if (df["EMA_14cal252_mrp"].iloc[-1] < cal252_mrp.iloc[-1] and nifty_data['EMA_200'].iloc[-1] < nifty_data['EMA_50'].iloc[-1] < nifty_data["Close"].iloc[-1] and RSI > 40) else ""
                        #MRP = MRP.iloc[-1] if MRP.iloc[-1] is not Nan else MRP.iloc[-2]
                        #print(Base_name,cal252_mrp)
                        UD= "UP" if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else ""
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,0)
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""   # and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        if len(df) > 0 and df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1] and df["SMA_200"].iloc[-1] > df["SMA_200_15"].iloc[-1] and df["Close"].iloc[-1] > df["52wkL"].iloc[-1]*1.25 and df["Close"].iloc[-1] > df["52wkH"].iloc[-1]*.75 and df["RSI14avg"].iloc[-5] < df["RSI14"].iloc[-1] > 60  :
                            M = "Y"
                        else:
                            M =""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "MV" : M,
                                    "Score":Score,
                                    "C":Consolidation,
                                    #"N570":NSE570s,
                                    "ROC_30": ROC_14,
                                    "MRP1yr": MRP,
                                    "MRPS":MRPD,
                                    "MRPL": UD,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    #"ROC_2": ROC_2,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    #"EXP50":LNEXP50,
                                    "MA200UP":SMA200UP,
                                    "OBVchg":OBVchg,
                                    "VX": VX,
                                    "CH52wk%":CH52wk,
                                    "Ps1yr":pos1yr,
                                    "DD%3yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        TJI.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)
                #continue


                    ######################
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["Score_18"].iloc[-1] < df["Score"].iloc[-1] > 1 and all(df['Score'].iloc[-2:] > 1) and df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1] and df["SMA_200"].iloc[-1] > df["SMA_200_15"].iloc[-1] and df["Close"].iloc[-1] > df["52wkL"].iloc[-1]*1.25 and df["Close"].iloc[-1] > df["52wkH"].iloc[-1]*.75 and df["RSI14avg"].iloc[-5] < df["RSI14"].iloc[-1] > 60  :  #df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0:and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        Score = round(df["Score"].iloc[-1],2)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        #lower_bound = df["SMA_200"].iloc[-90] * 0.85 and df["SMA_200"].iloc[-180] * 0.85
                        #upper_bound = df["SMA_200"].iloc[-90] * 1.15 and df["SMA_200"].iloc[-180] * 1.15
                        current_value = df["SMA_200"].iloc[-30]
                        latest_value = df["SMA_200"].iloc[-1]
                        #Consolidation = "Y" if ((lower_bound <= current_value <= upper_bound) and (latest_value > current_value)) else ""

                        #lower_bound_90 = df["SMA_200"].iloc[-66] * 0.85
                        #lower_bound_180 = df["SMA_200"].iloc[-130] * 0.85
                        #upper_bound_90 = df["SMA_200"].iloc[-66] * 1.15
                        #upper_bound_180 = df["SMA_200"].iloc[-130] * 1.15
                        #Consolidation = "Y" if (
                        #    (lower_bound_90 <= current_value <= upper_bound_90) and
                        #    (lower_bound_180 <= current_value <= upper_bound_180) and
                        #    (latest_value > current_value)
                        #) else ""
                        #is_range_Consolidation = (df["avgSTDDEV90"].iloc[-90]  < 2.5) and (df["avgSTDDEV90"].iloc[-130:-90].max() < 2.5 * 1)
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""

                        is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        #print(f"'minervini' {Base_name} , {Consolidation}")
                        #try:
                        detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                        #print(f"'minervini V' {Base_name} , {detect_V_shape1}")
                        #Consolidation =  "V" if detect_V_shape1 == True  else ""
                        Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")
                        #print(f"'minervini Final' {Base_name} , {Consolidation}")
                        #except Exception as e:
                        #    print(f"Error processing detect_V_shape {Base_name}: {str(e)}")
                        #    traceback_str = traceback.format_exc()
                        #    # Print detailed error information
                        #    print("Error type:", e.__class__.__name__)
                        #    print("Error message:", str(e))
                        #    print("Traceback:\n", traceback_str)
                        #    pass
                        #print(f'{Base_name} , {Consolidation}')
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        ROC_14= int(df['ROC_30'].iloc[-1])
                        OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-2],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
                        OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-2],2)
                        OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
                        #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
                        #ROC30_2yrL = get_roc30_2yrL_index(df)
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        #MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        MRP= f"{round(df['MRP'].iloc[-1], 2)}"
                        UD= f"{'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0 else ''}"
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,0)
                        #SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""   # and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "Score":Score,
                                    "N570":NSE570s,
                                    "C": Consolidation,
                                    "ROC_30": ROC_14,
                                    "MRP": MRP,
                                    "U/D": UD,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    #"ROC_2": ROC_2,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    #"EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBVchg":OBVchg,
                                    "VX": VX,
                                    "CH52wk%":CH52wk,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        minervini.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)
                        minervinitickers.append(file_name)

                        '''
                        try:
                            filepathpdf = '/home/rizpython236/BT5/screener-outputs/minervini_Charts.pdf'
                            with PdfPages(filepathpdf) as pdf:
                                dfM = df.copy()
                                dfM['Date'] = pd.to_datetime(dfM['Date'])  # Convert index to datetime

                                # 1. Combined Price, Volume, RSI Chart
                                fig_combined = plt.figure(figsize=(11, 8.5))
                                #gs = fig_combined.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                                gs = fig_combined.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])

                                # Price chart (line plot)
                                ax1 = fig_combined.add_subplot(gs[0])
                                ax1.plot(dfM['Date'], dfM['Close'], label='Price', color='black', linewidth=1)

                                # Plot SMAs on top of line chart
                                ax1.plot(dfM['Date'], dfM['SMA_50'], label='SMA 50', color='blue', linewidth=1.5)
                                ax1.plot(dfM['Date'], dfM['SMA_150'], label='SMA 150', color='orange', linewidth=1.5)
                                ax1.plot(dfM['Date'], dfM['SMA_200'], label='SMA 200', color='red', linewidth=1.5)
                                ax1.plot(dfM['Date'], dfM['SMA_200_15'], label='SMA 200(15)', color='purple', linewidth=1.5)

                                ax1.set_title(f'{Base_name} Price and Moving Averages', fontsize=14)
                                ax1.legend()

                                # Volume chart
                                ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                                ax2.bar(dfM['Date'], dfM['Volume']/ 1000, color='blue', width=0.5, alpha=0.5)
                                #ax2.set_title('Volume', fontsize=12)
                                #ax2.set_ylabel('Volume')
                                #ax2.set_title('Volume (in thousands)', fontsize=12)  # Update title to reflect units
                                ax2.set_ylabel('Volume (K)')  # Change y-axis label to indicate thousands

                                # RSI chart
                                ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                                ax3.plot(dfM['Date'], dfM["RSI14"], color='purple', label='RSI')
                                ax3.axhline(70, color='red', linestyle='--', alpha=0.5)
                                ax3.axhline(30, color='green', linestyle='--', alpha=0.5)
                                ax3.fill_between(dfM['Date'], 70, dfM["RSI14"],
                                               where=(dfM["RSI14"] >= 70), color='red', alpha=0.3)
                                ax3.fill_between(dfM['Date'], 30, dfM["RSI14"],
                                               where=(dfM["RSI14"] <= 30), color='green', alpha=0.3)
                                ax3.set_title('RSI (14)', fontsize=12)
                                ax3.set_ylim(0, 100)
                                ax3.legend()

                                # CCI chart
                                ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                                ax4.plot(dfM['Date'], dfM["CCI"], color='purple', label='CCI')
                                ax4.axhline(0, color='red', linestyle='--', alpha=0.5)
                                ax4.axhline(50, color='green', linestyle='--', alpha=0.5)
                                ax4.fill_between(dfM['Date'], 0, dfM["CCI"],
                                               where=(dfM["CCI"] <= 0), color='red', alpha=0.3)
                                ax4.fill_between(dfM['Date'], 50, dfM["CCI"],
                                               where=(dfM["CCI"] >= 50), color='green', alpha=0.3)
                                ax4.set_title('CCI (34)', fontsize=12)
                                ax4.set_ylim(-100, 150)
                                ax4.legend()

                                # Format x-axis to show labels on a quarterly basis
                                plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))  # Quarterly labels
                                plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format as 'YYYY-MM'
                                plt.xticks(rotation=90)
                                #plt.tight_layout()
                                # Reduce margins using tight_layout with padding adjustments
                                plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)  # Adjust padding as needed
                                #pdf.savefig(fig_combined)
                                pdf.savefig(fig_combined, bbox_inches='tight')

                                folder_path='/home/rizpython236/BT5/screener-outputs/'
                                file_path = os.path.join(folder_path)
                                chart_path = os.path.join(folder_path, f'minervini_{Base_name}.png')
                                plt.savefig(chart_path)
                                time.sleep(3)
                                post_telegram_file(chart_path)
                                os.remove(chart_path)
                                #if total_files == symNo:
                                plt.close(fig_combined)

                                # 2. Individual Price Chart (larger)
                                #fig_price = plt.figure(figsize=(11, 6))
                                #plt.plot(dfM.index, dfM['Close'], label='Price', color='black', linewidth=1)
                                #plt.title(f'{Base_name} Detailed Price Chart', fontsize=14)
                                #plt.tight_layout()
                                #pdf.savefig(fig_price)
                                #plt.close(fig_price)

                                # Add metadata
                                d = pdf.infodict()
                                d['Title'] = f'{Base_name} Technical Analysis Report'
                                d['Author'] = 'Automated Report Generator'

                            print(f"Generated report for {Base_name} at: {filepathpdf}")

                        except Exception as e:
                            print(f"Error processing {Base_name}: {str(e)}")
                            traceback_str = traceback.format_exc()
                        '''



                    ######################
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["Close"].iloc[-1] < 0 and ((df["ROC_22movavg"].iloc[-1] > 1 and df['EMA_14MRP'].iloc[-1] > df['EMA_30MRP'].iloc[-1]*1 and cal252_mrp.iloc[-1] > 2.5 and (df["ADX"].iloc[-1] > 28 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] )) or ( df["ROC_22movavg"].iloc[-1] < 0 and df['EMA_14MRP'].iloc[-1] < df['EMA_30MRP'].iloc[-1]*1 and cal252_mrp.iloc[-1] < 1.1 and (df["ADX"].iloc[-1] < 24 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] ) and df['High_Lower'].iloc[-1] )) and (round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2) > 1.01 or round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2) < .99 ) :  #df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0:and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        ROC_14= int(df['ROC_30'].iloc[-1])
                        OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
                        OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2)
                        OBVchg = f"{OBVchg1 if ROC_14 > 0 else OBVchg2}"
                        #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
                        #ROC30_2yrL = get_roc30_2yrL_index(df)
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        #MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        MRP= f"{round(df['MRP'].iloc[-1], 2)}"
                        UD= f"{'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0 else ''}"
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""   # and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "ROC_30": ROC_14,
                                    "MRP": MRP,
                                    "U/D": UD,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    #"ROC_2": ROC_2,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBVchg":OBVchg,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        MRHigerHigh.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)




                    ######################
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["Close"].iloc[-1] < 0 and ((df["ROC_2movavg"].iloc[-1] > 4 and df['EMA_14MRP'].iloc[-1] > df['EMA_30MRP'].iloc[-1]*1 and df['High_higher'].iloc[-1] and df['Low_higher'].iloc[-1] and (df["ADX"].iloc[-1] > 28 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] )) or ( df["ROC_2movavg"].iloc[-1] > -4 and df['EMA_14MRP'].iloc[-1] < df['EMA_30MRP'].iloc[-1]*1 and df['High_Lower'].iloc[-1] and df['High_lower12'].iloc[-1] and(df["ADX"].iloc[-1] < 24 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] ) )) and (round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2) > 1.05 or round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2) < .95 ) :  #df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0:and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        ROC_14= int(df['ROC_5'].iloc[-1])
                        ROC_30= int(df['ROC_30'].iloc[-1])
                        #OBVchg = round(df['OBV'].iloc[-1]/min(df["OBV"].iloc[-22],1),2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"

                        OBVchg1 = round(df['OBV'].iloc[-1]/df['MinOBV30'].iloc[-5],2)    #"UP" if (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else "DWN"
                        OBVchg2 = round(df['OBV'].iloc[-1]/df['MaxOBV30'].iloc[-5],2)
                        OBVchg = f"{OBVchg1 if ROC_30 > 0 else OBVchg2}"
                        #OBVchg = round(df['OBV'].iloc[-1]/median(df["OBV"].iloc[-22:]),2)
                        #is_range_Consolidation = (df["avgSTDDEV90"].iloc[-90]  < 2.5) and (df["avgSTDDEV90"].iloc[-130:-90].max() < 2.5 * 1)
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""

                        detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                        #Consolidation =  "V" if detect_V_shape1 == True  else ""
                        Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")
                        #ROC30_2yrL = get_roc30_2yrL_index(df)
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        #CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,1)
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""   # and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "C":Consolidation,
                                    "ROC_5": ROC_14,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP": MRP,
                                    #"ROC_2": ROC_2,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBVchg":OBVchg,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    #"CH52wk%":CH52wk,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        HigerHigh.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)
                        #HigerHightickers.append(file_name)




                    ######################
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["Close"].iloc[-1] < 0  and  df['ROC_30'].iloc[-1] > 12 and (df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] or df["ADX"].iloc[-1] > 25 ) and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and df["DD_PCT"].iloc[-1] < 70 and  0 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and df['Close'].iloc[-1] > df['EMA_30'].iloc[-1] and df['EMA_14MRP'].iloc[-1] > df['EMA_30MRP'].iloc[-1]*1:  #df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.0:and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        #ROC30_2yrL ="UP" if (df["Close"].iloc[-90:] == df["2yrL"].iloc[-1]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        ROC30_2yrL = get_roc30_2yrL_index(df)[0]
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        ROC_30= int(df['ROC_30'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "ROC_30": ROC_30,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP": MRP,
                                    #"ROC_2": ROC_2,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "ROC30_2yrL":ROC30_2yrL,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        L2yr30_ROC.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)



                    ######################
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and (df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] or df["ADX"].iloc[-1] > 25) and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and df["DD_PCT"].iloc[-1] < 10 and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 and df['EMA_14MRP'].iloc[-1] > df['EMA_30MRP'].iloc[-1]*1:#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["52wkL"].iloc[-1]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""

                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "ROC1": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP": MRP,
                                    #"ROC_2": ROC_2,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBV52wk":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        DDPCTlist.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                #is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                #detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                #Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["Score_18"].iloc[-1] < df["Score"].iloc[-1] > 1 and all(df['Score'].iloc[-2:] > 1) and df["Close"].iloc[-1] > df["SMA_50"].iloc[-1] > df["SMA_150"].iloc[-1] > df["SMA_200"].iloc[-1]  and df["ROC_2movavg"].iloc[-1] > -10 and (pos1yr > .80 or df["DD_PCT"].iloc[-1] < 20) and (df["ADX"].iloc[-1] > 28 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] ) and (df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] or df["CCI"].iloc[-1]  > 0) and  55 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 and df['EMA_14MRP'].iloc[-1] > df['EMA_30MRP'].iloc[-1]*1 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        Score = round(df["Score"].iloc[-1],2)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        #is_range_Consolidation = (df["avgSTDDEV90"].iloc[-90]  < 2.5) and (df["avgSTDDEV90"].iloc[-130:-90].max() < 2.5 * 1)
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                        #Consolidation =  "V" if detect_V_shape1 == True  else ""
                        #Consolidation= "V" if detect_V_shape1 else ("" if Consolidation != "C" else Consolidation)
                        Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")
                        if Consolidation != "":
                            Pos1yrHightickers.append(file_name)
                        MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["OBV"].iloc[-30]*1.7 < df["OBV"].iloc[-1]) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        CH52wk = round(((df["Close"].iloc[-1]/df["52wkL"].iloc[-1])-1)*100,0)
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataPos1yrHigh = {
                                    "Company": Base_name,
                                    "SCR":Score,
                                    "N570":NSE570s,
                                    "C":Consolidation,
                                    "ROC1": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP":MRP,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBTH":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    "CH52wk%":CH52wk,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        Pos1yrHigh.append(dataPos1yrHigh)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)


                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["macdhist"].iloc[-1] > -100 and df["ROC_2movavg"].iloc[-1] > -10 and (pos1yr < .80 or df["DD_PCT"].iloc[-1] > -100) and (df["ADX"].iloc[-1] > 28 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] ) and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -1000 and df['EMA_14MRP'].iloc[-1] > df['EMA_30MRP'].iloc[-1]*1 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        ROC30_2yrL = get_roc30_2yrL_index(df)[0]
                        MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["OBV"].iloc[-30]*1.7 < df["OBV"].iloc[-1]) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataPos1yrlow = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "ROC1": ROC_2,
                                    "ROC_2yrL": ROC30_2yrL,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP":MRP,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBV_CATH":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        Pos1yrlow.append(dataPos1yrlow)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)


                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and MaxVx > 1 and df['quantile'].iloc[-7]*1 < df["Volume"].iloc[-1] :#  df['quantile'].iloc[-7] and pos1yr > .70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= MaxVxM
                        MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        #is_range_Consolidation = (df["avgSTDDEV90"].iloc[-90]  < 2.5) and (df["avgSTDDEV90"].iloc[-130:-90].max() < 2.5 * 1)
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                        #Consolidation =  "V" if detect_V_shape1 == True  else ""
                        #Consolidation= "V" if detect_V_shape1 else ("" if Consolidation != "C" else Consolidation)
                        Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        datamaxVx = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "C":Consolidation,
                                    "ROC1": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP":MRP,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    #"OBV_CATH":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "MaxVX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        #print(datamaxVx)
                        maxVx.append(datamaxVx)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)



                if 2>0:#base_name in NSE570symbols:
                    if  df["Close"].iloc[-1] < 0  and ( df['SMA_91MRP'].iloc[-1] > df['SMA_200MRP'].iloc[-1]*1 and df['SMA_91MRP'].iloc[-5]*1 < df['SMA_200MRP'].iloc[-5]) or (df['SMA_91MRP'].iloc[-1] < df['SMA_200MRP'].iloc[-1]*1 and df['SMA_91MRP'].iloc[-5]*1 > df['SMA_200MRP'].iloc[-5])  :#  df['quantile'].iloc[-7] and pos1yr > .70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        MRP= round(df['MRP'].iloc[-1], 2)
                        MRPUPaa= (df['SMA_91MRP'].iloc[-1] > df['SMA_200MRP'].iloc[-1]*1 and df['SMA_91MRP'].iloc[-5]*1 < df['SMA_200MRP'].iloc[-5])
                        MRPDWaa= (df['SMA_91MRP'].iloc[-1]*1 < df['SMA_200MRP'].iloc[-1] and df['SMA_91MRP'].iloc[-5] > df['SMA_200MRP'].iloc[-5]*1)
                        #MRPUP1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] < df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRPDW1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else 'D'}"
                        MRPUP1= MRP if (MRPUPaa == True) else np.nan  #1234567890000
                        MRPDW1=  MRP if (MRPDWaa == True) else np.nan #1234567890000
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        #OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        #LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataMRPcross = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "MRPUP":MRPUP1,
                                    "MRPDW":MRPDW1,
                                    "ROC1": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    #"OBV_CATH":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "MaxVX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        #print(datamaxVx)
                        MRPcross.append(dataMRPcross)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                    #(df["ADX"].iloc[-1] > 28 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] )
                    #(df["ADX"].iloc[-1] < 24 or df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] )


                Base_name=symbol_to_company.get(base_name, base_name)
                NSE570s = "Y" if base_name in NSE570symbols  else ""
                if 2>0:#base_name in NSE570symbols:
                    if ((df['SMA_100'].iloc[-1]*1 < df['SMA_200'].iloc[-1] or df['EMA_100'].iloc[-1]*1 < df['EMA_200'].iloc[-1] ) and df['EMA_14MRP'].iloc[-1] > df['EMA_30MRP'].iloc[-1]):# and NSE570s == "Y" :#  df['quantile'].iloc[-7] and pos1yr > .70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        MRP= round(df['MRP'].iloc[-1], 2)
                        #MRPUPaa= (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 and df['SMA_30MRP'].iloc[-5]*1.05 < df['SMA_90MRP'].iloc[-5])
                        #MRPDWaa= (df['SMA_30MRP'].iloc[-1]*1.05 < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]*1.05)
                        #MRPUP1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] < df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRPDW1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else 'D'}"
                        #MRPUP1= MRP if (MRPUPaa == True) else np.nan  #1234567890000
                        #MRPDW1=  MRP if (MRPDWaa == True) else np.nan #1234567890000
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        #is_range_Consolidation = (df["avgSTDDEV90"].iloc[-90]  < 2.5) and (df["avgSTDDEV90"].iloc[-130:-90].max() < 2.5 * 1)
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        is_range_Consolidation =  detect_bollinger_squeeze_breakout(data52["Close"])
                        #Consolidation =  "C" if is_range_Consolidation == True  else ""
                        detect_V_shape1= detect_V_shape(data52["Close"],Slope_threshold=0.02,allow_equal=True,left_ratio=0.7)
                        #Consolidation =  "V" if detect_V_shape1 == True  else ""
                        #Consolidation= "V" if detect_V_shape1 else ("" if Consolidation != "C" else Consolidation)
                        Consolidation= "V" if detect_V_shape1 else ("C" if is_range_Consolidation == True else "")

                        #OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        #LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] < df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        try:
                            sma_crossover = df[df['EMA_200'] > df['EMA_100'] * 1]['EMA_200'].iloc[-1]
                            SMA200pctnumber = int((df['Close'].iloc[-1] - sma_crossover) / sma_crossover * 100)
                        except Exception as e:
                            SMA200pctnumber= 0
                            pass
                        #SMA200pct= SMA200pctnumber if (SMA200pctnumber > -10) else np.nan #1234567890000
                        #SMA200UP = "DW" if df["EMA_200"].iloc[-1] > df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataSMAcross = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "C":Consolidation,
                                    #"MRPUP":MRPUP1,
                                    #"MRPDW":MRPDW1,
                                    "MRP":MRP,
                                    "ROC1": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    #"OBV_CATH":OBV52wk,
                                    #"EMA200":SMA200UP,
                                    "MaxVX": VX,
                                    "SMA200pct":SMA200pctnumber,
                                    "Pos1yr":pos1yr,
                                    "DD%15yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        #print(datamaxVx)
                        SMAcross.append(dataSMAcross)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                ##########################
    except Exception as e:
        print(f"csvVXdaily  {base_name} error: {e}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass


#print(results_dfget_roc30_2yrL_index)
if len(Candleslist) > 0:
    Candleslist = pd.DataFrame(Candleslist)
    Candleslist = Candleslist.sort_values(by="Candle", ascending=False)
    Candleslist = Candleslist.dropna(subset=['candle '])
    Candleslist.fillna("", inplace=True)
    Candleslist.to_csv('/home/rizpython236/BT5/screener-outputs/Candleslist.csv', index=False)
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/Candleslist.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Candleslist.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
    time.sleep(5)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/Candleslist.pdf')

##########################
print("__________________________________________________________")

results_dfget_roc30_2yrL_index= pd.DataFrame(results_listget_roc30_2yrL_index, columns=['Company Name','N','ROC','OBV', 'YrlMRP','MRP','ADX','RSI','CCI','DD2yr','Pos52'])
results_dfget_roc30_2yrH_index= pd.DataFrame(results_listget_roc30_2yrH_index, columns=['Company Name','N','ROC','OBV', 'YrlMRP','MRP','ADX','RSI','CCI','DD2yr','Pos52'])
results_dfGreater = pd.DataFrame(results_listGreater, columns=['Company NameG','NG', 'YMRPG','MRPG','ADXG','RSIG','CCIG'])
results_dfLower = pd.DataFrame(results_listLower, columns=['Company NameL','NL', 'YMRPL','MRPL','ADXL','RSIL','CCIL'])

# Sort both DataFrames by 'Cal252_MRP' in descending order
results_dfGreater = results_dfGreater.sort_values(by='YMRPG', ascending=False).reset_index(drop=True)
results_dfLower = results_dfLower.sort_values(by='CCIL', ascending=False).reset_index(drop=True)
results_dfget_roc30_2yrL_index = results_dfget_roc30_2yrL_index.sort_values(by='OBV', ascending=False).reset_index(drop=True)
results_dfget_roc30_2yrH_index = results_dfget_roc30_2yrH_index.sort_values(by='OBV', ascending=True).reset_index(drop=True)

#print(results_dfget_roc30_2yrL_index)
if len(results_dfget_roc30_2yrL_index) > 0:
    results_dfget_roc30_2yrL_index.to_csv('/home/rizpython236/BT5/screener-outputs/roc30_2yrL.csv', index=False)
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/roc30_2yrL.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/roc30_2yrL.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
    time.sleep(5)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/roc30_2yrL.pdf')


print("__________________________________________________________")



#print(results_dfget_roc30_2yrH_index)
if len(results_dfget_roc30_2yrH_index) > 0:
    results_dfget_roc30_2yrH_index.to_csv('/home/rizpython236/BT5/screener-outputs/roc30_2yrH.csv', index=False)
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/roc30_2yrH.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/roc30_2yrH.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
    time.sleep(5)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/roc30_2yrH.pdf')


print("__________________________________________________________")


# Merge the DataFrames horizontally
#merged_df = pd.merge(results_dfGreater, results_dfLower, left_index=True, right_index=True,)
merged_df = pd.merge(results_dfGreater, results_dfLower, left_index=True, right_index=True, how='outer')
merged_df.to_csv('/home/rizpython236/BT5/screener-outputs/Cal252_MRP_Greater_Lower.csv', index=False)

if len(merged_df) > 0:
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/Cal252_MRP_Greater_Lower.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Cal252_MRP_Greater_Lower.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
    time.sleep(5)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/Cal252_MRP_Greater_Lower.pdf')

# Temporarily set the display option to show all rows
with pd.option_context('display.max_rows', None):
    #print(results_dfGreater)
    print("__________________________________________________________")
    #print(results_dfLower)

# Reset the display option to the default value (optional)
pd.reset_option('display.max_rows')

print("__________________________________________________________")




'''
#expLonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
#expSonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
EFIU.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
EFID.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
SMA_V7SMA_V40.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkL.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkH.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkrange.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
SMAUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
SMADWN.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIDWN.sort(key=lambda x: float(x.split('***')[-1]), reverse= False) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
#DDPCTlist.sort(key=lambda x: float(x.split('***')[-1]), reverse=True)
MRPUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
MRPDWN.sort(key=lambda x: float(x.split('***')[-1]), reverse=False) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
'''
'''
#indiceNOSHORT.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOSHORT[0] = 'Indices Exp lin Short-Long'

#indiceNOLONG.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOLONG[0] = 'Indices Exp lin Long'

for i in range(0, len(indiceNOSHORT), 35):
        block = indiceNOSHORT[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        ##post_telegram_message('\n'.join(block))

for i in range(0, len(indiceNOLONG), 35):
        block = indiceNOLONG[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        #post_telegram_message('\n'.join(block))
'''
# Calculate percentages
#Exp_percentage_mores40 = (S_TTMSqueeze / total_files) * 100
#print(Exp_percentage_mores40)

#mrp25_percentage_mores10 = (mrp25_count_mores10 / total_files) * 100
#mrp13_percentageless0 = (CountBExp / total_files) * 100
#mrp13_percentagemore0 = (mrp13_count_more0 / total_files) * 100
#mrp25_percentageless0 = (mrp25_count_less0 / total_files) * 100
#mrp25_percentagemore0 = (mrp25_count_more0 / total_files) * 100
#mrp25_percentagebothless0 = (mrp13_countbothless0 / total_files) * 100
#mrp25_percentagebothmore0 = (mrp25_countbothmore0 / total_files) * 100
#df = pd.DataFrame({'RP': file_names})
#df = pd.DataFrame({'BullCandle': Bullish})
#df = pd.DataFrame({'BearCandle': Bearish})
BUYmax_length = max(len(file_names), len(BExpShort), len(BExplong), len(B52High) , len(BRSI),len(BMRP),len(BBBTTM),len(B_DD_PCT_30) )
SELLmax_length = max(len(file_names), len(S_TTMSqueeze),len(S_ROC), len(S_fall), len(S_DCH) , len(S_EMS),len(S_DD_PCT_30),)

expmax_length = max(len(file_names), len(expSonly),len(expLonly),len(BExpShort),len(BExplong),len(EFIU),len(EFID))#,len(indiceNO))
VXmax_length = max(len(file_names), len(EFIU),len(EFID),len(SMA_V7SMA_V40))
_52wk_length = max(len(file_names), len(_52wkH),len(_52wkL),len(_52wkrange))
SMA_length = max(len(file_names), len(SMAUP),len(SMADWN),len(SMADWN))
RSI_length = max(len(file_names), len(RSIUP),len(RSIDWN),len(RSIDWN))
#DDPCTlist_length = max(len(file_names), len(DDPCTlist),len(DDPCTlist),len(DDPCTlist))
MRP_length = max(len(file_names), len(MRPUP),len(MRPUP),len(MRPDWN))

'''
MRPlist_data = {
    'MRPUP*RSI**VX***MRP': MRPUP + ['--'] * (MRP_length - len(MRPUP)),
    'MRPDWN*RSI**VX***MRP': MRPDWN + ['--'] * (MRP_length - len(MRPDWN))
}


#DDPCTlist_data = {
#    'DD*RSI*VX*CCI*MRP***DDPCT': DDPCTlist + ['--'] * (DDPCTlist_length - len(DDPCTlist))
#}

RSI_data = {
    'RSIUP*CCI**Vx***RSI': RSIUP + ['--'] * (RSI_length - len(RSIUP)),
    'RSIDWN*CCI**Vx***RSI': RSIDWN + ['--'] * (RSI_length - len(RSIDWN))
    #'52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}


SMA_data = {
    'SMAUP*CCI**Vx***RSI': SMAUP + ['--'] * (SMA_length - len(SMAUP)),
    'SMADWN*CCI**Vx***RSI': SMADWN + ['--'] * (SMA_length - len(SMADWN))
    #'52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

_52wkdata = {
    '52wkH-RSI-CCI--UP': _52wkH + ['--'] * (_52wk_length - len(_52wkH)),
    '52wkL-pos1yr-RSI-CCI--DWN': _52wkL + ['--'] * (_52wk_length - len(_52wkL)),
    '52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

expdata = {
    'ExpShort-L--S': expSonly + ['--'] * (expmax_length - len(expSonly)),
    'ExpLong-S--L': expLonly + ['--'] * (expmax_length - len(expLonly))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

VXdata = {
    #'ExpShort-L--S': expSonly + ['--'] * (expmax_length - len(expSonly)),
    #'ExpLong-S--L': expLonly + ['--'] * (expmax_length - len(expLonly))
    'EFIUP-ROC-CCI--UP': EFIU + ['--'] * (VXmax_length - len(EFIU)),
    'EFIDWN-ROC-CCI--DWN': EFID + ['--'] * (VXmax_length - len(EFID)),
    'SMA_V7/V40-ROC--V': SMA_V7SMA_V40 + ['--'] * (VXmax_length - len(SMA_V7SMA_V40))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

BUYdata = {
    'TTM': BBBTTM + ['--'] * (BUYmax_length - len(BBBTTM)),
    #'ExpShort': BExpShort + ['--'] * (BUYmax_length - len(BExpShort)),
    #'Explong': BExplong + ['--'] * (BUYmax_length - len(BExplong)),
    'RSI': BRSI + ['--'] * (BUYmax_length - len(BRSI)),
    'DD_PCT_25': B_DD_PCT_30 + ['--'] * (BUYmax_length - len(B_DD_PCT_30)),
    '52High': B52High + ['--'] * (BUYmax_length - len(B52High)),
    'MRP': BMRP + ['--'] * (BUYmax_length - len(BMRP))
}

SELLdata = {
    'TTM': S_TTMSqueeze + ['--'] * (SELLmax_length - len(S_TTMSqueeze)),
    'ROC': S_ROC + ['--'] * (SELLmax_length - len(S_ROC)),
    'Fall': S_fall + ['--'] * (SELLmax_length - len(S_fall)),
    'DD_PCT_25': S_DD_PCT_30 + ['--'] * (SELLmax_length - len(S_DD_PCT_30)),
    'DCH': S_DCH + ['--'] * (SELLmax_length - len(S_DCH)),
    'SEMA200': S_EMS + ['--'] * (SELLmax_length - len(S_EMS))
}
'''


dfBUY = pd.DataFrame() #BUYdata
dfSELL = pd.DataFrame() #SELLdata
dfexpdata = pd.DataFrame() #expdata
dfVXdata = pd.DataFrame() #VXdata
df52wkdata = pd.DataFrame() #_52wkdata
dfSMA_data = pd.DataFrame() #SMA_data
dfRSI_data = pd.DataFrame() #RSI_data
#dfDDPCTlist_data =pd.DataFrame(DDPCTlist_data)
#dfMRPlist_data =pd.DataFrame(MRPlist_data)

#print(dfBUY)
#print(dfSELL)
#print(dfexpdata)


old52wkdataWkly_path = '/home/rizpython236/BT5/trade-logs/52wkdatadaily.csv'
old52wkdataWklydf = pd.read_csv(old52wkdataWkly_path)

'''
#dfBUY.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv', index=False)
#dfSELL.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv', index=False)
#dfexpdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv', index=False)
dfVXdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv', index=False)
dfSMA_data.to_csv('/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/trade-logs/52wkdatadaily.csv', index=False)
dfRSI_data.to_csv('/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv', index=False)
#dfDDPCTlist_data.to_csv('/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv', index=False)
dfMRPlist_data.to_csv('/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv', index=False)
'''
#print(DDPCTlist)
try:
    #print(DDPCTlist)
    if len(TJI) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        #L2yr30_ROC = [entry for entry in L2yr30_ROC if entry["ROC30_2yrL"] == 'UP']


        #minervini.sort(key=lambda row: (row["RSI"], row["ROC_30"]), reverse=True)
        #minervini.sort(key=lambda row: row["CH52wk"], reverse=True)

        #L2yr30_ROC.sort(key=lambda row: row["ROC_30"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(L2yr30_ROC)

        TJI = pd.DataFrame(TJI)
        TJI = TJI.sort_values(by="CH52wk%", ascending=False)

        matching_rows = TJI[TJI["C"].isin(["C", "V"])]
        non_matching_rows = TJI[~TJI["C"].isin(["C", "V"])]
        # Concatenate (matching first, non-matching last)
        TJI = pd.concat([matching_rows, non_matching_rows])
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        TJI.fillna("", inplace=True)
        TJI.to_csv('/home/rizpython236/BT5/screener-outputs/TJI.csv', index=False)
        #TJI.to_csv('/home/rizpython236/BT5/trade-logs/Minervini.csv', index=False)


        #L2yr30_ROC = L2yr30_ROC[L2yr30_ROC['ROC30_2yrL'].notna() | (L2yr30_ROC['ROC30_2yrL'] != "")] #filter
        ###########L2yr30_ROC = L2yr30_ROC[(L2yr30_ROC['ROC30_2yrL'].notna()) | (L2yr30_ROC['ROC30_2yrL'] != "")]
        #L2yr30_ROC.drop(columns=['ROC30_2yrL'], inplace=True , errors='ignore')
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        #L2yr30_ROC.to_csv('/home/rizpython236/BT5/screener-outputs/2yrlow_30_ROC.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"TJI.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/TJI.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/TJI.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/TJI.pdf')
    else:
      print("No data found to write to TJI.csv")
except Exception as e:
    print(f"Error in pdf TJI- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")




try:
    logsminervini = '/home/rizpython236/BT5/trade-logs/Minervini.csv'
    logsminervini = pd.read_csv(logsminervini)
except Exception as e:
    print(f"Error in log Minervini- {e}")

try:
    #print(DDPCTlist)
    if len(minervini) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        #L2yr30_ROC = [entry for entry in L2yr30_ROC if entry["ROC30_2yrL"] == 'UP']


        #minervini.sort(key=lambda row: (row["RSI"], row["ROC_30"]), reverse=True)
        #minervini.sort(key=lambda row: row["CH52wk"], reverse=True)

        #L2yr30_ROC.sort(key=lambda row: row["ROC_30"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(L2yr30_ROC)

        minervini = pd.DataFrame(minervini)
        minervini = minervini.sort_values(by="CH52wk%", ascending=False)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        minervini.fillna("", inplace=True)
        minervini.to_csv('/home/rizpython236/BT5/screener-outputs/Minervini.csv', index=False)
        minervini.to_csv('/home/rizpython236/BT5/trade-logs/Minervini.csv', index=False)


        #L2yr30_ROC = L2yr30_ROC[L2yr30_ROC['ROC30_2yrL'].notna() | (L2yr30_ROC['ROC30_2yrL'] != "")] #filter
        ###########L2yr30_ROC = L2yr30_ROC[(L2yr30_ROC['ROC30_2yrL'].notna()) | (L2yr30_ROC['ROC30_2yrL'] != "")]
        #L2yr30_ROC.drop(columns=['ROC30_2yrL'], inplace=True , errors='ignore')
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        #L2yr30_ROC.to_csv('/home/rizpython236/BT5/screener-outputs/2yrlow_30_ROC.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"Minervini.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/Minervini.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Minervini.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/Minervini.pdf')
        time.sleep(5)
        try:
            1+1
            #post_telegram_file('/home/rizpython236/BT5/screener-outputs/minervini_Charts.pdf')
        except Exception as e:
            print(f"Error posting telegram minervini_Charts: {str(e)}")



        minervini_out_df = logsminervini[~logsminervini['Company'].isin(minervini['Company'])]
        minervini_new_df = minervini[~minervini['Company'].isin(logsminervini['Company'])]

        #if yesterday not in market_days:
        #if weekday == "Saturday" or  weekday == "Sunday":
        if yesterday not in market_days and len(minervini_out_df) == 0:
            1+2
        else:
            minervini_out_df.to_csv('/home/rizpython236/BT5/screener-outputs/Minervini_out.csv', index=False)
            time.sleep(10)
            print(f"Minervini_out.csv saved successfully in {folder_path}")
            input_csv_file = '/home/rizpython236/BT5/screener-outputs/Minervini_out.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Minervini_out.pdf'  # Replace with desired output PDF file
            time.sleep(10)
            create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
            time.sleep(10)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/Minervini_out.pdf')


        if yesterday not in market_days and len(minervini_new_df) == 0:
            1+2
        else:
            minervini_new_df.to_csv('/home/rizpython236/BT5/screener-outputs/Minervini_New.csv', index=False)
            time.sleep(10)
            print(f"Minervini_New.csv saved successfully in {folder_path}")
            input_csv_file = '/home/rizpython236/BT5/screener-outputs/Minervini_New.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Minervini_New.pdf'  # Replace with desired output PDF file
            time.sleep(10)
            create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
            time.sleep(10)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/Minervini_New.pdf')


    else:
      print("No data found to write to Minervini.csv")
except Exception as e:
    print(f"Error in pdf Minervini- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")




logsHigherHigh_Lowerlow = '/home/rizpython236/BT5/trade-logs/MRHigher_lower.csv'
logsHigherHigh_Lowerlow = pd.read_csv(logsHigherHigh_Lowerlow)

try:
    #print(DDPCTlist)
    if len(MRHigerHigh) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["ROC_30"] , row["MRP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2


        def sort_by_roc_30_and_mrp(data):
            """
            Sorts a list of dictionaries based on the values of "ROC_30" and "MRP".

            Args:
                data: A list of dictionaries, where each dictionary represents a row of data.

            Returns:
                A sorted list of dictionaries.
            """

            def sort_key(row):
                """
                Returns a tuple used for sorting: (ROC_30, MRP numerical value).
                """
                roc_30 = row["ROC_30"]
                mrp = float(row["MRP"].split()[0])  # Extract numerical value from MRP string
                return roc_30, mrp

            return sorted(data, key=sort_key)

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        #L2yr30_ROC = [entry for entry in L2yr30_ROC if entry["ROC30_2yrL"] == 'UP']
        #MRHigerHigh.sort(key=lambda row: row["ROC_30"], reverse=True)
        MRHigerHigh.sort(key=sort_by_roc_and_maxvx, reverse=True)
        #MRHigerHigh.sort(key=sort_by_roc_30_and_mrp, reverse=True)

        #L2yr30_ROC.sort(key=lambda row: row["ROC_30"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(HigerHigh)

        HigerHighpd = pd.DataFrame(MRHigerHigh)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        HigerHighpd.fillna("", inplace=True)
        HigerHighpd.to_csv('/home/rizpython236/BT5/screener-outputs/MRHigher_lower.csv', index=False)
        HigerHighpd.to_csv('/home/rizpython236/BT5/trade-logs/MRHigher_lower.csv', index=False)

        #L2yr30_ROC = L2yr30_ROC[L2yr30_ROC['ROC30_2yrL'].notna() | (L2yr30_ROC['ROC30_2yrL'] != "")] #filter
        ###########L2yr30_ROC = L2yr30_ROC[(L2yr30_ROC['ROC30_2yrL'].notna()) | (L2yr30_ROC['ROC30_2yrL'] != "")]
        #L2yr30_ROC.drop(columns=['ROC30_2yrL'], inplace=True , errors='ignore')
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        #HigerHigh.to_csv('/home/rizpython236/BT5/screener-outputs/HigherHigh_Lowerlow.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"MRHigher_lower.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/MRHigher_lower.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MRHigher_lower.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/MRHigher_lower.pdf')

        unique_companies_df = HigerHighpd[~HigerHighpd['Company'].isin(logsHigherHigh_Lowerlow['Company'])]

        #if yesterday not in market_days:
        #if weekday == "Saturday" or  weekday == "Sunday":
        if yesterday not in market_days:
            1+2
        else:
            unique_companies_df.to_csv('/home/rizpython236/BT5/screener-outputs/UniqueMRHigher_lower.csv', index=False)
            time.sleep(10)
            print(f"UniqueMRHigher_lower.csv saved successfully in {folder_path}")
            input_csv_file = '/home/rizpython236/BT5/screener-outputs/UniqueMRHigher_lower.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/UniqueMRHigher_lower.pdf'  # Replace with desired output PDF file
            time.sleep(10)
            create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
            time.sleep(10)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/UniqueMRHigher_lower.pdf')

    else:
      print("No data found to write to MRHigher_lower.csv")
except Exception as e:
    print(f"Error in pdf MRHigher_lower- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")


logsHigherHigh_Lowerlow = '/home/rizpython236/BT5/trade-logs/HigherHigh_Lowerlow.csv'
logsHigherHigh_Lowerlow = pd.read_csv(logsHigherHigh_Lowerlow)

try:
    #print(DDPCTlist)
    if len(HigerHigh) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["ROC_5"] , row["ADX"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        #L2yr30_ROC = [entry for entry in L2yr30_ROC if entry["ROC30_2yrL"] == 'UP']
        HigerHigh.sort(key=lambda row: row["ROC_5"], reverse=True)
        #HigerHigh.sort(key=sort_by_roc_and_maxvx, reverse=True)

        #L2yr30_ROC.sort(key=lambda row: row["ROC_30"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(HigerHigh)

        HigerHighpd = pd.DataFrame(HigerHigh)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        HigerHighpd.fillna("", inplace=True)
        HigerHighpd.to_csv('/home/rizpython236/BT5/screener-outputs/HigherHigh_Lowerlow.csv', index=False)
        HigerHighpd.to_csv('/home/rizpython236/BT5/trade-logs/HigherHigh_Lowerlow.csv', index=False)

        #L2yr30_ROC = L2yr30_ROC[L2yr30_ROC['ROC30_2yrL'].notna() | (L2yr30_ROC['ROC30_2yrL'] != "")] #filter
        ###########L2yr30_ROC = L2yr30_ROC[(L2yr30_ROC['ROC30_2yrL'].notna()) | (L2yr30_ROC['ROC30_2yrL'] != "")]
        #L2yr30_ROC.drop(columns=['ROC30_2yrL'], inplace=True , errors='ignore')
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        #HigerHigh.to_csv('/home/rizpython236/BT5/screener-outputs/HigherHigh_Lowerlow.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"HigherHigh_Lowerlow.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/HigherHigh_Lowerlow.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/HigherHigh_Lowerlow.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/HigherHigh_Lowerlow.pdf')



        # Select rows from new_df where the 'Company' is not in old_df['Company']
        unique_companies_df = HigerHighpd[~HigerHighpd['Company'].isin(logsHigherHigh_Lowerlow['Company'])]


        #if yesterday not in market_days:
        #if weekday == "Saturday" or  weekday == "Sunday":
        if yesterday not in market_days:
            1+2
        else:
            unique_companies_df.to_csv('/home/rizpython236/BT5/screener-outputs/UniqueHigherHigh_Lowerlow.csv', index=False)
            time.sleep(10)
            print(f"UniqueHigherHigh_Lowerlow.csv saved successfully in {folder_path}")
            input_csv_file = '/home/rizpython236/BT5/screener-outputs/UniqueHigherHigh_Lowerlow.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/UniqueHigherHigh_Lowerlow.pdf'  # Replace with desired output PDF file
            time.sleep(10)
            create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
            time.sleep(10)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/UniqueHigherHigh_Lowerlow.pdf')


    else:
      print("No data found to write to HigherHigh_Lowerlow.csv")
except Exception as e:
    print(f"Error in pdf HigherHigh_Lowerlow- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")



try:
    #print(DDPCTlist)
    if len(L2yr30_ROC) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        #L2yr30_ROC = [entry for entry in L2yr30_ROC if entry["ROC30_2yrL"] == 'UP']
        L2yr30_ROC.sort(key=lambda row: (row["RSI"], row["ROC_30"]), reverse=False)

        #L2yr30_ROC.sort(key=lambda row: row["ROC_30"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(L2yr30_ROC)

        L2yr30_ROC = pd.DataFrame(L2yr30_ROC)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        L2yr30_ROC.fillna("", inplace=True)
        L2yr30_ROC.to_csv('/home/rizpython236/BT5/screener-outputs/2yrlow_30_ROC.csv', index=False)

        #L2yr30_ROC = L2yr30_ROC[L2yr30_ROC['ROC30_2yrL'].notna() | (L2yr30_ROC['ROC30_2yrL'] != "")] #filter
        ###########L2yr30_ROC = L2yr30_ROC[(L2yr30_ROC['ROC30_2yrL'].notna()) | (L2yr30_ROC['ROC30_2yrL'] != "")]
        #L2yr30_ROC.drop(columns=['ROC30_2yrL'], inplace=True , errors='ignore')
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        #L2yr30_ROC.to_csv('/home/rizpython236/BT5/screener-outputs/2yrlow_30_ROC.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"2yrlow_30_ROC.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/2yrlow_30_ROC.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/2yrlow_30_ROC.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/2yrlow_30_ROC.pdf')
    else:
      print("No data found to write to L2yr30_ROC.csv")
except Exception as e:
    print(f"Error in pdf 2yrlow_30_ROC- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")

try:
    Scoretickersallold = pd.read_csv('/home/rizpython236/BT5/trade-logs/Scoretickersallmonthly.csv')
except Exception as e:
    1+1

Scoretickersall = pd.DataFrame(Scoretickersall)
Scoretickersall = Scoretickersall.sort_values(by="Score", ascending=False).reset_index(drop=True)
Scoretickersall.to_csv('/home/rizpython236/BT5/trade-logs/Scoretickersall.csv', index=False)
#input_csv_file = '/home/rizpython236/BT5/screener-outputs/Scoretickersall.csv'  # Replace with your CSV file
#output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Scoretickersall.pdf'  # Replace with desired output PDF file
#time.sleep(10)
#create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
#time.sleep(10)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/Scoretickersall.pdf')


valid_tickers_file = "/home/rizpython236/BT5/trade-logs/valid_tickers.csv"
valid_tickers = pd.read_csv(valid_tickers_file)
# Step 2: Merge to add Industry (Symbol ↔ Ticker)
merged = Scoretickersall.merge(
    valid_tickers[["Symbol", "Industry"]],
    left_on="Ticker", right_on="Symbol",
    how="left"
).drop(columns=["Symbol"])  # drop duplicate Symbol column

mergednumber =len(merged)

# Step 3: Pivot for Score > 1
pivot_gt1 = (
    merged[merged["Score"] > 1]
    .pivot_table(index="Industry", values="Score", aggfunc=["count", "mean"])
)
pivot_gt1.columns = ["Score_count>1", "Score_mean>1"]

# Step 4: Pivot for Score < 1
pivot_lt1 = (
    merged[merged["Score"] < 1]
    .pivot_table(index="Industry", values="Score", aggfunc=["count", "mean"])
)
pivot_lt1.columns = ["Score_count<1", "Score_mean<1"]

# Step 5: Merge the two pivot tables
#pivot_combined = pivot_gt1.merge(pivot_lt1, left_index=True, right_index=True, how="outer").fillna(0)
pivot_combined = (pivot_gt1.merge(pivot_lt1, left_index=True, right_index=True, how="outer").fillna(0).reset_index())   # <-- moves Industry from index to column)

# Step 6: Calculate percentage passing
pivot_combined["Total_count"] = pivot_combined["Score_count>1"] + pivot_combined["Score_count<1"]
pivot_combined["Pct_passing"] = round((pivot_combined["Score_count>1"] / pivot_combined["Total_count"]) * 100,2)
pivot_combined[["Score_mean<1", "Score_mean>1"]] = pivot_combined[["Score_mean<1", "Score_mean>1"]].round(3)
pivot_combined["Score_count>1"] = pivot_combined["Score_count>1"].astype(int)
pivot_combined["Score_count<1"] = pivot_combined["Score_count<1"].astype(int)

pivot_combined = pivot_combined.sort_values(by="Pct_passing", ascending=False).reset_index(drop=True)
pivot_combined = pivot_combined[["Industry","Total_count", "Score_count<1", "Score_count>1", "Score_mean<1", "Score_mean>1","Pct_passing"]]

# Step 7: Reset index for clean output
pivot_combined = pivot_combined.reset_index()

#print(pivot_combined)
pivot_combined.to_csv('/home/rizpython236/BT5/screener-outputs/ScoretickersallPivot.csv', index=False)
input_csv_file = '/home/rizpython236/BT5/screener-outputs/ScoretickersallPivot.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ScoretickersallPivot.pdf'  # Replace with desired output PDF file
time.sleep(10)
create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
time.sleep(10)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/ScoretickersallPivot.pdf')



'''
import calendar

# Get today's date
today = datetime.today()

# Check if the month is May (5) or December (12) and today is Saturday (weekday() == 5)
if today.month in [5, 12] and today.weekday() == 5:  # Saturday
    # Get last day of the month
    last_day = today.replace(day=calendar.monthrange(today.year, today.month)[1])

    # Calculate how many days to go back to reach last Saturday
    days_to_last_saturday = (last_day.weekday() - 5) % 7  # Saturday = 5
    last_saturday = last_day - timedelta(days=days_to_last_saturday)

    # Check if today is the last Saturday
    if today.date() == last_saturday.date():
        print("Today is the last Saturday of May or December!")
'''


try:
    # Get today's date
    today = datetime.today()

    # Check if today is Friday (weekday() == 4 means Friday, since Monday=0)
    if today.weekday() == 4:
        # Get the first day of this month
        first_day = today.replace(day=1)

        # Find the first Friday of this month
        days_until_friday = (4 - first_day.weekday()) % 7  # how many days to next Friday
        first_friday = first_day + timedelta(days=days_until_friday)

        # If today is that first Friday
        if today.date() == first_friday.date():
            Scoretickersall.to_csv('/home/rizpython236/BT5/trade-logs/Scoretickersallmonthly.csv', index=False)
            Scoretickersallnew = Scoretickersall

            # 1. Sort both by Score
            Scoretickersallnew = Scoretickersallnew.sort_values("Score", ascending=False).reset_index(drop=True)
            Scoretickersallold = Scoretickersallold.sort_values("Score", ascending=False).reset_index(drop=True)

            # 2. Filter new (Score > 1) & keep top 50
            Scoretickersallnew_top50 = Scoretickersallnew[(Scoretickersallnew["Score"] < 1000) & (Scoretickersallnew["Score"] > 1) & (Scoretickersallnew["AvgScore"] == "Y")].head(50).copy()  #AvgScore
            old_top50 = Scoretickersallold_top50 = Scoretickersallold[(Scoretickersallold["Score"] < 1000) & (Scoretickersallold["Score"] > 1) & (Scoretickersallold["AvgScore"] =="Y")].head(50).copy()

            # 3. Get top 50 tickers from old
            #old_top50 = Scoretickersallold.head(50).copy()

            # Merge old top 50 with new top 50
            merged = old_top50.merge(
                Scoretickersallnew_top50[["Ticker","Close", "Score"]],
                on="Ticker",
                how="left",
                suffixes=("_Old", "_New")
            )

            # 4. Mark Hold / Remove
            merged["Rebal"] = merged["Score_New"].apply(lambda x: "Hold" if pd.notna(x) else "Remove")

            # 5. Count Hold
            hold_count = (merged["Rebal"] == "Hold").sum()

            # If less than 50 Hold, add from new top 50 (highest scores not already in old top 50)
            if hold_count < 50:
                missing_needed = 50 - hold_count
                to_add = Scoretickersallnew_top50[
                    ~Scoretickersallnew_top50["Ticker"].isin(merged["Ticker"])
                ].head(missing_needed).copy()

                # Create mapping dictionaries from old dataframe
                score_map = Scoretickersallold.set_index("Ticker")["Score"].to_dict()
                close_map = Scoretickersallold.set_index("Ticker")["Close"].to_dict()

                score_map_new = Scoretickersallnew.set_index("Ticker")["Score"].to_dict()
                close_map_new = Scoretickersallnew.set_index("Ticker")["Close"].to_dict()


                to_add = to_add.rename(columns={"Score": "Score_New"})
                to_add["Score_Old"] = to_add["Ticker"].map(score_map)
                to_add["Close_Old"] = to_add["Ticker"].map(close_map)
                to_add["Rebal"] = "Add"

                final = pd.concat([merged, to_add], ignore_index=True)
            else:
                final = merged


            # Fill values in final
            mask = final["Rebal"].isin(["Add", "Remove"])

            # Score & Close from "old"
            final.loc[mask, "Score_Old"] = final.loc[mask, "Ticker"].map(score_map)
            final.loc[mask, "Close_Old"] = final.loc[mask, "Ticker"].map(close_map)

            # Score & Close from "new"
            final.loc[mask, "Score_New"] = final.loc[mask, "Ticker"].map(score_map_new)
            final.loc[mask, "Close_New"] = final.loc[mask, "Ticker"].map(close_map_new)

            # Add % change column for all rows
            final["%Chg_Close"] = round(((final["Close_New"] - final["Close_Old"]) / final["Close_Old"] * 100),1)
            final["%Chg_Score"] = round(((final["Score_New"] - final["Score_Old"]) / final["Score_Old"] * 100),1)

            # 6. Final clean-up
            final = final[["Company", "Ticker", "Close_Old","Close_New", "Score_Old", "Score_New","%Chg_Score","%Chg_Close", "Rebal"]]


            rebal_order = {"Hold": 0, "Add": 1, "Remove": 2}
            final["Rebal_order"] = final["Rebal"].map(rebal_order)

            final = final.sort_values(
                by=["Rebal_order", "%Chg_Score"],
                ascending=[True, False]
            ).drop(columns=["Rebal_order"]).reset_index(drop=True)

            print(final)

            final.to_csv('/home/rizpython236/BT5/screener-outputs/ScoretickersRebal.csv', index=False)
            input_csv_file = '/home/rizpython236/BT5/screener-outputs/ScoretickersRebal.csv'  # Replace with your CSV file
            output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ScoretickersRebal.pdf'  # Replace with desired output PDF file
            time.sleep(10)
            create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
            time.sleep(10)
            post_telegram_file('/home/rizpython236/BT5/screener-outputs/ScoretickersRebal.pdf')

except Exception as e:
    1+1


try:
    #print(DDPCTlist)
    if len(Scoretickers) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        #Scoretickers.sort(key=lambda row: row["Score"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(MRPcross)
        Scoretickers = pd.DataFrame(Scoretickers)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        Scoretickers.fillna("", inplace=True)
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)
        Scoretickers = Scoretickers.sort_values(by="Score", ascending=False).reset_index(drop=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        Scoretickers.to_csv('/home/rizpython236/BT5/screener-outputs/Scoretickers.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"Scoretickers.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/Scoretickers.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Scoretickers.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/Scoretickers.pdf')
    else:
      print("No data found to write to Scoretickers.csv")
except Exception as e:
    print(f"Error in pdf Scoretickers- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")


try:
    #print(DDPCTlist)
    if len(SMAcross) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        SMAcross.sort(key=lambda row: row["SMA200pct"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(MRPcross)
        SMAcross = pd.DataFrame(SMAcross)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        SMAcross.fillna("", inplace=True)
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        SMAcross.to_csv('/home/rizpython236/BT5/screener-outputs/SMA200_15yr.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"SMA200_15yr.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/SMA200_15yr.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/SMA200_15yr.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/SMA200_15yr.pdf')
    else:
      print("No data found to write to SMA200_15yr.csv")
except Exception as e:
    print(f"Error in pdf SMA200_15yr- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")

try:
    #print(DDPCTlist)
    if len(MRPcross) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''

        MRPcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(MRPcross)
        MRPcross = pd.DataFrame(MRPcross)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        MRPcross.fillna("", inplace=True)
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        MRPcross.to_csv('/home/rizpython236/BT5/screener-outputs/MRPcross15yr.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"MRPcross15yr.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/MRPcross15yr.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MRPcross15yr.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/MRPcross15yr.pdf')
    else:
      print("No data found to write to MRPcross15yr.csv")
except Exception as e:
    print(f"Error in pdf MRPcross15yr- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")


try:
    #print(DDPCTlist)
    if len(maxVx) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["ROC1"] > 0, row["MaxVX"], row["ROC1"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        maxVx.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(maxVx)
        maxVx = pd.DataFrame(maxVx)
        maxVx.fillna("", inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        maxVx.to_csv('/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT15yr.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"MaxVxT15yr.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.pdf')
    else:
      print("No data found to write to MaxVxT15yr.csv")
except Exception as e:
    print(f"Error in pdf MaxVxT15yr- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    #print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")

try:
    #print(DDPCTlist)
    if len(DDPCTlist) > 0:  # Check if DDPCTlist has entries before writing
      # Define the folder path (replace 'your_folder_path' with your desired location)
      folder_path = '/home/rizpython236/BT5/screener-outputs/'
      DDPCTlist.sort(key=lambda row: row["ADX"], reverse=True)
      DDPCTlist = pd.DataFrame(DDPCTlist)
      DDPCTlist.fillna("", inplace=True)
      DDPCTlist.fillna("nan", inplace=True)
      DDPCTlist.to_csv('/home/rizpython236/BT5/screener-outputs/DDPCT15yr.csv', index=False)

      '''
      # Create the folder if it doesn't exist
      #import os
      os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

      # Open the CSV file in write mode and write headers
      with open(os.path.join(folder_path, "DDPCT15yr.csv"), "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=DDPCTlist[0].keys())  #fieldnames=data.keys())
        writer.writeheader()

        # Write rows from DDPCTlist to the CSV file
        for row in DDPCTlist:
            writer.writerow(row)
      '''

      print(f"DDPCT15yr.csv saved successfully in {folder_path}")
      input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.csv'  # Replace with your CSV file
      output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf'  # Replace with desired output PDF file
      time.sleep(10)
      create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
      time.sleep(10)
      post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf')
    else:
      print("No data found to write to DDPCT15yr.csv")
except Exception as e:
    print(f"Error in pdf DDPCT15yr- {e}")
    pass

print("__________________________________________________________")

try:
    #print(DDPCTlist)
    if len(Pos1yrHigh) > 0:  # Check if DDPCTlist has entries before writing
      # Define the folder path (replace 'your_folder_path' with your desired location)
      folder_path = '/home/rizpython236/BT5/screener-outputs/'
      #Pos1yrHigh.sort(key=lambda row: row["Pos1yr"], reverse=True) #CH52wk%
      Pos1yrHigh.sort(key=lambda row: row["CH52wk%"], reverse=True)
      #print(Pos1yrHigh)
      Pos1yrHigh = pd.DataFrame(Pos1yrHigh)
      Pos1yrHigh = Pos1yrHigh.sort_values(by="CH52wk%", ascending=False).reset_index(drop=True)
      #Pos1yrHigh = Pos1yrHigh[Pos1yrHigh["C"].isin(["C", "V"])]
      # Split into matching and non-matching rows
      matching_rows = Pos1yrHigh[Pos1yrHigh["C"].isin(["C", "V"])]
      non_matching_rows = Pos1yrHigh[~Pos1yrHigh["C"].isin(["C", "V"])]
      # Concatenate (matching first, non-matching last)
      Pos1yrHigh = pd.concat([matching_rows, non_matching_rows])

      Pos1yrHigh.fillna("", inplace=True)
      Pos1yrHigh.fillna("nan", inplace=True)
      Pos1yrHigh.to_csv('/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.csv', index=False)
      '''
      # Create the folder if it doesn't exist
      #import os
      os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

      # Open the CSV file in write mode and write headers
      with open(os.path.join(folder_path, "Pos1yrHigh15yr.csv"), "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=Pos1yrHigh[0].keys())
        writer.writeheader()

        # Write rows from Pos1yrHigh to the CSV file
        for row in Pos1yrHigh:
            writer.writerow(row)
      '''

      print(f"Pos1yrHigh15yr.csv saved successfully in {folder_path}")
      input_csv_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.csv'  # Replace with your CSV file
      output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.pdf'  # Replace with desired output PDF file
      time.sleep(10)
      create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
      time.sleep(10)
      post_telegram_file('/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.pdf')
    else:
      print("No data found to write to Pos1yrHigh15yr.csv")
except Exception as e:
    print(f"Error in pdf Pos1yrHigh15yr- {e}")
    traceback_str = traceback.format_exc()
    #Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")


try:
    #print(DDPCTlist)
    if len(Pos1yrlow) > 0:  # Check if DDPCTlist has entries before writing
      # Define the folder path (replace 'your_folder_path' with your desired location)
      folder_path = '/home/rizpython236/BT5/screener-outputs/'
      Pos1yrlow.sort(key=lambda row: row["Pos1yr"], reverse=False)
      #print(Pos1yrHigh)
      Pos1yrlow = pd.DataFrame(Pos1yrlow)
      Pos1yrlow.fillna("", inplace=True)
      Pos1yrlow.fillna("nan", inplace=True)
      Pos1yrlow.to_csv('/home/rizpython236/BT5/screener-outputs/Pos1yrlow15yr.csv', index=False)
      '''
      # Create the folder if it doesn't exist
      #import os
      os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

      # Open the CSV file in write mode and write headers
      with open(os.path.join(folder_path, "Pos1yrHigh15yr.csv"), "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=Pos1yrHigh[0].keys())
        writer.writeheader()

        # Write rows from Pos1yrHigh to the CSV file
        for row in Pos1yrHigh:
            writer.writerow(row)
      '''

      print(f"Pos1yrlow15yr.csv saved successfully in {folder_path}")
      input_csv_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrlow15yr.csv'  # Replace with your CSV file
      output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrlow15yr.pdf'  # Replace with desired output PDF file
      time.sleep(10)
      create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
      time.sleep(10)
      post_telegram_file('/home/rizpython236/BT5/screener-outputs/Pos1yrlow15yr.pdf')
    else:
      print("No data found to write to Pos1yrlow15yr.csv")
except Exception as e:
    print(f"Error in pdf Pos1yrlow15yr- {e}")
    traceback_str = traceback.format_exc()
    #Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")


# Example usage:
#sector_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#valid_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#replace_values(sector_file, valid_file, output_file)

if weekday != "Tuesday":
    #dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
    #dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
    #dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
    #print("Made copy of Old file")
    1+1


input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/52wkdatadaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/RSIdatadaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)


input_csv_file = '/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MRPdatadaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/52wkdatadaily.pdf')

time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/MRPdatadaily.pdf')
time.sleep(2)

if dfRSI_data.empty:
    1+1
    #print("RSI_data is empty")
else:
    1+1
    #post_telegram_file('/home/rizpython236/BT5/screener-outputs/RSIdatadaily.pdf')
time.sleep(2)
if dfSMA_data.empty:
    1+1
    #print("SMA_data is empty")
else:
    1+1
    #post_telegram_file('/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.pdf')




try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf'
    if os.path.exists(output_pdf_file):
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        ###post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCT15yr.pdf')
except Exception as e:
    print(f"Error in ruuning DDPCT15yr pdf- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")
try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.pdf'
    if os.path.exists(output_pdf_file):
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        ##post_telegram_file('/home/rizpython236/BT5/screener-outputs/Pos1yrHigh15yr.pdf')
except Exception as e:
    print(f"Error in ruuning Pos1yrHigh15yr pdf- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass
print("__________________________________________________________")

try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.pdf'
    if os.path.exists(output_pdf_file):
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        ###post_telegram_file('/home/rizpython236/BT5/screener-outputs/MaxVxT15yr.pdf')
except Exception as e:
    print(f"Error in ruuning MaxVxT15yr pdf- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass
print("__________________________________________________________")

'''
##########
new =df52wkdata
old = old52wkdataWklydf
change = pd.DataFrame()

new['52wkH-RSI-CCI--UP'] = new['52wkH-RSI-CCI--UP'].apply(lambda x: x.split('*')[0])
old['52wkH-RSI-CCI--UP'] = old['52wkH-RSI-CCI--UP'].apply(lambda x: x.split('*')[0])

old['52wkL-pos1yr-RSI-CCI--DWN'] = old['52wkL-pos1yr-RSI-CCI--DWN'].apply(lambda x: x.split('*')[0])
new['52wkL-pos1yr-RSI-CCI--DWN'] = new['52wkL-pos1yr-RSI-CCI--DWN'].apply(lambda x: x.split('*')[0])

for column in old.columns:
    change[column] = new[column][~new[column].isin(old[column])]
change.to_csv('/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv', index=False)
#print(change)
time.sleep(2)
input_csv_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.pdf')

#print(df)
#print(Start_countmore0)
#df.to_csv('/home/rizpython236/BT5/screener-outputs/Relative_perf.csv', index=False)

#time.sleep(2)

#input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  # Replace with your CSV file
#output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  # Replace with desired output PDF file

#create_pdf(input_csv_file, output_pdf_file)

##post_telegram_file('/home/rizpython236/BT5/screener-outputs/Relative_perf.pdf')
'''

'''

#######################

if 1==1:
#try:
    if weekday == "Wednesday":
        print("Running Chgwatchlist")
        try:
            Buyfile_path = '/home/rizpython236/BT5/OldwatchlistBUY.csv'
            Bolddf = pd.read_csv(Buyfile_path)

            Sellfile_path = '/home/rizpython236/BT5/OldwatchlistSELL.csv'
            Solddf = pd.read_csv(Sellfile_path)

            expfile_path = '/home/rizpython236/BT5/OldwatchlistExpLinR.csv'
            expdf = pd.read_csv(expfile_path)
        except Exception as e:
            print(f"file not found Oldgwatchlist- {e}")
            pass


        dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
        dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
        dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
        print("Made copy of Old file")


        new =dfBUY
        old = Bolddf
        change = pd.DataFrame()
        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])
        #new['DD_PCT_25'] = new['DD_PCT_25'].applymap(lambda x: x.rsplit('-', 1)[-1])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])


        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf')



        ####

        new =dfSELL
        old = Solddf
        change = pd.DataFrame()

        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf')


        ####

        new =dfexpdata
        old = expdf
        change = pd.DataFrame()

        new['ExpLong-S--L'] = new['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])
        old['ExpLong-S--L'] = old['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        old['ExpShort-L--S'] = old['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])
        new['ExpShort-L--S'] = new['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf')

    else:
        1+1
#except Exception as e:
#    print(f"Error in ruuning Chgwatchlist- {e}")
#    pass
'''


try:
    print(minervinitickers)
    folder_path = '/home/rizpython236/BT5/ticker_15yr/'
    filepathpdf = '/home/rizpython236/BT5/screener-outputs/minervini_Charts.pdf'


    with PdfPages(filepathpdf) as pdf:
        # Loop through all files in the folder
        for file_name in os.listdir(folder_path):

            if file_name.endswith('.csv'):
                file_path = os.path.join(folder_path, file_name)
                #total_files += 1
                base_name = os.path.splitext(file_name)[0]
                #file_names.append(base_name)
                #print(base_name)

                try:
                    if file_name in minervinitickers:   #if base_name in minervinitickers:
                        file_path = os.path.join(folder_path, file_name)
                        selected_files.append(file_path)
                        #total_files += 1
                        Base_name=symbol_to_company.get(base_name, base_name)
                        # Read the CSV file into a DataFrame
                        dfM = pd.read_csv(file_path)
                        dfM['Date'] = pd.to_datetime(dfM['Date'])  # Convert index to datetime

                        dfM["CCI"]=tb.CCI(dfM['High'], dfM['Low'], dfM['Close'], timeperiod=120)
                        #dfM["CCImovavgL"] = tb.EMA(dfM["CCI"], timeperiod=14)
                        dfM["RSI14"] = tb.RSI(dfM['Close'], timeperiod=18)
                        dfM["SMA_50"] = tb.EMA(dfM['Close'], timeperiod=50)
                        dfM["SMA_200"] = tb.SMA(dfM['Close'], timeperiod=200)
                        #df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        dfM["SMA_150"] = tb.EMA(dfM['Close'], timeperiod=150)
                        #df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        #df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                        dfM["SMA_200_15"] = tb.SMA(dfM['SMA_200'], timeperiod=60)
                        dfM["OBV"] = tb.OBV(dfM['Close'], dfM['Volume'])
                        #dfM["AD"] = talib.AD(dfM['High'],dfM['Low'],dfM['Close'],dfM['Volume'])
                        #print(dfM)
                        #print(f"minervini_Charts for {Base_name}")


                        # 1. Combined Price, Volume, RSI Chart
                        fig_combined = plt.figure(figsize=(11, 8.5))
                        #gs = fig_combined.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                        #gs = fig_combined.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])
                        gs = fig_combined.add_gridspec(4, 1, height_ratios=[6, 1, 1.5, 1.5])  #Custom GridSpec for 60% Price, 10% Volume, 15% RSI, 15% CCI

                        # Price chart (line plot)
                        ax1 = fig_combined.add_subplot(gs[0])
                        ax1.plot(dfM['Date'], dfM['Close'], label='Price', color='black', linewidth=1)

                        # Plot SMAs on top of line chart
                        ax1.plot(dfM['Date'], dfM['SMA_50'], label='EMA 50', color='blue', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_150'], label='EMA 150', color='orange', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200'], label='SMA 200', color='red', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200_15'], label='SMA 200(15)', color='purple', linewidth=1.5)

                        ax1.set_title(f'{Base_name} Price and Moving Averages', fontsize=14)
                        ax1.legend()

                        '''
                        # Volume chart
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        ax2.bar(dfM['Date'], dfM['Volume']/ 1000, color='blue', width=0.5, alpha=0.5)
                        #ax2.set_title('Volume', fontsize=12)
                        #ax2.set_ylabel('Volume')
                        #ax2.set_title('Volume (in thousands)', fontsize=12)  # Update title to reflect units
                        ax2.set_ylabel('Volume (K)')  # Change y-axis label to indicate thousands
                        '''

                        # Volume chart with OBV
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        # Plot volume bars
                        ax2.bar(dfM['Date'], dfM['Volume']/1000, color='blue', width=0.5, alpha=0.5, label='Volume')
                        # Plot OBV line on secondary y-axis
                        ax2b = ax2.twinx()
                        ax2b.plot(dfM['Date'], dfM['OBV']/1000, color='black', linewidth=1.5, label='OBV')
                        # Set labels and title
                        ax2.set_ylabel('Volume (K)', color='blue')
                        ax2b.set_ylabel('OBV (K)', color='black')
                        # Set colors for y-axes to match their respective data
                        ax2.tick_params(axis='y', colors='blue')
                        ax2b.tick_params(axis='y', colors='black')
                        # Add legend
                        lines, labels = ax2.get_legend_handles_labels()
                        lines2, labels2 = ax2b.get_legend_handles_labels()
                        ax2.legend(lines + lines2, labels + labels2, loc='upper left')



                        # RSI chart
                        ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                        ax3.plot(dfM['Date'], dfM["RSI14"], color='purple', label='RSI')
                        ax3.axhline(70, color='red', linestyle='--', alpha=0.5)
                        ax3.axhline(30, color='green', linestyle='--', alpha=0.5)
                        ax3.fill_between(dfM['Date'], 70, dfM["RSI14"],
                                       where=(dfM["RSI14"] >= 70), color='red', alpha=0.3)
                        ax3.fill_between(dfM['Date'], 30, dfM["RSI14"],
                                       where=(dfM["RSI14"] <= 30), color='green', alpha=0.3)
                        ax3.set_title('RSI (24)', fontsize=12)
                        ax3.set_ylim(0, 100)
                        ax3.legend()

                        # CCI chart
                        ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                        ax4.plot(dfM['Date'], dfM["CCI"], color='purple', label='CCI')
                        ax4.axhline(0, color='red', linestyle='--', alpha=0.5)
                        ax4.axhline(50, color='green', linestyle='--', alpha=0.5)
                        ax4.fill_between(dfM['Date'], 0, dfM["CCI"],
                                       where=(dfM["CCI"] <= 0), color='red', alpha=0.3)
                        ax4.fill_between(dfM['Date'], 50, dfM["CCI"],
                                       where=(dfM["CCI"] >= 50), color='green', alpha=0.3)
                        ax4.set_title('CCI (34)', fontsize=12)
                        ax4.set_ylim(-100, 150)
                        ax4.legend()

                        # Format x-axis to show labels on a quarterly basis
                        plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=6))  # Quarterly labels
                        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format as 'YYYY-MM'
                        plt.xticks(rotation=35)
                        #plt.tight_layout()
                        # Reduce margins using tight_layout with padding adjustments
                        plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)  # Adjust padding as needed
                        #pdf.savefig(fig_combined)
                        pdf.savefig(fig_combined, bbox_inches='tight')

                        folder_pathf='/home/rizpython236/BT5/screener-outputs/'
                        file_path = os.path.join(folder_pathf)
                        chart_path = os.path.join(folder_pathf, f'minervini_{Base_name}.png')
                        #plt.savefig(chart_path)
                        #time.sleep(3)
                        #post_telegram_file(chart_path)
                        #os.remove(chart_path)
                        #if total_files == symNo:
                        plt.close(fig_combined)

                        # Add metadata
                        d = pdf.infodict()
                        d['Title'] = f'{Base_name} Technical Analysis Report'
                        d['Author'] = 'Automated Report Generator'

                        print(f"Generated report for {Base_name} at: {filepathpdf}")
                except Exception as e:
                    print(f"Error processing minervini_Charts {Base_name}: {str(e)}")
                    traceback_str = traceback.format_exc()
                    plt.close('all')
                    continue

    time.sleep(5)
    print(f"Send telegrame report: {filepathpdf}")
    post_telegram_file(filepathpdf)
except Exception as e:
    print(f"Error processing minervini_Charts: {str(e)}")
    traceback_str = traceback.format_exc()
    #plt.close('all')


try:
    # Split into matching and non-matching rows
    print(Pos1yrHightickers)
    folder_path = '/home/rizpython236/BT5/ticker_15yr/'
    filepathpdf = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh_Charts.pdf'


    with PdfPages(filepathpdf) as pdf:
        # Loop through all files in the folder
        for file_name in os.listdir(folder_path):

            if file_name.endswith('.csv'):
                file_path = os.path.join(folder_path, file_name)
                #total_files += 1
                base_name = os.path.splitext(file_name)[0]
                #file_names.append(base_name)
                #print(base_name)

                try:
                    if file_name in Pos1yrHightickers:   #if base_name in minervinitickers:
                        file_path = os.path.join(folder_path, file_name)
                        selected_files.append(file_path)
                        #total_files += 1
                        Base_name=symbol_to_company.get(base_name, base_name)
                        # Read the CSV file into a DataFrame
                        dfM = pd.read_csv(file_path)
                        dfM['Date'] = pd.to_datetime(dfM['Date'])  # Convert index to datetime

                        dfM["CCI"]=tb.CCI(dfM['High'], dfM['Low'], dfM['Close'], timeperiod=120)
                        #dfM["CCImovavgL"] = tb.EMA(dfM["CCI"], timeperiod=14)
                        dfM["RSI14"] = tb.RSI(dfM['Close'], timeperiod=18)
                        dfM["SMA_50"] = tb.EMA(dfM['Close'], timeperiod=50)
                        dfM["SMA_200"] = tb.SMA(dfM['Close'], timeperiod=200)
                        #df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        dfM["SMA_150"] = tb.EMA(dfM['Close'], timeperiod=150)
                        #df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        #df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                        dfM["SMA_200_15"] = tb.SMA(dfM['SMA_200'], timeperiod=60)
                        dfM["OBV"] = tb.OBV(dfM['Close'], dfM['Volume'])
                        #dfM["AD"] = talib.AD(dfM['High'],dfM['Low'],dfM['Close'],dfM['Volume'])
                        #print(dfM)
                        #print(f"minervini_Charts for {Base_name}")


                        # 1. Combined Price, Volume, RSI Chart
                        fig_combined = plt.figure(figsize=(11, 8.5))
                        #gs = fig_combined.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                        #gs = fig_combined.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])
                        gs = fig_combined.add_gridspec(4, 1, height_ratios=[6, 1, 1.5, 1.5])  #Custom GridSpec for 60% Price, 10% Volume, 15% RSI, 15% CCI

                        # Price chart (line plot)
                        ax1 = fig_combined.add_subplot(gs[0])
                        ax1.plot(dfM['Date'], dfM['Close'], label='Price', color='black', linewidth=1)

                        # Plot SMAs on top of line chart
                        ax1.plot(dfM['Date'], dfM['SMA_50'], label='EMA 50', color='blue', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_150'], label='EMA 150', color='orange', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200'], label='SMA 200', color='red', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200_15'], label='SMA 200(15)', color='purple', linewidth=1.5)

                        ax1.set_title(f'{Base_name} Price and Moving Averages', fontsize=14)
                        ax1.legend()

                        '''
                        # Volume chart
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        ax2.bar(dfM['Date'], dfM['Volume']/ 1000, color='blue', width=0.5, alpha=0.5)
                        #ax2.set_title('Volume', fontsize=12)
                        #ax2.set_ylabel('Volume')
                        #ax2.set_title('Volume (in thousands)', fontsize=12)  # Update title to reflect units
                        ax2.set_ylabel('Volume (K)')  # Change y-axis label to indicate thousands
                        '''

                        # Volume chart with OBV
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        # Plot volume bars
                        ax2.bar(dfM['Date'], dfM['Volume']/1000, color='blue', width=0.5, alpha=0.5, label='Volume')
                        # Plot OBV line on secondary y-axis
                        ax2b = ax2.twinx()
                        ax2b.plot(dfM['Date'], dfM['OBV']/1000, color='black', linewidth=1.5, label='OBV')
                        # Set labels and title
                        ax2.set_ylabel('Volume (K)', color='blue')
                        ax2b.set_ylabel('OBV (K)', color='black')
                        # Set colors for y-axes to match their respective data
                        ax2.tick_params(axis='y', colors='blue')
                        ax2b.tick_params(axis='y', colors='black')
                        # Add legend
                        lines, labels = ax2.get_legend_handles_labels()
                        lines2, labels2 = ax2b.get_legend_handles_labels()
                        ax2.legend(lines + lines2, labels + labels2, loc='upper left')



                        # RSI chart
                        ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                        ax3.plot(dfM['Date'], dfM["RSI14"], color='purple', label='RSI')
                        ax3.axhline(70, color='red', linestyle='--', alpha=0.5)
                        ax3.axhline(30, color='green', linestyle='--', alpha=0.5)
                        ax3.fill_between(dfM['Date'], 70, dfM["RSI14"],
                                       where=(dfM["RSI14"] >= 70), color='red', alpha=0.3)
                        ax3.fill_between(dfM['Date'], 30, dfM["RSI14"],
                                       where=(dfM["RSI14"] <= 30), color='green', alpha=0.3)
                        ax3.set_title('RSI (24)', fontsize=12)
                        ax3.set_ylim(0, 100)
                        ax3.legend()

                        # CCI chart
                        ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                        ax4.plot(dfM['Date'], dfM["CCI"], color='purple', label='CCI')
                        ax4.axhline(0, color='red', linestyle='--', alpha=0.5)
                        ax4.axhline(50, color='green', linestyle='--', alpha=0.5)
                        ax4.fill_between(dfM['Date'], 0, dfM["CCI"],
                                       where=(dfM["CCI"] <= 0), color='red', alpha=0.3)
                        ax4.fill_between(dfM['Date'], 50, dfM["CCI"],
                                       where=(dfM["CCI"] >= 50), color='green', alpha=0.3)
                        ax4.set_title('CCI (34)', fontsize=12)
                        ax4.set_ylim(-100, 150)
                        ax4.legend()

                        # Format x-axis to show labels on a quarterly basis
                        plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=6))  # Quarterly labels
                        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format as 'YYYY-MM'
                        plt.xticks(rotation=35)
                        #plt.tight_layout()
                        # Reduce margins using tight_layout with padding adjustments
                        plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)  # Adjust padding as needed
                        #pdf.savefig(fig_combined)
                        pdf.savefig(fig_combined, bbox_inches='tight')

                        folder_pathf='/home/rizpython236/BT5/screener-outputs/'
                        file_path = os.path.join(folder_pathf)
                        chart_path = os.path.join(folder_pathf, f'Pos1yrHigh_{Base_name}.png')
                        #plt.savefig(chart_path)
                        #time.sleep(3)
                        #post_telegram_file(chart_path)
                        #os.remove(chart_path)
                        #if total_files == symNo:
                        plt.close(fig_combined)

                        # Add metadata
                        d = pdf.infodict()
                        d['Title'] = f'{Base_name} Technical Analysis Report'
                        d['Author'] = 'Automated Report Generator'

                        print(f"Generated report for {Base_name} at: {filepathpdf}")
                except Exception as e:
                    print(f"Error processing Pos1yrHigh_Charts {Base_name}: {str(e)}")
                    traceback_str = traceback.format_exc()
                    plt.close('all')
                    continue

    time.sleep(5)
    print(f"Send telegrame report: {filepathpdf}")
    post_telegram_file(filepathpdf)
except Exception as e:
    print(f"Error processing Pos1yrHigh_Charts: {str(e)}")
    traceback_str = traceback.format_exc()
    #plt.close('all')

try:
    # Split into matching and non-matching rows
    print(TJItickers)
    folder_path = '/home/rizpython236/BT5/ticker_15yr/'
    filepathpdf = '/home/rizpython236/BT5/screener-outputs/TJI_Charts.pdf'


    with PdfPages(filepathpdf) as pdf:
        # Loop through all files in the folder
        for file_name in os.listdir(folder_path):

            if file_name.endswith('.csv'):
                file_path = os.path.join(folder_path, file_name)
                #total_files += 1
                base_name = os.path.splitext(file_name)[0]
                #file_names.append(base_name)
                #print(base_name)

                try:
                    if file_name in TJItickers:   #if base_name in minervinitickers:
                        file_path = os.path.join(folder_path, file_name)
                        selected_files.append(file_path)
                        #total_files += 1
                        Base_name=symbol_to_company.get(base_name, base_name)
                        # Read the CSV file into a DataFrame
                        dfM = pd.read_csv(file_path)
                        dfM['Date'] = pd.to_datetime(dfM['Date'])  # Convert index to datetime

                        dfM["CCI"]=tb.CCI(dfM['High'], dfM['Low'], dfM['Close'], timeperiod=120)
                        #dfM["CCImovavgL"] = tb.EMA(dfM["CCI"], timeperiod=14)
                        dfM["RSI14"] = tb.RSI(dfM['Close'], timeperiod=18)
                        dfM["SMA_50"] = tb.EMA(dfM['Close'], timeperiod=50)
                        dfM["SMA_200"] = tb.SMA(dfM['Close'], timeperiod=200)
                        #df["SMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        dfM["SMA_150"] = tb.EMA(dfM['Close'], timeperiod=150)
                        #df["EMA_100"] = tb.SMA(data52['Close'], timeperiod=100)
                        #df["EMA_200"] = tb.EMA(data52['Close'], timeperiod=200)
                        dfM["SMA_200_15"] = tb.SMA(dfM['SMA_200'], timeperiod=60)
                        dfM["OBV"] = tb.OBV(dfM['Close'], dfM['Volume'])
                        #dfM["AD"] = talib.AD(dfM['High'],dfM['Low'],dfM['Close'],dfM['Volume'])
                        #print(dfM)
                        #print(f"minervini_Charts for {Base_name}")


                        # 1. Combined Price, Volume, RSI Chart
                        fig_combined = plt.figure(figsize=(11, 8.5))
                        #gs = fig_combined.add_gridspec(3, 1, height_ratios=[3, 1, 1])
                        #gs = fig_combined.add_gridspec(4, 1, height_ratios=[3, 1, 1, 1])
                        gs = fig_combined.add_gridspec(4, 1, height_ratios=[6, 1, 1.5, 1.5])  #Custom GridSpec for 60% Price, 10% Volume, 15% RSI, 15% CCI

                        # Price chart (line plot)
                        ax1 = fig_combined.add_subplot(gs[0])
                        ax1.plot(dfM['Date'], dfM['Close'], label='Price', color='black', linewidth=1)

                        # Plot SMAs on top of line chart
                        ax1.plot(dfM['Date'], dfM['SMA_50'], label='EMA 50', color='blue', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_150'], label='EMA 150', color='orange', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200'], label='SMA 200', color='red', linewidth=1.5)
                        ax1.plot(dfM['Date'], dfM['SMA_200_15'], label='SMA 200(15)', color='purple', linewidth=1.5)

                        ax1.set_title(f'{Base_name} Price and Moving Averages', fontsize=14)
                        ax1.legend()

                        '''
                        # Volume chart
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        ax2.bar(dfM['Date'], dfM['Volume']/ 1000, color='blue', width=0.5, alpha=0.5)
                        #ax2.set_title('Volume', fontsize=12)
                        #ax2.set_ylabel('Volume')
                        #ax2.set_title('Volume (in thousands)', fontsize=12)  # Update title to reflect units
                        ax2.set_ylabel('Volume (K)')  # Change y-axis label to indicate thousands
                        '''

                        # Volume chart with OBV
                        ax2 = fig_combined.add_subplot(gs[1], sharex=ax1)
                        # Plot volume bars
                        ax2.bar(dfM['Date'], dfM['Volume']/1000, color='blue', width=0.5, alpha=0.5, label='Volume')
                        # Plot OBV line on secondary y-axis
                        ax2b = ax2.twinx()
                        ax2b.plot(dfM['Date'], dfM['OBV']/1000, color='black', linewidth=1.5, label='OBV')
                        # Set labels and title
                        ax2.set_ylabel('Volume (K)', color='blue')
                        ax2b.set_ylabel('OBV (K)', color='black')
                        # Set colors for y-axes to match their respective data
                        ax2.tick_params(axis='y', colors='blue')
                        ax2b.tick_params(axis='y', colors='black')
                        # Add legend
                        lines, labels = ax2.get_legend_handles_labels()
                        lines2, labels2 = ax2b.get_legend_handles_labels()
                        ax2.legend(lines + lines2, labels + labels2, loc='upper left')



                        # RSI chart
                        ax3 = fig_combined.add_subplot(gs[2], sharex=ax1)
                        ax3.plot(dfM['Date'], dfM["RSI14"], color='purple', label='RSI')
                        ax3.axhline(70, color='red', linestyle='--', alpha=0.5)
                        ax3.axhline(30, color='green', linestyle='--', alpha=0.5)
                        ax3.fill_between(dfM['Date'], 70, dfM["RSI14"],
                                       where=(dfM["RSI14"] >= 70), color='red', alpha=0.3)
                        ax3.fill_between(dfM['Date'], 30, dfM["RSI14"],
                                       where=(dfM["RSI14"] <= 30), color='green', alpha=0.3)
                        ax3.set_title('RSI (24)', fontsize=12)
                        ax3.set_ylim(0, 100)
                        ax3.legend()

                        # CCI chart
                        ax4 = fig_combined.add_subplot(gs[3], sharex=ax1)
                        ax4.plot(dfM['Date'], dfM["CCI"], color='purple', label='CCI')
                        ax4.axhline(0, color='red', linestyle='--', alpha=0.5)
                        ax4.axhline(50, color='green', linestyle='--', alpha=0.5)
                        ax4.fill_between(dfM['Date'], 0, dfM["CCI"],
                                       where=(dfM["CCI"] <= 0), color='red', alpha=0.3)
                        ax4.fill_between(dfM['Date'], 50, dfM["CCI"],
                                       where=(dfM["CCI"] >= 50), color='green', alpha=0.3)
                        ax4.set_title('CCI (34)', fontsize=12)
                        ax4.set_ylim(-100, 150)
                        ax4.legend()

                        # Format x-axis to show labels on a quarterly basis
                        plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=6))  # Quarterly labels
                        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))  # Format as 'YYYY-MM'
                        plt.xticks(rotation=35)
                        #plt.tight_layout()
                        # Reduce margins using tight_layout with padding adjustments
                        plt.tight_layout(pad=1.0, h_pad=1.0, w_pad=1.0)  # Adjust padding as needed
                        #pdf.savefig(fig_combined)
                        pdf.savefig(fig_combined, bbox_inches='tight')

                        folder_pathf='/home/rizpython236/BT5/screener-outputs/'
                        file_path = os.path.join(folder_pathf)
                        chart_path = os.path.join(folder_pathf, f'TJI_{Base_name}.png')
                        #plt.savefig(chart_path)
                        #time.sleep(3)
                        #post_telegram_file(chart_path)
                        #os.remove(chart_path)
                        #if total_files == symNo:
                        plt.close(fig_combined)

                        # Add metadata
                        d = pdf.infodict()
                        d['Title'] = f'{Base_name} Technical Analysis Report'
                        d['Author'] = 'Automated Report Generator'

                        print(f"Generated report for {Base_name} at: {filepathpdf}")
                except Exception as e:
                    print(f"Error processing TJI_Charts {Base_name}: {str(e)}")
                    traceback_str = traceback.format_exc()
                    plt.close('all')
                    continue

    time.sleep(5)
    print(f"Send telegrame report: {filepathpdf}")
    post_telegram_file(filepathpdf)
except Exception as e:
    print(f"Error processing TJI_Charts: {str(e)}")
    traceback_str = traceback.format_exc()
    #plt.close('all')

print("csv15yrs done")



























