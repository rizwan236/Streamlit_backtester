

from datetime import date
import sys
import time
import traceback

from mail_utils import trigger_generic_email
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
from settings import MAX_RETRIES, NIFTY_WEEKLY_AVG_STATS_IMAGE
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/rizenv/lib/python3.7/site-packages/")
#from nsepy import get_index_pe_history
import nsepy


end_date = date.today()
YEAR_DIFF = 5
start_date = date(end_date.year - YEAR_DIFF, end_date.month, end_date.day)


print("Downloading Nifty PE Historical Data...")
print("-" * 60)


download_successful = False
while MAX_RETRIES:
    try:
        nifty_pe = nsepy.get_index_pe_history("NIFTY", start_date, end_date)
        nifty_pe.reset_index(level=0, inplace=True)
        nifty_pe.dropna(inplace=True)
        nifty_pe = nifty_pe[nifty_pe["P/E"] != 0]
        nifty_pe["Date"] = pd.to_datetime(nifty_pe["Date"]).dt.date
        nifty_pe = nifty_pe.sort_values("Date")
        # nifty_pe.to_csv("nifty_pe_historical_data.csv", index=False)
        download_successful = True
        print("Download NIFTY PE historical data successful")
        MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(2)
        print("Download NIFTY PE historical data failed! Retrying...")
        print(exc)
        print("-" * 50)
        MAX_RETRIES -= 1


if not download_successful:
    post_telegram_message(message="Download data for NSE PE")
    sys.exit()


def find_nifty_statistics(nifty_pe, metric_list=["P/E", "P/B", "Div Yield"]):

    nifty_report_text_list = []
    nifty_stat_df = nifty_pe.copy()

    for metric in metric_list:

        nifty_metric_current = round(nifty_stat_df[metric][len(nifty_stat_df) - 1], 2)
        nifty_stat_df = nifty_stat_df.sort_values(metric).reset_index(drop=True)

        nifty_metric_min = round(nifty_stat_df[metric].min(), 2)
        nifty_metric_min_date = nifty_stat_df["Date"][0]

        nifty_metric_max = round(nifty_stat_df[metric].max(), 2)
        nifty_metric_max_date = nifty_stat_df["Date"][len(nifty_stat_df) - 1]

        nifty_metric_median = round(nifty_stat_df[metric].median(), 2)
        nifty_metric_mean = round(nifty_stat_df[metric].mean(), 2)

        nifty_metric_report = "Nifty {} Report for period {} to {} \n\n \
            Nifty {} - Current => {} \n \
            Nifty {} - Min => {} on {} \n \
            Nifty {} - Max => {} on {} \n \
            Nifty {} - Mean => {} \n \
            Nifty {} - Median => {} \n\n \
            ----------------------------\n\n".format(
            metric,
            str(start_date),
            str(end_date),
            metric,
            nifty_metric_current,
            metric,
            nifty_metric_min,
            nifty_metric_min_date,
            metric,
            nifty_metric_max,
            nifty_metric_max_date,
            metric,
            nifty_metric_mean,
            metric,
            nifty_metric_median,
        )

        nifty_report_text_list.append(nifty_metric_report)

    nifty_report = " ".join(nifty_report_text_list)

    return nifty_report


# def plot_nifty_statistics_v1(nifty_pe, metric_list=["P/E", "P/B", "Div Yield"]):
# OLD PLOTTING FUNCTION - DON'T USE IT
#     nifty_plot_df = nifty_pe.copy()
#     nifty_plot_df = nifty_plot_df.set_index(["Date"])
#     nifty_plot_df.index = pd.to_datetime(nifty_plot_df.index)

#     metric_series_list = []
#     for metric in metric_list:
#         nifty_metric_weekly_avg = nifty_plot_df.groupby([pd.Grouper(freq="W-FRI")])[metric].mean()
#         metric_series_list.append(nifty_metric_weekly_avg)

#     metric_stats_df = pd.concat(metric_series_list,axis=1)
#     metric_stats_df["Avg P/E"] = round(nifty_pe["P/E"].mean(),2)
#     metric_stats_df["Avg P/B"] = round(nifty_pe["P/B"].mean(),2)
#     metric_stats_df["Avg Div Yield"] = round(nifty_pe["Div Yield"].mean(),2)
#     print(metric_stats_df)
#     # # print(nifty_pe_weekly_avg)
#     line_chart = metric_stats_df.plot.line(title="Nifty Stats Weekly Average")
#     fig = line_chart.get_figure()
#     fig.savefig(NIFTY_PE_AVG_IMAGE)
#     return


def plot_nifty_statistics_v2(nifty_pe, metric_list=["P/E", "P/B", "Div Yield"]):

    nifty_plot_df1 = nifty_pe.copy()
    nifty_plot_df1 = nifty_plot_df1.set_index(["Date"])
    nifty_plot_df1.index = pd.to_datetime(nifty_plot_df1.index)

    nifty_pe_weekly_avg = nifty_plot_df1.groupby([pd.Grouper(freq="W-FRI")])[
        "P/E"
    ].mean()
    nifty_pe_weekly_avg = pd.DataFrame(data=nifty_pe_weekly_avg, columns=["P/E"])
    # nifty_pb_weekly_avg = pd.concat([nifty_pe_weekly_avg], axis=1)
    nifty_pe_weekly_avg["Avg P/E"] = round(nifty_pe["P/E"].mean(), 2)

    nifty_plot_df2 = nifty_pe.copy()
    nifty_plot_df2 = nifty_plot_df2.set_index(["Date"])
    nifty_plot_df2.index = pd.to_datetime(nifty_plot_df2.index)

    nifty_pb_weekly_avg = nifty_plot_df2.groupby([pd.Grouper(freq="W-FRI")])[
        "P/B"
    ].mean()
    nifty_dy_weekly_avg = nifty_plot_df2.groupby([pd.Grouper(freq="W-FRI")])[
        "Div Yield"
    ].mean()
    nifty_pb_dy_combined = pd.concat([nifty_pb_weekly_avg, nifty_dy_weekly_avg], axis=1)
    nifty_pb_dy_combined["Avg P/B"] = round(nifty_pe["P/B"].mean(), 2)
    nifty_pb_dy_combined["Avg Div Yield"] = round(nifty_pe["Div Yield"].mean(), 2)

    fig, ax = plt.subplots(figsize=(12, 5))
    ax2 = ax.twinx()
    ax2.set_ylim(0, 6)
    ax3 = ax.twinx()
    ax3.set_ylim(0, 6)
    # ax.set_title('GDP per capita ($) and GDP growth rate')
    ax.set_xlabel("Date")

    ax.plot(nifty_pe_weekly_avg.index, nifty_pe_weekly_avg["P/E"], color="green")
    ax.plot(nifty_pe_weekly_avg.index, nifty_pe_weekly_avg["Avg P/E"], color="green")

    ax2.plot(nifty_pb_dy_combined.index, nifty_pb_dy_combined["P/B"], color="red")
    ax2.plot(nifty_pb_dy_combined.index, nifty_pb_dy_combined["Avg P/B"], color="red")

    ax3.plot(
        nifty_pb_dy_combined.index, nifty_pb_dy_combined["Div Yield"], color="blue"
    )
    ax3.plot(
        nifty_pb_dy_combined.index, nifty_pb_dy_combined["Avg Div Yield"], color="blue"
    )

    ax.set_ylabel("Nifty P/E Range")
    ax2.set_ylabel("Nifty P/B and Div Yield Range")

    ax.legend(["Nifty Weekly Avg P/E"])
    ax2.legend(["Nifty Weekly Avg P/B"])
    ax3.legend(["Nifty Weekly Avg Div Yield"], loc="upper center")

    ax.yaxis.grid(color="lightgray", linestyle="dashed")
    plt.tight_layout()
    plt.savefig(NIFTY_WEEKLY_AVG_STATS_IMAGE)

    return


nifty_pe_report = find_nifty_statistics(nifty_pe)
plot_nifty_statistics_v2(nifty_pe)
post_telegram_message(message=nifty_pe_report)
post_telegram_file(NIFTY_WEEKLY_AVG_STATS_IMAGE)
trigger_generic_email(msg=nifty_pe_report, attachment=NIFTY_WEEKLY_AVG_STATS_IMAGE)
