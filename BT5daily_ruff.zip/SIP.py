import os
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PDFconvert import create_pdf
from telegram_bot import post_telegram_file, post_telegram_message


# Parameters
starting_portfolio = 400  # Initial portfolio value 41 lakh
cagr = 0.26  # 15% annual growth rate
monthly_cagr = (1 + cagr) ** (1 / 12) - 1  # Convert annual growth rate to monthly
monthly_sip = 1  # Initial monthly investment  10K
sip_increase_rate = 0.07  # SIP increases by 5% annually
years = 15  # Investment period in years
months = years * 12  # Total number of months


# Parameters
starting_portfolio = 40  # Initial portfolio value 45 lakh
cagr = 0.26  # 15% annual growth rate
monthly_cagr = (1 + cagr) ** (1 / 12) - 1  # Convert annual growth rate to monthly
monthly_sip = 1/12  # Initial monthly investment  10K
sip_increase_rate = 0.05  # SIP increases by 5% annually
years = 15  # Investment period in years
months = years * 12  # Total number of months

# Track when portfolio value crosses 100
cross_100_flag = False

# Arrays to store the results
data = []
sip_amount = monthly_sip
current_portfolio = starting_portfolio
invested_amount = 0

# Loop over each month
for month in range(1, months + 1):
    # Invest the SIP at the beginning of the month
    invested_amount += sip_amount
    current_portfolio += sip_amount

    # Grow the portfolio with the monthly CAGR
    current_portfolio *= (1 + monthly_cagr)

    # Store the results in the data array
    data.append({
        'Month': month,
        'Year': month // 12 + 1,
        'Monthly SIP': round(sip_amount,2),
        'Total Invested': round((invested_amount + starting_portfolio),2),
        'Portfolio Value': round(current_portfolio,2),
        'Incremental Value': round((current_portfolio-(invested_amount + starting_portfolio)),2),
        'Incremental Greater Total Invested Value': int(current_portfolio-(invested_amount + starting_portfolio)-(invested_amount + starting_portfolio)*1),
    })

    # Check if the portfolio value crosses 100 for the first time
    if not cross_100_flag and current_portfolio >= 100:
        #print(f"Portfolio value crosses 100 in month {month}, which is year {month // 12 + 1}.")
        cross_100_flag = True

    # Increase the SIP annually
    if month % 12 == 0:
        sip_amount *= (1 + sip_increase_rate)

# Create a DataFrame
df = pd.DataFrame(data)

# Display the DataFrame
print(df)

# Check when the portfolio value crosses 100
cross_100 = df[df['Portfolio Value'] >= 100].head(1)
if not cross_100.empty:
    month_crossed = cross_100.iloc[0]['Month']
    year_crossed = cross_100.iloc[0]['Year']
    print(f"Portfolio value crosses 1 Cr in month {month_crossed}, which is year {month_crossed/12}.")
else:
    print("Portfolio value never crosses 100 during the given period.")


# Find the month when Incremental Greater Total Invested Value first becomes positive
positive_month = df[df['Incremental Greater Total Invested Value'] > 0].iloc[0]['Month']
print(f"Month when Incremental Greater Total Invested Value first becomes positive: {positive_month}")
print(f"Year when Incremental Greater Total Invested Value first becomes positive: {positive_month/12}")


df.to_csv('/home/rizpython236/BT5/screener-outputs/SIP_value.csv', index=False)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/SIP_value.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/SIP_value.pdf'  # Replace with desired output PDF file
time.sleep(3)
create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
time.sleep(3)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/SIP_value.pdf')



# Create figure and axis
fig, ax = plt.subplots(figsize=(16, 8))

# Plot Total Invested and Portfolio Value
ax.plot(df['Month'], df['Total Invested'], label='Total Invested', color='green', linestyle='--', marker='o')
ax.plot(df['Month'], df['Portfolio Value'], label='Portfolio Value', color='blue', linestyle='-', marker='o')

# Add titles and labels
ax.set_title('Total Invested and Portfolio Value over Time (Months)')
ax.set_xlabel('Month')
ax.set_ylabel('Amount (INR)')

# Add a legend
ax.legend()

# Display grid
ax.grid(True)

plt.tight_layout()

fig.savefig('/home/rizpython236/BT5/screener-outputs/SIP_value.png', format='png')

time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/SIP_value.png')

print("Done")