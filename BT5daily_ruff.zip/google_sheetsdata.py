from datetime import datetime, date
import numpy as np
from scipy.optimize import newton
from collections import defaultdict
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials
import os
import json
from pyxirr import xirr as pyxirr_calc
from tabulate import tabulate
import sys,traceback
from datetime import datetime

print("=" * 60)
print("STOCK XIRR CALCULATOR")
print("=" * 60)

# ============================================================================
# CONFIGURATION
# ============================================================================
CREDENTIALS_FILE = '/home/rizpython236/BT5/root-stock-483209-u1-b7e74d74ef93.json'
SPREADSHEET_KEY = '1CWtL-P5LhzEy4VnSw7B_HDfGYkB9dhSjt5ybjboeLMo'

# ============================================================================
# GOOGLE SHEETS SETUP
# ============================================================================
def setup_google_sheets():
    """Set up connection to Google Sheets with error handling"""
    try:
        print(f"Using credentials file: {CREDENTIALS_FILE}")
        print(f"File exists: {os.path.exists(CREDENTIALS_FILE)}")

        # Define the scope
        scope = [
            'https://www.googleapis.com/auth/spreadsheets',
            'https://www.googleapis.com/auth/drive.file'
        ]

        # Authenticate with service account
        creds = Credentials.from_service_account_file(
            CREDENTIALS_FILE,
            scopes=scope
        )

        client = gspread.authorize(creds)
        print("✓ Authentication successful!")

        # Open the spreadsheet
        spreadsheet = client.open_by_key(SPREADSHEET_KEY)
        print(f"✓ Spreadsheet opened: {spreadsheet.title}")
        return spreadsheet

    except Exception as e:
        print(f"✗ Authentication error: {e}")
        return None

# ============================================================================
# XIRR CORE FUNCTIONS
# ============================================================================
def xnpv(rate, cashflows):
    """Calculate Net Present Value for irregular cash flows"""
    if rate <= -1:
        return float('inf')

    # Find the earliest date
    t0 = min([cf[0] for cf in cashflows])

    total = 0
    for cf_date, cf_amount in cashflows:
        days_diff = (cf_date - t0).days
        if (1 + rate) <= 0:
            return float('inf')
        discount_factor = (1 + rate) ** (days_diff / 365.0)
        total += cf_amount / discount_factor

    return total

def calculate_xirr(cashflows, guess=0.1):
    """
    Calculate XIRR for irregular cash flows
    Args:
        cashflows: List of tuples [(date, amount), ...]
        guess: Initial guess for the rate
    Returns:
        XIRR as decimal (e.g., 0.1 for 10%) or None if calculation fails
    """
    try:
        if len(cashflows) < 2:
            return None

        # Check for valid cash flow pattern (must have both positive and negative)
        amounts = [cf[1] for cf in cashflows]
        if all(amt >= 0 for amt in amounts) or all(amt <= 0 for amt in amounts):
            return None

        # Try Newton's method
        try:
            result = newton(lambda r: xnpv(r, cashflows), guess, maxiter=100, tol=1e-6)
            if abs(xnpv(result, cashflows)) < 1e-6:
                return result
            return None
        except (RuntimeError, ValueError):
            # Fallback to binary search
            return calculate_xirr_binary_search(cashflows)

    except Exception as e:
        print(f"XIRR calculation error: {e}")
        return None

def calculate_xirr_binary_search(cashflows):
    """Calculate XIRR using binary search (fallback method)"""
    try:
        low, high = -0.9999, 10.0
        npv_low, npv_high = xnpv(low, cashflows), xnpv(high, cashflows)

        if npv_low * npv_high > 0:
            return None

        for _ in range(50):
            mid = (low + high) / 2
            npv_mid = xnpv(mid, cashflows)

            if abs(npv_mid) < 1e-6:
                return mid

            if npv_low * npv_mid < 0:
                high, npv_high = mid, npv_mid
            else:
                low, npv_low = mid, npv_mid

        return mid
    except:
        return None

# ============================================================================
# DATA PARSING FUNCTIONS
# ============================================================================
def parse_date(date_value):
    """Parse date from various formats"""
    if date_value is None:
        return None

    if isinstance(date_value, (datetime, date)):
        return datetime.combine(date_value if isinstance(date_value, date) else date_value.date(),
                              datetime.min.time())

    date_str = str(date_value).strip()

    # Try the expected format first (YYYY-mm-dd)
    try:
        return datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        pass

    date_formats = [
        '%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y',
        '%d-%m-%Y', '%m-%d-%Y', '%Y/%m/%d',
        '%d %b %Y', '%d %B %Y'
    ]

    for fmt in date_formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue

    # Try Excel serial date
    try:
        excel_date = float(date_str)
        from datetime import timedelta
        return datetime(1899, 12, 30) + timedelta(days=excel_date)
    except:
        pass

    print(f"Warning: Could not parse date: {date_value}")
    return None

def parse_amount(amount):
    """Parse amount from various formats"""
    if amount is None:
        return 0.0

    try:
        if isinstance(amount, (int, float)):
            return float(amount)

        amount_str = str(amount).strip()
        for char in ['$', '€', '£', '₹', '¥', ',', ' ', '\xa0']:
            amount_str = amount_str.replace(char, '')

        return float(amount_str)
    except:
        print(f"Warning: Could not parse amount: {amount}")
        return 0.0

# ============================================================================
# STOCK XIRR FUNCTION
# ============================================================================
def calculate_stock_xirr(transactions, market_value, stock_name=""):
    """
    Calculate XIRR for a single stock

    Args:
        transactions: List of dictionaries with 'date' and 'amount' keys
        market_value: Current market value of the stock
        stock_name: Name of the stock (for logging)

    Returns:
        Dictionary with xirr, investment, current_value, and gain/loss
    """
    if stock_name:
        1+1
        #print(f"\nProcessing {stock_name}...")
        #if  stock_name == ("Kirloskar Pneumatic Company" or "PTC India Financial Services" or "RIR Power Electronics" :


    # Append a new transaction before sorting
    new_transaction = {
        'date': datetime.now(),  # Use datetime.now() for current timestamp
        'amount': market_value   # Use your market_value variable
    }

    if market_value !=0:
        transactions.append(new_transaction)

    # Sort transactions by date
    sorted_transactions = sorted(transactions, key=lambda x: x['date'])


    if  stock_name == "Eco Recycling" or stock_name == "P N Gadgil Jewellers"  :
        df =  pd.DataFrame(sorted_transactions)
        #print(df.columns)
        print("_________")
        print(stock_name)
        df = df[['date', 'amount']]
        print(df.to_string(index=False))
        print("_________")
    #else:
    #    continue





    # Prepare cash flows for XIRR calculation
    dates = []
    amounts = []
    total_investment = 0
    total_sell = 0

    today = datetime.now()
    final_value = market_value

    #if final_value > 0:
    #    dates.append(today)
    #    amounts.append(final_value)

   # Process all transactions
    for trans in sorted_transactions:
        amount = trans['amount']
        dates.append(trans['date'])
        amounts.append(amount)

        if amount < 0:
            total_investment += abs(amount)
        if amount > 0:
            total_sell += abs(amount)


    '''
    if stock_name:
        print(f"  Transactions: {len(transactions)}")
        print(f"  Investment: ₹{total_investment:,.2f}")
        print(f"  Current value: ₹{final_value:,.2f}")
        print(f"  Cash flows: {len(dates)}")
    '''


    # Calculate XIRR using pyxirr
    xirr_value = None
    if len(dates) >= 2:
        # Calculate investment period in years
        first_date = min(dates)
        last_date = max(dates)
        investment_days = (last_date - first_date).days
        investment_years = investment_days / 365.25

        # Calculate simple return
        simple_return_pct = None
        if total_investment > 0:
            simple_return = (total_sell - total_investment) / total_investment
            #simple_return = (final_value - total_investment) / total_investment
            simple_return_pct = simple_return * 100

        # Check if investment period is less than 1 year
        if investment_years < 1:
            # Use simple holding period return (non-annualized)
            if simple_return_pct is not None:
                xirr_value = simple_return_pct
                if stock_name:
                    1+1
                    #print(f"  Period: {investment_days} days (< 1 year)")
                    #print(f"  ✓ Simple Return: {xirr_value:.2f}% (non-annualized)")
            elif stock_name:
                print(f"  ✗ Cannot calculate simple return (zero investment)")
        else:
            # Investment period is 1 year or more, use XIRR

            try:
                1+1
                # Try to import pyxirr
                try:
                    from pyxirr import xirr as pyxirr_calc
                    use_pyxirr = True
                except ImportError:
                    use_pyxirr = False
                    if stock_name:
                        print(f"  ⚠ pyxirr not available, using fallback method...")

                if use_pyxirr:
                    # Calculate XIRR using pyxirr
                    xirr_decimal = pyxirr_calc(dates, amounts)
                else:
                    # Fall back to original calculation
                    cashflows = list(zip(dates, amounts))
                    xirr_decimal = calculate_xirr(cashflows)

                if xirr_decimal is not None:
                    xirr_value = xirr_decimal * 100
                    method = "pyxirr" if use_pyxirr else "fallback"
                    if stock_name:
                        #print(f"  ✓ XIRR ({method}): {xirr_value:.2f}%")
                        1+1

                        # Also show simple return for comparison
                        if simple_return_pct is not None:
                            if stock_name:
                                #print(f"  Simple Return: {simple_return_pct:.2f}%")
                                1+1

                elif stock_name:
                    print(f"  ✗ Could not calculate XIRR")

            except Exception as e:
                # Handle any calculation errors
                if stock_name:
                    print(f"  ✗  {stock_name} XIRR calculation error: {str(e)[:50]}...")
                    df =  pd.DataFrame(sorted_transactions)
                    #print(df.columns)
                    df = df[['date', 'amount']]
                    print(df.to_string(index=False))


                    # Fallback to simple return
                    if simple_return_pct is not None:
                        xirr_value = simple_return_pct
                        if stock_name:
                            print(f"  Using simple return: {simple_return_pct:.2f}%")

    elif stock_name:
        print(f"  ✗  {stock_name}  Insufficient cash flows (need at least 2, got {len(dates)})")
        df =  pd.DataFrame(sorted_transactions)
        #print(df.columns)
        df = df[['date', 'amount']]
        print(df.to_string(index=False))

    return {
        'xirr': xirr_value,
        'investment': total_investment,
        'current_value': total_sell,
        'gain_loss': total_sell - total_investment,
        'transaction_count': len(transactions),
        'cashflow_count': len(dates),
        'investment_days': investment_days if len(dates) >= 2 else 0,
        'investment_years': investment_years if len(dates) >= 2 else 0
    }



# ============================================================================
# PORTFOLIO XIRR FUNCTION
# ============================================================================
def calculate_portfolio_xirr(all_transactions, total_market_value,Cost_portfolio_value):
    """
    Calculate XIRR for the entire portfolio

    Args:
        all_transactions: List of all transactions across all stocks
        total_market_value: Total current market value of the portfolio

    Returns:
        Portfolio XIRR as percentage or None
    """
    print("\n" + "=" * 80)
    print("CALCULATING PORTFOLIO XIRR")
    print("=" * 80)


    unrelialized_GL = total_market_value - Cost_portfolio_value
    print(unrelialized_GL,total_market_value,Cost_portfolio_value)

    # Append a new transaction before sorting
    new_transaction = {
        'date': datetime.now(),  # Use datetime.now() for current timestamp
        'amount': total_market_value   # Use your market_value variable
    }

    all_transactions.append(new_transaction)

    all_transactions = sorted(all_transactions, key=lambda x: x['date'])
    #print(all_transactions)

    # Prepare cash flows for XIRR calculation
    dates = []
    amounts = []
    total_portfolio_investment = 0
    total_portfolio_sell = 0

    # Process all transactions
    for trans in all_transactions:
        amount = trans['amount']
        dates.append(trans['date'])
        amounts.append(amount)
        if amount < 0: #BUY
            total_portfolio_investment  += abs(amount) #+= amount
        if amount > 0: #SELL
            total_portfolio_sell  += abs(amount) #+= amount

    #total_market_value = total_market_value  - Cost_portfolio_value
    print(f"Total portfolio investment: ₹{total_portfolio_investment:,.2f}")
    print(f"Total portfolio Mkt value: ₹{total_portfolio_sell:,.2f}")

    #print(all_transactions)


    def fuc(all_transactions):

        # Step 1: Create DataFrame properly
        df = pd.DataFrame(all_transactions)

        # Step 2: Verify
        print(f"DataFrame created. Shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")

        # Step 3: Check date column
        print(f"\nFirst date value: {df['date'].iloc[0]} (type: {type(df['date'].iloc[0])})")

        # Step 4: Convert to pandas datetime (optional since they're already datetime objects)
        df['date'] = pd.to_datetime(df['date'])
        print(f"\nAfter conversion - Date dtype: {df['date'].dtype}")

        # Step 5: Display
        print("\nDataFrame:")
        print(df)

    #fuc(all_transactions)
    #ff


    # Add final total market value as positive cash flow (today's date)
    #today = datetime.now()
    #if total_market_value != 0:
    #    #portfolio_cashflows.append((today, total_market_value))
    #    amounts.append(amount)
    #    dates.append(today)
    #    #amount = trans['amount']
    #    #dates.append(trans['date'])


    # Calculate portfolio XIRR
    portfolio_xirr = None
    if len(all_transactions) >= 2:
        xirr_decimal = pyxirr_calc(dates, amounts) #calculate_xirr(portfolio_cashflows)
        if xirr_decimal is not None:
            portfolio_xirr = xirr_decimal * 100
            print(f"✓ Portfolio XIRR calculated: {portfolio_xirr:.2f}%")
        else:
            print("✗ Could not calculate portfolio XIRR")
    else:
        print("✗ Insufficient cash flows for portfolio XIRR")

    return {
        'portfolio_xirr': portfolio_xirr,
        'total_investment': total_portfolio_investment,
        'total_value': total_portfolio_sell,
        'total_gain_loss': total_portfolio_sell - total_portfolio_investment
    }

# ============================================================================
# DATA PROCESSING FUNCTION
# ============================================================================

def filter_stock_data_simple(transactions_data):
    """
    Simple approach without using DataFrame
    """
    if not transactions_data:
        return []

    # Group data by Stock
    stock_groups = {}
    for transaction in transactions_data:
        stock = transaction['Stock']
        if stock not in stock_groups:
            stock_groups[stock] = []
        stock_groups[stock].append(transaction)

    # Process each stock group
    filtered_data = []

    for stock, transactions in stock_groups.items():
        # Sort by Date descending (most recent first)
        transactions_sorted = sorted(
            transactions,
            key=lambda x: x['Date'],
            reverse=True
        )

        # Find first occurrence from bottom where Prev Row is 0 and Type is Buy
        keep_from_index = None
        for i, transaction in enumerate(transactions_sorted):
            if transaction['Prev Row'] == 0 and transaction['Type'] == 'Buy':
                keep_from_index = i
                break

        # If found such a row, keep from that row onward (most recent to that point)
        if keep_from_index is not None:
            # Get transactions from that point onward (most recent first)
            transactions_to_keep = transactions_sorted[:keep_from_index + 1]
        else:
            # Keep all transactions for this stock
            transactions_to_keep = transactions_sorted

        # Sort back to chronological order and add to filtered data
        transactions_to_keep_sorted = sorted(
            transactions_to_keep,
            key=lambda x: x['Date']
        )
        filtered_data.extend(transactions_to_keep_sorted)

    return filtered_data



def process_investment_data(transactions_sheet, holdings_sheet):
    """
    Process data from Google Sheets and calculate both stock and portfolio XIRR

    Args:
        transactions_sheet: Worksheet object for ZDHTransactions
        holdings_sheet: Worksheet object for ZDH Summary

    Returns:
        Dictionary containing stock XIRR results and portfolio XIRR results
    """
    print("\nProcessing data...")

    try:
        # Get all data from sheets
        transactions_data = transactions_sheet.get_all_records()
        holdings_data = holdings_sheet.get_all_records()

        print(f"✓ Found {len(transactions_data)} transactions")
        print(f"✓ Found {len(holdings_data)} holdings")

        # Debug column names
        if transactions_data:
            #print(transactions_data)
            #transactions_data = filter_stock_data_simple(transactions_data)
            #print(transactions_data)
            1+1
            #print(f"\nTransaction columns: {list(transactions_data[0].keys())}")
        if holdings_data:
            1+1
            #print(f"Holding columns: {list(holdings_data[0].keys())}")

        # Create holdings dictionary from ZDH Summary
        holdings_dict = {}
        total_portfolio_value = 0
        Cost_portfolio_value = 0
        unique_keys = set()

        #print(holdings_data)
        for holding in holdings_data:
            # Find stock name column
            stock_name = None
            for key in holding.keys():
                if 'stock' in key.lower() or 'name' in key.lower():
                    stock_name = str(holding[key]).strip()
                    break


            if stock_name:
                # Find market value column Mkt Value ,Cost
                market_value = 0
                Cost_value = 0

                for key in holding.keys():
                    #print(holding.keys())
                    key_lower = key.lower().replace(' ', '').replace('_', '')
                    #print(key_lower)
                    #if key_lower in ['marketvalue', 'mktvalue', 'currentvalue']:
                    #if any(term in key for term in ['Mkt', 'market', 'Mkt Value','Value']):
                    if key == 'Mkt Value' and holding[key] != 0 :# in holding:
                        market_value = parse_amount(holding[key])
                        #print(holding[key])
                        #break
                    key_lower = key.lower().replace(' ', '').replace('_', '')
                    #if key_lower in ['marketvalue', 'cost', 'currentvalue']:
                    #if any(term in key.lower() for term in ['valuex', 'cost', 'mktx']):
                    if key == 'Cost' and holding[key] != 0 :
                        Cost_value = parse_amount(holding[key])
                        #print(holding[key])
                        #break
                    if 'cost' in key or 'mktvalue' in key or 'Mkt Value' in key :
                        #print("Holding sheet issue")
                        #print(key_lower)
                        unique_keys.add(key)
                        #print(f"\nUnique keys ({len(unique_keys)} total): {', '.join(sorted(unique_keys))}")
                        #sys.exit(1)

                holdings_dict[stock_name] = market_value
                total_portfolio_value += market_value
                Cost_portfolio_value += Cost_value

        print(f"✓ Created holdings dictionary with {len(holdings_dict)} stocks")
        print(f"✓ Total portfolio value: ₹{total_portfolio_value:,.2f}")
        print(f"✓ Total COST value: ₹{Cost_portfolio_value:,.2f}")

        # Exit if we didn't find what we need
        if total_portfolio_value == 0 or Cost_portfolio_value == 0:
            print("ERROR: Could not find market value or cost!")
            print(f"\nUnique keys ({len(unique_keys)} total): {', '.join(sorted(unique_keys))}")
            sys.exit(1)

        # Group transactions by stock and collect all transactions for portfolio
        stock_transactions = defaultdict(list)
        all_transactions_for_portfolio = []

        for transaction in transactions_data:
            # Find stock column
            stock = None
            for key in transaction.keys():
                if 'stock' in key.lower():
                    stock = str(transaction[key]).strip()
                    break

            if not stock:
                continue

            # Find amount column
            cf = 0
            for key in transaction.keys():
                if key.lower() in ['cf', 'cash flow', 'amountx', 'cash', 'amountx']:
                    cf = parse_amount(transaction[key])
                    break

            # Find date column
            date_str = None
            for key in transaction.keys():
                if 'date' in key.lower():
                    date_str = transaction[key]
                    break

            if not date_str:
                continue

            # Parse date
            trans_date = parse_date(date_str)
            if not trans_date:
                continue

            # Store transaction for this stock
            stock_transactions[stock].append({
                'date': trans_date,
                'amount': cf
            })

            # Store for portfolio aggregation
            all_transactions_for_portfolio.append({
                'date': trans_date,
                'amount': cf
            })

        print(f"✓ Grouped transactions for {len(stock_transactions)} stocks")

        # Calculate XIRR for each stock
        stock_xirr_results = {}

        #print(stock_transactions.columns)


        for stock, transactions in stock_transactions.items():
            market_value = holdings_dict.get(stock, 0)
            result = calculate_stock_xirr(transactions, market_value, stock)
            stock_xirr_results[stock] = result

        # Calculate portfolio XIRR
        portfolio_results = calculate_portfolio_xirr(
            all_transactions_for_portfolio,
            total_portfolio_value,Cost_portfolio_value
        )

        return {
            'stock_results': stock_xirr_results,
            'portfolio_results': portfolio_results,
            'holdings_dict': holdings_dict
        }

    except Exception as e:
        print(f"✗ Error processing data: {e}")
        import traceback
        traceback.print_exc()
        return {}

# ============================================================================
# MAIN EXECUTION FUNCTION
# ============================================================================
def main():
    """Main function to run the XIRR calculator"""
    try:
        # Setup Google Sheets connection
        spreadsheet = setup_google_sheets()
        if not spreadsheet:
            print("Failed to connect to Google Sheets")
            return None

        # Get worksheets
        try:
            transactions_sheet = spreadsheet.worksheet('ZDHTransactions')
            print("✓ Found ZDHTransactions sheet")
        except:
            print("✗ ZDHTransactions sheet not found. Available sheets:")
            for ws in spreadsheet.worksheets():
                print(f"  - {ws.title}")
            return None

        try:
            holdings_sheet = spreadsheet.worksheet('ZDH Summary')
            print("✓ Found ZDH Summary sheet")
        except:
            print("✗ ZDH Summary sheet not found. Available sheets:")
            for ws in spreadsheet.worksheets():
                print(f"  - {ws.title}")
            return None

        # Process data and calculate XIRR
        results = process_investment_data(transactions_sheet, holdings_sheet)

        if not results:
            print("✗ No results to display")
            return None

        # Extract results
        stock_results = results['stock_results']
        portfolio_results = results['portfolio_results']
        holdings_dict = results['holdings_dict']

        # Print portfolio summary
        print("\n" + "=" * 80)
        print("PORTFOLIO SUMMARY")
        print("=" * 80)

        print(f"\n📊 Overall Portfolio:")
        print(f"   Total Investment:    ₹{portfolio_results['total_investment']:>15,.2f}")
        print(f"   Current Value:       ₹{portfolio_results['total_value']:>15,.2f}")
        print(f"   Total Gain/Loss:     ₹{portfolio_results['total_gain_loss']:>15,.2f}")

        if portfolio_results['portfolio_xirr'] is not None:
            print(f"   Portfolio XIRR:      {portfolio_results['portfolio_xirr']:>15.2f}%")

            # Calculate simple return
            if portfolio_results['total_investment'] > 0:
                simple_return = (portfolio_results['total_gain_loss'] /
                               portfolio_results['total_investment'] * 100)
                print(f"   Simple Return:       {simple_return:>15.2f}%")
        else:
            print(f"   Portfolio XIRR:      {'N/A':>15}")


        # Filter and sort stock results
        valid_stock_results = {k: v for k, v in stock_results.items()
                              if v['xirr'] is not None}
        sorted_stocks = sorted(valid_stock_results.items(),
                              key=lambda x: x[1]['xirr'])

        sorted_stocks = sorted(valid_stock_results.items(),
                               key=lambda x: x[1]['xirr'],
                               reverse=True)  # Add this for descending order

        # Filter for long-term investments (≥ 1 year)
        #sorted_stocks = long_term_stocks = [(stock, data) for stock, data in sorted_stocks
        #                    if data['investment_years'] >= 1]

        # Filter for stocks currently held
        sorted_stocks = [(stock, data) for stock, data in sorted_stocks
                            if stock in holdings_dict]

        print(f"Current holdings: {len(sorted_stocks)} stocks")


        # Print individual stock results
        print("\n" + "=" * 80)
        print("INDIVIDUAL STOCK XIRR RESULTS (Ascending Order)")
        print("=" * 80)
        '''
        if sorted_stocks:
            print(f"\n{'No.':<4} {'Stock':<25} {'XIRR':<12} {'Investment':<15} {'SOLD/Current Value':<15} {'Gain/Loss':<15} {'Year':<15} {'Simple/XIRR':<15} {'Holding':<15}"")
            print("-" * 86)

            for i, (stock, data) in enumerate(sorted_stocks, 1):
                print(f"{i:<4} {stock:<25} {data['xirr']:<12.2f}% "
                      f"₹{data['investment']:<13,.2f} "
                      f"₹{data['current_value']:<14,.2f} "
                      f"₹{data['gain_loss']:<14,.2f}"
                      f"{data['investment_years']:<14,.2f}"
                      f"{'simple return' if data['investment_years'] < 1 else 'XIRR'}")
                      #f"₹{data['gain_loss']:<14,.2f}")

            '''


        if sorted_stocks:
            # Prepare table data
            table_data = []
            for i, (stock, data) in enumerate(sorted_stocks, 1):
                method = "Simple" if data['investment_years'] < 1 else "XIRR"
                if stock in holdings_dict:
                    Status = "YES"
                else:
                    Status = "NO"
                row = [
                    i,
                    stock,
                    f"{data['xirr']:.2f}%",
                    f"₹{data['investment']:,.2f}",
                    f"₹{data['current_value']:,.2f}",
                    f"₹{data['gain_loss']:,.2f}",
                    f"{data['investment_years']:.2f}",
                    method,
                    Status

                ]
                table_data.append(row)

            # Define headers
            headers = ['No.', 'Stock', 'XIRR', 'Investment', 'Current Value', 'Gain/Loss', 'Years', 'Method', 'Holding Now']

            # Print table
            #print(tabulate(table_data, headers=headers, tablefmt='grid', stralign='right', numalign='right'))

            # Create DataFrame
            df = pd.DataFrame(table_data, columns=headers)

            # Filter for holdings currently held
            #df = df[df['Holding Now'] == 'YES']

            # If you want to reset the 'No.' column after filtering
            #df = df.reset_index(drop=True)
            #df.index = df.index + 1  # Make index start from 1 again
            #df['No.'] = range(1, len(df_held) + 1)  # Update the 'No.' column

            # Set 'No.' as the index if desired
            df = df.set_index('No.')

            # Display the DataFrame
            #print(df)
            print(tabulate(df, headers=headers, tablefmt='grid', stralign='right', numalign='right'))

            '''
            df = pd.DataFrame(table_data, columns=headers)
            # Filter for Holding Now == YES
            df_filtered = df[df['Holding Now'] == 'YES'].copy()

            # Reset the No. column for filtered view
            df_filtered['No.'] = range(1, len(df_filtered) + 1)

            # Print filtered table
            if not df_filtered.empty:
                print("Current Holdings Only:")
                print(tabulate(df_filtered.values, headers=headers, tablefmt='grid', stralign='right', numalign='right'))
            '''

            sorted_stocks = [(stock, data) for stock, data in sorted_stocks
                             if stock != 'Privi Speciality Chemicals' or stock != 'SKF India (Industrial)' or stock != 'Tata Motors Commercial Vhcls' or stock != 'Aditya Birla Lifestyle Brands']

            # Statistics
            xirr_values = [data['xirr'] for _, data in sorted_stocks]
            print("\n📊 Individual Stock Statistics:")
            print(f"  Total stocks with XIRR: {len(sorted_stocks)}")
            print(f"  Average XIRR: {np.mean(xirr_values):.2f}%")
            print(f"  Minimum XIRR: {np.min(xirr_values):.2f}%")
            print(f"  Maximum XIRR: {np.max(xirr_values):.2f}%")
            print(f"  Median XIRR: {np.median(xirr_values):.2f}%")

            #print(sorted_stocks)


            total_inv_weighted = sum(data['investment'] for _, data in sorted_stocks)
            if total_inv_weighted > 0:
                weighted_avg = sum(data['xirr'] * data['investment']
                                  for _, data in sorted_stocks) / total_inv_weighted
                print(f"  Weighted Avg XIRR Investment: {weighted_avg:.2f}%")

            # Weighted average XIRR
            total_inv_weighted = sum(data['investment'] for _, data in sorted_stocks)
            if total_inv_weighted > 0  :
                weighted_avg = sum(data['xirr'] * data['current_value']
                                  for _, data in sorted_stocks) / total_inv_weighted
                print(f"  Weighted Avg XIRR current_value: {weighted_avg:.2f}%")

            # Filter for stocks with investment_years > 1
            long_term_stocks = [(stock, data) for stock, data in sorted_stocks if data['investment_years'] > 1]

            if long_term_stocks:
                total_inv_weighted = sum(data['investment'] for _, data in long_term_stocks)
                #total_inv_weighted = data[data['Method'] == 'XIRR']['Investment'].sum()
                #total_inv_weighted = sum(data.get('investment', 0) for _, data in long_term_stocks.items()) # if data.get('Method') == 'XIRR' or data.get('Method') == 'Simple')
                #total_inv_weighted = sum(data.get('investment', 0) for data in long_term_stocks)  # No .items() for lists


                if total_inv_weighted > 0:
                    #weighted_avg = sum(data['xirr'] * data['current_value']
                    #                  for _, data in long_term_stocks) / total_inv_weighted
                    weighted_avg = sum(
                        data['xirr'] * data['current_value']
                        for _, data in long_term_stocks  # or just long_term_stocks if it's already iterable
                        #if data.get('Method') == 'XIRR'
                    ) / total_inv_weighted if total_inv_weighted > 0 else 0
                    print(f"Weighted average XIRR current_value (holdings > 1 year): {weighted_avg:.2f}%")


        else:
            print("\nNo valid XIRR calculations available for individual stocks.")

        # Print stocks with no XIRR
        no_xirr_stocks = [k for k, v in stock_results.items() if v['xirr'] is None]
        if no_xirr_stocks:
            print(f"\n⚠️  Stocks with no XIRR calculation ({len(no_xirr_stocks)}):")
            for stock in no_xirr_stocks:
                data = stock_results[stock]
                print(f"  - {stock}: Investment: ₹{data['investment']:,.2f}, "
                      f"Current: ₹{data['current_value']:,.2f}")

        print("\n" + "=" * 80)
        print("✅ Calculation complete!")
        print("=" * 80)

        return results

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return None

# ============================================================================
# ENTRY POINT
# ============================================================================
if __name__ == "__main__":
    print("\nStarting Stock XIRR Calculator...")

    # Check if required packages are installed
    try:
        import gspread
        import numpy
        import scipy
    except ImportError:
        print("Installing required packages...")
        import subprocess
        subprocess.check_call(['pip', 'install', 'gspread', 'numpy', 'scipy',
                              'google-auth', 'google-auth-oauthlib', 'google-auth-httplib2'])
        print("✅ Packages installed. Please restart the script.")
        exit()

    # Import timedelta for date calculations
    from datetime import timedelta

    # Run main function
    try:
        results = main()
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")

gggggggggggg

'''
from ZDHTransactions use Date, Stock, Cash Flow
from ZDH Summary use Stock Name , Mkt Value
'''

CREDENTIALS_FILE = '/home/rizpython236/BT5/root-stock-483209-u1-b7e74d74ef93.json'

#CREDENTIALS_FILE = 'credentials.json'  # Your service account credentials
SPREADSHEET_KEY = '1CWtL-P5LhzEy4VnSw7B_HDfGYkB9dhSjt5ybjboeLMo'  # From your Google Sheets URL


