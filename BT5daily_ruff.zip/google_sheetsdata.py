"""
Stock XIRR Calculator - Optimised & Robust
-------------------------------------------
Calculates XIRR for individual stocks and the entire portfolio using
transaction data and current holdings from Google Sheets.
Uses pandas for efficient data processing with flexible column name detection.
"""

import sys
from datetime import datetime, timedelta
from collections import defaultdict

import pandas as pd
import gspread
from google.oauth2.service_account import Credentials
from pyxirr import xirr as pyxirr_calc
from tabulate import tabulate

# ============================================================================
# CONFIGURATION
# ============================================================================
CONFIG = {
    "credentials_file": "/home/rizpython236/BT5/root-stock-483209-u1-b7e74d74ef93.json",
    "spreadsheet_key": "1CWtL-P5LhzEy4VnSw7B_HDfGYkB9dhSjt5ybjboeLMo",
    "transactions_sheet_name": "ZDHTransactions",
    "holdings_sheet_name": "ZDH Summary",
}

# ============================================================================
# GOOGLE SHEETS HELPERS
# ============================================================================
def setup_google_sheets():
    """Authenticate and return the Google Sheets client."""
    try:
        scope = [
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive.file",
        ]
        creds = Credentials.from_service_account_file(
            CONFIG["credentials_file"], scopes=scope
        )
        client = gspread.authorize(creds)
        print("✓ Google Sheets authentication successful.")
        return client.open_by_key(CONFIG["spreadsheet_key"])
    except Exception as e:
        print(f"✗ Google Sheets connection failed: {e}")
        sys.exit(1)


def load_worksheet_data(spreadsheet, sheet_name):
    """Load a worksheet into a pandas DataFrame with proper column handling."""
    try:
        worksheet = spreadsheet.worksheet(sheet_name)
        records = worksheet.get_all_records()
        if not records:
            print(f"⚠ Warning: Worksheet '{sheet_name}' is empty.")
            return pd.DataFrame()
        df = pd.DataFrame(records)
        # Standardise column names: lower case, strip spaces
        df.columns = df.columns.str.strip().str.lower()
        print(f"✓ Loaded {len(df)} rows from '{sheet_name}'")
        return df
    except Exception as e:
        print(f"✗ Could not load '{sheet_name}': {e}")
        return pd.DataFrame()


# ============================================================================
# PARSING HELPERS (vectorised with pandas)
# ============================================================================
def parse_dates_vectorized(date_series):
    """
    Convert a pandas Series of mixed date formats to datetime.
    Unknown formats become NaT.
    """
    # First try the expected format
    dates = pd.to_datetime(date_series, format="%Y-%m-%d", errors="coerce")
    # For those that failed, try Excel serial numbers (if numeric)
    mask_na = dates.isna()
    if mask_na.any():
        excel_series = pd.to_numeric(date_series[mask_na], errors="coerce")
        if excel_series.notna().any():
            excel_dates = pd.to_datetime(
                "1899-12-30"
            ) + pd.to_timedelta(excel_series, unit="D")
            dates.loc[mask_na] = excel_dates
    return dates


def parse_amounts_vectorized(amount_series):
    """Remove currency symbols and commas, convert to float."""
    cleaned = amount_series.astype(str).str.replace(
        r"[\$€£₹¥, \xa0]", "", regex=True
    )
    return pd.to_numeric(cleaned, errors="coerce").fillna(0.0)





def invt_days(cf,stock_name):
    # Your DataFrame (ensure dates are datetime and sorted)
    cf_df = original = cf.copy()
    #cf_df = cf.copy()
    cf_df["date"] = pd.to_datetime(cf_df["date"])
    cf_df = cf_df.sort_values("date").reset_index(drop=True)
    is_different = not original.equals(cf_df)

    is_already_sorted = original["date"].is_monotonic_increasing
    if is_already_sorted ==False:
        #print("Already sorted by date:", is_already_sorted)
        print(f"{stock_name} Order changed:", is_different)

    # Exclude rows with amount == 0 (these are not actual transactions)
    #transactions_df = cf_df[cf_df["amount"] != 0].copy()

    investment_days = 0
    start_date = None

    for _, row in cf_df.iterrows():
        if row["cumulative_units"] > 0:
            # If we are not already in an active period, start one
            if start_date is None:
                start_date = row["date"]
        #elif cumulative_units == 0:  #else:
        else:
            # If we were in an active period, close it now
            if start_date is not None:
                investment_days += (row["date"] - start_date).days
                start_date = None

    # If after the loop we are still in an active period (no zero at the end),
    # you may decide to either ignore it (as no exit) or calculate up to last date.
    # According to your example, all periods end with a zero, so no action needed.

    investment_years = investment_days / 365.25 if investment_days > 0 else 0

    #print(f"Investment days (active periods only): {investment_days}")
    #print(f"Investment years: {investment_years:.2f}")

    return investment_days if investment_days > 0 else 0


# ============================================================================
# XIRR CORE (using pyxirr, with fallback for short periods)
# ============================================================================
def calculate_xirr(cashflow_df):
    """
    Calculate XIRR for a DataFrame with columns 'date' and 'amount'.
    For holding periods < 1 year, returns simple return (non‑annualised).
    Returns None if insufficient data or calculation fails.
    """
    if cashflow_df.empty or len(cashflow_df) < 2:
        return None

    # Ensure sorted by date
    cashflow_df = cashflow_df.sort_values("date").copy()
    total_investment = -cashflow_df[cashflow_df["amount"] < 0]["amount"].sum()
    total_realised = cashflow_df[cashflow_df["amount"] > 0]["amount"].sum()

    first_date = cashflow_df["date"].min()
    last_date = cashflow_df["date"].max()
    years = (last_date - first_date).days / 365.25

    # If period < 1 year, return simple return (non‑annualised)
    if years < 1:
        if total_investment == 0:
            return None
        simple_return = (total_realised - total_investment) / total_investment
        return simple_return * 100  # as percentage

    # Use pyxirr for XIRR
    try:
        xirr_decimal = pyxirr_calc(cashflow_df["date"], cashflow_df["amount"])
        if xirr_decimal is not None:
            return xirr_decimal * 100
    except Exception:
        pass
    return None


# ============================================================================
# STOCK & PORTFOLIO XIRR
# ============================================================================
def calculate_stock_xirr(transactions_df, market_value, stock_name=""):
    """
    Compute XIRR for a single stock.
    Args:
        transactions_df: DataFrame with columns 'date', 'amount'
        market_value: current holding value (positive)
        stock_name: for logging (optional)
    Returns:
        dict with xirr, investment, current_value, gain_loss, etc.
    """
    # Append current market value as a final cash flow
    current_date = datetime.now()
    if market_value > 0:
        last_cumulative_units = 0 #df["cumulative_units"].iloc[-1]
        final_cf = pd.DataFrame({"date": [current_date], "amount": [market_value],"cumulative_units": [last_cumulative_units]})
        cf_df = pd.concat([transactions_df, final_cf], ignore_index=True)
    else:
        cf_df = transactions_df



    #print(transactions_df)


    # Compute aggregates
    total_investment = -cf_df[cf_df["amount"] < 0]["amount"].sum()
    total_realised = cf_df[cf_df["amount"] > 0]["amount"].sum()



    # Additional info
    if len(cf_df) >= 2:
        first_date = cf_df["date"].min()
        last_date = cf_df["date"].max()
        investment_days = invt_days(cf_df,stock_name) #(last_date - first_date).days
        investment_years = investment_days / 365.25
    else:
        investment_days = investment_years = 0

    if investment_years > 1:
        xirr_pct = calculate_xirr(cf_df)
    else:# simple
        xirr_pct = ((total_realised - total_investment) /
                          total_investment) * 100

    return {
        "xirr": xirr_pct,
        "investment": total_investment,
        "current_value": total_realised,
        "gain_loss": total_realised - total_investment,
        "transaction_count": len(transactions_df),
        "cashflow_count": len(cf_df),
        "investment_days": investment_days,
        "investment_years": investment_years,
        #"investment_years": investment_years,
    }


def calculate_portfolio_xirr(all_cashflows_df, total_market_value,unrealised_value):
    """
    Compute XIRR for the whole portfolio.
    all_cashflows_df: DataFrame with columns 'date', 'amount' for all stocks.
    total_market_value: sum of current holdings (positive cash flow).
    """
    # Append current total value
    current_date = datetime.now()
    if total_market_value > 0:
        #print(unrealised_value)
        #final_cf = pd.DataFrame({"date": [current_date], "amount": [unrealised_value]})
        final_cf = pd.DataFrame({"date": [current_date], "amount": [total_market_value]})
        cf_df = pd.concat([all_cashflows_df, final_cf], ignore_index=True)
    else:
        cf_df = all_cashflows_df

    total_invested = -cf_df[cf_df["amount"] < 0]["amount"].sum()
    total_value = cf_df[cf_df["amount"] > 0]["amount"].sum()

    xirr_pct = calculate_xirr(cf_df)

    #print(f"Portfolio XIRR {xirr_pct:.2f}%")


    return {
        "portfolio_xirr": xirr_pct,
        "total_investment": total_invested,
        "total_value": total_value,
        "total_gain_loss": total_value - total_invested,
    }


# ============================================================================
# FLEXIBLE COLUMN DETECTION
# ============================================================================
def find_column(df, candidates, fallback_contains=None):
    """
    Find a column in a DataFrame by trying exact matches first,
    then partial matches (if fallback_contains is a list of substrings).
    Returns the column name or None.
    """
    # Exact match
    for col in candidates:
        if col in df.columns:
            return col
    # Partial match
    if fallback_contains:
        for col in df.columns:
            for sub in fallback_contains:
                if sub in col:
                    return col
    return None


# ============================================================================
# MAIN PROCESSING PIPELINE (PANDAS HEAVY)
# ============================================================================
def process_investment_data(transactions_df, holdings_df):
    """
    Process transaction and holding DataFrames to compute stock‑level
    and portfolio XIRR.
    """
    # ------------------------------------------------------------
    # 1. Holdings sheet: find stock name, market value, cost columns
    # ------------------------------------------------------------
    if holdings_df.empty:
        print("✗ Holdings sheet is empty. Cannot proceed.")
        return {}, {}

    print("\n[DEBUG] Holdings columns:", list(holdings_df.columns))

    # Stock name column
    stock_col = find_column(
        holdings_df,
        candidates=["stock", "name", "security", "instrument", "scrip"],
        fallback_contains=["stock", "name", "security"]
    )
    if not stock_col:
        raise KeyError(f"No stock name column found in holdings sheet. "
                       f"Available: {list(holdings_df.columns)}")

    # Market value column
    mkt_col = find_column(
        holdings_df,
        candidates=["mkt value", "market value", "current value", "mktvalue", "marketvalue"],
        fallback_contains=["mkt", "market", "current"]
    )
    if not mkt_col:
        raise KeyError(f"Missing market value column in holdings sheet. "
                       f"Available: {list(holdings_df.columns)}")

    # Cost column
    cost_col = find_column(
        holdings_df,
        candidates=["cost", "cost value", "purchase value", "investment"],
        fallback_contains=["cost", "purchase"]
    )
    if not cost_col:
        raise KeyError(f"Missing cost column in holdings sheet. "
                       f"Available: {list(holdings_df.columns)}")

    # Parse numeric columns
    holdings_df["market_value"] = parse_amounts_vectorized(holdings_df[mkt_col])
    holdings_df["cost_value"] = parse_amounts_vectorized(holdings_df[cost_col])
    holdings_df["stock"] = holdings_df[stock_col].astype(str).str.strip()

    # Keep only rows with positive market value (active holdings)
    active_holdings = holdings_df[holdings_df["market_value"] > 0].copy()
    total_portfolio_value = active_holdings["market_value"].sum()
    total_cost_value = active_holdings["cost_value"].sum()
    unrealised_value = total_portfolio_value - total_cost_value
    print(f"✓ Total portfolio value: ₹{total_portfolio_value:,.2f}")
    print(f"✓ Total cost: ₹{total_cost_value:,.2f}")

    # ------------------------------------------------------------
    # 2. Transactions sheet: find date, amount, stock columns
    # ------------------------------------------------------------
    if transactions_df.empty:
        print("✗ Transactions sheet is empty.")
        return {}, {}

    print("\n[DEBUG] Transactions columns:", list(transactions_df.columns))

    # Date column
    date_col = find_column(
        transactions_df,
        candidates=["date", "transaction date", "trade date", "datex"],
        fallback_contains=["date"]
    )
    if not date_col:
        raise KeyError(f"No date column found in transactions sheet. "
                       f"Available: {list(transactions_df.columns)}")

    # Amount column
    amount_col = find_column(
        transactions_df,
        candidates=["cf", "cash flow", "amount", "value", "net amount"],
        fallback_contains=["cf", "amount", "cash", "value"]
    )
    if not amount_col:
        raise KeyError(f"No amount/cash flow column found in transactions sheet. "
                       f"Available: {list(transactions_df.columns)}")

    # Stock column
    stock_col_txn = find_column(
        transactions_df,
        candidates=["stock", "security", "symbol", "scrip"],
        fallback_contains=["stock", "security"]
    )
    if not stock_col_txn:
        raise KeyError(f"No stock column found in transactions sheet. "
                       f"Available: {list(transactions_df.columns)}")

    # cumulative units column
    cumulative_units_col_txn = find_column(
        transactions_df,
        candidates=["cumulative units", "securityxx", "symbolxx", "scripxx"],
        fallback_contains=["cumulative units", "securityxx"]
    )
    if not cumulative_units_col_txn:
        raise KeyError(f"No cumulative units column found in transactions sheet. "
                       f"Available: {list(transactions_df.columns)}")

    # Parse dates and amounts
    transactions_df["date"] = parse_dates_vectorized(transactions_df[date_col])
    transactions_df["amount"] = parse_amounts_vectorized(transactions_df[amount_col])
    transactions_df["stock"] = transactions_df[stock_col_txn].astype(str).str.strip()
    transactions_df["cumulative_units"] = parse_amounts_vectorized(transactions_df[cumulative_units_col_txn])

    # Remove rows with invalid dates
    transactions_df = transactions_df.dropna(subset=["date"]).copy()
    # Keep only stocks that are still held
    active_stocks = set(active_holdings["stock"])
    #transactions_df["Holding"] = transactions_df["stock"].isin(active_stocks)
    transactions_df["HOLDING"] = transactions_df["stock"].apply(lambda x: "YES" if x in active_stocks else "NO")
    #transactions_df["HOLDING"] = "YES"   # all rows are active
    #transactions_df = transactions_df[transactions_df["stock"].isin(active_stocks)]    #####################################

    # ------------------------------------------------------------
    # 3. Group transactions by stock and compute XIRR
    # ------------------------------------------------------------
    stock_results = {}
    all_portfolio_cashflows = []

    for stock, group in transactions_df.groupby("stock"):
        cf = group[["date", "amount","cumulative_units"]].copy()
        market_val = active_holdings.loc[
            active_holdings["stock"] == stock, "market_value"
        ].values
        market_val = market_val[0] if len(market_val) > 0 else 0.0

        if market_val == 0:
            1+1
            #continue

        result = calculate_stock_xirr(cf, market_val, stock)
        stock_results[stock] = result
        all_portfolio_cashflows.append(cf)

    # ------------------------------------------------------------
    # 4. Portfolio XIRR
    # ------------------------------------------------------------
    if all_portfolio_cashflows:
        portfolio_cf = pd.concat(all_portfolio_cashflows, ignore_index=True)
        portfolio_result = calculate_portfolio_xirr(portfolio_cf, total_portfolio_value,unrealised_value)
    else:
        portfolio_result = {
            "portfolio_xirr": None,
            "total_investment": 0,
            "total_value": total_portfolio_value,
            "total_gain_loss": total_portfolio_value,
        }

    return stock_results, portfolio_result,transactions_df


# ============================================================================
# DISPLAY RESULTS (USING PANDAS & TABULATE)
# ============================================================================
def display_results(stock_results, portfolio_result, holdings_df,active_stocks):
    """Pretty print the XIRR results."""
    print("\n" + "=" * 80)
    print("PORTFOLIO SUMMARY")
    print("=" * 80)
    print(f"\n📊 Overall Portfolio:")
    print(f"   Total Investment:    ₹{portfolio_result['total_investment']:>15,.2f}")
    print(f"   Current Value:       ₹{portfolio_result['total_value']:>15,.2f}")
    print(f"   Total Gain/Loss:     ₹{portfolio_result['total_gain_loss']:>15,.2f}")
    if portfolio_result['portfolio_xirr'] is not None:
        print(f"   Portfolio XIRR:      {portfolio_result['portfolio_xirr']:>15.2f}%")
        if portfolio_result['total_investment'] > 0:
            simple = (portfolio_result['total_gain_loss'] /
                      portfolio_result['total_investment'] * 100)
            print(f"   Simple Return:       {simple:>15.2f}%")
    else:
        print(f"   Portfolio XIRR:      {'N/A':>15}")

    # Prepare stock-level table
    valid_stocks = {k: v for k, v in stock_results.items() if v['xirr'] is not None}
    if not valid_stocks:
        print("\nNo valid XIRR calculations for individual stocks.")
        return

    # Build DataFrame for display
    rows = []
    for stock, data in valid_stocks.items():
        method = "Simple" if data['investment_years'] < 1 else "XIRR"
        rows.append({
            "Stock": stock,
            "XIRR (%)": data['xirr'],
            "Investment (₹)": data['investment'],
            "Current Value (₹)": data['current_value'],
            "Gain/Loss (₹)": data['gain_loss'],
            "Years": data['investment_years'],
            "Method": method,
        })

    df_display = pd.DataFrame(rows)
    df_display["HOLDING"] = df_display["Stock"].apply(lambda x: "YES" if x in active_stocks else "NO")

    print(list(df_display.columns))
    # Sort by XIRR descending
    df_display = df_display.sort_values(["HOLDING","Current Value (₹)"], ascending=[False, False]).reset_index(drop=True)
    #df_display = df_display.sort_values("XIRR (%)", ascending=False).reset_index(drop=True)
    df_display.index = df_display.index + 1  # 1‑based index for display

    print("\n" + "=" * 80)
    print("INDIVIDUAL STOCK XIRR RESULTS (Descending Order)")
    print("=" * 80)
    print(tabulate(df_display, headers="keys", tablefmt="grid", floatfmt=".2f"))
    df_display = df_display[(df_display["XIRR (%)"] < 2000) & (df_display["HOLDING"] != 'xxx') ]

    # Additional statistics
    xirr_vals = df_display["XIRR (%)"].values
    print("\n📊 Individual Stock Statistics:")
    print(f"  Total stocks with XIRR: {len(xirr_vals)}")
    print(f"  Average XIRR: {xirr_vals.mean():.2f}%")
    print(f"  Minimum XIRR: {xirr_vals.min():.2f}%")
    print(f"  Maximum XIRR: {xirr_vals.max():.2f}%")
    print(f"  Median XIRR: {pd.Series(xirr_vals).median():.2f}%")

    # Weighted by investment
    total_inv = df_display["Investment (₹)"].sum()
    if total_inv > 0:
        weighted = (df_display["XIRR (%)"] * df_display["Investment (₹)"]).sum() / total_inv
        print(f"  Weighted Avg XIRR (by investment): {weighted:.2f}%")

    # Long-term holdings (>1 year)
    long_term = df_display[(df_display["Years"] > 1) & (df_display['HOLDING'] =='YES') ]
    if not long_term.empty:
        lt_inv = long_term["Investment (₹)"].sum()
        if lt_inv > 0:
            lt_weighted = (long_term["XIRR (%)"] * long_term["Investment (₹)"]).sum() / lt_inv
            print(f"  Weighted Avg XIRR for Cr holdings >1 year: {lt_weighted:.2f}%")

    # Stocks without XIRR (e.g., insufficient data)
    no_xirr = [s for s, d in stock_results.items() if d['xirr'] is None]
    if no_xirr:
        print(f"\n⚠️  Stocks with no XIRR calculation ({len(no_xirr)}):")
        for s in no_xirr:
            d = stock_results[s]
            print(f"  - {s}: Invested ₹{d['investment']:,.2f}, Current ₹{d['current_value']:,.2f}")


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================
def main():
    print("\nStarting Stock XIRR Calculator (Optimised)...")
    print("=" * 60)

    try:
        # 1. Connect to Google Sheets
        spreadsheet = setup_google_sheets()

        # 2. Load data into DataFrames
        trans_df = load_worksheet_data(spreadsheet, CONFIG["transactions_sheet_name"])
        holdings_df = load_worksheet_data(spreadsheet, CONFIG["holdings_sheet_name"])

        if trans_df.empty or holdings_df.empty:
            print("✗ Required data missing. Exiting.")
            return

        # 3. Process and calculate XIRR
        stock_results, portfolio_result , transactions_df= process_investment_data(trans_df, holdings_df)
        #print(stock_results)
        active_holdings = holdings_df[holdings_df["market_value"] > 0].copy()
        active_stocks = set(active_holdings["stock"])
        #transactions_df["HOLDING"] = transactions_df["stock"].apply(lambda x: "YES" if x in active_stocks else "NO")


        # 4. Display results
        display_results(stock_results, portfolio_result, holdings_df,active_stocks)
        #print(transactions_df)
        total_market_value = holdings_df[holdings_df["market_value"] > 0]["market_value"].sum()
        #print(total_market_value)



        print("\n" + "=" * 80)
        print("✅ Calculation complete!")
        print("=" * 80)

    except KeyError as e:
        print(f"\n❌ Column name error: {e}")
        print("\nPlease check that your Google Sheets have columns similar to:")
        print("  - Holdings sheet: 'Stock', 'Mkt Value', 'Cost' (or names containing these words)")
        print("  - Transactions sheet: 'Date', 'Amount/CF', 'Stock' (or similar)")
        print("Run again after correcting the column names.\n")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


# ============================================================================
# ENTRY POINT
# ============================================================================
if __name__ == "__main__":
    main()









################################################################################################################

gggg


from datetime import datetime, date
import numpy as np
from scipy.optimize import newton
from collections import defaultdict
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials
import os
import json
from pyxirr import xirr as pyxirr_calc
from tabulate import tabulate
import sys,traceback
from datetime import datetime

print("=" * 60)
print("STOCK XIRR CALCULATOR")
print("=" * 60)

# ============================================================================
# CONFIGURATION
# ============================================================================
CREDENTIALS_FILE = '/home/rizpython236/BT5/root-stock-483209-u1-b7e74d74ef93.json'
SPREADSHEET_KEY = '1CWtL-P5LhzEy4VnSw7B_HDfGYkB9dhSjt5ybjboeLMo'

# ============================================================================
# GOOGLE SHEETS SETUP
# ============================================================================
def setup_google_sheets():
    """Set up connection to Google Sheets with error handling"""
    try:
        print(f"Using credentials file: {CREDENTIALS_FILE}")
        print(f"File exists: {os.path.exists(CREDENTIALS_FILE)}")

        # Define the scope
        scope = [
            'https://www.googleapis.com/auth/spreadsheets',
            'https://www.googleapis.com/auth/drive.file'
        ]

        # Authenticate with service account
        creds = Credentials.from_service_account_file(
            CREDENTIALS_FILE,
            scopes=scope
        )

        client = gspread.authorize(creds)
        print("✓ Authentication successful!")

        # Open the spreadsheet
        spreadsheet = client.open_by_key(SPREADSHEET_KEY)
        print(f"✓ Spreadsheet opened: {spreadsheet.title}")
        return spreadsheet

    except Exception as e:
        print(f"✗ Authentication error: {e}")
        return None

# ============================================================================
# XIRR CORE FUNCTIONS
# ============================================================================
def xnpv(rate, cashflows):
    """Calculate Net Present Value for irregular cash flows"""
    if rate <= -1:
        return float('inf')

    # Find the earliest date
    t0 = min([cf[0] for cf in cashflows])

    total = 0
    for cf_date, cf_amount in cashflows:
        days_diff = (cf_date - t0).days
        if (1 + rate) <= 0:
            return float('inf')
        discount_factor = (1 + rate) ** (days_diff / 365.0)
        total += cf_amount / discount_factor

    return total

def calculate_xirr(cashflows, guess=0.1):
    """
    Calculate XIRR for irregular cash flows
    Args:
        cashflows: List of tuples [(date, amount), ...]
        guess: Initial guess for the rate
    Returns:
        XIRR as decimal (e.g., 0.1 for 10%) or None if calculation fails
    """
    try:
        if len(cashflows) < 2:
            return None

        # Check for valid cash flow pattern (must have both positive and negative)
        amounts = [cf[1] for cf in cashflows]
        if all(amt >= 0 for amt in amounts) or all(amt <= 0 for amt in amounts):
            return None

        # Try Newton's method
        try:
            result = newton(lambda r: xnpv(r, cashflows), guess, maxiter=100, tol=1e-6)
            if abs(xnpv(result, cashflows)) < 1e-6:
                return result
            return None
        except (RuntimeError, ValueError):
            # Fallback to binary search
            return calculate_xirr_binary_search(cashflows)

    except Exception as e:
        print(f"XIRR calculation error: {e}")
        return None

def calculate_xirr_binary_search(cashflows):
    """Calculate XIRR using binary search (fallback method)"""
    try:
        low, high = -0.9999, 10.0
        npv_low, npv_high = xnpv(low, cashflows), xnpv(high, cashflows)

        if npv_low * npv_high > 0:
            return None

        for _ in range(50):
            mid = (low + high) / 2
            npv_mid = xnpv(mid, cashflows)

            if abs(npv_mid) < 1e-6:
                return mid

            if npv_low * npv_mid < 0:
                high, npv_high = mid, npv_mid
            else:
                low, npv_low = mid, npv_mid

        return mid
    except:
        return None

# ============================================================================
# DATA PARSING FUNCTIONS
# ============================================================================
def parse_date(date_value):
    """Parse date from various formats"""
    if date_value is None:
        return None

    if isinstance(date_value, (datetime, date)):
        return datetime.combine(date_value if isinstance(date_value, date) else date_value.date(),
                              datetime.min.time())

    date_str = str(date_value).strip()

    # Try the expected format first (YYYY-mm-dd)
    try:
        return datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        pass

    date_formats = [
        '%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y',
        '%d-%m-%Y', '%m-%d-%Y', '%Y/%m/%d',
        '%d %b %Y', '%d %B %Y'
    ]

    for fmt in date_formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue

    # Try Excel serial date
    try:
        excel_date = float(date_str)
        from datetime import timedelta
        return datetime(1899, 12, 30) + timedelta(days=excel_date)
    except:
        pass

    print(f"Warning: Could not parse date: {date_value}")
    return None

def parse_amount(amount):
    """Parse amount from various formats"""
    if amount is None:
        return 0.0

    try:
        if isinstance(amount, (int, float)):
            return float(amount)

        amount_str = str(amount).strip()
        for char in ['$', '€', '£', '₹', '¥', ',', ' ', '\xa0']:
            amount_str = amount_str.replace(char, '')

        return float(amount_str)
    except:
        print(f"Warning: Could not parse amount: {amount}")
        return 0.0

# ============================================================================
# STOCK XIRR FUNCTION
# ============================================================================
def calculate_stock_xirr(transactions, market_value, stock_name=""):
    """
    Calculate XIRR for a single stock

    Args:
        transactions: List of dictionaries with 'date' and 'amount' keys
        market_value: Current market value of the stock
        stock_name: Name of the stock (for logging)

    Returns:
        Dictionary with xirr, investment, current_value, and gain/loss
    """
    if stock_name:
        1+1
        #print(f"\nProcessing {stock_name}...")
        #if  stock_name == ("Kirloskar Pneumatic Company" or "PTC India Financial Services" or "RIR Power Electronics" :


    # Append a new transaction before sorting
    new_transaction = {
        'date': datetime.now(),  # Use datetime.now() for current timestamp
        'amount': market_value   # Use your market_value variable
    }

    if market_value !=0:
        transactions.append(new_transaction)

    # Sort transactions by date
    sorted_transactions = sorted(transactions, key=lambda x: x['date'])


    if  stock_name == "Eco Recycling" or stock_name == "P N Gadgil Jewellers"  :
        df =  pd.DataFrame(sorted_transactions)
        #print(df.columns)
        print("_________")
        print(stock_name)
        df = df[['date', 'amount']]
        print(df.to_string(index=False))
        print("_________")
    #else:
    #    continue


    print(sorted_transactions)

    lll


    # Prepare cash flows for XIRR calculation
    dates = []
    amounts = []
    total_investment = 0
    total_sell = 0

    today = datetime.now()
    final_value = market_value

    #if final_value > 0:
    #    dates.append(today)
    #    amounts.append(final_value)

   # Process all transactions
    for trans in sorted_transactions:
        amount = trans['amount']
        dates.append(trans['date'])
        amounts.append(amount)

        if amount < 0:
            total_investment += abs(amount)
        if amount > 0:
            total_sell += abs(amount)


    '''
    if stock_name:
        print(f"  Transactions: {len(transactions)}")
        print(f"  Investment: ₹{total_investment:,.2f}")
        print(f"  Current value: ₹{final_value:,.2f}")
        print(f"  Cash flows: {len(dates)}")
    '''


    # Calculate XIRR using pyxirr
    xirr_value = None
    if len(dates) >= 2:
        # Calculate investment period in years
        first_date = min(dates)
        last_date = max(dates)
        investment_days = (last_date - first_date).days
        investment_years = investment_days / 365.25

        # Calculate simple return
        simple_return_pct = None
        if total_investment > 0:
            simple_return = (total_sell - total_investment) / total_investment
            #simple_return = (final_value - total_investment) / total_investment
            simple_return_pct = simple_return * 100

        # Check if investment period is less than 1 year
        if investment_years < 1:
            # Use simple holding period return (non-annualized)
            if simple_return_pct is not None:
                xirr_value = simple_return_pct
                if stock_name:
                    1+1
                    #print(f"  Period: {investment_days} days (< 1 year)")
                    #print(f"  ✓ Simple Return: {xirr_value:.2f}% (non-annualized)")
            elif stock_name:
                print(f"  ✗ Cannot calculate simple return (zero investment)")
        else:
            # Investment period is 1 year or more, use XIRR

            try:
                1+1
                # Try to import pyxirr
                try:
                    from pyxirr import xirr as pyxirr_calc
                    use_pyxirr = True
                except ImportError:
                    use_pyxirr = False
                    if stock_name:
                        print(f"  ⚠ pyxirr not available, using fallback method...")

                if use_pyxirr:
                    # Calculate XIRR using pyxirr
                    xirr_decimal = pyxirr_calc(dates, amounts)
                else:
                    # Fall back to original calculation
                    cashflows = list(zip(dates, amounts))
                    xirr_decimal = calculate_xirr(cashflows)

                if xirr_decimal is not None:
                    xirr_value = xirr_decimal * 100
                    method = "pyxirr" if use_pyxirr else "fallback"
                    if stock_name:
                        #print(f"  ✓ XIRR ({method}): {xirr_value:.2f}%")
                        1+1

                        # Also show simple return for comparison
                        if simple_return_pct is not None:
                            if stock_name:
                                #print(f"  Simple Return: {simple_return_pct:.2f}%")
                                1+1

                elif stock_name:
                    print(f"  ✗ Could not calculate XIRR")

            except Exception as e:
                # Handle any calculation errors
                if stock_name:
                    print(f"  ✗  {stock_name} XIRR calculation error: {str(e)[:50]}...")
                    df =  pd.DataFrame(sorted_transactions)
                    #print(df.columns)
                    df = df[['date', 'amount']]
                    print(df.to_string(index=False))


                    # Fallback to simple return
                    if simple_return_pct is not None:
                        xirr_value = simple_return_pct
                        if stock_name:
                            print(f"  Using simple return: {simple_return_pct:.2f}%")

    elif stock_name:
        print(f"  ✗  {stock_name}  Insufficient cash flows (need at least 2, got {len(dates)})")
        df =  pd.DataFrame(sorted_transactions)
        #print(df.columns)
        df = df[['date', 'amount']]
        print(df.to_string(index=False))

    return {
        'xirr': xirr_value,
        'investment': total_investment,
        'current_value': total_sell,
        'gain_loss': total_sell - total_investment,
        'transaction_count': len(transactions),
        'cashflow_count': len(dates),
        'investment_days': investment_days if len(dates) >= 2 else 0,
        'investment_years': investment_years if len(dates) >= 2 else 0
    }



# ============================================================================
# PORTFOLIO XIRR FUNCTION
# ============================================================================
def calculate_portfolio_xirr(all_transactions, total_market_value,Cost_portfolio_value):
    """
    Calculate XIRR for the entire portfolio

    Args:
        all_transactions: List of all transactions across all stocks
        total_market_value: Total current market value of the portfolio

    Returns:
        Portfolio XIRR as percentage or None
    """
    print("\n" + "=" * 80)
    print("CALCULATING PORTFOLIO XIRR")
    print("=" * 80)


    unrelialized_GL = total_market_value - Cost_portfolio_value
    print(unrelialized_GL,total_market_value,Cost_portfolio_value)

    # Append a new transaction before sorting
    new_transaction = {
        'date': datetime.now(),  # Use datetime.now() for current timestamp
        'amount': total_market_value   # Use your market_value variable
    }

    all_transactions.append(new_transaction)

    all_transactions = sorted(all_transactions, key=lambda x: x['date'])
    #print(all_transactions)

    # Prepare cash flows for XIRR calculation
    dates = []
    amounts = []
    total_portfolio_investment = 0
    total_portfolio_sell = 0

    # Process all transactions
    for trans in all_transactions:
        amount = trans['amount']
        dates.append(trans['date'])
        amounts.append(amount)
        if amount < 0: #BUY
            total_portfolio_investment  += abs(amount) #+= amount
        if amount > 0: #SELL
            total_portfolio_sell  += abs(amount) #+= amount

    #total_market_value = total_market_value  - Cost_portfolio_value
    print(f"Total portfolio investment: ₹{total_portfolio_investment:,.2f}")
    print(f"Total portfolio Mkt value: ₹{total_portfolio_sell:,.2f}")

    #print(all_transactions)


    def fuc(all_transactions):

        # Step 1: Create DataFrame properly
        df = pd.DataFrame(all_transactions)

        # Step 2: Verify
        print(f"DataFrame created. Shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")

        # Step 3: Check date column
        print(f"\nFirst date value: {df['date'].iloc[0]} (type: {type(df['date'].iloc[0])})")

        # Step 4: Convert to pandas datetime (optional since they're already datetime objects)
        df['date'] = pd.to_datetime(df['date'])
        print(f"\nAfter conversion - Date dtype: {df['date'].dtype}")

        # Step 5: Display
        print("\nDataFrame:")
        print(df)

    #fuc(all_transactions)
    #ff


    # Add final total market value as positive cash flow (today's date)
    #today = datetime.now()
    #if total_market_value != 0:
    #    #portfolio_cashflows.append((today, total_market_value))
    #    amounts.append(amount)
    #    dates.append(today)
    #    #amount = trans['amount']
    #    #dates.append(trans['date'])


    # Calculate portfolio XIRR
    portfolio_xirr = None
    if len(all_transactions) >= 2:
        xirr_decimal = pyxirr_calc(dates, amounts) #calculate_xirr(portfolio_cashflows)
        if xirr_decimal is not None:
            portfolio_xirr = xirr_decimal * 100
            print(f"✓ Portfolio XIRR calculated: {portfolio_xirr:.2f}%")
        else:
            print("✗ Could not calculate portfolio XIRR")
    else:
        print("✗ Insufficient cash flows for portfolio XIRR")

    return {
        'portfolio_xirr': portfolio_xirr,
        'total_investment': total_portfolio_investment,
        'total_value': total_portfolio_sell,
        'total_gain_loss': total_portfolio_sell - total_portfolio_investment
    }

# ============================================================================
# DATA PROCESSING FUNCTION
# ============================================================================

def filter_stock_data_simple(transactions_data):
    """
    Simple approach without using DataFrame
    """
    if not transactions_data:
        return []

    # Group data by Stock
    stock_groups = {}
    for transaction in transactions_data:
        stock = transaction['Stock']
        if stock not in stock_groups:
            stock_groups[stock] = []
        stock_groups[stock].append(transaction)

    # Process each stock group
    filtered_data = []

    for stock, transactions in stock_groups.items():
        # Sort by Date descending (most recent first)
        transactions_sorted = sorted(
            transactions,
            key=lambda x: x['Date'],
            reverse=True
        )

        # Find first occurrence from bottom where Prev Row is 0 and Type is Buy
        keep_from_index = None
        for i, transaction in enumerate(transactions_sorted):
            if transaction['Prev Row'] == 0 and transaction['Type'] == 'Buy':
                keep_from_index = i
                break

        # If found such a row, keep from that row onward (most recent to that point)
        if keep_from_index is not None:
            # Get transactions from that point onward (most recent first)
            transactions_to_keep = transactions_sorted[:keep_from_index + 1]
        else:
            # Keep all transactions for this stock
            transactions_to_keep = transactions_sorted

        # Sort back to chronological order and add to filtered data
        transactions_to_keep_sorted = sorted(
            transactions_to_keep,
            key=lambda x: x['Date']
        )
        filtered_data.extend(transactions_to_keep_sorted)

    return filtered_data



def process_investment_data(transactions_sheet, holdings_sheet):
    """
    Process data from Google Sheets and calculate both stock and portfolio XIRR

    Args:
        transactions_sheet: Worksheet object for ZDHTransactions
        holdings_sheet: Worksheet object for ZDH Summary

    Returns:
        Dictionary containing stock XIRR results and portfolio XIRR results
    """
    print("\nProcessing data...")

    try:
        # Get all data from sheets
        transactions_data = transactions_sheet.get_all_records()
        holdings_data = holdings_sheet.get_all_records()

        print(f"✓ Found {len(transactions_data)} transactions")
        print(f"✓ Found {len(holdings_data)} holdings")

        # Debug column names
        if transactions_data:
            #print(transactions_data)
            #transactions_data = filter_stock_data_simple(transactions_data)
            #print(transactions_data)
            1+1
            #print(f"\nTransaction columns: {list(transactions_data[0].keys())}")
        if holdings_data:
            1+1
            #print(f"Holding columns: {list(holdings_data[0].keys())}")

        # Create holdings dictionary from ZDH Summary
        holdings_dict = {}
        total_portfolio_value = 0
        Cost_portfolio_value = 0
        unique_keys = set()

        #print(holdings_data)
        for holding in holdings_data:
            # Find stock name column
            stock_name = None
            for key in holding.keys():
                if 'stock' in key.lower() or 'name' in key.lower():
                    stock_name = str(holding[key]).strip()
                    break


            if stock_name:
                # Find market value column Mkt Value ,Cost
                market_value = 0
                Cost_value = 0

                for key in holding.keys():
                    #print(holding.keys())
                    key_lower = key.lower().replace(' ', '').replace('_', '')
                    #print(key_lower)
                    #if key_lower in ['marketvalue', 'mktvalue', 'currentvalue']:
                    #if any(term in key for term in ['Mkt', 'market', 'Mkt Value','Value']):
                    if key == 'Mkt Value' and holding[key] != 0 :# in holding:
                        market_value = parse_amount(holding[key])
                        #print(holding[key])
                        #break
                    key_lower = key.lower().replace(' ', '').replace('_', '')
                    #if key_lower in ['marketvalue', 'cost', 'currentvalue']:
                    #if any(term in key.lower() for term in ['valuex', 'cost', 'mktx']):
                    if key == 'Cost' and holding[key] != 0 :
                        Cost_value = parse_amount(holding[key])
                        #print(holding[key])
                        #break
                    if 'cost' in key or 'mktvalue' in key or 'Mkt Value' in key :
                        #print("Holding sheet issue")
                        #print(key_lower)
                        unique_keys.add(key)
                        #print(f"\nUnique keys ({len(unique_keys)} total): {', '.join(sorted(unique_keys))}")
                        #sys.exit(1)

                holdings_dict[stock_name] = market_value
                total_portfolio_value += market_value
                Cost_portfolio_value += Cost_value

        print(f"✓ Created holdings dictionary with {len(holdings_dict)} stocks")
        print(f"✓ Total portfolio value: ₹{total_portfolio_value:,.2f}")
        print(f"✓ Total COST value: ₹{Cost_portfolio_value:,.2f}")

        # Exit if we didn't find what we need
        if total_portfolio_value == 0 or Cost_portfolio_value == 0:
            print("ERROR: Could not find market value or cost!")
            print(f"\nUnique keys ({len(unique_keys)} total): {', '.join(sorted(unique_keys))}")
            sys.exit(1)

        # Group transactions by stock and collect all transactions for portfolio
        stock_transactions = defaultdict(list)
        all_transactions_for_portfolio = []

        for transaction in transactions_data:
            # Find stock column
            stock = None
            for key in transaction.keys():
                if 'stock' in key.lower():
                    stock = str(transaction[key]).strip()
                    break

            if not stock:
                continue

            # Find amount column
            cf = 0
            for key in transaction.keys():
                if key.lower() in ['cf', 'cash flow', 'amountx', 'cash', 'amountx']:
                    cf = parse_amount(transaction[key])
                    break

            # Find date column
            date_str = None
            for key in transaction.keys():
                if 'date' in key.lower():
                    date_str = transaction[key]
                    break

            if not date_str:
                continue

            # Parse date
            trans_date = parse_date(date_str)
            if not trans_date:
                continue

            # Store transaction for this stock
            stock_transactions[stock].append({
                'date': trans_date,
                'amount': cf
            })

            # Store for portfolio aggregation
            all_transactions_for_portfolio.append({
                'date': trans_date,
                'amount': cf
            })

        print(f"✓ Grouped transactions for {len(stock_transactions)} stocks")

        # Calculate XIRR for each stock
        stock_xirr_results = {}

        #print(stock_transactions.columns)


        for stock, transactions in stock_transactions.items():
            market_value = holdings_dict.get(stock, 0)
            result = calculate_stock_xirr(transactions, market_value, stock)
            stock_xirr_results[stock] = result

        # Calculate portfolio XIRR
        portfolio_results = calculate_portfolio_xirr(
            all_transactions_for_portfolio,
            total_portfolio_value,Cost_portfolio_value
        )

        return {
            'stock_results': stock_xirr_results,
            'portfolio_results': portfolio_results,
            'holdings_dict': holdings_dict
        }

    except Exception as e:
        print(f"✗ Error processing data: {e}")
        import traceback
        traceback.print_exc()
        return {}

# ============================================================================
# MAIN EXECUTION FUNCTION
# ============================================================================
def main():
    """Main function to run the XIRR calculator"""
    try:
        # Setup Google Sheets connection
        spreadsheet = setup_google_sheets()
        if not spreadsheet:
            print("Failed to connect to Google Sheets")
            return None

        # Get worksheets
        try:
            transactions_sheet = spreadsheet.worksheet('ZDHTransactions')
            print("✓ Found ZDHTransactions sheet")
        except:
            print("✗ ZDHTransactions sheet not found. Available sheets:")
            for ws in spreadsheet.worksheets():
                print(f"  - {ws.title}")
            return None

        try:
            holdings_sheet = spreadsheet.worksheet('ZDH Summary')
            print("✓ Found ZDH Summary sheet")
        except:
            print("✗ ZDH Summary sheet not found. Available sheets:")
            for ws in spreadsheet.worksheets():
                print(f"  - {ws.title}")
            return None

        # Process data and calculate XIRR
        results = process_investment_data(transactions_sheet, holdings_sheet)

        if not results:
            print("✗ No results to display")
            return None

        # Extract results
        stock_results = results['stock_results']
        portfolio_results = results['portfolio_results']
        holdings_dict = results['holdings_dict']

        # Print portfolio summary
        print("\n" + "=" * 80)
        print("PORTFOLIO SUMMARY")
        print("=" * 80)

        print(f"\n📊 Overall Portfolio:")
        print(f"   Total Investment:    ₹{portfolio_results['total_investment']:>15,.2f}")
        print(f"   Current Value:       ₹{portfolio_results['total_value']:>15,.2f}")
        print(f"   Total Gain/Loss:     ₹{portfolio_results['total_gain_loss']:>15,.2f}")

        if portfolio_results['portfolio_xirr'] is not None:
            print(f"   Portfolio XIRR:      {portfolio_results['portfolio_xirr']:>15.2f}%")

            # Calculate simple return
            if portfolio_results['total_investment'] > 0:
                simple_return = (portfolio_results['total_gain_loss'] /
                               portfolio_results['total_investment'] * 100)
                print(f"   Simple Return:       {simple_return:>15.2f}%")
        else:
            print(f"   Portfolio XIRR:      {'N/A':>15}")


        # Filter and sort stock results
        valid_stock_results = {k: v for k, v in stock_results.items()
                              if v['xirr'] is not None}
        sorted_stocks = sorted(valid_stock_results.items(),
                              key=lambda x: x[1]['xirr'])

        sorted_stocks = sorted(valid_stock_results.items(),
                               key=lambda x: x[1]['xirr'],
                               reverse=True)  # Add this for descending order

        # Filter for long-term investments (≥ 1 year)
        #sorted_stocks = long_term_stocks = [(stock, data) for stock, data in sorted_stocks
        #                    if data['investment_years'] >= 1]

        # Filter for stocks currently held
        sorted_stocks = [(stock, data) for stock, data in sorted_stocks
                            if stock in holdings_dict]

        print(f"Current holdings: {len(sorted_stocks)} stocks")


        # Print individual stock results
        print("\n" + "=" * 80)
        print("INDIVIDUAL STOCK XIRR RESULTS (Ascending Order)")
        print("=" * 80)
        '''
        if sorted_stocks:
            print(f"\n{'No.':<4} {'Stock':<25} {'XIRR':<12} {'Investment':<15} {'SOLD/Current Value':<15} {'Gain/Loss':<15} {'Year':<15} {'Simple/XIRR':<15} {'Holding':<15}"")
            print("-" * 86)

            for i, (stock, data) in enumerate(sorted_stocks, 1):
                print(f"{i:<4} {stock:<25} {data['xirr']:<12.2f}% "
                      f"₹{data['investment']:<13,.2f} "
                      f"₹{data['current_value']:<14,.2f} "
                      f"₹{data['gain_loss']:<14,.2f}"
                      f"{data['investment_years']:<14,.2f}"
                      f"{'simple return' if data['investment_years'] < 1 else 'XIRR'}")
                      #f"₹{data['gain_loss']:<14,.2f}")

            '''


        if sorted_stocks:
            # Prepare table data
            table_data = []
            for i, (stock, data) in enumerate(sorted_stocks, 1):
                method = "Simple" if data['investment_years'] < 1 else "XIRR"
                if stock in holdings_dict:
                    Status = "YES"
                else:
                    Status = "NO"
                row = [
                    i,
                    stock,
                    f"{data['xirr']:.2f}%",
                    f"₹{data['investment']:,.2f}",
                    f"₹{data['current_value']:,.2f}",
                    f"₹{data['gain_loss']:,.2f}",
                    f"{data['investment_years']:.2f}",
                    method,
                    Status

                ]
                table_data.append(row)

            # Define headers
            headers = ['No.', 'Stock', 'XIRR', 'Investment', 'Current Value', 'Gain/Loss', 'Years', 'Method', 'Holding Now']

            # Print table
            #print(tabulate(table_data, headers=headers, tablefmt='grid', stralign='right', numalign='right'))

            # Create DataFrame
            df = pd.DataFrame(table_data, columns=headers)

            # Filter for holdings currently held
            #df = df[df['Holding Now'] == 'YES']

            # If you want to reset the 'No.' column after filtering
            #df = df.reset_index(drop=True)
            #df.index = df.index + 1  # Make index start from 1 again
            #df['No.'] = range(1, len(df_held) + 1)  # Update the 'No.' column

            # Set 'No.' as the index if desired
            df = df.set_index('No.')

            # Display the DataFrame
            #print(df)
            print(tabulate(df, headers=headers, tablefmt='grid', stralign='right', numalign='right'))

            '''
            df = pd.DataFrame(table_data, columns=headers)
            # Filter for Holding Now == YES
            df_filtered = df[df['Holding Now'] == 'YES'].copy()

            # Reset the No. column for filtered view
            df_filtered['No.'] = range(1, len(df_filtered) + 1)

            # Print filtered table
            if not df_filtered.empty:
                print("Current Holdings Only:")
                print(tabulate(df_filtered.values, headers=headers, tablefmt='grid', stralign='right', numalign='right'))
            '''

            sorted_stocks = [(stock, data) for stock, data in sorted_stocks
                             if stock != 'Privi Speciality Chemicals' or stock != 'SKF India (Industrial)' or stock != 'Tata Motors Commercial Vhcls' or stock != 'Aditya Birla Lifestyle Brands']

            # Statistics
            xirr_values = [data['xirr'] for _, data in sorted_stocks]
            print("\n📊 Individual Stock Statistics:")
            print(f"  Total stocks with XIRR: {len(sorted_stocks)}")
            print(f"  Average XIRR: {np.mean(xirr_values):.2f}%")
            print(f"  Minimum XIRR: {np.min(xirr_values):.2f}%")
            print(f"  Maximum XIRR: {np.max(xirr_values):.2f}%")
            print(f"  Median XIRR: {np.median(xirr_values):.2f}%")

            #print(sorted_stocks)


            total_inv_weighted = sum(data['investment'] for _, data in sorted_stocks)
            if total_inv_weighted > 0:
                weighted_avg = sum(data['xirr'] * data['investment']
                                  for _, data in sorted_stocks) / total_inv_weighted
                print(f"  Weighted Avg XIRR Investment: {weighted_avg:.2f}%")

            # Weighted average XIRR
            total_inv_weighted = sum(data['investment'] for _, data in sorted_stocks)
            if total_inv_weighted > 0  :
                weighted_avg = sum(data['xirr'] * data['current_value']
                                  for _, data in sorted_stocks) / total_inv_weighted
                print(f"  Weighted Avg XIRR current_value: {weighted_avg:.2f}%")

            # Filter for stocks with investment_years > 1
            long_term_stocks = [(stock, data) for stock, data in sorted_stocks if data['investment_years'] > 1]

            long_term_stocks = [(stock, data) for stock, data in sorted_stocks
                    if data['investment_years'] > 1
                    and data['xirr'] <= 200]

            import pprint

            #for stock, data in long_term_stocks:
            #    print(f"\n{'='*50}")
            #    print(f"Stock: {stock}")
            #    print(f"{'='*50}")
            #    pprint.pprint(data)

            if long_term_stocks:
                total_inv_weighted = sum(data['investment'] for _, data in long_term_stocks)
                #total_inv_weighted = data[data['Method'] == 'XIRR']['Investment'].sum()
                #total_inv_weighted = sum(data.get('investment', 0) for _, data in long_term_stocks.items()) # if data.get('Method') == 'XIRR' or data.get('Method') == 'Simple')
                #total_inv_weighted = sum(data.get('investment', 0) for data in long_term_stocks)  # No .items() for lists


                if total_inv_weighted > 0:
                    #weighted_avg = sum(data['xirr'] * data['current_value']
                    #                  for _, data in long_term_stocks) / total_inv_weighted
                    weighted_avg = sum(
                        data['xirr'] * data['current_value']
                        for _, data in long_term_stocks  # or just long_term_stocks if it's already iterable
                        #if data.get('Method') == 'XIRR'
                    ) / total_inv_weighted if total_inv_weighted > 0 else 0
                    print(f"Weighted average XIRR current_value (holdings > 1 year): {weighted_avg:.2f}%")


        else:
            print("\nNo valid XIRR calculations available for individual stocks.")

        # Print stocks with no XIRR
        no_xirr_stocks = [k for k, v in stock_results.items() if v['xirr'] is None]
        if no_xirr_stocks:
            print(f"\n⚠️  Stocks with no XIRR calculation ({len(no_xirr_stocks)}):")
            for stock in no_xirr_stocks:
                data = stock_results[stock]
                print(f"  - {stock}: Investment: ₹{data['investment']:,.2f}, "
                      f"Current: ₹{data['current_value']:,.2f}")

        print("\n" + "=" * 80)
        print("✅ Calculation complete!")
        print("=" * 80)

        return results

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return None

# ============================================================================
# ENTRY POINT
# ============================================================================
if __name__ == "__main__":
    print("\nStarting Stock XIRR Calculator...")

    # Check if required packages are installed
    try:
        import gspread
        import numpy
        import scipy
    except ImportError:
        print("Installing required packages...")
        import subprocess
        subprocess.check_call(['pip', 'install', 'gspread', 'numpy', 'scipy',
                              'google-auth', 'google-auth-oauthlib', 'google-auth-httplib2'])
        print("✅ Packages installed. Please restart the script.")
        exit()

    # Import timedelta for date calculations
    from datetime import timedelta

    # Run main function
    try:
        results = main()
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")

gggggggggggg

'''
from ZDHTransactions use Date, Stock, Cash Flow
from ZDH Summary use Stock Name , Mkt Value
'''

CREDENTIALS_FILE = '/home/rizpython236/BT5/root-stock-483209-u1-b7e74d74ef93.json'

#CREDENTIALS_FILE = 'credentials.json'  # Your service account credentials
SPREADSHEET_KEY = '1CWtL-P5LhzEy4VnSw7B_HDfGYkB9dhSjt5ybjboeLMo'  # From your Google Sheets URL


