import csv
from datetime import date
import os
import shutil
import sys
import time
import traceback
import uuid

from mail_utils import trigger_email_notification, trigger_generic_email
import pandas as pd
from settings import (
    BT_SCREENER_CSV,
    EMPTY_BT_SCREENER_MSG,
    MAX_RETRIES,
    NIFTY_WEEKLY_AVG_STATS_IMAGE,
    NO_NEW_SIGNALS_FOUND_MSG,
    SCREENER_OUTPUT_CSV,
    SCREENER_OUTPUT_FOLDER_PATH,
    SYMBOLS_CSV,
    TALIB_SCREENER_CSV,
    TICKER_CSV_DATA_FOLDER_PATH,
    TRADE_LOGS_FOLDER_PATH,
    TRADEBOOK_CSV,
)
from telegram_bot import (
    post_telegram_file,
    post_telegram_message,
    trigger_telegram_notifications,
)


SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"

BT_FILE_PATH = '/home/rizpython236/BT5/screener-outputs/trade_list_BT_mhtly_Screener.csv'
TALIB_FILE_PATH = SCREENER_OUTPUT_FOLDER_PATH + "/" + TALIB_SCREENER_CSV
CURRENT_DAY_SCREENER_FILE_PATH = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
TRADEBOOK_FILE_PATH = '/home/rizpython236/BT5/trade-logs/tradebook_mhtly.csv'
TODAYS_DATE = date.today()
empty_FILE_PATH = "/home/rizpython236/BT5/screener-outputs/emptyscreener.csv"
SCREENER_OUTPUT_CSV="screener-output_mhtly.csv"

with open(BT_FILE_PATH, "r") as f:
    reader = csv.reader(f)
    header = next(reader)
    data = [row for row in reader]
    if not data:
        print("NO_NEW_SIGNALS_FOUND_MSG")
        post_telegram_message("NO_NEW_SIGNALS_FOUND_MSG_ Mhtly")
        src_path = empty_FILE_PATH
        dst_path = BT_FILE_PATH
        #shutil.copy2(src_path, dst_path)
        #shutil.copy2(trade_list_BT_Screener.csv, trade_list_Talib_Screener.csv)
        #print("The file has no data under the header column.")
    else:
        post_telegram_message("BT_fileMhtly_has_screener_data")
        print("BT file has Mhtlyscreener data")
        #continue
        #shutil.copy2(BT_FILE_PATH.csv, empty_FILE_PATH)
        # Continue with the rest of the code here

bt_data = pd.read_csv(BT_FILE_PATH)
talib_data = pd.read_csv(TALIB_FILE_PATH)
# new_screener_data = pd.read_csv(NEW_FILE_PATH)
tradebook = pd.read_csv(TRADEBOOK_FILE_PATH)


"""
Checking if the BT-data is empty or not and
triggering a mail if it's empty.
"""
if len(bt_data) == 0:
    print(EMPTY_BT_SCREENER_MSG)
    trigger_generic_email(msg=EMPTY_BT_SCREENER_MSG)
    sys.exit()


bt_tickers = list(bt_data["ticker"].unique())
talib_tickers = list(talib_data["ticker"].unique())


active_tradebook = tradebook[tradebook["status"] == "active"]
active_tradebook_tickers = list(active_tradebook["ticker"].unique())


def fetch_talib_results_for_ticker(ticker):

    talib_record = {"talib_date": "", "talib_signal": "", "talib_price": ""}

    if ticker not in talib_tickers:
        return talib_record

    talib_record["talib_date"] = talib_data.loc[
        talib_data["ticker"] == ticker, "datein"
    ].iloc[0]
    talib_record["talib_signal"] = talib_data.loc[
        talib_data["ticker"] == ticker, "dir"
    ].iloc[0]
    talib_record["talib_price"] = talib_data.loc[
        talib_data["ticker"] == ticker, "pricein"
    ].iloc[0]

    return talib_record


def trigger_compilation():

    new_trades = []

    for row in range(len(bt_data)):

        ticker = bt_data["ticker"][row]
        generated_signal = bt_data["dir"][row]

        ticker_date = bt_data.loc[bt_data["ticker"] == ticker, "datein"].iloc[0]
        ticker_signal = bt_data.loc[bt_data["ticker"] == ticker, "dir"].iloc[0]
        ticker_price = bt_data.loc[bt_data["ticker"] == ticker, "pricein"].iloc[0]
        pnl_percentage = None

        if ticker in active_tradebook_tickers:
            #print("Ticker already present, checking for active signal ...")
            active_signal = active_tradebook.loc[
                active_tradebook["ticker"] == ticker, "signal"
            ].iloc[0]

            if active_signal == generated_signal:
                # signal has not changed, hence continue
                continue
            else:
                print("Signal changed for => {}. Updating status ...".format(ticker))
                post_telegram_message("Signal changed for => {}. Updating status Mhtly .".format(ticker))
                trade_id = active_tradebook.loc[
                    active_tradebook["ticker"] == ticker, "trade_id"
                ].iloc[0]
                old_trade_price = active_tradebook.loc[
                    active_tradebook["trade_id"] == trade_id, "price"
                ].iloc[0]

                tradebook.loc[
                    (tradebook["trade_id"] == trade_id), ["status"]
                ] = "closed"
                tradebook.loc[
                    (tradebook["trade_id"] == trade_id), ["trade_updated_on"]
                ] = str(TODAYS_DATE)

                if active_signal == "BUY" and generated_signal == "SELL":
                    print(
                        "Buy + Sell completed for {}, calculating PnL.".format(ticker)
                    )
                    pnl_percentage = round(
                        ((ticker_price - old_trade_price) / old_trade_price) * 100, 2
                    )
                    # tradebook.loc[
                    #     active_tradebook["trade_id"] == trade_id, "pnl"
                    # ] = pnl_percentage

        talib_data_dict = fetch_talib_results_for_ticker(ticker)
        # new_screener_dict = fetch_new_screener_dict(ticker)

        record = {
            "trade_logged_on": str(TODAYS_DATE),
            "trade_id": str(uuid.uuid4()),
            "status": "active",
            "date": ticker_date,
            "ticker": ticker,
            "signal": ticker_signal,
            "price": ticker_price,
        }

        if pnl_percentage:
            record.update({"pnl": pnl_percentage})

        record.update(talib_data_dict)
        # record.updated(new_screener_dict)
        new_trades.append(record)
        record = {}

    return new_trades


def cleanup_files():

    print("-" * 50)
    print("Removing the files ...")
    print("-" * 50)

    # remove BT Screener Output
    #print("Deleting BT Screener Output File.")
    #if os.path.exists(BT_FILE_PATH):
    #    os.remove(BT_FILE_PATH)

    # remove Talib Output
    #print("Deleting Talib Screener Output File.")
    #if os.path.exists(TALIB_FILE_PATH):
    #    os.remove(TALIB_FILE_PATH)

    # remove Talib Output
    print("Deleting Last Saved Screener Output File.")
    if os.path.exists(CURRENT_DAY_SCREENER_FILE_PATH):
        post_telegram_file(CURRENT_DAY_SCREENER_FILE_PATH)
        #os.remove(CURRENT_DAY_SCREENER_FILE_PATH)
        1+1
    '''
    # remove valid, invalid and incomplete ticker csvs
    print("Emptying valid, invalid and incomplete ticker output files.")
    dir1 = SCREENER_OUTPUT_FOLDER_PATH
    for f in os.listdir(dir1):
        ff = dir1 + "/" + f
        temp_df = pd.read_csv(ff)
        temp_df.drop(temp_df.index, inplace=True)
        temp_df.to_csv(ff, index=False)
        # os.remove(os.path.join(dir1, f))

    # remove Symbol list
    #print("Emptying Symbol List")
    #sym_df = pd.read_csv(SYMBOLS_CSV)
    #sym_df.drop(sym_df.index, inplace=True)
    #sym_df.to_csv(SYMBOLS_CSV, index=False)

    # ff = "./screener-outputs/valid_tickers.csv"
    # temp_df = pd.read_csv(ff)
    # temp_df.drop(temp_df.index, inplace=True)
    # temp_df.to_csv(ff, index=False)

    # remove ticker data csv files
    print("Deleting all the ticker data csv files.")
    dir2 = TICKER_CSV_DATA_FOLDER_PATH
    for f in os.listdir(dir2):
        os.remove(os.path.join(dir2, f))

    print("Deleting Nifty Weekly Avg Stats Image")
    if os.path.exists(NIFTY_WEEKLY_AVG_STATS_IMAGE):
        os.remove(NIFTY_WEEKLY_AVG_STATS_IMAGE)
    '''
    # folder = TICKER_CSV_DATA_FOLDER_PATH
    # for filename in os.listdir(folder):
    #    file_path = os.path.join(folder, filename)
    #    try:
    #        if os.path.isfile(file_path) or os.path.islink(file_path):
    #            os.unlink(file_path)
    #        elif os.path.isdir(file_path):
    #            shutil.rmtree(file_path)
    #    except Exception as e:
    #        print("Failed to delete %s. Reason: %s" % (file_path, e))


def generate_notifications(new_trades):

    if not new_trades:
        print("No new Mhtlysignals for today!")
        trigger_generic_email(msg=NO_NEW_SIGNALS_FOUND_MSG)
        post_telegram_message(message=NO_NEW_SIGNALS_FOUND_MSG)
        #cleanup_files()
        return

    new_trades_df = pd.DataFrame(data=new_trades)
    # here we are sorting based on BT signal type - column = "signal"
    new_trades_df = new_trades_df.sort_values("signal")
    updated_tradebook = pd.concat([tradebook, new_trades_df], axis=0)
    updated_tradebook.to_csv(TRADEBOOK_FILE_PATH, index=False)

    new_trades_file_path = TRADE_LOGS_FOLDER_PATH + "/" + SCREENER_OUTPUT_CSV
    new_trades_df.to_csv(new_trades_file_path, index=False)

    trigger_email_notification()
    time.sleep(1)
    trigger_telegram_notifications()

    #cleanup_files()
    #file_path ='/home/rizpython236/BT5/trade-logs/screener-output_mhtly.csv'
    #delete_file(file_path)

def delete_file(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)
        print(f"Deleted file: {file_path}")
    else:
        print(f"File not found: {file_path}")


def main():
    new_trades = trigger_compilation()
    generate_notifications(new_trades)
    file_path ='/home/rizpython236/BT5/trade-logs/screener-output_mhtly.csv'
    post_telegram_file(file_path)
    delete_file(file_path)


while MAX_RETRIES:
    try:
        main()
        MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(10)
        print("Operation Failed! Retrying...")
        print(traceback.format_exc())
        print(exc)
        print("-" * 50)
        MAX_RETRIES -= 1
