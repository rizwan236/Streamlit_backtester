import io
import time
import traceback

import pandas as pd
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from add_company_name import (
    copyfile1,
)
from settings import (
    EXCLUDE_TICKERS_CSV,
    INCLUDE_TICKERS_CSV,
    MAX_RETRIES,
)
from symbol_copy import import_user_module
from telegram_bot import post_telegram_message


base_dir_module = "/home/rizpython236/BT5"


# filepath ='/home/rizpython236/BT5/Equity (5).csv'
# fix_bse_column_names(filepath)

include_tickers = pd.read_csv(INCLUDE_TICKERS_CSV)
include_tickers = list(include_tickers["Symbol"].unique())
exclude_tickers = pd.read_csv(EXCLUDE_TICKERS_CSV)
exclude_tickers2 = pd.read_csv(
    "/home/rizpython236/BT5/exclude_tickersmanual.csv")

df_combined = (pd.concat([exclude_tickers, exclude_tickers2],
               ignore_index=True).drop_duplicates(subset="Symbol", keep="first"))
df_combined.to_csv(EXCLUDE_TICKERS_CSV, index=False)
exclude_tickers = df_combined


# exclude_tickers = list(exclude_tickers["Symbol"].unique())

Final111 = pd.read_csv("/home/rizpython236/BT5/finalfull.csv")
new_tickers = pd.read_csv("/home/rizpython236/BT5/trade-logs/new_tickers.csv")


def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df


# proposed delisted


# Set up Chrome options
chrome_options = Options()
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--window-size=1920,1080")
chrome_options.add_argument("--disable-blink-features=AutomationControlled")
chrome_options.add_argument("--enable-unsafe-swiftshader")

chrome_options.add_experimental_option("prefs", {
    # "download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True,
})

# Initialize WebDriver
driver = webdriver.Chrome(options=chrome_options)


attempt = 0
max_attempts = 0
success = False

while attempt < max_attempts and not success:
    try:
        # Open the webpage
        url = "https://www.nseindia.com/regulations/list-of-companies-proposed-to-be-delisted"
        driver.get(url)

        # Wait for the export button to be clickable
        export_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable(
                (By.ID, "/html/body/div[10]/div/section/div/div/div/div/div/div/div[1]/div[3]/div[1]/div/p[3]/a")),
        )

        # Scroll into view
        driver.execute_script(
            "arguments[0].scrollIntoView(true);", export_button)

        # Use JavaScript to click if needed
        driver.execute_script("arguments[0].click();", export_button)

        # Wait for the file to download
        time.sleep(5)

        # Step 4: Load the downloaded CSV into a pandas DataFrame
        download_dir = "/home/rizpython236/BT5"
        csv_filename = f"{download_dir}/Companies_proposed_to_be_delisted_list_2.xlsx"
        delisted = pd.read_excel(csv_filename)

        input_file = "/home/rizpython236/BT5/Companies_proposed_to_be_delisted_list_2.xlsx"
        output_file = "/home/rizpython236/BT5/trade-logs/Companies_proposed_to_be_delisted_list_2.xlsx"
        copyfile1(input_file, output_file)

        # Print and/or save the DataFrame as needed
        print(delisted.head())

        add_suffix_to_column(delisted, "Symbol", ".NS")

        success = True
        print("Download and processing successful Companies_proposed_to_be_delisted_list_2.xlsx.")
        post_telegram_message("NSE_proposed_to_be_delisted Downloaded")

    except Exception as e:  # (TimeoutException, Exception) as e:
        attempt += 1
        print(f"Attempt {attempt} failed NSE_proposed_to_be_delisted: {e!s}")
        traceback_str = traceback.format_exc()
        print(traceback_str)
        if attempt < max_attempts:
            print("Retrying...")
        else:
            print(
                "Max attempts reached. Failed to Companies_proposed_to_be_delisted_list_2.xlsx")
            # post_telegram_message("NSE_proposed_to_be_delisted Error")

    finally:
        # Close the browser
        driver.quit()


# Load BSE file

max_retries = 1  # Set the maximum number of retries
retry_count = 0

while retry_count < max_retries:
    try:
        # Try importing the module and reading the file
        # import bse_ticker_download
        time.sleep(2)
        bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
        print("BSE")
        # print(bse)
        break  # Exit the loop if successful
    except Exception as exc:
        retry_count += 1
        print(f"Attempt {retry_count} failed bse_ticker_download: {exc}")
        traceback_str = traceback.format_exc()
        print(traceback_str)
        time.sleep(2)  # Wait 1 second before retrying
        bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
        if retry_count == max_retries:
            print("Max retries reached. Exiting.")
            # post_telegram_message("Download from bse_ticker_download failed!...")
            print("Download from bse_ticker_download failed!...")
"""
try:
    import bse_ticker_download
    #if os.path.getsize(csv_filename) > 0:
    bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
    #else:
    #    bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
except Exception as exc:
    time.sleep(1)
    bse = pd.read_csv("/home/rizpython236/BT5/Equity.csv")
    print("Download from bse_ticker_download failed! Retrying...")
    #post_telegram_message("Download from NSE failed! Retrying...")
    print(exc)
"""
# bse = pd.read_csv("/home/rizpython236/BT5/bse.csv")
# https://www.bseindia.com/corporates/List_Scrips.html


download_successful = False

while MAX_RETRIES:
    try:
        time.sleep(1)
        datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")
        print("Downloading NSE symbol list from NSE Website.")
        # https://www.nseindia.com/market-data/securities-available-for-trading
        url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
        response = requests.get(url)
        csv_data = io.StringIO(response.text)
        csv_content = csv_data.getvalue()
        # print(csv_content)
        if "Access Denied" in csv_content:
            print("ERROR: Access Denied - NSE is blocking the request.")
            datanse.to_csv("/home/rizpython236/BT5/nse.csv", index=False)
            MAX_RETRIES -= 1
            download_successful = False
            break
        else:
            print("CSV downloaded successfully. Content:")
            # print(csv_content)  # Print the full CSV data
            datanse = pd.read_csv(csv_data)
            print("NSE")
            # print(datanse)
            # time.sleep(5)
            # datanse = pd.read_csv(url)
            # print(datanse)
            print(f"Found {len(datanse)} tickers in NSE symbol list")
            download_successful = True
            MAX_RETRIES = 0
            break
    except Exception as exc:
        time.sleep(3)
        print("Download from NSE failed! Retrying...")
        # post_telegram_message("Download from NSE failed! Retrying...")
        print(exc)
        traceback_str = traceback.format_exc()
        print(traceback_str)
        print("-" * 50)
        MAX_RETRIES -= 1


if download_successful == True:
    datanse.to_csv("/home/rizpython236/BT5/nse.csv", index=False)
else:
    # if not download_successful:
    print("Download data from NSE Failed")
    post_telegram_message(message="Download data from NSE Failed")
    # sys.exit()
    datanse = pd.read_csv("/home/rizpython236/BT5/nse.csv")


# print(bse)


# Rename Security Id column to SYMBOL
bse.drop(
    columns=[
        # "Group",
        # "Face Value",
        # "ISIN No",
        "Industry",
        "Instrument",
        "Sector Name",
        "Industry New Name",
        "Igroup Name",
        "ISubgroup Name",
    ],
    inplace=True, errors="ignore",
)

print(bse)

"""
bse.rename(columns={"Issuer Name": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Code": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Security Name"] == "Active"]
accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]
bse = bse[~bse["Security Id"].str.contains("ETF")]
bse = bse[~bse["Security Id"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["Security Id"].str.contains("FUND")]
bse = bse[~bse["Security Id"].str.contains("Fund")]
#bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")
condition = bse['SYMBOL'].str.endswith('*')
bse.loc[condition, 'SYMBOL'] = bse.loc[condition, 'SYMBOL'].str[:-1]
# Filter dataframe
bse = bse[bse["Status"].isin(accepted_values)]
"""
bse.rename(columns={"Security Id": "SYMBOL"}, inplace=True)
bse.rename(columns={"Security Name": "NAME OF COMPANY"}, inplace=True)
bse = bse[bse["Status"] == "Active"]
accepted_values = ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT"]
accepted_values = ["A ", "B ", "T ", "X ", "XT",
                   "R ", "M ", "MT", "IP", "P", "XD", "Z", "ZP"]
# Get unique items in the "Group" column
unique_items = bse["Group"].unique()
# Convert to a list
accepted_values = unique_items.tolist()
# Print the result
print("Unique items in 'Group':", accepted_values)
bse = bse[~bse["NAME OF COMPANY"].str.contains("ETF")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("EXCHANGE TRADED")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("FUND")]
bse = bse[~bse["NAME OF COMPANY"].str.contains("Fund")]
# bse["SYMBOL"] = bse["SYMBOL"].str.replace("*", "")

# bse = bse[
#    ~(
#        bse["NAME OF COMPANY"].str.endswith("ETF", na=False) |
#        bse["NAME OF COMPANY"].str.endswith("EXCHANGE TRADED", na=False) |
#        bse["NAME OF COMPANY"].str.endswith("FUND", na=False) |
#        bse["NAME OF COMPANY"].str.endswith("Fund", na=False)
#    )
# ]


condition = bse["SYMBOL"].str.endswith("*")
bse.loc[condition, "SYMBOL"] = bse.loc[condition, "SYMBOL"].str[:-1]
# Filter dataframe
#                  ["A ", "B ", "T ", "X ", "XT", "R ", "M ", "MT" ,"IP","P","XD","Z","ZP"]
# accepted_values =  ['A ', 'B ', 'T ', 'X ', 'XT', 'R ', 'M ', 'MT', 'Z ','XD']  #"P","XD","ZP" , 'IP'
accepted_valuesx = unique_items.tolist()
to_remove = {"P", "ZP", "IP", "Y"}  # use a set for fast lookup
accepted_values = [v for v in accepted_valuesx if v not in to_remove]

bse = bse[bse["Group"].isin(accepted_values)]


"""
#url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
#response = requests.get(url)
#datanse = pd.read_csv(url)
"""

# lower_bound = datetime.datetime.today() - datetime.timedelta(days=370)
# print(lower_bound)
# upper_bound = datetime.datetime.today()
"""
datanse[" DATE OF LISTING"] = pd.to_datetime(
    datanse[" DATE OF LISTING"], format="%d-%b-%Y"
)
datanse1 = datanse[(datanse[" DATE OF LISTING"] <= lower_bound)]
"""

datanse.drop(
    columns=[
        " SERIES",
        " DATE OF LISTING",
        " PAID UP VALUE",
        " MARKET LOT",
        # " ISIN NUMBER",
        " FACE VALUE",
    ],
    inplace=True,
)

# bse=bse['Igroup Name'].fillna("Zero", inplace=True)
# print(bse)
# print(datanse)

# datansebse = pd.merge(datanse, bse, left_on=[' ISIN NUMBER'], right_on=['Face Value'], how='left')
datansebse = pd.merge(datanse, bse, left_on=[" ISIN NUMBER"], right_on=[
                      "ISIN No"], how="right")
# print(datansebse)

# datansebse = pd.merge(datanse, bse, on=' ISIN NUMBER', how='left')
# print(datansebse)
# datanse.to_csv('/home/rizpython236/BT5/screener-outputs/datanse.csv', index=False)
# bse.to_csv('/home/rizpython236/BT5/screener-outputs/databse.csv', index=False)


bse_nse_common = common_symbols = bse[bse["ISIN No"].isin(
    datanse[" ISIN NUMBER"])]  # common isin
# common_symbols = bse[bse["SYMBOL"].isin(datanse["SYMBOL"])]

print(len(common_symbols))


bse = bse[~bse["ISIN No"].isin(common_symbols["ISIN No"])]
# Deleting the rows with common symbols in the bse file
# bse = bse[~bse["SYMBOL"].isin(common_symbols["SYMBOL"])]
print(len(bse))


add_suffix_to_column(bse_nse_common, "SYMBOL", ".BO")
# bse_nse_common["SYMBOL"].to_csv('/home/rizpython236/BT5/bse_nse_common.csv', index=False)
bse_nse_common[["SYMBOL"]].rename(columns={"SYMBOL": "Symbol"}).to_csv(
    "/home/rizpython236/BT5/bse_nse_common.csv", index=False)
# print(bse_nse_common)


add_suffix_to_column(bse, "SYMBOL", ".BO")
add_suffix_to_column(datanse, "SYMBOL", ".NS")


# Merging the two files
result = pd.concat([bse, datanse], axis=0, ignore_index=True)
# datanse = result[~result["Security Id"]astype(str).str.contains("ETF", na=False)]
result.rename(columns={"SYMBOL": "Symbol"}, inplace=True)
# result.insert(0, "^NSEI")
# result.insert(1, "^NSEBANK")
# result.insert(2, "^CRSLDX")
# result.insert(3, "^NSEMDCP50")

# print(result)
"""
result.drop(
    columns=[
        "NAME OF COMPANY",
        "Security Id",
        "Security Name",
        "Status",
        #" ISIN NUMBER",
        #" FACE VALUE",
    ],
    inplace=True,
)
"""
result.drop(
    columns=[
        "NAME OF COMPANY",
        "Issuer Name",
        "Group",
        # "Security Id",
        "Security Code",
        # "Security Name",
        "Status",
        # " ISIN NUMBER",
        "Face Value",
    ],
    inplace=True,
)
# print(result)

include_tickers_df = pd.DataFrame(include_tickers, columns=["Symbol"])
# result=result['Symbol']
# print(include_tickers_df)
# print(result)
# result = result.append(include_tickers_df['Symbol'], ignore_index=True)


common_symbols = include_tickers_df[~include_tickers_df["Symbol"].isin(
    result["Symbol"])]  # common isin
common_symbols = common_symbols["Symbol"]
# print(common_symbols)
# print((len(common_symbols)))
common_symbols.to_csv(
    "/home/rizpython236/BT5/screener-outputs/common.csv", index=False)


result = pd.concat([result, include_tickers_df], ignore_index=True)
result.to_csv("/home/rizpython236/BT5/finalfull.csv", index=False)
resultfull = pd.read_csv("/home/rizpython236/BT5/finalfull.csv")
# result = result.append(include_tickers[['Symbol']], ignore_index=True)

# print(exclude_tickers)
# unique_symbols = exclude_tickers["Symbol"].unique()  # Get the list of unique symbols
# exclude_tickers = pd.DataFrame(unique_symbols, columns=["Symbol"])  # Create DataFrame

# result = result[~result["Symbol"].isin(exclude_tickers)]
result = result[~result["Symbol"].isin(exclude_tickers["Symbol"])]
try:
    result = result[~result["Symbol"].isin(delisted["Symbol"])]

    # Drop excluded + delisted in one go
    symbols_to_remove = set(exclude_tickers["Symbol"]).union(
        set(delisted["Symbol"]))
    result = result[~result["Symbol"].isin(symbols_to_remove)]
except Exception as e:
    print("An unexpected error occurred:", e)

exclude_fromresult = result[result["Symbol"].isin(exclude_tickers["Symbol"])]
print(exclude_fromresult)

# for ex_ticker in result["Symbol"]: #ex_ticker in exclude_tickers:
#    if ex_ticker in result:
#        print(ex_ticker)
#        result = result[result["Symbol"] != ex_ticker] #result.remove(ex_ticker)
#    else:
#        1+1

# assuming exclude_tickers is a list/Series of tickers to remove
for ex_ticker in result["Symbol"]:
    if ex_ticker in exclude_tickers:  # ✅ check against exclude list
        # print(ex_ticker)
        result = result[result["Symbol"] != ex_ticker]  # remove ticker row
    else:
        pass

# result=list(result["Symbol"].unique())
# result=pd.DataFrame(result)
# result = result.rename(columns={result.columns[0]: "Symbol"})
result.loc[len(result), "Symbol"] = "^NSEI"
result.loc[len(result), "Symbol"] = "^NSEBANK"
result.loc[len(result), "Symbol"] = "^CRSLDX"
result.loc[len(result), "Symbol"] = "^NSEMDCP50"
result.loc[len(result), "Symbol"] = "MON100.NS"
result.loc[len(result), "Symbol"] = "MAFANG.NS"
result.loc[len(result), "Symbol"] = "MAHKTECH.NS"
result.loc[len(result), "Symbol"] = "SBIGETS.BO"
result.loc[len(result), "Symbol"] = "AXISCETF.NS"
result.loc[len(result), "Symbol"] = "ICICIINFRA.NS"
result.loc[len(result), "Symbol"] = "^CNXCMDT"
result.loc[len(result), "Symbol"] = "^CNXINFRA"
result.loc[len(result), "Symbol"] = "^CNXAUTO"
result.loc[len(result), "Symbol"] = "^CNXPHARMA"
result.loc[len(result), "Symbol"] = "^CNXPSUBANK"
result.loc[len(result), "Symbol"] = "^CNXIT"
result.loc[len(result), "Symbol"] = "^CNXCONSUM"
result.loc[len(result), "Symbol"] = "NIFTYPVTBANK.NS"
result.loc[len(result), "Symbol"] = "^CNXMETAL"
result.loc[len(result), "Symbol"] = "^CNXREALTY"
result.loc[len(result), "Symbol"] = "^CNXENERGY"
result.loc[len(result), "Symbol"] = "^CNXFMCG"
result.loc[len(result), "Symbol"] = "NIFTYSMLCAP250.NS"
result.loc[len(result), "Symbol"] = "NIFTY_MICROCAP250.NS"
result.loc[len(result), "Symbol"] = "BSE-IPO.BO"
result.loc[len(result), "Symbol"] = "NIFTY_FIN_SERVICE.NS"


result = list(result["Symbol"].unique())
result = pd.DataFrame(result)
result = result.rename(columns={result.columns[0]: "Symbol"})
# Remove any rows where the 'Symbol' column contains '-RE'
result = result[~result["Symbol"].str.contains("-RE.")]
result = result[~result["Symbol"].str.contains("DUMMY")]

result.to_csv("/home/rizpython236/BT5/Final.csv", index=False)

# result = pd.read_csv("/home/rizpython236/BT5/Final.csv")
# result =  result["Symbol"].str.replace('"', '')

# result.to_csv("/home/rizpython236/BT5/Final.csv", index=False)
# df = pd.read_csv("file.csv")
# result = result.rename(columns={df.columns[0]: "Symbol"})
# result.to_csv("file.csv", index=False)

post_telegram_message(
    message=f"Found {len(result)} tickers in final Symbol list")
print(f"Found {len(Final111)} tickers in full old Symbol list")
print(f"Found {len(result)} tickers in full Symbol list")

# print(resultfull)  # Should output <class 'pandas.core.series.Series'>
result_set = set(result["Symbol"])
resultfull_set = set(resultfull["Symbol"])
Final111_set = set(Final111["Symbol"])
new_tickers_set = set(new_tickers["FULLSymbol"])

# Find items in result but not in Final111
items_not_in_Final111 = resultfull_set - Final111_set - new_tickers_set

# Print the items
print(", ".join(items_not_in_Final111))
post_telegram_message(message=", ".join(items_not_in_Final111))

# Assuming new_tickers.csv has a column named 'FULLSymbol'
csv_file_path = "/home/rizpython236/BT5/trade-logs/new_tickers.csv"
Holding = "/home/rizpython236/BT5/myholding.csv"

try:
    # Read the existing CSV file into a DataFrame
    existing_tickers_df = pd.read_csv(csv_file_path)
    existing_tickers_df["FULLSymbol"] = existing_tickers_df["FULLSymbol"].astype(
        str)
    existing_tickers_df["NSE750"] = existing_tickers_df["NSE750"].astype(str)

    # Convert the items_not_in_Final111 set to a DataFrame
    new_tickers_df = pd.DataFrame(
        items_not_in_Final111, columns=["FULLSymbol"])

    # Append new_tickers_df to existing_tickers_df
    merged_df = pd.concat(
        [existing_tickers_df, new_tickers_df], ignore_index=True)

    merged_df.drop_duplicates(subset=["FULLSymbol", "NSE750"], inplace=True)

    # Reset index after removing duplicates
    merged_df.reset_index(drop=True, inplace=True)

    if len(new_tickers_df) < 30:
        # Save the merged DataFrame back to the CSV file
        merged_df.to_csv(csv_file_path, index=False)

    time.sleep(3)
    import_user_module(base_dir_module, "holding_unique")
    import_user_module(base_dir_module, "filtersymbols")
    import_user_module(base_dir_module, "ISINbsense")
except Exception as exc:
    print(exc)
# global_df = pd.DataFrame()
# global_df["Symbol"] = global_ticker_list
# global_df.to_csv(SYMBOLS_CSV, index=False)

import_user_module(base_dir_module, "symbol_copy")
print("Ticker download operation finished successfully!")

#####################################
"""
def download_tickers_from_url(url):
    # headers = {
    #     "User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0"
    # }
    url_response = requests.get(url, timeout=10).content
    return url_response


def convert_buffer_response_to_dataframe(buffer_response):
    df = pd.read_csv(io.StringIO(buffer_response.decode("utf-8")))
    return df


download_successful = False
while MAX_RETRIES:
    try:
        time.sleep(1)
        print("Downloading Nifty500 and MicroCap250 from NSE Website.")
        NIFTY_500 = convert_buffer_response_to_dataframe(
            download_tickers_from_url(NSE_NIFTY_500_URL)
        )
        print("Found {} tickers in NSE NIFTY 500".format(len(NIFTY_500)))
        MICROCAP_250 = convert_buffer_response_to_dataframe(
            download_tickers_from_url(NSE_MICROCAP_250_URL)
        )
        print("Found {} tickers in NSE MICROCAP 250".format(len(MICROCAP_250)))
        download_successful = True
        MAX_RETRIES = 0
    except Exception as exc:
        time.sleep(1)
        print("Download from NSE failed! Retrying...")
        print(exc)
        print("-" * 50)
        MAX_RETRIES -= 1


if not download_successful:
    post_telegram_message(message="Download data from NSE Failed")
    sys.exit()


# Include/Exclude Tickers
print("Preparing Symbol List")
global_ticker_list = []
global_ticker_list += list(NIFTY_500.Symbol)
global_ticker_list += list(MICROCAP_250.Symbol)
global_ticker_list += include_tickers
print("Found {} tickers in global_ticker_list".format(len(global_ticker_list)))

for ex_ticker in exclude_tickers:
    if ex_ticker in global_ticker_list:
        global_ticker_list.remove(ex_ticker)


global_ticker_list = list(set(global_ticker_list))
# global_ticker_list = sorted(global_ticker_list)

# Formatting tickers as per Yahoo ticker naming convention
global_ticker_list = [ticker + ".NS" for ticker in global_ticker_list]

# IMPORTANT: Adding NSEI on top of the file
global_ticker_list.insert(0, "^NSEI")
global_ticker_list.insert(1, "^NSEBANK")
global_ticker_list.insert(2, "^CRSLDX")
global_ticker_list.insert(3, "^NSEMDCP50")
global_ticker_list.insert(4,"SDBL.BO")
global_ticker_list.insert(5,"ALUFLUOR.BO")
global_ticker_list.insert(6,"AMNPLST.BO")
global_ticker_list.insert(7,"ANUHPHR.BO")
global_ticker_list.insert(8,"APOLLOTRI.BO")
global_ticker_list.insert(9,"DAICHI.BO")
global_ticker_list.insert(10,"DYNAMIND.BO")
global_ticker_list.insert(11,"FERMENTA.BO")
global_ticker_list.insert(12,"FRONTSP.BO")
global_ticker_list.insert(13,"DHABRIYA.BO")
global_ticker_list.insert(14,"FRSHTRP.BO")
global_ticker_list.insert(15,"HALDYNGL.BO")
global_ticker_list.insert(16,"HAWKINCOOK.BO")
global_ticker_list.insert(17,"INDOAMIN.BO")
global_ticker_list.insert(18,"IONEXCHANG.BO")
global_ticker_list.insert(19,"SHAILY.BO")
global_ticker_list.insert(20,"JYOTIRES.BO")
global_ticker_list.insert(21,"KOVAI.BO")
global_ticker_list.insert(22,"MANORG.BO")
global_ticker_list.insert(23,"NATPEROX.BO")
global_ticker_list.insert(24,"NGLFINE.BO")
global_ticker_list.insert(25,"PAUSHAKLTD.BO")
global_ticker_list.insert(26,"PERMAGN.BO")
global_ticker_list.insert(27,"RACLGEAR.BO")
global_ticker_list.insert(28,"RAJOOENG.BO")
global_ticker_list.insert(29,"ROTO.BO")
global_ticker_list.insert(30,"SAINTGOBAIN.BO")
global_ticker_list.insert(31,"SAMKRG.BO")
global_ticker_list.insert(32,"SUYOG.BO")
global_ticker_list.insert(33,"TALBROAUTO.BO")
global_ticker_list.insert(34,"TRITONV.BO")
global_ticker_list.insert(35,"TYCHE.BO")
global_ticker_list.insert(36,"VENKYS.BO")
global_ticker_list.insert(37,"VIRINCHI.BO")
global_ticker_list.insert(39,"YASHPAKKA.BO")
global_ticker_list.insert(40,"TAALENT.BO")
global_ticker_list.insert(41,"TANAA.BO")
global_ticker_list.insert(42,"STOVACQ.BO")
global_ticker_list.insert(43,"^CNXSC")
global_ticker_list.insert(44,"UNITDSPR.BO")
global_ticker_list.insert(45,"GUJGAS.BO")
global_ticker_list.insert(46,"DEEPAKNI.BO")
global_ticker_list.insert(47,"LLOYDSME.BO")
global_ticker_list.insert(48,"AEGISLOG.BO")
global_ticker_list.insert(49,"FINOLEXIND.BO")
global_ticker_list.insert(50,"EUREKAFORBE.BO")
global_ticker_list.insert(51,"ALOKTEXT.BO")
global_ticker_list.insert(52,"GMM.BO")
global_ticker_list.insert(53,"CAPPL.BO")
global_ticker_list.insert(54,"AVANTI.BO")
global_ticker_list.insert(55,"SAFARIND.BO")
global_ticker_list.insert(56,"RAJGLOWIR.BO")
global_ticker_list.insert(57,"SINDHUTRAD.BO")
global_ticker_list.insert(58,"EKI.BO")
global_ticker_list.insert(59,"KIRLPNU.BO")
global_ticker_list.insert(60,"AIIL.BO")
global_ticker_list.insert(61,"PTCIL.BO")
global_ticker_list.insert(62,"NIRLON.BO")
global_ticker_list.insert(63,"RSYSTEMINT.BO")
global_ticker_list.insert(64,"RAJRAYON.BO")
global_ticker_list.insert(65,"SADHNANIQ.BO")
global_ticker_list.insert(66,"SANDUMA.BO")
global_ticker_list.insert(67,"SGFIN.BO")
global_ticker_list.insert(68,"SHBCLQ.BO")
global_ticker_list.insert(69,"DFM.BO")
global_ticker_list.insert(70,"MSTC.BO")
global_ticker_list.insert(71,"JISLDVREQS.BO")
global_ticker_list.insert(72,"JTLIND.BO")
global_ticker_list.insert(73,"SUBEX.BO")
global_ticker_list.insert(74,"PACL.BO")
global_ticker_list.insert(75,"APOLLOPIPES.BO")
global_ticker_list.insert(76,"LLOYDSTEEL.BO")
global_ticker_list.insert(77,"YASHO.BO")
global_ticker_list.insert(78,"AVL.BO")
global_ticker_list.insert(79,"PQIF.BO")
global_ticker_list.insert(80,"WARDINMOBI.BO")
global_ticker_list.insert(81,"NOVARTIND.BO")
global_ticker_list.insert(82,"RAJNISH.BO")
global_ticker_list.insert(83,"TIMEX.BO")
global_ticker_list.insert(84,"GENSOL.BO")
global_ticker_list.insert(85,"CIGNITI.BO")
global_ticker_list.insert(86,"MMWL.BO")
global_ticker_list.insert(87,"TTKHEALTH.BO")
global_ticker_list.insert(88,"TGVSL.BO")
global_ticker_list.insert(89,"KMEW.BO")
global_ticker_list.insert(90,"SANINFRA.BO")
global_ticker_list.insert(91,"ANDREWYU.BO")
global_ticker_list.insert(92,"LANCER.BO")
global_ticker_list.insert(93,"CRESSAN.BO")
global_ticker_list.insert(94,"MCLOUD.BO")
global_ticker_list.insert(95,"RPEL.BO")
global_ticker_list.insert(96,"DISAQ.BO")
global_ticker_list.insert(97,"WPIL.BO")
global_ticker_list.insert(98,"ELPROINTL.BO")
global_ticker_list.insert(99,"MOSCHIP.BO")
global_ticker_list.insert(100,"GUJTHEM.BO")
global_ticker_list.insert(101,"SHIVACEM.BO")
global_ticker_list.insert(102,"RADIANTCMS.BO")
global_ticker_list.insert(103,"BCLIL.BO")
global_ticker_list.insert(104,"FINKURVE.BO")
global_ticker_list.insert(105,"KMCSHIL.BO")
global_ticker_list.insert(106,"WAAREERTL.BO")
global_ticker_list.insert(107,"RPIL.BO")
global_ticker_list.insert(108,"TANFACIND.BO")
global_ticker_list.insert(109,"UDAICEMENT.BO")
global_ticker_list.insert(110,"ULTRAMAR.BO")
global_ticker_list.insert(111,"DEEPIND.BO")
global_ticker_list.insert(112,"WELSPLSOL.BO")
global_ticker_list.insert(113,"TRANSPEK.BO")
global_ticker_list.insert(114,"SRD.BO")
global_ticker_list.insert(115,"BLACKROSE.BO")
global_ticker_list.insert(116,"BEEKAY.BO")
global_ticker_list.insert(117,"DDEVPLASTIK.BO")
global_ticker_list.insert(118,"BLIL.BO")
global_ticker_list.insert(119,"DAVANGERE.BO")
global_ticker_list.insert(120,"BMW.BO")
global_ticker_list.insert(121,"RELTD.BO")
global_ticker_list.insert(122,"QUINT.BO")
global_ticker_list.insert(123,"TOYAMSL.BO")
global_ticker_list.insert(124,"TUTIALKA.BO")
global_ticker_list.insert(125,"COCKERILL.BO")
global_ticker_list.insert(126,"PRAVEG.BO")
global_ticker_list.insert(127,"TRU.BO")
global_ticker_list.insert(128,"CHAMANSEQ.BO")
global_ticker_list.insert(129,"LINCOPH.BO")
global_ticker_list.insert(130,"WARDWIZFBL.BO")
global_ticker_list.insert(131,"ARIHCAPM.BO")
global_ticker_list.insert(132,"AVANTEL.BO")
global_ticker_list.insert(133,"3IINFOTECH.BO")
global_ticker_list.insert(134,"VERITAS.BO")
global_ticker_list.insert(135,"RAJPALAYAM.BO")
global_ticker_list.insert(136,"BINNY.BO")
global_ticker_list.insert(137,"DCMSRMIND.BO")
global_ticker_list.insert(138,"NAGARFERT.BO")
global_ticker_list.insert(139,"BALUFORGE.BO")
global_ticker_list.insert(140,"ANDHRAPET.BO")
global_ticker_list.insert(141,"RAFL.BO")
global_ticker_list.insert(142,"NIKHILAD.BO")
global_ticker_list.insert(143,"KSE.BO")
global_ticker_list.insert(144,"SAYAJIHOTL.BO")
global_ticker_list.insert(145,"BHARATAGRI.BO")
global_ticker_list.insert(146,"BARODARY.BO")
global_ticker_list.insert(147,"SPENCER.BO")
global_ticker_list.insert(148,"MUFIN.BO")
global_ticker_list.insert(149,"WIMPLAST.BO")
global_ticker_list.insert(150,"NITTAGELA.BO")
global_ticker_list.insert(151,"CHEMCRUX.BO")
global_ticker_list.insert(152,"NICCOPAR.BO")
global_ticker_list.insert(153,"ASMTEC.BO")
global_ticker_list.insert(154,"LORDSCHLO.BO")
global_ticker_list.insert(155,"JAGAJITIND.BO")
global_ticker_list.insert(156,"FREDUN.BO")
global_ticker_list.insert(157,"WORL.BO")
global_ticker_list.insert(158,"SALZER.BO")
global_ticker_list.insert(159,"RAGHUSYN.BO")
global_ticker_list.insert(160,"NIBE.BO")
global_ticker_list.insert(161,"SCFL.BO")
global_ticker_list.insert(162,"BHEEMACEM.BO")
global_ticker_list.insert(163,"STL.BO")
global_ticker_list.insert(164,"BAJAJST.BO")
global_ticker_list.insert(165,"TIGERLOGS.BO")
global_ticker_list.insert(166,"PICCADIL.BO")
global_ticker_list.insert(167,"STARLENT.BO")
global_ticker_list.insert(168,"GOODRICKE.BO")
global_ticker_list.insert(169,"SUNSHIEL.BO")
global_ticker_list.insert(170,"MAFATIND.BO")
global_ticker_list.insert(171,"NATCAPSUQ.BO")
global_ticker_list.insert(172,"SINGER.BO")
global_ticker_list.insert(173,"MOLDTEK.BO")
global_ticker_list.insert(174,"ORICON.BO")
global_ticker_list.insert(175,"SHILCTECH.BO")
global_ticker_list.insert(176,"VARIMAN.BO")
global_ticker_list.insert(177,"ZFSTEERING.BO")
global_ticker_list.insert(178,"KRITIIND.BO")
global_ticker_list.insert(179,"SAHYADRI.BO")
global_ticker_list.insert(180,"KPEL.BO")
global_ticker_list.insert(181,"MUTHTFN.BO")
global_ticker_list.insert(182,"MAXINDIA.BO")
global_ticker_list.insert(183,"RUBFILA.BO")
global_ticker_list.insert(184,"COMSYN.BO")
global_ticker_list.insert(185,"AIML.BO")
global_ticker_list.insert(186,"ORIRAIL.BO")
global_ticker_list.insert(187,"DIAMINESQ.BO")
global_ticker_list.insert(188,"SUPREME.BO")
global_ticker_list.insert(189,"PONDYOXIDE.BO")
global_ticker_list.insert(190,"VISHAL.BO")
global_ticker_list.insert(191,"SAURASHCEM.BO")
global_ticker_list.insert(192,"AQFINTECH.BO")
global_ticker_list.insert(193,"ARFIN.BO")
global_ticker_list.insert(194,"ADVAIT.BO")
global_ticker_list.insert(195,"DECNGOLD.BO")
global_ticker_list.insert(196,"EMPIND.BO")
global_ticker_list.insert(197,"MONEYBOXX.BO")
global_ticker_list.insert(198,"GLOSTERLTD.BO")
global_ticker_list.insert(199,"KIRANVYPAR.BO")
global_ticker_list.insert(200,"ZENOTECH.BO")
global_ticker_list.insert(201,"STARHFL.BO")
global_ticker_list.insert(202,"SBGLP.BO")
global_ticker_list.insert(203,"AXTEL.BO")
global_ticker_list.insert(204,"KPL.BO")
global_ticker_list.insert(205,"TINNARUBR.BO")
global_ticker_list.insert(206,"XTGLOBAL.BO")
global_ticker_list.insert(207,"DEEP.BO")
global_ticker_list.insert(208,"GALXBRG.BO")
global_ticker_list.insert(209,"AAL.BO")
global_ticker_list.insert(210,"NIYOGIN.BO")
global_ticker_list.insert(211,"KHODAY.BO")
global_ticker_list.insert(212,"EFCIL.BO")
global_ticker_list.insert(213,"SWISSMLTRY.BO")
global_ticker_list.insert(214,"VINCOFE.BO")
global_ticker_list.insert(215,"RACE.BO")
global_ticker_list.insert(216,"NSL.BO")
global_ticker_list.insert(217,"AFFORDABLE.BO")
global_ticker_list.insert(218,"KILPEST.BO")
global_ticker_list.insert(219,"BHARATSE.BO")
global_ticker_list.insert(220,"BHATIA.BO")
global_ticker_list.insert(221,"DHPIND.BO")
global_ticker_list.insert(222,"SINCLAIR.BO")
global_ticker_list.insert(223,"MLKFOOD.BO")
global_ticker_list.insert(224,"INFLAME.BO")
global_ticker_list.insert(225,"INTEGRAEN.BO")
global_ticker_list.insert(226,"COSMOFE.BO")
global_ticker_list.insert(227,"SGRL.BO")
global_ticker_list.insert(228,"PANCHSHEEL.BO")
global_ticker_list.insert(229,"JENBURPH.BO")
global_ticker_list.insert(230,"AJANTSOY.BO")
global_ticker_list.insert(231,"PODARPIGQ.BO")
global_ticker_list.insert(232,"HIGHENE.BO")
global_ticker_list.insert(233,"SIKA.BO")
global_ticker_list.insert(234,"INA.BO")
global_ticker_list.insert(235,"ARTSONEN.BO")
global_ticker_list.insert(236,"ADORFO.BO")
global_ticker_list.insert(237,"BAMBINO.BO")
global_ticker_list.insert(238,"KACL.BO")
global_ticker_list.insert(239,"JAYSHREETEA.BO")
global_ticker_list.insert(240,"PRADPME.BO")
global_ticker_list.insert(241,"MARKOLINES.BO")
global_ticker_list.insert(242,"MODINATUR.BO")
global_ticker_list.insert(243,"MIC.BO")
global_ticker_list.insert(244,"TALBROSENG.BO")
global_ticker_list.insert(245,"JAYKAY.BO")
global_ticker_list.insert(246,"BAIDFIN.BO")
global_ticker_list.insert(247,"VOEPL.BO")
global_ticker_list.insert(248,"INDRANIB.BO")
global_ticker_list.insert(249,"AMAL.BO")
global_ticker_list.insert(250,"GLOBUSCON.BO")
global_ticker_list.insert(251,"ECORECO.BO")
global_ticker_list.insert(252,"UDAYJEW.BO")
global_ticker_list.insert(253,"WESTLEIRES.BO")
global_ticker_list.insert(254,"IFL.BO")
global_ticker_list.insert(255,"LOTUSCHO.BO")
global_ticker_list.insert(256,"SISL.BO")
global_ticker_list.insert(257,"MANAKSTELTD.BO")
global_ticker_list.insert(258,"KLBRENG-B.BO")
global_ticker_list.insert(259,"RNBDENIMS.BO")
global_ticker_list.insert(260,"ULTRACAB.BO")
global_ticker_list.insert(261,"SRGHFL.BO")
global_ticker_list.insert(262,"RIR.BO")
global_ticker_list.insert(263,"NAVKAR.BO")
global_ticker_list.insert(264,"BIRLAPREC.BO")
global_ticker_list.insert(265,"PANCHMAHQ.BO")
global_ticker_list.insert(266,"SERA.BO")
global_ticker_list.insert(267,"MODIS.BO")
global_ticker_list.insert(268,"SCOOTER.BO")
global_ticker_list.insert(269,"MULTIBASE.BO")
global_ticker_list.insert(270,"MITSU.BO")
global_ticker_list.insert(271,"MENNPIS.BO")
global_ticker_list.insert(272,"TITANBIO.BO")
global_ticker_list.insert(273,"SBECSUG.BO")
global_ticker_list.insert(274,"THINKINK.BO")
global_ticker_list.insert(275,"SVRL.BO")
global_ticker_list.insert(276,"ABANSENT.BO")
global_ticker_list.insert(277,"TPLPLAST.BO")
global_ticker_list.insert(278,"INDIANVSH.BO")
global_ticker_list.insert(279,"KINETICENG.BO")
global_ticker_list.insert(280,"UYFINCORP.BO")
global_ticker_list.insert(281,"MAXIMUS.BO")
global_ticker_list.insert(282,"COCHINM.BO")
global_ticker_list.insert(283,"KINGSINFR.BO")
global_ticker_list.insert(284,"SPELS.BO")
global_ticker_list.insert(285,"MKEXIM.BO")
global_ticker_list.insert(286,"AEPL.BO")
global_ticker_list.insert(287,"DIGJAMLTD.BO")
global_ticker_list.insert(288,"QUESTCAP.BO")
global_ticker_list.insert(289,"MANCREDIT.BO")
global_ticker_list.insert(290,"SKYGOLD.BO")
global_ticker_list.insert(291,"ADCINDIA.BO")
global_ticker_list.insert(292,"SAMRATPH.BO")
global_ticker_list.insert(293,"GEE.BO")
global_ticker_list.insert(294,"VIKRAMTH.BO")
global_ticker_list.insert(295,"OVOBELE.BO")
global_ticker_list.insert(296,"PALRED.BO")
global_ticker_list.insert(297,"INDAG.BO")
global_ticker_list.insert(298,"HOCL.BO")
global_ticker_list.insert(299,"REFEXRENEW.BO")
global_ticker_list.insert(300,"ABMKNO.BO")
global_ticker_list.insert(301,"KANCHI.BO")
global_ticker_list.insert(302,"INDTONER.BO")
global_ticker_list.insert(303,"RUDRA.BO")
global_ticker_list.insert(304,"SCANSTL.BO")
global_ticker_list.insert(305,"AMBALALSA.BO")
global_ticker_list.insert(306,"ALPINEHOU.BO")
global_ticker_list.insert(307,"BASANTGL.BO")
global_ticker_list.insert(308,"SYSCHEM.BO")
global_ticker_list.insert(309,"PANAENERG.BO")
global_ticker_list.insert(310,"JASCH.BO")
global_ticker_list.insert(311,"SMRUTHIORG.BO")
global_ticker_list.insert(312,"ITHL.BO")
global_ticker_list.insert(313,"KIMIABL.BO")
global_ticker_list.insert(314,"MODINSU.BO")
global_ticker_list.insert(315,"INDIANACRY.BO")
global_ticker_list.insert(316,"VTMLTD.BO")
global_ticker_list.insert(317,"AINFRA.BO")
global_ticker_list.insert(318,"RRIL.BO")
global_ticker_list.insert(319,"IWP.BO")
global_ticker_list.insert(320,"AARNAV.BO")
global_ticker_list.insert(321,"SHIVTEX.BO")
global_ticker_list.insert(322,"CALCOM.BO")
global_ticker_list.insert(323,"STHINPA.BO")
global_ticker_list.insert(324,"RDBRL.BO")
global_ticker_list.insert(325,"SHISHIND.BO")
global_ticker_list.insert(326,"THEBYKE.BO")
global_ticker_list.insert(327,"SHAWGELTIN.BO")
global_ticker_list.insert(328,"SHARDUL.BO")
global_ticker_list.insert(329,"GALACTICO.BO")
global_ticker_list.insert(330,"CGVAK.BO")
global_ticker_list.insert(331,"ATAM.BO")
global_ticker_list.insert(332,"FILATFASH.BO")
global_ticker_list.insert(333,"RMC.BO")
global_ticker_list.insert(334,"DEEPAKSP.BO")
global_ticker_list.insert(335,"CEINSYSTECH.BO")
global_ticker_list.insert(336,"COMPUAGE.BO")
global_ticker_list.insert(337,"STML.BO")
global_ticker_list.insert(338,"BIMETAL.BO")
global_ticker_list.insert(339,"PACIFICI.BO")
global_ticker_list.insert(340,"SHARP.BO")
global_ticker_list.insert(341,"MANOMAY.BO")
global_ticker_list.insert(342,"INDGELA.BO")
global_ticker_list.insert(343,"CAPRIHANS.BO")
global_ticker_list.insert(344,"BELLACASA.BO")
global_ticker_list.insert(345,"BEMHY.BO")
global_ticker_list.insert(346,"AVAILFC.BO")
global_ticker_list.insert(347,"AJIL.BO")
global_ticker_list.insert(348,"AASHKA.BO")
global_ticker_list.insert(349,"MSL.BO")
global_ticker_list.insert(350,"WAAREE.BO")
global_ticker_list.insert(351,"LEHIL.BO")
global_ticker_list.insert(352,"THAKDEV.BO")
global_ticker_list.insert(353,"MAGNAELQ.BO")
global_ticker_list.insert(354,"SHREESEC.BO")
global_ticker_list.insert(355,"ARCHITORG.BO")
global_ticker_list.insert(356,"KAJARIR.BO")
global_ticker_list.insert(357,"VIPULORG.BO")
global_ticker_list.insert(358,"AVONMORE.BO")
global_ticker_list.insert(359,"WINSOMTX.BO")
global_ticker_list.insert(360,"BHAGYNAGAR.BO")
global_ticker_list.insert(361,"GRAVISSHO.BO")
global_ticker_list.insert(362,"SURAJ.BO")
global_ticker_list.insert(363,"CTL.BO")
global_ticker_list.insert(364,"SRSOLTD.BO")
global_ticker_list.insert(365,"ASRL.BO")
global_ticker_list.insert(366,"AIMCOPEST.BO")
global_ticker_list.insert(367,"ZODIACVEN.BO")
global_ticker_list.insert(368,"MNKALCOLTD.BO")
global_ticker_list.insert(369,"TLL.BO")
global_ticker_list.insert(370,"PATELSAI.BO")
global_ticker_list.insert(371,"ANG.BO")
global_ticker_list.insert(372,"FLEXFO.BO")
global_ticker_list.insert(373,"PML.BO")
global_ticker_list.insert(374,"SURJIND.BO")
global_ticker_list.insert(375,"HINDADH.BO")
global_ticker_list.insert(376,"HFIL.BO")
global_ticker_list.insert(377,"JAYANT.BO")
global_ticker_list.insert(378,"SRAMSET.BO")
global_ticker_list.insert(379,"GARNETINT.BO")
global_ticker_list.insert(380,"DUNCANENG.BO")
global_ticker_list.insert(381,"RATNABHUMI.BO")
global_ticker_list.insert(382,"COMPEAU.BO")
global_ticker_list.insert(383,"BI.BO")
global_ticker_list.insert(384,"SPITZE.BO")
global_ticker_list.insert(385,"SICAGEN.BO")
global_ticker_list.insert(386,"BIBCL.BO")
global_ticker_list.insert(387,"AGOL.BO")
global_ticker_list.insert(388,"SHAHLON.BO")
global_ticker_list.insert(389,"TEJNAKSH.BO")
global_ticker_list.insert(390,"MAXHEIGHTS.BO")
global_ticker_list.insert(391,"KRRAIL.BO")
global_ticker_list.insert(392,"MAINFRA.BO")
global_ticker_list.insert(393,"LASTMILE.BO")
global_ticker_list.insert(394,"CNCRD.BO")
global_ticker_list.insert(395,"ALPHALOGIC.BO")
global_ticker_list.insert(396,"COROENGG.BO")
global_ticker_list.insert(397,"GNRL.BO")
global_ticker_list.insert(398,"DENISCHEM.BO")
global_ticker_list.insert(399,"RESONANCE.BO")
global_ticker_list.insert(400,"SONAL.BO")
global_ticker_list.insert(401,"REXNORD.BO")
global_ticker_list.insert(402,"SWADPOL.BO")
global_ticker_list.insert(403,"INNOVATORS.BO")
global_ticker_list.insert(404,"DAMOINDUS.BO")
global_ticker_list.insert(405,"INDSILHYD.BO")
global_ticker_list.insert(406,"VEDAVAAG.BO")
global_ticker_list.insert(407,"MNKCMILTD.BO")
global_ticker_list.insert(408,"APMIN.BO")
global_ticker_list.insert(409,"GLOBOFFS.BO")
global_ticker_list.insert(410,"NETTLINX.BO")
global_ticker_list.insert(411,"LEHAR.BO")
global_ticker_list.insert(412,"GGL.BO")
global_ticker_list.insert(413,"LANCORHOL.BO")
global_ticker_list.insert(414,"KRISHNA.BO")
global_ticker_list.insert(415,"NATHIND.BO")
global_ticker_list.insert(416,"RTSPOWR.BO")
global_ticker_list.insert(417,"KEERTHI.BO")
global_ticker_list.insert(418,"KKALPANAIND.BO")
global_ticker_list.insert(419,"MEFCOMCAP.BO")
global_ticker_list.insert(420,"VIRAT.BO")
global_ticker_list.insert(421,"HAZOOR.BO")
global_ticker_list.insert(422,"SURAJLTD.BO")
global_ticker_list.insert(423,"VGCL.BO")
global_ticker_list.insert(424,"ISHANCH.BO")
global_ticker_list.insert(425,"SIGNETIND.BO")
global_ticker_list.insert(426,"UNIAUTO.BO")
global_ticker_list.insert(427,"HINDTIN.BO")
global_ticker_list.insert(428,"COMFINCAP.BO")
global_ticker_list.insert(429,"FLUIDOM.BO")
global_ticker_list.insert(430,"LKPFIN.BO")
global_ticker_list.insert(431,"DUROPLY.BO")
global_ticker_list.insert(432,"VISTARAMAR.BO")
global_ticker_list.insert(433,"KERALAYUR.BO")
global_ticker_list.insert(434,"NAGPI.BO")
global_ticker_list.insert(435,"INDSUCR.BO")
global_ticker_list.insert(436,"HEMANG.BO")
global_ticker_list.insert(437,"SHINDL.BO")
global_ticker_list.insert(438,"GORANIN.BO")
global_ticker_list.insert(439,"TRANSCOR.BO")
global_ticker_list.insert(440,"SHIVAAGRO.BO")
global_ticker_list.insert(441,"VALIANT.BO")
global_ticker_list.insert(442,"ASIIL.BO")
global_ticker_list.insert(443,"PREMCO.BO")
global_ticker_list.insert(444,"EKANSH.BO")
global_ticker_list.insert(445,"KGPETRO.BO")
global_ticker_list.insert(446,"KANSHST.BO")
global_ticker_list.insert(447,"VSL.BO")
global_ticker_list.insert(448,"PRIMAPLA.BO")
global_ticker_list.insert(449,"LKPSEC.BO")
global_ticker_list.insert(450,"EMERALD.BO")
global_ticker_list.insert(451,"BIHSPONG.BO")
global_ticker_list.insert(452,"BONLON.BO")
global_ticker_list.insert(453,"PJL.BO")
global_ticker_list.insert(454,"SEML.BO")
global_ticker_list.insert(455,"NTCIND.BO")
global_ticker_list.insert(456,"SAMPRE.BO")
global_ticker_list.insert(457,"TAMBOLI.BO")
global_ticker_list.insert(458,"FAMILYCARE.BO")
global_ticker_list.insert(459,"OKPLA.BO")
global_ticker_list.insert(460,"BESTEAST.BO")
global_ticker_list.insert(461,"EVERESTO.BO")
global_ticker_list.insert(462,"BRIGHTBR.BO")
global_ticker_list.insert(463,"ACML.BO")
global_ticker_list.insert(464,"SAHLIBHFI.BO")
global_ticker_list.insert(465,"AREYDRG.BO")
global_ticker_list.insert(466,"RISHIROOP.BO")
global_ticker_list.insert(467,"LUDLOWJUT.BO")
global_ticker_list.insert(468,"AKASHDEEP.BO")
global_ticker_list.insert(469,"SSLEL.BO")
global_ticker_list.insert(470,"LAHOTIOV.BO")
global_ticker_list.insert(471,"PARVATI.BO")
global_ticker_list.insert(472,"NITINCAST.BO")
global_ticker_list.insert(473,"LATIMMETAL.BO")
global_ticker_list.insert(474,"VBCFERROQ.BO")
global_ticker_list.insert(475,"ACCEL.BO")
global_ticker_list.insert(476,"OLYMPTX.BO")
global_ticker_list.insert(477,"SCANPGEOM.BO")
global_ticker_list.insert(478,"CBPL.BO")
global_ticker_list.insert(479,"BTTL.BO")
global_ticker_list.insert(480,"KRANTI.BO")
global_ticker_list.insert(481,"DIVSHKT.BO")
global_ticker_list.insert(482,"SHERVANI.BO")
global_ticker_list.insert(483,"SAVERA.BO")
global_ticker_list.insert(484,"TTFL.BO")
global_ticker_list.insert(485,"BRPL.BO")
global_ticker_list.insert(486,"GTV.BO")
global_ticker_list.insert(487,"LYKISLTD.BO")
global_ticker_list.insert(488,"DANLAW.BO")
global_ticker_list.insert(489,"BABA.BO")
global_ticker_list.insert(490,"SVGLOBAL.BO")
global_ticker_list.insert(491,"CPL.BO")
global_ticker_list.insert(492,"SHREYASI.BO")
global_ticker_list.insert(493,"RAJOIL.BO")
global_ticker_list.insert(494,"JSTL.BO")
global_ticker_list.insert(495,"BDH.BO")
global_ticker_list.insert(496,"VEERKRUPA.BO")
global_ticker_list.insert(497,"GOLKUNDIA.BO")
global_ticker_list.insert(498,"BRAHMINFRA.BO")
global_ticker_list.insert(499,"VISHALBL.BO")
global_ticker_list.insert(500,"ANJANIFOODS.BO")
global_ticker_list.insert(501,"ODYSSEY.BO")
global_ticker_list.insert(502,"COMFINTE.BO")
global_ticker_list.insert(503,"PARNAXLAB.BO")
global_ticker_list.insert(504,"ATHENAGLO.BO")
global_ticker_list.insert(505,"EDVENSWA.BO")
global_ticker_list.insert(506,"GROWINGTON.BO")
global_ticker_list.insert(507,"ARL.BO")
global_ticker_list.insert(508,"FLOMIC.BO")
global_ticker_list.insert(509,"CHLLTD.BO")
global_ticker_list.insert(510,"POEL.BO")
global_ticker_list.insert(511,"SABOOSOD.BO")
global_ticker_list.insert(512,"KGDENIM.BO")
global_ticker_list.insert(513,"INTLCOMBQ.BO")
global_ticker_list.insert(514,"CANDOUR.BO")
global_ticker_list.insert(515,"VIPPYSP.BO")
global_ticker_list.insert(516,"WEPSOLN.BO")
global_ticker_list.insert(517,"BCPL.BO")
global_ticker_list.insert(518,"SAGAR.BO")
global_ticker_list.insert(519,"INDICAP.BO")
global_ticker_list.insert(520,"HKG.BO")
global_ticker_list.insert(521,"BANASFN.BO")
global_ticker_list.insert(522,"IMCAP.BO")
global_ticker_list.insert(523,"ACTIVE.BO")
global_ticker_list.insert(524,"GCKL.BO")
global_ticker_list.insert(525,"AICHAMP.BO")
global_ticker_list.insert(526,"GKB.BO")
global_ticker_list.insert(527,"METALCO.BO")
global_ticker_list.insert(528,"KLRFM.BO")
global_ticker_list.insert(529,"YASHCHEM.BO")
global_ticker_list.insert(530,"BLUECLOUDS.BO")
global_ticker_list.insert(531,"REALECO.BO")
global_ticker_list.insert(532,"TATAYODOGA.BO")
global_ticker_list.insert(533,"GTNINDS.BO")
global_ticker_list.insert(534,"AAIL.BO")
global_ticker_list.insert(535,"BENGALT.BO")
global_ticker_list.insert(536,"HIMTEK.BO")
global_ticker_list.insert(537,"NATPLASTI.BO")
global_ticker_list.insert(538,"UPSURGE.BO")
global_ticker_list.insert(539,"VIRATCRA.BO")
global_ticker_list.insert(540,"DPL.BO")
global_ticker_list.insert(541,"RAMINFO.BO")
global_ticker_list.insert(542,"LAL.BO")
global_ticker_list.insert(543,"GLOBALCA.BO")
global_ticker_list.insert(544,"ARNOLD.BO")
global_ticker_list.insert(545,"RDBRIL.BO")
global_ticker_list.insert(546,"AMRAPLIN.BO")
global_ticker_list.insert(547,"GODAVARI.BO")
global_ticker_list.insert(548,"CASPIAN.BO")
global_ticker_list.insert(549,"TECHNOPACK.BO")
global_ticker_list.insert(550,"MODULEX.BO")
global_ticker_list.insert(551,"MAKERSL.BO")
global_ticker_list.insert(552,"MODAIRY.BO")
global_ticker_list.insert(553,"WHBRADY.BO")
global_ticker_list.insert(554,"DLTNCBL.BO")
global_ticker_list.insert(555,"SUMEDHA.BO")
global_ticker_list.insert(556,"CARGOSOL.BO")
global_ticker_list.insert(557,"SHILGRAVQ.BO")
global_ticker_list.insert(558,"TIRUSTA.BO")
global_ticker_list.insert(559,"CNOVAPETRO.BO")
global_ticker_list.insert(560,"KELENRG.BO")
global_ticker_list.insert(561,"CHENFERRO.BO")
global_ticker_list.insert(562,"LOYAL.BO")
global_ticker_list.insert(563,"CENLUB.BO")
global_ticker_list.insert(564,"LACTOSE.BO")
global_ticker_list.insert(565,"NATFIT.BO")
global_ticker_list.insert(566,"JAYSYN.BO")
global_ticker_list.insert(567,"POLYSPIN.BO")
global_ticker_list.insert(568,"GGPL.BO")
global_ticker_list.insert(569,"SHETR.BO")
global_ticker_list.insert(570,"MORGAN.BO")
global_ticker_list.insert(571,"AEL.BO")
global_ticker_list.insert(572,"ECOBOAR.BO")
global_ticker_list.insert(573,"ITL.BO")
global_ticker_list.insert(574,"KESAR.BO")
global_ticker_list.insert(575,"SUDTIND-B.BO")
global_ticker_list.insert(576,"PACE.BO")
global_ticker_list.insert(577,"SARTHAKIND.BO")
global_ticker_list.insert(578,"MRCAGRO.BO")
global_ticker_list.insert(579,"GUJHOTE.BO")
global_ticker_list.insert(580,"UNIVSTAR.BO")
global_ticker_list.insert(581,"RAINBOWF.BO")
global_ticker_list.insert(582,"RITESHIN.BO")
global_ticker_list.insert(583,"LLFICL.BO")
global_ticker_list.insert(584,"EIKO.BO")
global_ticker_list.insert(585,"SURYAAMBA.BO")
global_ticker_list.insert(586,"KALLAM.BO")
global_ticker_list.insert(587,"RAWEDGE.BO")
global_ticker_list.insert(588,"WAA.BO")
global_ticker_list.insert(589,"TEXELIN.BO")
global_ticker_list.insert(590,"SANDUPHQ.BO")
global_ticker_list.insert(591,"SWARNSAR.BO")
global_ticker_list.insert(592,"MEDICAPQ.BO")
global_ticker_list.insert(593,"TIGLOB.BO")
global_ticker_list.insert(594,"SHALIWIR.BO")
global_ticker_list.insert(595,"CHANDRAP.BO")
global_ticker_list.insert(596,"POLYLINK.BO")
global_ticker_list.insert(597,"ASHNOOR.BO")
global_ticker_list.insert(598,"PRERINFRA.BO")
global_ticker_list.insert(599,"INOVSYNTH.BO")
global_ticker_list.insert(600,"DHINDIA.BO")
global_ticker_list.insert(601,"SAMINDUS.BO")
global_ticker_list.insert(602,"DANUBE.BO")
global_ticker_list.insert(603,"PIONRINV.BO")
global_ticker_list.insert(604,"GLHRL.BO")
global_ticker_list.insert(605,"BCCL.BO")
global_ticker_list.insert(606,"ACME.BO")
global_ticker_list.insert(607,"HBPOR.BO")
global_ticker_list.insert(608,"TITANSEC.BO")
global_ticker_list.insert(609,"HBESD.BO")
global_ticker_list.insert(610,"QUEST.BO")





print("Found {} tickers in global_ticker_list".format(len(global_ticker_list)))

global_df = pd.DataFrame()
global_df["Symbol"] = global_ticker_list
global_df.to_csv(SYMBOLS_CSV, index=False)
print("Ticker download operation finished successfully!")

"""
