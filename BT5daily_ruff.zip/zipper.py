#!/usr/bin/env python3
"""test_stack.py
Quick functional checks for: numpy, pandas, numexpr, bottleneck, numba.

Usage:
    python test_stack.py
"""

import os
import shutil
import sys
import time
import traceback
import zipfile

# post_telegram_file('/home/rizpython236/BT5/BT5dailyx.zip')
from cleanup import cleanup_files, remove_ticker_data_csv_files
from telegram_bot import post_telegram_file


def safe_import(name):
    try:
        mod = __import__(name)
        return mod, None
    except Exception as e:
        print(traceback.format_exc())
        return None, e


def print_header(title):
    print("\n" + "=" * 8 + f" {title} " + "=" * 8)


def main():
    results = {}

    # 1) numpy
    print_header("NUMPY")
    np, err = safe_import("numpy")
    if np is None:
        print("numpy import FAILED:", err)
        results["numpy"] = False
    else:
        print("numpy version:", np.__version__)
        a = np.arange(10_000_000, dtype=np.float64)
        t0 = time.perf_counter()
        s = a.sum()
        t1 = time.perf_counter()
        print(f"sum of 10M floats = {s:.2e} (took {t1-t0:.4f}s)")
        results["numpy"] = True

    # 2) pandas (and pd.eval using numexpr later)
    print_header("PANDAS")
    pd, err = safe_import("pandas")
    if pd is None:
        print("pandas import FAILED:", err)
        results["pandas"] = False
    else:
        print("pandas version:", pd.__version__)
        # small DataFrame operation
        import numpy as _np
        df = pd.DataFrame({
            "a": _np.random.randn(1_000_000),
            "b": _np.random.randn(1_000_000),
        })
        t0 = time.perf_counter()
        # vectorized add
        df["c"] = df["a"] + df["b"] * 2
        t1 = time.perf_counter()
        print(
            f"created DataFrame and computed 'c' for 1M rows (took {t1-t0:.4f}s)")
        results["pandas"] = True

    # 3) numexpr
    print_header("NUMEXPR")
    ne, err = safe_import("numexpr")
    if ne is None:
        print("numexpr import FAILED:", err)
        results["numexpr"] = False
    else:
        print("numexpr version:", ne.__version__)
        import numpy as _np
        a = _np.random.randn(5_000_000)
        b = _np.random.randn(5_000_000)
        expr = "a + 2*b - (a*b) / (a + 1.0)"
        # using evaluate
        t0 = time.perf_counter()
        out_ne = ne.evaluate(expr)
        t1 = time.perf_counter()
        print(f"numexpr.evaluate on 5M-length arrays (took {t1-t0:.4f}s)")
        # sanity check vs numpy for a tiny slice
        t0 = time.perf_counter()
        out_np = a[:1000] + 2 * b[:1000] - \
            (a[:1000] * b[:1000]) / (a[:1000] + 1.0)
        t1 = time.perf_counter()
        # compare tiny sample
        same = _np.allclose(out_ne[:1000], out_np, atol=1e-12, equal_nan=True)
        print("sample comparison with numpy:", "OK" if same else "MISMATCH")
        results["numexpr"] = same

    # 4) bottleneck
    print_header("BOTTLENECK")
    bn, err = safe_import("bottleneck")
    if bn is None:
        print("bottleneck import FAILED:", err)
        results["bottleneck"] = False
    else:
        print("bottleneck version:", bn.__version__)
        import numpy as _np
        x = _np.random.randn(3_000_000)
        # inject some NaNs
        x[::100] = _np.nan
        t0 = time.perf_counter()
        m = bn.nanmean(x)   # fast nan-aware mean
        t1 = time.perf_counter()
        print(f"bottleneck.nanmean on 3M array = {m:.6f} (took {t1-t0:.4f}s)")
        # fallback check vs numpy nanmean (within tolerance)
        np_m = _np.nanmean(x)
        ok = _np.isfinite(m) and abs(m - np_m) < 1e-12
        print("compare with numpy.nanmean:",
              "OK" if ok else f"DIFF (numpy={np_m:.6f})")
        results["bottleneck"] = ok

    # 5) numba
    print_header("NUMBA")
    nb, err = safe_import("numba")
    if nb is None:
        print("numba import FAILED:", err)
        results["numba"] = False
    else:
        print("numba version:", nb.__version__)
        import numpy as _np

        # A small example function to sum using a simple loop.
        # We'll JIT compile it with numba.njit and run it twice to see compile vs run time.
        @nb.njit  # nopython mode
        def loop_sum(arr):
            s = 0.0
            for i in range(arr.shape[0]):
                s += arr[i]
            return s

        arr = _np.random.randn(2_000_000).astype(_np.float64)
        # first call — includes compilation overhead
        t0 = time.perf_counter()
        s1 = loop_sum(arr)
        t1 = time.perf_counter()
        # second call — should be faster (no compile)
        t2 = time.perf_counter()
        s2 = loop_sum(arr)
        t3 = time.perf_counter()
        print(
            f"numba loop_sum first call (compile+run): {t1-t0:.4f}s, second call (run): {t3-t2:.4f}s")
        # compare to numpy sum
        t0 = time.perf_counter()
        s_np = arr.sum()
        t1 = time.perf_counter()
        print(f"numpy sum (for same arr): {t1-t0:.4f}s")
        # sanity
        close = abs(s1 - s_np) / (abs(s_np) + 1e-12) < 1e-10
        print("numba result matches numpy:", "OK" if close else "MISMATCH")
        results["numba"] = close

    # 6) pandas eval with numexpr engine (optional check)
    print_header("PANDAS.eval using numexpr engine (optional)")
    if pd is None:
        print("skipping pandas.eval test because pandas import failed earlier.")
        results["pandas_eval"] = False
    else:
        try:
            import numpy as _np
            df_small = pd.DataFrame({
                "a": _np.arange(100000, dtype=float),
                "b": _np.arange(100000, dtype=float) * 0.5,
            })
            t0 = time.perf_counter()
            # prefer numexpr engine if available
            try:
                res = pd.eval(
                    "a + 2*b", local_dict={"a": df_small["a"], "b": df_small["b"]}, engine="numexpr")
                used_engine = "numexpr"
            except Exception:
                # fall back to python engine if numexpr not available
                res = pd.eval(
                    "a + 2*b", local_dict={"a": df_small["a"], "b": df_small["b"]}, engine="python")
                used_engine = "python"
            t1 = time.perf_counter()
            print(
                f"pd.eval used engine='{used_engine}' and completed in {t1-t0:.4f}s")
            results["pandas_eval"] = True
        except Exception as e:
            print("pandas.eval test failed:", e)
            print(traceback.format_exc())
            results["pandas_eval"] = False

    # Summary
    print_header("SUMMARY")
    for k, v in results.items():
        status = "OK" if v else "FAILED"
        print(f"{k:12s} : {status}")

    # overall exit code
    ok_overall = all(bool(v) for v in results.values())
    print("\nOverall result:", "ALL OK" if ok_overall else "SOME TESTS FAILED")
    if not ok_overall:
        print("If a test failed, inspect the printed error for the library and consider reinstalling, e.g.:")
        print("    pip install --upgrade numpy pandas numexpr bottleneck numba")
    # exit code (useful in CI)
    sys.exit(0 if ok_overall else 2)


# if __name__ == "__main__":
#    main()

# main()

# hhhh


file_path = "/home/rizpython236/BT5/screener-outputs/Tickerdata.zip"
if os.path.exists(file_path):
    os.remove(file_path)


# _____________________________________
"""
import logging

# Create logger
logger = logging.getLogger(__name__)

# Set logger to capture all levels from DEBUG up
logger.setLevel(logging.DEBUG)

# Create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# Create console handler and set level to DEBUG
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)  # Handler level filters what actually gets displayed
ch.setFormatter(formatter)

fh = logging.FileHandler('trade_compiler_Logging.log')
fh.setLevel(logging.DEBUG)
fh.setFormatter(formatter)
logger.addHandler(fh)

# Add handler to the logger
logger.addHandler(ch)

# Example usage
logger.debug('This is a debug message')
logger.info('This is an info message')
logger.warning('This is a warning message')
logger.error('This is an error message')
logger.critical('This is a critical message')
"""
# _________________________________________________________

remove_ticker_data_csv_files()
cleanup_files()


def zip_folderxx(folder_path, output_filename, output_folder="/home/rizpython236/BT5/"):
    """Zips a folder and saves the zip file in the specified output folder.
    Only files from specific subfolders (screener-outputs/, ticker-csv-files/,
    ticker-csv-files-mhtly/, ticker_15yr/) are included in the zip.

    Args:
        folder_path (str): Path to the folder to be zipped.
        output_filename (str): Name of the output zip file.
        output_folder (str, optional): Path to the folder where the zip file
                                       will be saved. Defaults to "/home/rizpython236/BT5/".

    """
    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    # Construct the full output filepath
    output_filepath = os.path.join(output_folder, output_filename + ".zip")

    # List of subfolders to include in the zip
    subfolders_to_include = {"screener-outputs", "ticker-csv-files", "ticker-csv-files-mhtly", "ticker-csv-files-weekly",
                             "ticker_15yr", "ticker_daily1yr", "trade-logs", "refactoredpyB", "backtraderx", "optimizedcode"}

    # file_pathzip = '/home/rizpython236/BT5/BT52.zip'

    # Check if the file exists
    if os.path.exists(output_folder):
        os.remove(output_filepath)  # Remove the file
        1 + 1
        print(f"File {output_filepath} has been removed.")
    else:
        print(f"File {output_filepath} does not exist.")

    # ZIP_LZMA → highest compression, but can be slow on very large files.

    # ZIP_BZIP2 → good compression + faster than LZMA.

    # ZIP_DEFLATED → default, fastest but bigger files.

    # Create the zip file
    # with zipfile.ZipFile(output_filepath, "w", zipfile.ZIP_DEFLATED) as zip_file:
    with zipfile.ZipFile(output_filepath, "w", compression=zipfile.ZIP_BZIP2) as zip_file:
        for root, _, files in os.walk(folder_path):
            # Check if the current folder is one of the subfolders to include
            if os.path.basename(root) in subfolders_to_include:
                for file in files:
                    file_path = os.path.join(root, file)
                    # Add the file to the zip, preserving the relative path
                    zip_file.write(file_path, os.path.relpath(
                        file_path, folder_path))

    print(f"Folder zipped successfully! Zip file saved at: {output_filepath}")


def zip_folder(folder_path, output_filename, output_folder="/home/rizpython236/BT5/"):
    """Zips a folder and saves the zip file in the specified output folder.
    Includes:
      - Files in the BT5 folder itself
      - Files from specific subfolders (screener-outputs/, ticker-csv-files/,
        ticker-csv-files-mhtly/, ticker-csv-files-weekly/, ticker_15yr/,
        ticker_daily1yr/, trade-logs/)
      - Empty subfolders are also preserved in the zip.

    Args:
        folder_path (str): Path to the folder to be zipped.
        output_filename (str): Name of the output zip file.
        output_folder (str, optional): Path to the folder where the zip file
                                       will be saved. Defaults to "/home/rizpython236/BT5/".

    """
    os.makedirs(output_folder, exist_ok=True)
    output_filepath = os.path.join(output_folder, output_filename + ".zip")

    subfolders_to_include = {
        "screener-outputs",
        "refactoredpyB",
        "backtraderx",
        "optimizedcode",
        "ticker-csv-files",
        "ticker-csv-files-mhtly",
        "ticker-csv-files-weekly",
        "ticker_15yr",
        "ticker_daily1yr",
        "trade-logs",
    }

    # Remove old zip if exists
    if os.path.exists(output_filepath):
        os.remove(output_filepath)
        print(f"Old zip {output_filepath} removed.")

    # ZIP_LZMA → highest compression, but can be slow on very large files.

    # ZIP_BZIP2 → good compression + faster than LZMA.

    # ZIP_DEFLATED → default, fastest but bigger files.

    with zipfile.ZipFile(output_filepath, "w", zipfile.ZIP_BZIP2) as zip_file:

        # 1. Include files directly in BT5 folder
        for file in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file)
            if os.path.isfile(file_path) and not file.endswith(".zip"):
                zip_file.write(file_path, os.path.relpath(
                    file_path, folder_path))

        # 2. Include files + empty subfolders
        for root, dirs, files in os.walk(folder_path):
            folder_name = os.path.basename(root)

            if folder_name in subfolders_to_include:
                # Add empty folder entry if no files exist
                if not files and not dirs:
                    arcname = os.path.relpath(root, folder_path) + "/"
                    # create empty folder in zip
                    zip_file.writestr(arcname, "")

                # Add files if they exist
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, folder_path)
                    zip_file.write(file_path, arcname)

    print(f"✅ Folder zipped successfully! Saved at: {output_filepath}")


# Example usage
folder_path = "/home/rizpython236/BT5/"  # Replace with your folder path
output_filename = "BT5daily_ruff"  # Name for the zip file

zip_folder(folder_path, output_filename,
           output_folder="/home/rizpython236/BT5/")

time.sleep(5)

post_telegram_file("/home/rizpython236/BT5/BT5daily_ruff.zip")
# os.remove('/home/rizpython236/BT5/BT5.zip')

time.sleep(20)
# ___________________________________________________


def delete_files_in_folder(folder_path):
    """Deletes all files in the specified folder.

    Args:
        folder_path (str): Path to the folder whose files will be deleted.

    """
    # Check if the folder exists
    if not os.path.exists(folder_path):
        print(f"The folder {folder_path} does not exist.")
        return

    # Iterate over all files in the folder and delete them
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            # Check if it's a file (not a subfolder)
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)  # Delete the file or symbolic link
                print(f"Deleted file: {file_path}")
            elif os.path.isdir(file_path):
                # If it's a subfolder, delete it recursively
                shutil.rmtree(file_path)
                print(f"Deleted folder: {file_path}")
        except Exception as e:
            print(f"Failed to delete {file_path}. Reason: {e}")


# Example usage
cache_folder = "/home/rizpython236/BT5/__pycache__"
delete_files_in_folder(cache_folder)

cache_folder = "/home/rizpython236/.local/share/virtualenv/wheel/house"
delete_files_in_folder(cache_folder)


# ___________________________________________________


def extract_zip_contents(zip_path, output_dir, target_in_zip):
    """Extracts specific contents from a ZIP file without creating the root output directory.

    Args:
        zip_path (str): Path to the ZIP file
        output_dir (str): Target extraction directory (won't be created if missing)
        target_in_zip (str): Path prefix inside ZIP to extract (with trailing slash)

    Returns:
        int: Number of files extracted

    """
    extracted_count = 0

    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        for file_info in zip_ref.infolist():
            if file_info.filename.startswith(target_in_zip) and not file_info.is_dir():
                relative_path = file_info.filename[len(target_in_zip):]
                if not relative_path:
                    continue

                dest_path = os.path.join(output_dir, relative_path)

                # Create parent directories if needed
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)

                # Extract file
                with zip_ref.open(file_info) as source, open(dest_path, "wb") as target:
                    target.write(source.read())

                extracted_count += 1
                print(f"Extracted: {relative_path}")
                print(f"  → {dest_path}")

    print(f"\nExtraction complete. Files extracted: {extracted_count}")
    # return extracted_count


# Configuration
zip_path = "/home/rizpython236/BT5/BT5abc.zip"
output_dir = "/home/rizpython236/BT5/screener-outputs"
target_in_zip = "BT5/screener-outputs/"

# Execute extraction
print(f"Extracting contents from '{target_in_zip}' in {zip_path}")
print(f"Destination: {output_dir}\n")

# extracted_count = extract_zip_contents(zip_path, output_dir, target_in_zip)
