import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def create_wheel_for_package(package_spec, output_dir=None):
    """
    Create a wheel file for a Python package.
    
    Args:
        package_spec (str): Package name (can include version, e.g., 'package==1.0')
        output_dir (str, optional): Directory to save the wheel file. 
                                  If None, uses current directory.
    Returns:
        Path: Path to the created wheel file or None if failed
    """
    # Set default output directory if not specified
    if output_dir is None:
        output_dir = os.getcwd()
    else:
        os.makedirs(output_dir, exist_ok=True)
    
    # Create a temporary directory for the download
    with tempfile.TemporaryDirectory() as temp_dir:
        try:
            # Download the package as wheel to temp directory
            download_cmd = [
                sys.executable, "-m", "pip", "download",
                "--only-binary=:all:",
                "--no-deps",
                "--dest", temp_dir,
                package_spec
            ]
            subprocess.check_call(download_cmd)
            
            # Find the downloaded wheel file
            wheel_files = list(Path(temp_dir).glob("*.whl"))
            if not wheel_files:
                print(f"No wheel file was downloaded for package '{package_spec}'")
                return None
                
            wheel_file = wheel_files[0]
            
            # Move the wheel file to output directory
            destination = Path(output_dir) / wheel_file.name
            wheel_file.rename(destination)
            
            print(f"Successfully created wheel file: {destination}")
            return destination
            
        except subprocess.CalledProcessError as e:
            print(f"Failed to create wheel for package '{package_spec}': {e}")
            return None
        except Exception as e:
            print(f"An error occurred: {e}")
            return None

if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(description="Create a wheel file for a Python package")
    parser.add_argument(
        "package", 
        help="Package name and optional version (e.g., 'ta-lib' or 'ta-lib==0.6.4')"
    )
    parser.add_argument(
        "--output-dir", 
        help="Directory to save the wheel file (default: current directory)",
        default=os.getcwd()
    )
    '''
    parser = argparse.ArgumentParser(description="Create a wheel file for a Python package")
    parser.add_argument(
        "package", 
        help="ta-lib==0.6.4"
    )
    parser.add_argument(
        "--output-dir", 
        help="/home/rizpython236/BT5/",
        default=os.getcwd()
    )    
    '''
    
    args = parser.parse_args()
    
    result = create_wheel_for_package(args.package, args.output_dir)
    if not result:
        sys.exit(1)
        
        
        
        
'''
sudo apt-get install build-essential
sudo apt-get install python3-dev
python /home/rizpython236/BT5/create_wheel.py "ta-lib==0.6.4" --output-dir "/home/rizpython236/BT5/"
http://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
'''

