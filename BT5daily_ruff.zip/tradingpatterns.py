import numpy as np
import pandas as pd


#$ pip install tradingpattern

def detect_head_shoulder(df, window=3):
# Define the rolling window
    roll_window = window
    # Create a rolling window for High and Low
    df['high_roll_max'] = df['High'].rolling(window=roll_window).max()
    df['low_roll_min'] = df['Low'].rolling(window=roll_window).min()
    # Create a boolean mask for Head and Shoulder pattern
    mask_head_shoulder = ((df['high_roll_max'] > df['High'].shift(1)) & (df['high_roll_max'] > df['High'].shift(-1)) & (df['High'] < df['High'].shift(1)) & (df['High'] < df['High'].shift(-1)))
    # Create a boolean mask for Inverse Head and Shoulder pattern
    mask_inv_head_shoulder = ((df['low_roll_min'] < df['Low'].shift(1)) & (df['low_roll_min'] < df['Low'].shift(-1)) & (df['Low'] > df['Low'].shift(1)) & (df['Low'] > df['Low'].shift(-1)))
    # Create a new column for Head and Shoulder and its inverse pattern and populate it using the boolean masks
    df['head_shoulder_pattern'] = np.nan
    df.loc[mask_head_shoulder, 'head_shoulder_pattern'] = 'Head and Shoulder'
    df.loc[mask_inv_head_shoulder, 'head_shoulder_pattern'] = 'Inverse Head and Shoulder'
    return df
    # return not df['head_shoulder_pattern'].isna().any().item()

def detect_multiple_tops_bottoms(df, window=3):
# Define the rolling window
    roll_window = window
    # Create a rolling window for High and Low
    df['high_roll_max'] = df['High'].rolling(window=roll_window).max()
    df['low_roll_min'] = df['Low'].rolling(window=roll_window).min()
    df['close_roll_max'] = df['Close'].rolling(window=roll_window).max()
    df['close_roll_min'] = df['Close'].rolling(window=roll_window).min()
    # Create a boolean mask for multiple top pattern
    mask_top = (df['high_roll_max'] >= df['High'].shift(1)) & (df['close_roll_max'] < df['Close'].shift(1))
    # Create a boolean mask for multiple bottom pattern
    mask_bottom = (df['low_roll_min'] <= df['Low'].shift(1)) & (df['close_roll_min'] > df['Close'].shift(1))
    # Create a new column for multiple top bottom pattern and populate it using the boolean masks
    df['multiple_top_bottom_pattern'] = np.nan
    df.loc[mask_top, 'multiple_top_bottom_pattern'] = 'Multiple Top'
    df.loc[mask_bottom, 'multiple_top_bottom_pattern'] = 'Multiple Bottom'
    return df

def calculate_support_resistance(df, window=3):
# Define the rolling window
    roll_window = window
    # Set the number of standard deviation
    std_dev = 2
    # Create a rolling window for High and Low
    df['high_roll_max'] = df['High'].rolling(window=roll_window).max()
    df['low_roll_min'] = df['Low'].rolling(window=roll_window).min()
    # Calculate the mean and standard deviation for High and Low
    mean_high = df['High'].rolling(window=roll_window).mean()
    std_high = df['High'].rolling(window=roll_window).std()
    mean_low = df['Low'].rolling(window=roll_window).mean()
    std_low = df['Low'].rolling(window=roll_window).std()
    # Create a new column for support and resistance
    df['support'] = mean_low - std_dev * std_low
    df['resistance'] = mean_high + std_dev * std_high
    return df

def detect_triangle_pattern(df, window=3):
    # Define the rolling window
    roll_window = window
    # Create a rolling window for High and Low
    df['high_roll_max'] = df['High'].rolling(window=roll_window).max()
    df['low_roll_min'] = df['Low'].rolling(window=roll_window).min()
    # Create a boolean mask for ascending triangle pattern
    mask_asc = (df['high_roll_max'] >= df['High'].shift(1)) & (df['low_roll_min'] <= df['Low'].shift(1)) & (df['Close'] > df['Close'].shift(1))
    # Create a boolean mask for descending triangle pattern
    mask_desc = (df['high_roll_max'] <= df['High'].shift(1)) & (df['low_roll_min'] >= df['Low'].shift(1)) & (df['Close'] < df['Close'].shift(1))
    # Create a new column for triangle pattern and populate it using the boolean masks
    df['triangle_pattern'] = np.nan
    df.loc[mask_asc, 'triangle_pattern'] = 'Ascending Triangle'
    df.loc[mask_desc, 'triangle_pattern'] = 'Descending Triangle'
    return df

def detect_wedge(df, window=3):
    # Define the rolling window
    roll_window = window
    # Create a rolling window for High and Low
    df['high_roll_max'] = df['High'].rolling(window=roll_window).max()
    df['low_roll_min'] = df['Low'].rolling(window=roll_window).min()
    df['trend_high'] = df['High'].rolling(window=roll_window).apply(lambda x: 1 if (x[-1]-x[0])>0 else -1 if (x[-1]-x[0])<0 else 0)
    df['trend_low'] = df['Low'].rolling(window=roll_window).apply(lambda x: 1 if (x[-1]-x[0])>0 else -1 if (x[-1]-x[0])<0 else 0)
    # Create a boolean mask for Wedge Up pattern
    mask_wedge_up = (df['high_roll_max'] >= df['High'].shift(1)) & (df['low_roll_min'] <= df['Low'].shift(1)) & (df['trend_high'] == 1) & (df['trend_low'] == 1)
    # Create a boolean mask for Wedge Down pattern
        # Create a boolean mask for Wedge Down pattern
    mask_wedge_down = (df['high_roll_max'] <= df['High'].shift(1)) & (df['low_roll_min'] >= df['Low'].shift(1)) & (df['trend_high'] == -1) & (df['trend_low'] == -1)
    # Create a new column for Wedge Up and Wedge Down pattern and populate it using the boolean masks
    df['wedge_pattern'] = np.nan
    df.loc[mask_wedge_up, 'wedge_pattern'] = 'Wedge Up'
    df.loc[mask_wedge_down, 'wedge_pattern'] = 'Wedge Down'
    return df

def detect_channel(df, window=3):
    # Define the rolling window
    roll_window = window
    # Define a factor to check for the range of channel
    channel_range = 0.1
    # Create a rolling window for High and Low
    df['high_roll_max'] = df['High'].rolling(window=roll_window).max()
    df['low_roll_min'] = df['Low'].rolling(window=roll_window).min()
    df['trend_high'] = df['High'].rolling(window=roll_window).apply(lambda x: 1 if (x[-1]-x[0])>0 else -1 if (x[-1]-x[0])<0 else 0)
    df['trend_low'] = df['Low'].rolling(window=roll_window).apply(lambda x: 1 if (x[-1]-x[0])>0 else -1 if (x[-1]-x[0])<0 else 0)
    # Create a boolean mask for Channel Up pattern
    mask_channel_up = (df['high_roll_max'] >= df['High'].shift(1)) & (df['low_roll_min'] <= df['Low'].shift(1)) & (df['high_roll_max'] - df['low_roll_min'] <= channel_range * (df['high_roll_max'] + df['low_roll_min'])/2) & (df['trend_high'] == 1) & (df['trend_low'] == 1)
    # Create a boolean mask for Channel Down pattern
    mask_channel_down = (df['high_roll_max'] <= df['High'].shift(1)) & (df['low_roll_min'] >= df['Low'].shift(1)) & (df['high_roll_max'] - df['low_roll_min'] <= channel_range * (df['high_roll_max'] + df['low_roll_min'])/2) & (df['trend_high'] == -1) & (df['trend_low'] == -1)
    # Create a new column for Channel Up and Channel Down pattern and populate it using the boolean masks
    df['channel_pattern'] = np.nan
    df.loc[mask_channel_up, 'channel_pattern'] = 'Channel Up'
    df.loc[mask_channel_down, 'channel_pattern'] = 'Channel Down'
    return df

def detect_double_top_bottom(df, window=3, threshold=0.05):
    # Define the rolling window
    roll_window = window
    # Define a threshold to check for the range of pattern
    range_threshold = threshold

    # Create a rolling window for High and Low
    df['high_roll_max'] = df['High'].rolling(window=roll_window).max()
    df['low_roll_min'] = df['Low'].rolling(window=roll_window).min()

    # Create a boolean mask for Double Top pattern
    mask_double_top = (df['high_roll_max'] >= df['High'].shift(1)) & (df['high_roll_max'] >= df['High'].shift(-1)) & (df['High'] < df['High'].shift(1)) & (df['High'] < df['High'].shift(-1)) & ((df['High'].shift(1) - df['Low'].shift(1)) <= range_threshold * (df['High'].shift(1) + df['Low'].shift(1))/2) & ((df['High'].shift(-1) - df['Low'].shift(-1)) <= range_threshold * (df['High'].shift(-1) + df['Low'].shift(-1))/2)
    # Create a boolean mask for Double Bottom pattern
    mask_double_bottom = (df['low_roll_min'] <= df['Low'].shift(1)) & (df['low_roll_min'] <= df['Low'].shift(-1)) & (df['Low'] > df['Low'].shift(1)) & (df['Low'] > df['Low'].shift(-1)) & ((df['High'].shift(1) - df['Low'].shift(1)) <= range_threshold * (df['High'].shift(1) + df['Low'].shift(1))/2) & ((df['High'].shift(-1) - df['Low'].shift(-1)) <= range_threshold * (df['High'].shift(-1) + df['Low'].shift(-1))/2)

    # Create a new column for Double Top and Double Bottom pattern and populate it using the boolean masks
    df['double_pattern'] = np.nan
    df.loc[mask_double_top, 'double_pattern'] = 'Double Top'
    df.loc[mask_double_bottom, 'double_pattern'] = 'Double Bottom'

    return df

def detect_trendline(df, window=2):
    # Define the rolling window
    roll_window = window
    # Create new columns for the linear regression slope and y-intercept
    df['slope'] = np.nan
    df['intercept'] = np.nan

    for i in range(window, len(df)):
        x = np.array(range(i-window, i))
        y = df['Close'][i-window:i]
        A = np.vstack([x, np.ones(len(x))]).T
        m, c = np.linalg.lstsq(A, y, rcond=None)[0]
        df.at[df.index[i], 'slope'] = m
        df.at[df.index[i], 'intercept'] = c

    # Create a boolean mask for trendline support
    mask_support = df['slope'] > 0

    # Create a boolean mask for trendline resistance
    mask_resistance = df['slope'] < 0

    # Create new columns for trendline support and resistance
    df['support'] = np.nan
    df['resistance'] = np.nan

    # Populate the new columns using the boolean masks
    df.loc[mask_support, 'support'] = df['Close'] * df['slope'] + df['intercept']
    df.loc[mask_resistance, 'resistance'] = df['Close'] * df['slope'] + df['intercept']

    return df

def find_pivots(df):
    # Calculate differences between consecutive highs and lows
    high_diffs = df['high'].diff()
    low_diffs = df['low'].diff()

    # Find higher high
    higher_high_mask = (high_diffs > 0) & (high_diffs.shift(-1) < 0)

    # Find lower low
    lower_low_mask = (low_diffs < 0) & (low_diffs.shift(-1) > 0)

    # Find lower high
    lower_high_mask = (high_diffs < 0) & (high_diffs.shift(-1) > 0)

    # Find higher low
    higher_low_mask = (low_diffs > 0) & (low_diffs.shift(-1) < 0)

    # Create signals column
    df['signal'] = ''
    df.loc[higher_high_mask, 'signal'] = 'HH'
    df.loc[lower_low_mask, 'signal'] = 'LL'
    df.loc[lower_high_mask, 'signal'] = 'LH'
    df.loc[higher_low_mask, 'signal'] = 'HL'

    return df



######################################################
#optimized

def detect_head_shoulder(df, window=3):
    roll_window = window

    # Rolling max/min (vectorized)
    high_roll_max = df['High'].rolling(window=roll_window, min_periods=1).max()
    low_roll_min = df['Low'].rolling(window=roll_window, min_periods=1).min()

    # Precompute shifted arrays (avoids recomputation)
    high_shift_fwd = df['High'].shift(-1)
    high_shift_back = df['High'].shift(1)
    low_shift_fwd = df['Low'].shift(-1)
    low_shift_back = df['Low'].shift(1)

    # Vectorized boolean masks
    mask_head_shoulder = (
        (high_roll_max > high_shift_back) &
        (high_roll_max > high_shift_fwd) &
        (df['High'] < high_shift_back) &
        (df['High'] < high_shift_fwd)
    )

    mask_inv_head_shoulder = (
        (low_roll_min < low_shift_back) &
        (low_roll_min < low_shift_fwd) &
        (df['Low'] > low_shift_back) &
        (df['Low'] > low_shift_fwd)
    )

    # Assign values with np.select (faster than .loc row by row)
    df['head_shoulder_pattern'] = np.select(
        [mask_head_shoulder, mask_inv_head_shoulder],
        ['Head and Shoulder', 'Inverse Head and Shoulder'],
        default=np.nan
    )

    return df


def detect_multiple_tops_bottoms(df, window=3):
    roll_window = window

    # Rolling max/min (vectorized)
    high_roll_max = df['High'].rolling(window=roll_window, min_periods=1).max()
    low_roll_min = df['Low'].rolling(window=roll_window, min_periods=1).min()
    close_roll_max = df['Close'].rolling(window=roll_window, min_periods=1).max()
    close_roll_min = df['Close'].rolling(window=roll_window, min_periods=1).min()

    # Precompute shifted arrays (avoids recomputation)
    high_shift_back = df['High'].shift(1)
    low_shift_back = df['Low'].shift(1)
    close_shift_back = df['Close'].shift(1)

    # Vectorized boolean masks
    mask_top = (high_roll_max >= high_shift_back) & (close_roll_max < close_shift_back)
    mask_bottom = (low_roll_min <= low_shift_back) & (close_roll_min > close_shift_back)

    # Assign values with np.select (faster than multiple loc assignments)
    df['multiple_top_bottom_pattern'] = np.select(
        [mask_top, mask_bottom],
        ['Multiple Top', 'Multiple Bottom'],
        default=np.nan
    )

    return df

def calculate_support_resistance(df, window=3, std_dev=2):
    roll_window = window

    # Rolling calculations for High
    high_roll = df['High'].rolling(window=roll_window, min_periods=1)
    mean_high = high_roll.mean()
    std_high = high_roll.std(ddof=0)  # ddof=0 is slightly faster and consistent

    # Rolling calculations for Low
    low_roll = df['Low'].rolling(window=roll_window, min_periods=1)
    mean_low = low_roll.mean()
    std_low = low_roll.std(ddof=0)

    # Support and Resistance levels (vectorized math)
    df['support'] = mean_low - std_dev * std_low
    df['resistance'] = mean_high + std_dev * std_high

    return df

def detect_triangle_pattern(df, window=3):
    roll_window = window

    # Rolling max/min (computed once)
    high_roll_max = df['High'].rolling(window=roll_window, min_periods=1).max()
    low_roll_min  = df['Low'].rolling(window=roll_window, min_periods=1).min()

    # Precompute shifted arrays (avoid recomputation)
    high_shift_back  = df['High'].shift(1)
    low_shift_back   = df['Low'].shift(1)
    close_shift_back = df['Close'].shift(1)

    # Vectorized boolean masks
    mask_asc = (
        (high_roll_max >= high_shift_back) &
        (low_roll_min  <= low_shift_back) &
        (df['Close'] > close_shift_back)
    )

    mask_desc = (
        (high_roll_max <= high_shift_back) &
        (low_roll_min  >= low_shift_back) &
        (df['Close'] < close_shift_back)
    )

    # Assign patterns using np.select (vectorized)
    df['triangle_pattern'] = np.select(
        [mask_asc, mask_desc],
        ['Ascending Triangle', 'Descending Triangle'],
        default=np.nan
    )

    return df



def detect_wedge(df, window=3):
    roll_window = window

    # Rolling max/min
    high_roll_max = df['High'].rolling(window=roll_window, min_periods=1).max()
    low_roll_min  = df['Low'].rolling(window=roll_window, min_periods=1).min()

    # Compute trend: sign of (last - first) in window
    high_first = df['High'].shift(window-1)   # first element of window
    high_last  = df['High']                   # last element of window
    trend_high = np.sign(high_last - high_first)  # -1, 0, +1

    low_first = df['Low'].shift(window-1)
    low_last  = df['Low']
    trend_low = np.sign(low_last - low_first)

    # Precompute shifted values (avoid recomputation)
    high_shift_back = df['High'].shift(1)
    low_shift_back  = df['Low'].shift(1)

    # Boolean masks
    mask_wedge_up = (
        (high_roll_max >= high_shift_back) &
        (low_roll_min  <= low_shift_back) &
        (trend_high == 1) &
        (trend_low == 1)
    )

    mask_wedge_down = (
        (high_roll_max <= high_shift_back) &
        (low_roll_min  >= low_shift_back) &
        (trend_high == -1) &
        (trend_low == -1)
    )

    # Assign patterns using np.select
    df['wedge_pattern'] = np.select(
        [mask_wedge_up, mask_wedge_down],
        ['Wedge Up', 'Wedge Down'],
        default=np.nan
    )

    return df



def detect_channel(df, window=3, channel_range=0.1):
    roll_window = window

    # Rolling max/min (vectorized)
    high_roll_max = df['High'].rolling(window=roll_window, min_periods=1).max()
    low_roll_min  = df['Low'].rolling(window=roll_window, min_periods=1).min()

    # Vectorized trend calculation: sign(last - first) in window
    high_first = df['High'].shift(window-1)
    high_last  = df['High']
    trend_high = np.sign(high_last - high_first)

    low_first = df['Low'].shift(window-1)
    low_last  = df['Low']
    trend_low = np.sign(low_last - low_first)

    # Precompute shifted values
    high_shift_back = df['High'].shift(1)
    low_shift_back  = df['Low'].shift(1)

    # Channel range condition
    channel_width = high_roll_max - low_roll_min
    channel_mid   = (high_roll_max + low_roll_min) / 2
    channel_cond  = channel_width <= channel_range * channel_mid

    # Boolean masks
    mask_channel_up = (
        (high_roll_max >= high_shift_back) &
        (low_roll_min  <= low_shift_back) &
        channel_cond &
        (trend_high == 1) &
        (trend_low == 1)
    )

    mask_channel_down = (
        (high_roll_max <= high_shift_back) &
        (low_roll_min  >= low_shift_back) &
        channel_cond &
        (trend_high == -1) &
        (trend_low == -1)
    )

    # Assign patterns vectorized
    df['channel_pattern'] = np.select(
        [mask_channel_up, mask_channel_down],
        ['Channel Up', 'Channel Down'],
        default=np.nan
    )

    return df



def detect_double_top_bottom(df, window=3, threshold=0.05):
    roll_window = window
    range_threshold = threshold

    # Rolling max/min
    high_roll_max = df['High'].rolling(window=roll_window, min_periods=1).max()
    low_roll_min  = df['Low'].rolling(window=roll_window, min_periods=1).min()

    # Precompute shifted values (once, reused)
    high_shift_fwd  = df['High'].shift(-1)
    high_shift_back = df['High'].shift(1)
    low_shift_fwd   = df['Low'].shift(-1)
    low_shift_back  = df['Low'].shift(1)

    # Precompute range condition for back/forward shifts
    range_back = (high_shift_back - low_shift_back) <= range_threshold * ((high_shift_back + low_shift_back) / 2)
    range_fwd  = (high_shift_fwd  - low_shift_fwd)  <= range_threshold * ((high_shift_fwd  + low_shift_fwd)  / 2)

    # Boolean masks
    mask_double_top = (
        (high_roll_max >= high_shift_back) &
        (high_roll_max >= high_shift_fwd) &
        (df['High'] < high_shift_back) &
        (df['High'] < high_shift_fwd) &
        range_back & range_fwd
    )

    mask_double_bottom = (
        (low_roll_min <= low_shift_back) &
        (low_roll_min <= low_shift_fwd) &
        (df['Low'] > low_shift_back) &
        (df['Low'] > low_shift_fwd) &
        range_back & range_fwd
    )

    # Assign patterns with np.select (vectorized)
    df['double_pattern'] = np.select(
        [mask_double_top, mask_double_bottom],
        ['Double Top', 'Double Bottom'],
        default=np.nan
    )

    return df




def detect_trendline(df, window=2):
    roll_window = window

    # Create x as a simple increasing integer index
    x = np.arange(len(df))

    # Rolling sums for regression formula
    sum_x  = pd.Series(x).rolling(window=roll_window, min_periods=window).sum().values
    sum_y  = df['Close'].rolling(window=roll_window, min_periods=window).sum().values
    sum_xy = pd.Series(x * df['Close'].values).rolling(window=roll_window, min_periods=window).sum().values
    sum_x2 = pd.Series(x**2).rolling(window=roll_window, min_periods=window).sum().values

    n = roll_window
    denominator = n * sum_x2 - sum_x**2

    # Vectorized slope and intercept
    slope = (n * sum_xy - sum_x * sum_y) / denominator
    intercept = (sum_y - slope * sum_x) / n

    # Assign back
    df['slope'] = slope
    df['intercept'] = intercept

    # Trendline masks
    mask_support = slope > 0
    mask_resistance = slope < 0

    # Trendline values (vectorized)
    df['support'] = np.where(mask_support, df['Close'] * slope + intercept, np.nan)
    df['resistance'] = np.where(mask_resistance, df['Close'] * slope + intercept, np.nan)

    return df



def find_pivots(df):
    # Calculate differences
    high_diffs = df['high'].diff()
    low_diffs  = df['low'].diff()

    # Boolean masks
    higher_high_mask = (high_diffs > 0) & (high_diffs.shift(-1) < 0)
    lower_low_mask   = (low_diffs < 0) & (low_diffs.shift(-1) > 0)
    lower_high_mask  = (high_diffs < 0) & (high_diffs.shift(-1) > 0)
    higher_low_mask  = (low_diffs > 0) & (low_diffs.shift(-1) < 0)

    # Vectorized assignment using np.select
    df['signal'] = np.select(
        [higher_high_mask, lower_low_mask, lower_high_mask, higher_low_mask],
        ['HH', 'LL', 'LH', 'HL'],
        default=''
    )

    return df

######################################################
#optimized

def detect_all_patterns(df, window=3, wedge_window=3, channel_window=3, double_threshold=0.05, regression_window=2, channel_range=0.1):
    df = df.copy()

    n = len(df)

    # --- Rolling max/min ---
    high_roll_max = df['High'].rolling(window=window, min_periods=1).max()
    low_roll_min  = df['Low'].rolling(window=window, min_periods=1).min()
    close_roll_max = df['Close'].rolling(window=window, min_periods=1).max()
    close_roll_min = df['Close'].rolling(window=window, min_periods=1).min()

    # --- Precompute shifts ---
    high_shift_fwd  = df['High'].shift(-1)
    high_shift_back = df['High'].shift(1)
    low_shift_fwd   = df['Low'].shift(-1)
    low_shift_back  = df['Low'].shift(1)
    close_shift_back = df['Close'].shift(1)
    close_shift_fwd  = df['Close'].shift(-1)

    # --- Head and Shoulder ---
    mask_hs = (high_roll_max > high_shift_back) & (high_roll_max > high_shift_fwd) & (df['High'] < high_shift_back) & (df['High'] < high_shift_fwd)
    mask_inv_hs = (low_roll_min < low_shift_back) & (low_roll_min < low_shift_fwd) & (df['Low'] > low_shift_back) & (df['Low'] > low_shift_fwd)
    df['head_shoulder_pattern'] = np.select([mask_hs, mask_inv_hs], ['Head and Shoulder', 'Inverse Head and Shoulder'], default=np.nan)

    # --- Multiple Tops/Bottoms ---
    mask_top = (high_roll_max >= high_shift_back) & (close_roll_max < close_shift_back)
    mask_bottom = (low_roll_min <= low_shift_back) & (close_roll_min > close_shift_back)
    df['multiple_top_bottom_pattern'] = np.select([mask_top, mask_bottom], ['Multiple Top', 'Multiple Bottom'], default=np.nan)

    # --- Support / Resistance ---
    roll_high = df['High'].rolling(window=window, min_periods=1)
    roll_low  = df['Low'].rolling(window=window, min_periods=1)
    mean_high = roll_high.mean()
    std_high = roll_high.std(ddof=0)
    mean_low = roll_low.mean()
    std_low = roll_low.std(ddof=0)
    df['support'] = mean_low - 2*std_low
    df['resistance'] = mean_high + 2*std_high

    # --- Triangle Pattern ---
    mask_asc = (high_roll_max >= high_shift_back) & (low_roll_min <= low_shift_back) & (df['Close'] > close_shift_back)
    mask_desc = (high_roll_max <= high_shift_back) & (low_roll_min >= low_shift_back) & (df['Close'] < close_shift_back)
    df['triangle_pattern'] = np.select([mask_asc, mask_desc], ['Ascending Triangle', 'Descending Triangle'], default=np.nan)

    # --- Wedge ---
    high_first = df['High'].shift(wedge_window-1)
    low_first  = df['Low'].shift(wedge_window-1)
    trend_high = np.sign(df['High'] - high_first)
    trend_low  = np.sign(df['Low'] - low_first)
    mask_wedge_up = (high_roll_max >= high_shift_back) & (low_roll_min <= low_shift_back) & (trend_high == 1) & (trend_low == 1)
    mask_wedge_down = (high_roll_max <= high_shift_back) & (low_roll_min >= low_shift_back) & (trend_high == -1) & (trend_low == -1)
    df['wedge_pattern'] = np.select([mask_wedge_up, mask_wedge_down], ['Wedge Up', 'Wedge Down'], default=np.nan)

    # --- Channel ---
    high_first_ch = df['High'].shift(channel_window-1)
    low_first_ch = df['Low'].shift(channel_window-1)
    trend_high_ch = np.sign(df['High'] - high_first_ch)
    trend_low_ch  = np.sign(df['Low'] - low_first_ch)
    channel_width = high_roll_max - low_roll_min
    channel_mid = (high_roll_max + low_roll_min)/2
    channel_cond = channel_width <= channel_range * channel_mid
    mask_channel_up = (high_roll_max >= high_shift_back) & (low_roll_min <= low_shift_back) & channel_cond & (trend_high_ch == 1) & (trend_low_ch == 1)
    mask_channel_down = (high_roll_max <= high_shift_back) & (low_roll_min >= low_shift_back) & channel_cond & (trend_high_ch == -1) & (trend_low_ch == -1)
    df['channel_pattern'] = np.select([mask_channel_up, mask_channel_down], ['Channel Up', 'Channel Down'], default=np.nan)

    # --- Double Top/Bottom ---
    range_back = (high_shift_back - low_shift_back) <= double_threshold * (high_shift_back + low_shift_back)/2
    range_fwd = (high_shift_fwd - low_shift_fwd) <= double_threshold * (high_shift_fwd + low_shift_fwd)/2
    mask_double_top = (high_roll_max >= high_shift_back) & (high_roll_max >= high_shift_fwd) & (df['High'] < high_shift_back) & (df['High'] < high_shift_fwd) & range_back & range_fwd
    mask_double_bottom = (low_roll_min <= low_shift_back) & (low_roll_min <= low_shift_fwd) & (df['Low'] > low_shift_back) & (df['Low'] > low_shift_fwd) & range_back & range_fwd
    df['double_pattern'] = np.select([mask_double_top, mask_double_bottom], ['Double Top', 'Double Bottom'], default=np.nan)

    # --- Trendline Regression ---
    x = np.arange(n)
    sum_x  = pd.Series(x).rolling(window=regression_window, min_periods=regression_window).sum().values
    sum_y  = df['Close'].rolling(window=regression_window, min_periods=regression_window).sum().values
    sum_xy = pd.Series(x * df['Close'].values).rolling(window=regression_window, min_periods=regression_window).sum().values
    sum_x2 = pd.Series(x**2).rolling(window=regression_window, min_periods=regression_window).sum().values
    denom = regression_window * sum_x2 - sum_x**2
    slope = (regression_window*sum_xy - sum_x*sum_y)/denom
    intercept = (sum_y - slope*sum_x)/regression_window
    df['slope'] = slope
    df['intercept'] = intercept
    df['support_trend'] = np.where(slope>0, df['Close']*slope + intercept, np.nan)
    df['resistance_trend'] = np.where(slope<0, df['Close']*slope + intercept, np.nan)

    # --- Pivots ---
    high_diffs = df['High'].diff()
    low_diffs = df['Low'].diff()
    higher_high_mask = (high_diffs > 0) & (high_diffs.shift(-1) < 0)
    lower_low_mask = (low_diffs < 0) & (low_diffs.shift(-1) > 0)
    lower_high_mask = (high_diffs < 0) & (high_diffs.shift(-1) > 0)
    higher_low_mask = (low_diffs > 0) & (low_diffs.shift(-1) < 0)
    df['pivot_signal'] = np.select([higher_high_mask, lower_low_mask, lower_high_mask, higher_low_mask], ['HH','LL','LH','HL'], default='')

    return df




