import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait


# set up the web driver
options = webdriver.ChromeOptions()
options.add_experimental_option('prefs', {
    "download.default_directory": '/path/to/download/directory',
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "plugins.always_open_pdf_externally": True
})
driver = webdriver.Chrome(options=options)

# go to the website
driver.get("https://www.bseindia.com/corporates/List_Scrips.html")

# select "Equity" from the drop-down menu
select = Select(driver.find_element_by_id("ddlMarketType"))
select.select_by_visible_text("Equity")

# click the "Submit" button
submit_button = driver.find_element_by_id("btnSubmit")
submit_button.click()

# wait for the download link to appear
wait = WebDriverWait(driver, 10)
download_link = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "Download file in CSV Format")))

# download the file
download_link.click()

# convert the file to a pandas dataframe
df = pd.read_csv('/path/to/download/directory/Scrips.csv')

# close the web driver
driver.quit()





#################

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


# set up the web driver
options = webdriver.ChromeOptions()
options.add_experimental_option('prefs', {
    "download.default_directory": '/path/to/download/directory',
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "plugins.always_open_pdf_externally": True
})
driver = webdriver.Chrome(options=options)

# go to the website
driver.get("https://www.bseindia.com/corporates/List_Scrips.html")

# select "Equity" from the drop-down menu
select = Select(driver.find_element_by_id("ddlMarketType"))
select.select_by_visible_text("Equity")

# click the "Submit" button
submit_button = driver.find_element_by_id("btnSubmit")
submit_button.click()

# wait for the securityId text to be visible
wait = WebDriverWait(driver, 10)
security_id = wait.until(EC.visibility_of_element_located((By.ID, "securityId")))

# check if the text is as expected
if security_id.text == "Security Id:":
    # download the file
    download_link = driver.find_element_by_link_text("Download file in CSV Format")
    download_link.click()

    # convert the file to a pandas dataframe
    df = pd.read_csv('/path/to/download/directory/Scrips.csv')

# close the web driver
driver.quit()
