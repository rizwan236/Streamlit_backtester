from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
from bse import BSE

download_folder=BSE_DIR = Path("/home/rizpython236/BT5/trade-logs")
BSE_DIR.mkdir(parents=True, exist_ok=True)

bse = BSE()
today = datetime.today()

for i in range(7):
    d = today - timedelta(days=i)
    try:
        file_path = BSE.deliveryReport(d, folder=BSE_DIR)
        #df = pd.read_csv(file_path)
        print(f"✅ BSE Bhavcopy: {d.date()}")
        #print(df.head())
        break
    except Exception as e:
        print(e)
        continue
