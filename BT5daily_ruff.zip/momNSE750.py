import csv
from datetime import datetime
import os
import sys

#from scipy import stats
import time
import traceback

import numpy as np
import pandas as pd
from PDFconvert import create_pdf
import pytz

#import yfinance as yf
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


#sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
#import pandas_ta as ta

'''
use below strategy where the universe of stock ticker is in a csv file
1) 12 month & 6 month  Momentum Ratio =  Price return / σp  # [Price (M-1)/Price (M-13)]-1
2) σp = Annualised standard deviation of lognormal daily returns of the stock for 1 year
3) Z Score of the Momentum Ratio for 12 month & 6 month
4) Weighted Average Z Score = 50% * (12 month Momentum Z Score) + 50% * (6 month Momentum Z Score)
5) Normalized Momentum Score = (1+ Wgt. Average Z score) if Wgt. Average Z score >=0  or (1- Weighted Average Z score)^-1 if Wgt. Average Z score < 0
6) The top 30 stocks with the highest Normalized Momentum Score are selected
The top 30 stocks with the highest Normalized Momentum Score are selected

MR12 is the 12 month Momentum Ratio of the stock
µMR, 12 is the mean of the 12 month Momentum Ratios of the eligible
universe
σMR,12  is the std. deviation of the 12 month Momentum Ratios of the
eligible universe



'''

print("Start momNSE750")
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)

#input_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv'
def update_output_file(input_file, output_file):
    """
    Updates the output file with VLOOKUP logic for Symbol, Company, YFindustry, and Industry columns.
    Fills in missing data for symbols without VLOOKUP matches.

    Args:
        input_file (str): Path to the input CSV file.
        output_file (str): Path to the output CSV file.
    """

    df_input = pd.read_csv(input_file)
    df_output = output_file# pd.read_csv(output_file)

    # Sort dataframes before merging to improve performance
    df_input.sort_values('Symbol', inplace=True)
    df_output.sort_values('Symbol', inplace=True)

    # Reduce dataframe size by selecting only necessary columns
    df_input = df_input[['Symbol', 'Company', 'YFindustry', 'Industry']]

    # Perform VLOOKUP and merge using the correct join type (left join in this case)
    merged_data = pd.merge(df_output, df_input, on='Symbol', how='left')

    # Fill 'Company' with corresponding 'Symbol' if it's missing
    merged_data['Company'] = merged_data['Company'].fillna(merged_data['Symbol'])
    merged_data["YFindustry"].fillna("Blank", inplace=True)
    merged_data["Industry"].fillna("Blank", inplace=True)

    # Save the merged data to a new CSV file
    rankedTop30=merged_data
    #merged_data.to_csv(output_file, index=False)

def add_suffix_to_column(df, column_name, suffix):
    # Load the csv file into a Pandas DataFrame
    # df = pd.read_csv(file_name)
    # df = Dffile  # pd.read_csv(file_name)
    # Modify the specified column in-place
    df[column_name] = df[column_name].astype(str) + suffix
    #df[column_name] = df[column_name].apply(lambda x: x + suffix)
    return df

#folder_path = '/home/rizpython236/BT5/ticker_15yr/'  # Replace with the actual folder path  ticker_daily1yr58
folder_path = '/home/rizpython236/BT5/ticker_daily1yr/'
exclude_tickers = pd.read_csv('/home/rizpython236/BT5/exclude_tickers.csv')
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
#ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
#ticker_df = pd.read_csv(ticker_path)
#symbols = ticker_df['Symbol'].tolist()[:]
#symbols = list(dict.fromkeys(symbols))  #list(set(symbols))

#________________________

'''
NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(NSE570_path)
NSE570symbols1 = NSE570ticker_df['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols1))
symbols = list(dict.fromkeys(NSE570symbols1))
number=len(symbols)
print(number)
symbols= [symbol for symbol in NSE570symbols if symbol not in exclude_tickers["Symbol"]]
number=len(symbols)
print(number)
jj
'''

valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))

#___________________________________
NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'         #NSE750
#nse500 = pd.read_csv("/home/rizpython236/BT5/nse500.csv")  #NSE500
nse500 = pd.read_csv(NSE570_path)   #NSE750
#add_suffix_to_column(nse500, "Symbol", ".NS")              # use with nse500.csv
NSE570symbols1 = nse500['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols1))
symbols = list(dict.fromkeys(NSE570symbols1))
number=len(symbols)
print(number)

#symbols = symbols[~symbols["Symbol"].isin(exclude_tickers["Symbol"])]
#symbols = [symbol for symbol in symbols if symbol["Symbol"] not in exclude_tickers]
symbols= [symbol for symbol in NSE570symbols if symbol not in exclude_tickers["Symbol"]]
number=len(symbols)
print(number)

#_____________________________

rankedTop30 = []
selected_files=[]
all_stats = []
momentumratiosall=[]





FinalMicrocap250 = pd.read_csv("/home/rizpython236/BT5/FinalMicrocap250.csv")
#NSE570ticker_df = pd.read_csv(nse500)
add_suffix_to_column(FinalMicrocap250, "Symbol", ".NS")
FinalMicrocap250symbols = FinalMicrocap250['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
FinalMicrocap250symbols = list(set(FinalMicrocap250symbols))

def downside_deviation_from_pricesaaa(log_returns, mar=0):
    # Calculate the returns that are below the minimum acceptable return (MAR)
    downside_returns = log_returns[log_returns < mar]

    # Square these returns
    squared_downside_returns = downside_returns ** 2

    # Calculate the mean of these squared returns
    mean_squared_downside = squared_downside_returns.mean()

    # Take the square root of the mean squared downside returns
    downside_deviation = np.sqrt(mean_squared_downside)
    #print(downside_deviation)

    return downside_deviation

def calculate_lognormal_daily_returns(prices):
    """Calculates lognormal daily returns of a stock.

    Args:
        prices (pandas.Series): Time series of closing prices.

    Returns:
        pandas.Series: Time series of lognormal daily returns.
    """

    log_returns = np.log(prices)-np.log(prices.shift(1)) #np.log(prices.pct_change() + 1)
    return log_returns

def nifty_momentum_backtest(data,Company,df,base_name,FinalMicrocap250symbols):
    """Backtests the Nifty momentum strategy with transaction costs.

    Args:
        start_date (str): Start date for backtesting in 'YYYY-MM-DD' format.
        end_date (str): End date for backtesting in 'YYYY-MM-DD' format.
        universe_file (str): Path to CSV file containing stock tickers.

    Returns:
        pandas.DataFrame: DataFrame containing backtesting results.
    """
    #df = pd.read_csv(file_path)
    data["SMA_30MRP"] = tb.EMA(data['MRP'], timeperiod=60)
    data["SMA_90MRP"] = tb.EMA(data['MRP'], timeperiod=200)
    data["SMA_30close"] = tb.EMA(data['Close'], timeperiod=60)
    data["SMA_90close"] = tb.EMA(data['Close'], timeperiod=200)
    data["OBV"] = tb.OBV(data['Close'], data['Volume'])
    data["obvmovavg"] = tb.EMA(data["OBV"], timeperiod=60)
    #data["CCI"] = tb.CCI(data['High'], data['Low'], data['Close'], timeperiod=34*5)
    #data["SMA100_cci"] = tb.SMA(data['CCI'], timeperiod=100)
    #data["SMA200_cci"] = tb.SMA(data['CCI'], timeperiod=200)
    if  data['SMA_30MRP'].iloc[-1] > data['SMA_90MRP'].iloc[-1]*1 and  data['SMA_30close'].iloc[-1] > data['SMA_90close'].iloc[-1]*1.02: # True:


        # Transaction cost (adjust as needed)
        #transaction_cost = 0.001  # 0.1% per trade

        # Read universe file
        #with open(universe_file, 'r') as f:
        #    tickers = f.readlines()
        #tickers = [ticker.strip() for ticker in tickers]

        # Download data for all tickers
        #data = yf.download(tickers, start=start_date, end=end_date)

        # Calculate daily returns and annualized standard deviation
        #daily_returns = data['Close'].pct_change()
        # data['ROC_6m'] = data['Close'].pct_change(periods=126) * 100
        #annualized_std = daily_returns.std(axis=0) * np.sqrt(252)
        lognormal_returns = calculate_lognormal_daily_returns(data['Close'][-252:])
        #annualized_lognormal_std = lognormal_returns.std(axis=0) #* np.sqrt(252)
        annualized_lognormal_std = lognormal_returns.rolling(252).apply(downside_deviation_from_pricesaaa)
        #print(lognormal_returns)
        #print(annualized_lognormal_std)

        #rolling_std = lognormal_returns.rolling(window=252).std()
        #data['annualized_lognormal_std'] = rolling_std * np.sqrt(252)

        # Calculate momentum ratios (12 & 6 months)
        #momentum_ratio_12m = daily_returns.rolling(window=252).mean() / annualized_lognormal_std
        #momentum_ratio_6m = daily_returns.rolling(window=126).mean() / annualized_lognormal_std
        data['ROC_3m']=tb.ROC(data['Close'], timeperiod=63)
        data['ROC_6m']=tb.ROC(data['Close'], timeperiod=126)
        data['ROC_12m']=tb.ROC(data['Close'], timeperiod=252)

        momentum_ratio_12m = data['ROC_12m'].iloc[-1] / annualized_lognormal_std
        momentum_ratio_6m = data['ROC_6m'].iloc[-1]  / annualized_lognormal_std
        momentum_ratio_3m = data['ROC_3m'].iloc[-1]  / annualized_lognormal_std

        # Calculate Z-scores

        #z_score_12m = ta.zscore(momentum_ratio_12m)
        #z_score_6m = ta.zscore(momentum_ratio_6m)
        z_score_3m =  (momentum_ratio_3m -df['mean_momentum_3m'].iloc[-1]) / df['std_momentum_3m'].iloc[-1]
        z_score_6m =  (momentum_ratio_6m -df['mean_momentum_6m'].iloc[-1]) / df['std_momentum_6m'].iloc[-1]
        z_score_12m = (momentum_ratio_12m -df['mean_momentum_12m'].iloc[-1])/ df['std_momentum_12m'].iloc[-1]


        # Calculate weighted average Z-score
        #weighted_zscore = 0.5 * z_score_12m + 0.5 * z_score_6m
        weighted_zscore = 0.45 * z_score_12m + 0.45 * z_score_6m + 0.1 * z_score_3m

        # Calculate normalized momentum score
        normalized_score = (1 + weighted_zscore) * (weighted_zscore >= 0) + (1 / (1 - weighted_zscore))**(-1) * (weighted_zscore < 0)

        # Rank stocks by normalized score
        #ranked_data = pd.DataFrame({'Ticker': Company, 'Normalized Score': normalized_score.iloc[-1]})
        #ranked_data = ranked_data.sort_values(by='Normalized Score', ascending=False)
        #top_30 = ranked_data
        normalized_score =round(weighted_zscore,4)
        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                "Company": Company,
                "NSE250": NSE570s,
                "Score": normalized_score,
                }

        # Calculate daily returns for the top 30 stocks (assuming equal weights)
        #daily_returns_filtered = data['Close'][top_30['Ticker']].pct_change()

        # Simulate portfolio returns with transaction costs
        #portfolio_return = daily_returns_filtered.mean(axis=1)
        #gross_return = (1 + portfolio_return).prod() - 1
        #net_return = gross_return - transaction_cost * portfolio_return.sum()

        # Create results DataFrame
        #results = pd.DataFrame({
        #    'Start Date': start_date,
        #    'End Date': end_date,
        #    'Gross Return': gross_return,
        #    'Net Return': net_return
        #})

        rankedTop30.append(ranked_data1)
        #print(rankedTop30)
        #return ranked_data
    else:
        normalized_score =0.001
        NSE570s = "Y" if base_name in FinalMicrocap250symbols  else ""
        ranked_data1 = {
                "Company": Company,
                "NSE250": NSE570s,
                "Score": normalized_score,
                }
        rankedTop30.append(ranked_data1)
        1+1



def calculate_momentum_stats(folder_path,symbols):
    """
    Calculates mean and standard deviation of 6-month and 12-month momentum ratios
    across all CSV files in a specified folder.

    Args:
        folder_path (str): Path to the folder containing CSV files.

    Returns:
        dict: A dictionary containing the following statistics:
            - mean_momentum_6m (float): Mean of 6-month momentum ratios for all stocks.
            - std_momentum_6m (float): Standard deviation of 6-month momentum ratios.
            - mean_momentum_12m (float): Mean of 12-month momentum ratios for all stocks.
            - std_momentum_12m (float): Standard deviation of 12-month momentum ratios.
    """
    #nse500 = pd.read_csv("/home/rizpython236/BT5/nse500.csv")
    #NSE570ticker_df = pd.read_csv(nse500)
    #add_suffix_to_column(nse500, "Symbol", ".NS")
    #NSE570symbols1 = nse500['Symbol'].tolist()[:]
    #NSE570symbols = list(dict.fromkeys(symbols))
    #NSE570symbols = list(set(NSE570symbols1))
    #symbols = list(dict.fromkeys(NSE570symbols1))

    for file_name in os.listdir(folder_path):

        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            #total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)

            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                #print(file_path)
                data1 = pd.read_csv(file_path)

                # Calculate 6-month and 12-month ROC (Rate of Change)
                #data['ROC_6m'] = data['Close'].pct_change(periods=126) * 100  # Percentage change
                #data['ROC_12m'] = data['Close'].pct_change(periods=252) * 100  # Percentage change
                data1['ROC_3m']=tb.ROC(data1['Close'], timeperiod=63)
                data1['ROC_6m']=tb.ROC(data1['Close'], timeperiod=126)
                data1['ROC_12m']=tb.ROC(data1['Close'], timeperiod=252)

                lognormal_returns = calculate_lognormal_daily_returns(data1['Close'][-252:])
                #annualized_lognormal_std = lognormal_returns.std(axis=0) #* np.sqrt(252)
                annualized_lognormal_std = lognormal_returns.rolling(252).apply(downside_deviation_from_pricesaaa)

                # Calculate momentum ratios (using ROC instead of TA-Lib for clarity)
                momentum_ratio_3m = data1['ROC_3m'].iloc[-1] / annualized_lognormal_std
                momentum_ratio_6m = data1['ROC_6m'].iloc[-1] / annualized_lognormal_std
                momentum_ratio_12m = data1['ROC_12m'].iloc[-1] / annualized_lognormal_std

                # Update statistics
                #momentum_stats['mean_momentum_6m'] += momentum_ratio_6m
                #momentum_stats['std_momentum_6m'] += momentum_ratio_6m**2
                #momentum_stats['mean_momentum_12m'] += momentum_ratio_12m
                #momentum_stats['std_momentum_12m'] += momentum_ratio_12m**2
                momentumratios ={
                    'momentum_3m': momentum_ratio_3m,
                    'momentum_6m': momentum_ratio_6m,
                    #'std_momentum_6m': np.nan,  # Initialize with NaN (no calculation yet)
                    'momentum_12m': momentum_ratio_12m,
                    }
                #momentumratiosall.append(momentumratios)
                file_stats = {
                    'Company': base_name,
                    'momentum_3m': momentum_ratio_3m,
                    'momentum_6m': momentum_ratio_6m,
                    #'std_momentum_6m': np.nan,  # Initialize with NaN (no calculation yet)
                    'momentum_12m': momentum_ratio_12m,
                    #'std_momentum_12m': np.nan  # Initialize with NaN (no calculation yet)
                }

                all_stats.append(file_stats)
            else:
                print("No base name")
        else:
            print("No file name")
    if 1==1:
        #print(all_stats)
        df = pd.DataFrame(all_stats)  # Create DataFrame from stats list
        #dfmomentumratiosall = pd.DataFrame(momentumratiosall)
        #print(df)
        number= len(df['momentum_6m'])
        df['mean_momentum_3m'] = sum(df['momentum_3m'])/len(df['momentum_3m'])
        df['mean_momentum_6m'] = sum(df['momentum_6m'])/len(df['momentum_6m'])
        df['mean_momentum_12m'] = sum(df['momentum_12m'])/len(df['momentum_12m'])
        df['std_momentum_3m'] = tb.STDDEV(df['momentum_3m'], timeperiod=number, nbdev=1)
        df['std_momentum_6m'] = tb.STDDEV(df['momentum_6m'], timeperiod=number, nbdev=1) # Vectorized std calculation for 6m  df['momentum_6m'].pow(2).mean(axis=1)
        df['std_momentum_12m'] = tb.STDDEV(df['momentum_12m'], timeperiod=number, nbdev=1)  #df['momentum_12m'].pow(2).mean(axis=1)  # Vectorized std calculation for 12m

    else:
        df = pd.DataFrame(columns=['Company','mean_momentum_3m', 'mean_momentum_6m', 'mean_momentum_12m','std_momentum_3m','std_momentum_6m','std_momentum_12m'])
    print(df)
    #print(dfmomentumratiosall)
    return df



#ranked_data_Final = pd.DataFrame(columns=['Ticker', 'Normalized Score'])

universemomentum_stats= calculate_momentum_stats(folder_path,symbols)
#df['std_momentum_3m']=tb.STDDEV(df['momentum_3m'], timeperiod=number, nbdev=1)
#df['std_momentum_6m']= tb.STDDEV(df['momentum_6m'], timeperiod=number, nbdev=1)
#df['std_momentum_12m']= tb.STDDEV(df['momentum_12m'], timeperiod=number, nbdev=1)


for file_name in os.listdir(folder_path):
    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            #total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)


            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                #print(base_name)

                # Read the CSV file into a DataFrame
                data = pd.read_csv(file_path)
                #data=data[-252:]
                Company=symbol_to_company.get(base_name, base_name)
                nifty_momentum_backtest(data,Company,universemomentum_stats,base_name,FinalMicrocap250symbols)
                #ranked_data_Final['Ticker','Normalized Score'].append(ranked_data)
            else:
                1+1
        else:
            print("No data found to write to momNSE750")
    except Exception as e:
        print(f"Error in  momNSE750- {e}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass

print("__________________________________________________________")




#industry_scoresold = pd.read_csv('/home/rizpython236/BT5/trade-logs/industry_scores.csv')

#print(rankedTop30)

#rankedTop30 = rankedTop30.sort(key=lambda row: row["Normalized_Score"], reverse=False)
rankedTop30list = sorted(rankedTop30, key=lambda item: item['Score'], reverse=True)
#print(rankedTop30list)


#rankedTop30 = pd.DataFrame({'Ticker': Company, 'Normalized_Score': normalized_score.iloc[-1]})
#ranked_data = ranked_data.sort_values(by='Normalized Score', ascending=False)
column_names = ["Company","NSE250", "Score",]
rankedTop30 = pd.DataFrame(columns=column_names)
rankedTop30 = rankedTop30.append(rankedTop30list, ignore_index=True)
rankedTop30 = rankedTop30.drop_duplicates(subset=['Company'])

print("vlookup_and_merge")
# Read the input files
valid_tickers = pd.read_csv('/home/rizpython236/BT5/trade-logs/valid_tickers.csv')
trade_list = rankedTop30  #pd.read_csv('/home/rizpython236/BT5/screener-outputs/trade_list_BT_Screener.csv')

# Sort dataframes before merging to improve performance
valid_tickers.sort_values('Symbol', inplace=True)
rankedTop30.sort_values('Company', inplace=True)

# Reduce dataframe size by selecting only necessary columns
valid_tickers = valid_tickers[['Symbol', 'Company', 'Industry']]

# Perform VLOOKUP and merge using the correct join type (left join in this case)
rankedTop30 = pd.merge(rankedTop30, valid_tickers, left_on='Company', right_on='Company', how='left')


# Drop the redundant 'Symbol' column
rankedTop30.drop(columns=['Symbol'], inplace=True)
desired_order = ['Company', 'Industry', 'NSE250','Score']
rankedTop30 = rankedTop30[desired_order]

industry_scores = rankedTop30[:].groupby('Industry')['Score'].sum().reset_index()
industry_scores['Count'] = rankedTop30[:].groupby('Industry')['Company'].count().reset_index()['Company']
industry_scores = industry_scores[industry_scores['Count'] >= 1]
industry_scores['Avg'] = round(industry_scores['Score'] / industry_scores['Count'],3)

median_scores = rankedTop30.groupby('Industry')['Score'].median().reset_index()  # Calculate medians
median_scores['Median'] = rankedTop30[:].groupby('Industry')['Score'].median().reset_index()['Score']
median_scores['Median']=round(median_scores['Median'],3)
median_scores.drop(columns=['Score'], inplace=True)
#print(median_scores)
industry_scores = industry_scores.merge(median_scores[['Industry', 'Median']], how='left', on='Industry')  # Merge DataFrames
industry_scores.rename(columns={'Score': 'Sum_Score'}, inplace=True)
industry_scores['Sum_Score'] =round(industry_scores['Sum_Score'],3)
#industry_scoresM.rename(columns={'Score': 'Median'}, inplace=True)  # Rename column (optional)
#

# Sort by sum of score (descending)
industry_scores = industry_scores.sort_values(by='Median', ascending=False)
rankedTop30 = rankedTop30.sort_values(by='Score', ascending=False)
# Print the result
print(industry_scores)

if len(industry_scores) > 3:
    industry_scores.to_csv('/home/rizpython236/BT5/screener-outputs/industry_scores.csv', index=False)
    industry_scores.to_csv('/home/rizpython236/BT5/trade-logs/industry_scores.csv', index=False)
    print(f"industry_scores.csv saved successfully in {folder_path}")
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/industry_scores.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/industry_scores.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= True)
    time.sleep(3)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/industry_scores.pdf')
    print("made PDF industry_scores.pdf")
else:
     print("No data found to write to industry_scores.csv")
###################33

'''
industry_scoresnew = industry_scores #= pd.read_csv('/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv', index=False)
industry_scoresold =industry_scoresold #= pd.read_csv('/home/rizpython236/BT5/trade-logs/NIFTY500MOMENTUM30.csv', index=False)

industry_scoresnew = industry_scoresnew.rename(columns={'Score': 'Score_new'})
industry_scoresold = industry_scoresold.rename(columns={'Score': 'Score_old'})
industry_scoresold = industry_scoresold.rename(columns={'Rank': 'Rank_old'})
industry_scoresold = industry_scoresold.drop(['NSE250','Industry'], axis=1)
#print(NIFTY750MOMENTUM30old)
#print(NIFTY750MOMENTUM30new)

# Ensure both DataFrames have the same columns
#if not set(NIFTY750MOMENTUM30new.columns) == set(NIFTY750MOMENTUM30old.columns):
#    raise ValueError("DataFrames have different columns. Please ensure they have the same columns.")

# Merge DataFrames (assuming 'Ticker' is the common column for merging)
merged_df = pd.merge(NIFTY750MOMENTUM30new, NIFTY750MOMENTUM30old, how='left', on='Company')
merged_df['Score_old'] = merged_df['Score_old'].fillna(0)
merged_df.sort_values(by=['Score_new'], inplace=True)  # Sort by Ticker and new score
# Calculate the percentage change
merged_df['PctChg'] = round(((merged_df['Score_new'] - merged_df['Score_old']) / merged_df['Score_old']) * 100,1)
merged_df['PctChg'] = merged_df['PctChg'].fillna(0)
merged_df.sort_values(by=['Score_new'], inplace=True, ascending=False)   # Sort by Ticker and new score
merged_df = merged_df.drop_duplicates(subset=['Company'])
#merged_df = merged_df.drop(['NSE250'], axis=1)
desired_order = ['Company', 'Industry','NSE250','Rank','Rank_old','Score_new','Score_old','PctChg'] #  Company,Industry,NSE250,Score_new,Score_old,PctChg
merged_df = merged_df[desired_order]
'''
##############

# Save the merged data to a new CSV file
#merged_data.to_csv(output_file, index=False)
#print(f"Successfully merged data and saved to rankedTop30 ")

rankedTop30.fillna("", inplace=True)

#ranked_data = pd.DataFrame({'Ticker': Company, 'Normalized Score': normalized_score.iloc[-1]})
rankedTop30 = rankedTop30.sort_values(by='Score', ascending=False)
rankedTop30['Rank'] = rankedTop30['Score'].rank(ascending=False).astype(int)
desired_order = ['Company', 'Industry', 'NSE250','Rank','Score']
rankedTop30 = rankedTop30[desired_order]
rankedTop30= round(rankedTop30,3)
rankedTop30= rankedTop30[:]
rankedTop30.head(10)
print(rankedTop30)




NIFTY750MOMENTUM30old = pd.read_csv('/home/rizpython236/BT5/trade-logs/NIFTY500MOMENTUM30.csv')


if len(rankedTop30) > 3:
    rankedTop30.to_csv('/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv', index=False)
    rankedTop30.to_csv('/home/rizpython236/BT5/trade-logs/NIFTY500MOMENTUM30.csv', index=False)
    print(f"NIFTY750MOMENTUM30.csv saved successfully in {folder_path}")
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.pdf'  # Replace with desired output PDF file
    time.sleep(4)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= True)
    time.sleep(3)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.pdf')
    print("file created NIFTY500MOMENTUM30.pdf")
else:
     print("No data found to write to NIFTY500MOMENTUM30.csv")

# Example usage
#if __name__ == '__main__':
#    start_date = '2020-01-01'
#    end_date = '2024-05-10'  # Adjust end date as needed
#    universe_file = 'nifty_universe.csv'  # Replace with your universe file path

#    results = nifty


# Read CSV files
NIFTY750MOMENTUM30new = rankedTop30 #= pd.read_csv('/home/rizpython236/BT5/screener-outputs/NIFTY500MOMENTUM30.csv', index=False)
NIFTY750MOMENTUM30old =NIFTY750MOMENTUM30old #= pd.read_csv('/home/rizpython236/BT5/trade-logs/NIFTY500MOMENTUM30.csv', index=False)

NIFTY750MOMENTUM30new = NIFTY750MOMENTUM30new.rename(columns={'Score': 'Score_new'})
NIFTY750MOMENTUM30old = NIFTY750MOMENTUM30old.rename(columns={'Score': 'Score_old'})
NIFTY750MOMENTUM30old = NIFTY750MOMENTUM30old.rename(columns={'Rank': 'Rank_old'})
NIFTY750MOMENTUM30old = NIFTY750MOMENTUM30old.drop(['NSE250','Industry'], axis=1)
#print(NIFTY750MOMENTUM30old)
#print(NIFTY750MOMENTUM30new)

# Ensure both DataFrames have the same columns
#if not set(NIFTY750MOMENTUM30new.columns) == set(NIFTY750MOMENTUM30old.columns):
#    raise ValueError("DataFrames have different columns. Please ensure they have the same columns.")

# Merge DataFrames (assuming 'Ticker' is the common column for merging)
merged_df = pd.merge(NIFTY750MOMENTUM30new, NIFTY750MOMENTUM30old, how='left', on='Company')
merged_df['Score_old'] = merged_df['Score_old'].fillna(0)
merged_df.sort_values(by=['Score_new'], inplace=True)  # Sort by Ticker and new score
# Calculate the percentage change
merged_df['PctChg'] = round(((merged_df['Score_new'] - merged_df['Score_old']) / merged_df['Score_old']) * 100,1)
merged_df['PctChg'] = merged_df['PctChg'].fillna(0)
merged_df.sort_values(by=['Score_new'], inplace=True, ascending=False)   # Sort by Ticker and new score
merged_df = merged_df.drop_duplicates(subset=['Company'])
#merged_df = merged_df.drop(['NSE250'], axis=1)
desired_order = ['Company', 'Industry','NSE250','Rank','Rank_old','Score_new','Score_old','PctChg'] #  Company,Industry,NSE250,Score_new,Score_old,PctChg
merged_df = merged_df[desired_order]

if len(merged_df) > 3:
    merged_df.to_csv('/home/rizpython236/BT5/screener-outputs/MergeNIFTY500MOMENTUM30.csv', index=False)
    #rankedTop30.to_csv('/home/rizpython236/BT5/trade-logs/NIFTY500MOMENTUM30.csv', index=False)
    print(f"MergeNIFTY500MOMENTUM30.csv saved successfully in {folder_path}")
    input_csv_file = '/home/rizpython236/BT5/screener-outputs/MergeNIFTY500MOMENTUM30.csv'  # Replace with your CSV file
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MergeNIFTY500MOMENTUM30.pdf'  # Replace with desired output PDF file
    time.sleep(5)
    create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
    time.sleep(3)
    post_telegram_file('/home/rizpython236/BT5/screener-outputs/MergeNIFTY500MOMENTUM30.pdf')
    print("file created MergeNIFTY500MOMENTUM30.pdf")
else:
     print("No data found to write to MergeNIFTY500MOMENTUM30.csv")

# Prepare data for plotting (assuming higher score means better ranking)
merged_df.fillna("", inplace=True)
#merged_df[['Ticker', 'Normalized_Score_new','Normalized_Score_old']] = merged_df[['Normalized_Score_new', 'Normalized_Score_old']].apply(pd.to_numeric, errors='coerce')
print(merged_df)


tickers = merged_df['Company'].tolist()
new_scores = merged_df['Score_new'].tolist()
old_scores = merged_df['Score_old'].tolist()

#import pandas as pd
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt


try:
    # Create the line chart
    plt.figure(figsize=(12, 10))  # Adjust figure size as needed
    #fig, ax = plt.subplots()


    merged_df = merged_df.dropna(subset=['PctChg'])
    merged_df = merged_df[merged_df['PctChg'] != 0]
    merged_df = merged_df[merged_df['Score_old'] != 0.001]
    merged_df = merged_df[merged_df['Score_new'] != 0.001]
    merged_df = merged_df[(merged_df['PctChg'] < 100) or (merged_df['PctChg'] > -100)]  #merged_df[merged_df['PctChg'] < 100]
    merged_df = merged_df.sort_values(by=['PctChg'], inplace=True, ascending=False)
    merged_df= merged_df[:45]

    tickers = merged_df['Company'].tolist()
    new_scores = merged_df['Score_new'].tolist()
    old_scores = merged_df['Score_old'].tolist()
    Percent_Change = merged_df['PctChg'].tolist()



    plt.bar(tickers, Percent_Change, label='Percent_Change', color='blue')

    # Set labels and title
    plt.xlabel('Company')
    plt.ylabel('Percent_Change Score')
    plt.title('Comparison of Normalized Scores - New vs. Old')

    # Add legend
    plt.legend(loc='upper left')
    plt.grid(True)
    # Rotate x-axis labels to prevent overlapping if there are many tickers
    plt.xticks(rotation=90)


    # Show the plot
    plt.grid(True)
    plt.tight_layout()

    chart_path = '/home/rizpython236/BT5/screener-outputs/momNSE500.png'
    plt.savefig(chart_path)
    time.sleep(2)
    post_telegram_file(chart_path)

    print('saved momNSE500.png')
except Exception as e:
    print(f"Error occurred for momNSE500 plot: {str(e)}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass
#plt.show()

# Add 'Count' information to industry names using string concatenation
industry_scores['Industry'] = industry_scores['Industry'] + '-  : ' + industry_scores['Count'].astype(str)

industry_scores1 = industry_scores.sort_values(by='Avg', ascending=False)
#industry_scores1 = industry_scores1.dropna(subset=['Avg'])
#industry_scores1 = industry_scores1[industry_scores['Avg'] != 0]
print(industry_scores1)

tickers = industry_scores1['Industry'].tolist()
Avg_score = industry_scores1['Avg'].tolist()
count = industry_scores1['Count'].tolist()
Score = industry_scores1['Sum_Score'].tolist()


# Create the line chart
plt.figure(figsize=(12, 10))  # Adjust figure size as needed
plt.subplots_adjust(left=0.05, right=0.99, top=0.09, bottom=0.08)

# Plot lines for new and old scores with distinct colors and labels
#plt.plot(tickers, new_scores, marker='o', label='New Score', color='b')
#plt.plot(tickers, old_scores, marker='o', label='Old Score', color='g')
# plt.bar(tickers, old_scores, label='Old Score', color='g')
bars = plt.bar(tickers, Avg_score, label='Avg Score', color='b')

# Add company count as labels on top of the bars
#for bar, cnt in zip(bars, count):
#    yval = bar.get_height()  # Get the height of the bar
#    plt.text(bar.get_x() + bar.get_width() / 2, yval + 5, f"{cnt}", ha='right', va='bottom', fontsize=10)

# Set labels and title
plt.xlabel('Industry')
plt.ylabel('Avg Normalized Score')
plt.title('Industry Avg Score')


# Add legend
plt.legend(loc='upper right')
plt.grid(True)
# Rotate x-axis labels to prevent overlapping if there are many tickers
plt.xticks(rotation=90)

# Show the plot
plt.grid(True)
plt.tight_layout()

chart_path = '/home/rizpython236/BT5/screener-outputs/Industry_AvgScore.png'
plt.savefig(chart_path)
time.sleep(2)
post_telegram_file(chart_path)

print('saved Industry_Avgscore.png')

industry_scores1 = industry_scores.sort_values(by='Median', ascending=False)
#industry_scores1 = industry_scores1.dropna(subset=['Median'])
#industry_scores1 = industry_scores1[industry_scores['Median'] != 0]

tickers = industry_scores1['Industry'].tolist()
Avg_score = industry_scores1['Avg'].tolist()
count = industry_scores1['Count'].tolist()
Score = industry_scores1['Sum_Score'].tolist()
Median_score = industry_scores1['Median'].tolist()



# Create the line chart
plt.figure(figsize=(12, 10))  # Adjust figure size as needed
plt.subplots_adjust(left=0.05, right=0.99, top=0.09, bottom=0.08)

# Plot lines for new and old scores with distinct colors and labels
#plt.plot(tickers, new_scores, marker='o', label='New Score', color='b')
#plt.plot(tickers, old_scores, marker='o', label='Old Score', color='g')
# plt.bar(tickers, old_scores, label='Old Score', color='g')
bars = plt.bar(tickers, Median_score, label='Median Score', color='b')

# Add company count as labels on top of the bars
#for bar, cnt in zip(bars, count):
#    yval = bar.get_height()  # Get the height of the bar
#    plt.text(bar.get_x() + bar.get_width() / 2, yval + 5, f"{cnt}", ha='right', va='bottom', fontsize=10)

# Set labels and title
plt.xlabel('Industry')
plt.ylabel('Median Normalized Score')
plt.title('Industry Median Score')


# Add legend
plt.legend(loc='upper right')
plt.grid(True)
# Rotate x-axis labels to prevent overlapping if there are many tickers
plt.xticks(rotation=90)

# Show the plot
plt.grid(True)
plt.tight_layout()

chart_path = '/home/rizpython236/BT5/screener-outputs/Industry_MedianScorenew.png'
chart_pathold = '/home/rizpython236/BT5/trade-logs/Industry_MedianScoreold.png'
try:
    post_telegram_file(chart_pathold)
except Exception as e:
    print(f"Error in  momNSE750- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

plt.savefig(chart_path)
plt.savefig(chart_pathold)
time.sleep(2)
post_telegram_file(chart_path)

print('saved Industry_MedianScore.png')
print('Done')


