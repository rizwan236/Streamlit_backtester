
import sys


sys.path.append("/home/rizpython236/.virtualenvs/Pybroker39/lib/python3.9/site-packages/")
import yfinance as yf


screener = yf.Screener()
screener.set_predefined_body('day_gainers')
result = screener.response



# Example query to filter stocks
gt = yf.EquityQuery('gt', ['eodprice', 3])
lt = yf.EquityQuery('lt', ['avgdailyvol3m', 99999999999])
btwn = yf.EquityQuery('btwn', ['intradaymarketcap', 0, 100000000])
eq = yf.EquityQuery('eq', ['sector', 'Technology'])

# Combine queries using AND/OR
qt = yf.EquityQuery('and', [gt, lt])
qf = yf.EquityQuery('or', [qt, btwn, eq])

# Create a screener instance
screener = yf.Screener()

# Set the default body using a custom query
screener.set_default_body(qf)

# Set predefined body
screener.set_predefined_body('day_gainers')

# Set the fully custom body 
# The keys below are required fields for the request body
screener.set_body({
    "offset": 0,
    "size": 100,
    "sortField": "ticker",
    "sortType": "desc",
    "quoteType": "equity",
    "query": qf.to_dict(),
    "userId": "",
    "userIdType": "guid"
})

# Patch parts of the body
screener.patch_body({"offset": 100})

# view the current body of the screener
screener.body

# Fetch and display the result json
result = screener.response
print(results)

# save the queried symbols
symbols = [quote['symbol'] for quote in result['quotes']]



print(symbols)