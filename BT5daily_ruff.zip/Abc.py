import pandas as pd

# --- Configuration ---
excel_file = "/home/rizpython236/BT5/screener-outputs/transactions data google sheets.xlsx"          # Path to your Excel file
output_prefix = "filtered_"        # Prefix for output CSV files


# --- 1. Read all sheets ---
sheets = pd.read_excel(excel_file, sheet_name=None, header=0)

# --- 2. Extract valid stock names from Sheet4 ---
sheet4 = sheets.get("Sheet4")
if sheet4 is None:
    raise ValueError("Sheet4 not found in the Excel file.")

if "Name" not in sheet4.columns:
    raise ValueError("Sheet4 does not have a column named 'Name'.")

#valid_stocks = set(sheet4["Name"].dropna().astype(str).str.strip())
valid_stocks = set(sheet4["Name"].dropna().astype(str))
print(f"📋 Found {len(valid_stocks)} valid stock names from Sheet4.")

# --- 3. Process each target sheet ---
target_sheets = ["skkhan", "aqzerodha", "Sk"]

for sheet_name in target_sheets:
    if sheet_name not in sheets:
        print(f"⚠️ Sheet '{sheet_name}' not found. Skipping.")
        continue

    df = sheets[sheet_name]

    # Check required columns
    if "Stock" not in df.columns:
        print(f"⚠️ Sheet '{sheet_name}' has no 'Stock' column. Skipping.")
        continue

    # Normalise stock names (strip spaces)
    #df["Stock_clean"] = df["Stock"].astype(str).str.strip()
    df["Stock_clean"] = df["Stock"]

    # --- Start filtering ---
    mask = df["Stock_clean"].isin(valid_stocks)

    # Also remove rows where Type is "Div" (if the column exists)
    if "Type" in df.columns:
        # Normalise Type: strip spaces, case-sensitive (adjust if needed)
        df["Type_clean"] = df["Type"].astype(str).str.strip()
        mask = mask & (df["Type_clean"] != "Div")
        # Drop temporary Type_clean later
    else:
        print(f"⚠️ Sheet '{sheet_name}' has no 'Type' column – skipping type filter.")

    filtered_df = df[mask].copy()

    # Drop temporary columns
    drop_cols = ["Stock_clean"]
    if "Type_clean" in filtered_df.columns:
        drop_cols.append("Type_clean")
    filtered_df = filtered_df.drop(columns=drop_cols, errors="ignore")

    # --- 4. Save to CSV ---
    output_file = f"/home/rizpython236/BT5/screener-outputs/{output_prefix}{sheet_name}.csv"
    filtered_df.to_csv(output_file, index=False)
    print(f"✅ Saved {len(filtered_df)} rows to '{output_file}'.")

print("🎉 Done.")

ff
















import sys

import bottleneck as bn
from pkg_resources import working_set


bn.test()


f


print("Python version:", sys.version)

installed_packages = sorted([f"{i.key}=={i.version}" for i in working_set])
print("\n".join(installed_packages))

import subprocess


def create_requirements_txt(filename="requirements_new.txt"):
  """
  Creates a requirements.txt file listing installed packages.

  Args:
      filename (str, optional): The filename for the requirements.txt. Defaults to "requirements.txt".
  """
  # Run pip freeze command and capture output
  process = subprocess.Popen(["pip", "freeze"], stdout=subprocess.PIPE)
  output, error = process.communicate()

  # Check for errors
  if error:
    raise RuntimeError(f"Error generating requirements.txt: {error}")

  # Write package names to file
  with open(filename, "w") as f:
    f.write(output.decode())

  print(f"Contents of {filename}:\n{output.decode()}")
  print(f"Created requirements.txt: {filename}")

# Example usage
create_requirements_txt()

'''
########################

import os
import pandas as pd

# Define paths
folder_path = '/home/rizpython236/BT5/ticker_15yr/'
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'

# Read symbols from the CSV file
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()
symbols = list(dict.fromkeys(symbols))  # Remove duplicates

# Iterate over files in the folder
for file_name in os.listdir(folder_path):
    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            base_name = os.path.splitext(file_name)[0]

            # Check if the base name is not in the symbols list
            if base_name not in symbols:
                os.remove(file_path)  # Delete the file
                print(f"Deleted: {file_path}")

    except Exception as e:
        print(f"Error processing file {file_name}: {e}")
'''