import sys

import bottleneck as bn
from pkg_resources import working_set


bn.test()


f


print("Python version:", sys.version)

installed_packages = sorted([f"{i.key}=={i.version}" for i in working_set])
print("\n".join(installed_packages))

import subprocess


def create_requirements_txt(filename="requirements_new.txt"):
  """
  Creates a requirements.txt file listing installed packages.

  Args:
      filename (str, optional): The filename for the requirements.txt. Defaults to "requirements.txt".
  """
  # Run pip freeze command and capture output
  process = subprocess.Popen(["pip", "freeze"], stdout=subprocess.PIPE)
  output, error = process.communicate()

  # Check for errors
  if error:
    raise RuntimeError(f"Error generating requirements.txt: {error}")

  # Write package names to file
  with open(filename, "w") as f:
    f.write(output.decode())

  print(f"Contents of {filename}:\n{output.decode()}")
  print(f"Created requirements.txt: {filename}")

# Example usage
create_requirements_txt()

'''
########################

import os
import pandas as pd

# Define paths
folder_path = '/home/rizpython236/BT5/ticker_15yr/'
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'

# Read symbols from the CSV file
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()
symbols = list(dict.fromkeys(symbols))  # Remove duplicates

# Iterate over files in the folder
for file_name in os.listdir(folder_path):
    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            base_name = os.path.splitext(file_name)[0]

            # Check if the base name is not in the symbols list
            if base_name not in symbols:
                os.remove(file_path)  # Delete the file
                print(f"Deleted: {file_path}")

    except Exception as e:
        print(f"Error processing file {file_name}: {e}")
'''