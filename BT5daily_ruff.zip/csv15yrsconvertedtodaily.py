import os
import sys
import time

import numpy as np
import pandas as pd
import pytz
from scipy import stats
import talib as tb
from telegram_bot import post_telegram_file, post_telegram_message


sys.path.append("/home/rizpython236/.virtualenvs/rizenvnew/lib/python3.7/site-packages/")
import csv
from datetime import datetime
import traceback

import pandas_ta as ta
from PDFconvert import create_pdf


'''
input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.pdf')
ggg
'''

Monday=True
IST_TIMEZONE = pytz.timezone("Asia/Kolkata")
today=datetime.now(IST_TIMEZONE).date()
ISTnow=datetime.now(IST_TIMEZONE)
weekday = datetime.now(IST_TIMEZONE).strftime("%A")
print(weekday)


current_datetimeUTC = datetime.now()
weekdayUTC = datetime.now().strftime("%A")

formatted_datetimeUTC = current_datetimeUTC.strftime("%d %b %Y %I:%M %p")
formatted_datetimeIST = ISTnow.strftime("%d %b %Y %I:%M %p")

day=today.weekday() == 1



print("Start csv15yrs")


def is_range_bound(dataR, window=100, slope_threshold=0.02):
  """
  Checks if a stock is range-bound based on price slope and historical volatility.

  Args:
    data: A pandas DataFrame containing OHLC (Open, High, Low, Close) data.
    window: Lookback window for slope calculation (default: 20 days).
    slope_threshold: Absolute value threshold for low slope (default: 0.02).

  Returns:
    True if the stock is considered range-bound, False otherwise.
  """

  # Calculate closing price slope
  data=dataR
  data["Slope"] = np.polyfit(range(window), data["Close"].iloc[-window:], 1)[0]

  # Calculate Average True Range (ATR)
  atr = data["High"].max(axis=0) - data["Low"].min(axis=0) - np.abs(
      data["Close"].shift(1) - data["Open"]
  )
  atr = atr.ewm(alpha=1 / window, min_periods=window).mean()

  #print((data["Slope"].iloc[-1]))
  # Check range-bound conditions
  return (data["Slope"].iloc[-1]) #<= slope_threshold #and np.mean(atr)*3 > 0.005

# Function to calculate adjusted R-squared
def adjusted_r_squared(y, x, slope, intercept,r_value):
    #y_pred = intercept + slope * x
    #ss_total = np.sum((y - np.mean(y)) ** 2)
    #ss_residual = np.sum((y - y_pred) ** 2)
    #r_squared = 1 - (ss_residual / ss_total)
    r_squared = r_value
    n = len(y)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    return adj_r_squared

def calculate_exponential_linear_regression(df,period=12):
    # Download historical data from yfinance
    data  = df.iloc[-(period+5):] # yf.download(stock_symbol, period="1y")
    data=df
    #print(data)

    # Calculate the natural logarithm of returns
    returns = np.log(data['Close'])
    #print(returns)
    x = np.arange(len(returns))
    #print(x)

    #slope, intercept, r_value, p_value, std_err = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x))
    #print(slope, intercept, r_value, p_value, std_err )
    slope = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[0])
    #annualized_slope = (np.power(np.exp(slope), 252) - 1) * 100
    annualized_slope = (np.power((1+slope), 252)) *100
    r_value = returns.rolling(window=period).apply(lambda x: stats.linregress(np.arange(len(x)), x)[2])
    r_squared = r_value
    n = len(x)
    k = 1  # Number of predictors (independent variables)
    adj_r_squared = 1 - ((1 - r_squared) * (n - 1) / (n - k - 1))
    annualized_slope_r_value = round(annualized_slope * (adj_r_squared ** 2), 2)

    #print(slope)
    #print(annualized_slope)

    # Calculate linear regression
    #slope, _, r_value, _, _ = stats.linregress(x, returns)

    # Calculate annualized slope
    #annualized_slope = (np.power(np.exp(slope), 52) - 1) * 100

    # Calculate annualized_slope_r_value
    #annualized_slope_r_value = round(annualized_slope * (r_value ** 2), 2)

    # Round the annualized slope and annualized_slope_r_value
    #rounded_annualized_slope = round(annualized_slope, 2)

    # Find the maximum value between annualized_slope_r_value and rounded_annualized_slope
    higher_value = annualized_slope_r_value #np.maximum(annualized_slope_r_value, rounded_annualized_slope)

    return higher_value


# Specify the folder path containing CSV files
folder_path = '/home/rizpython236/BT5/ticker_daily1yr/'  # Replace with the actual folder path
#ticker_path = '/home/rizpython236/BT5/myholding.csv'
ticker_path = '/home/rizpython236/BT5/symbol_list.csv'
ticker_df = pd.read_csv(ticker_path)
symbols = ticker_df['Symbol'].tolist()[:]
symbols = list(dict.fromkeys(symbols))  #list(set(symbols))
indices= ['^NSEI', 'BSE-500.BO', '^NSEMDCP50', 'NIFTYSMLCAP250.NS', 'NIFTY_MICROCAP250.NS', 'BSE-IPO.BO', 'BTC-USD', 'GOLDBEES.NS', '^NSEBANK', 'PSUBNKBEES.BO', '^CNXPSUBANK', 'NIFTYPVTBANK.NS', 'NIFTY_FIN_SERVICE.NS', '^CNXAUTO', '^CNXREALTY', '^CNXCMDT', '^CNXMETAL', '^CNXINFRA', 'ICICIINFRA.NS', 'PHARMABEES.NS', '^CNXPHARMA', '^CNXFMCG', '^CNXCONSUM', '^CNXIT', '^CNXENERGY', '^CRSLDX', 'MON100.NS', 'MAFANG.NS','HNGSNGBEES.NS', 'MAHKTECH.NS', 'SBIGETS.BO', 'AXISCETF.NS']

NSE570_path = '/home/rizpython236/BT5/Finalnse.csv'
NSE570ticker_df = pd.read_csv(NSE570_path)
NSE570symbols = NSE570ticker_df['Symbol'].tolist()[:]
#NSE570symbols = list(dict.fromkeys(symbols))
NSE570symbols = list(set(NSE570symbols))
#print(len(NSE570symbols))



selected_files = []

valid_file = '/home/rizpython236/BT5/trade-logs/valid_tickers.csv'
valid_df = pd.read_csv(valid_file)
symbol_to_company = dict(zip(valid_df['Symbol'], valid_df['Company']))


# Initialize counters for MRP13 and MRP25
CountBExp = 0
mrp13_count_more0 = 0
mrp25_count_less0 = 0
mrp25_count_more0 = 0
mrp13_countbothless0 = 0
mrp25_countbothmore0 = 0
CountS_DCH = 0
total_files = 0
file_names = []
Bullish = []
Bearish = []
Start_countmore0 = 0
mrp25_count_mores10 = 0
mrp25_mores10 = []
mrp25_count_M1L1 =[]
mrp25_count_M1L2 =[]
CountS_TTMSqueeze =0
CountS_fall =0
S_TTMSqueeze=[]
S_fall=[]
S_DCH =[]
CountS_EMA=0
S_EMS=[]
BExpShort=[]
CountBExplong=0
BExplong=[]
CountB52high =0
B52High=[]
CountBRSI = 0
BRSI =[]
CountBMRP = 0
BMRP =[]
CountBBTTM =0
BBBTTM = []
CountFinalSell=0
FinalSell=[]
CountFinalBUY=0
FinalBUY=[]
S_ROC =[]
S_DD_PCT_30 =[]
B_DD_PCT_30 =[]
expLonly =[]
expSonly =[]
indiceNOLONG=[]
indiceNOSHORT=[]
EFIU=[]
EFID=[]
SMA_V7SMA_V40=[]
_52wkL= []
_52wkH= []
_52wkrange=[]
SMAUP=[]
SMADWN=[]
RSIUP=[]
RSIDWN=[]
DDPCTlist=[]
MRPUP=[]
MRPDWN =[]
Pos1yrHigh=[]
maxVx=[]
MRPcross=[]
SMAcross=[]

def rolling_two_largest(x):
  # Convert window to pandas Series (recommended from previous solution)
  window_series = pd.Series(x)
  # Sort the window in descending order
  sorted_window = window_series.sort_values(ascending=False)
  # Fill with NaNs and replace top 2 with actual values
  result = pd.Series(np.nan * len(x))
  result.iloc[0:2] = sorted_window.head(2)
  #print(result)
  return result

# Loop through all files in the folder
for file_name in os.listdir(folder_path):
    try:
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            #total_files += 1
            base_name = os.path.splitext(file_name)[0]
            #file_names.append(base_name)
            #print(base_name)


            if base_name in symbols:
                file_path = os.path.join(folder_path, file_name)
                selected_files.append(file_path)
                total_files += 1

                # Read the CSV file into a DataFrame
                df = pd.read_csv(file_path)
                dfexp=df
                dataR=df

                #print(df)

                #df['CCI'] = df.ta.cci(df['High'], df['Low'], df['Close'], window=34)
                #df['CCI'] = tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34)
                #df['CCIavg'] = tb.SMA(df['CCI'], timeperiod=12)
                #df['ADX'] = tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['macd'], df['macdsignal'], df['macdhist'] = tb.MACD(df['Close'], fastperiod=12, slowperiod=26, signalperiod=9)
                #df['ATR'] = tb.ATR(df['High'], df['Low'], df['Close'], timeperiod=10)
                #df['SuperTrend_Upper_Band'] = df['High'] + (3 * df['ATR'])
                #df['SuperTrend_Lower_Band'] = df['Low'] - (3 * df['ATR'])
                #df['SuperTrend'] = (df['SuperTrend_Upper_Band'] + df['SuperTrend_Lower_Band']) / 2
                #df['VolumeSMA'] = tb.SMA(df['Volume'], timeperiod=14)

                ###############################
                df["CCI"]=tb.CCI(df['High'], df['Low'], df['Close'], timeperiod=34*5)
                df["CCImovavgL"] = tb.SMA(df["CCI"], timeperiod=14)
                df["CCImovavgS"] = tb.SMA(df["CCI"], timeperiod=7)
                df["macd"], df["macdsignal"], df["macdhist"] = tb.MACDEXT(df['Close'], fastperiod=12, fastmatype=0, slowperiod=26, slowmatype=0, signalperiod=9, signalmatype=0)
                df["ADX"]= tb.ADX(df['High'], df['Low'], df['Close'], timeperiod=18*5)
                df["ADXavg"] = tb.SMA(df["ADX"], timeperiod=14)
                #df['PLUS_DI'] = tb.PLUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                #df['MINUS_DI'] = tb.MINUS_DI(df['High'], df['Low'], df['Close'], timeperiod=14)
                df["RSI"] = tb.RSI(df['Close'], timeperiod=34*5)
                df["RSIavg"] = tb.EMA(df["RSI"], timeperiod=7)
                df["OBV"] = tb.OBV(df['Close'], df['Volume'])
                df["obvmovavg"] = tb.SMA(df["OBV"], timeperiod=14)
                supertrend_values= ta.supertrend(high=df['High'], low=df['Low'], close=df['Close'], length=10, multiplier=3)#, offset=None,)#(df['High'], df['Low'], df['Close'], period=10, multiplier=3)
                df['ST'] = supertrend_values['SUPERT_10_3.0']
                #df["SMA_20"] = tb.SMA(df['Close'], timeperiod=20)
                #df["SMA_50"] = tb.SMA(df['Close'], timeperiod=50)
                df["SMA_200"] = tb.SMA(df['Close'], timeperiod=200)
                df["SMA_100"] = tb.SMA(df['Close'], timeperiod=100)
                df["EMA_100"] = tb.SMA(df['Close'], timeperiod=100)
                df["EMA_200"] = tb.EMA(df['Close'], timeperiod=200)
                #df["EMA_7W"] = tb.EMA(df['Close'], timeperiod=7)
                #df["EMA_5W"] = tb.EMA(df['Close'], timeperiod=5)
                #donchian_values=ta.donchian(df['High'], df['Low'], lower_length=20, upper_length=20, offset=None,)
                #df= pd.concat([df, donchian_values], axis=1)
                #df["DCH"]= ((df["DCU_20_20"] - df["DCL_20_20"]) / (df["DCU_20_20"] / 1)) * 100
                #df["DCHema"] = tb.SMA(df["DCH"], timeperiod=14)
                df['Exp_lin_reg']= exp12 = calculate_exponential_linear_regression(df,period=120)
                df['Exp_lin_regslow']= exp50 = calculate_exponential_linear_regression(df,period=180)
                #df["upperband"], df["middleband"], df["lowerband"] = tb.BBANDS(df['Close'], timeperiod=20, nbdevup=2, nbdevdn=2, matype=0)
                #squeeze_pro=ta.squeeze_pro(df['High'], df['Low'], df['Close'], bb_length=20, bb_std=2, kc_length=20, kc_scalar_wide=2, kc_scalar_normal=1.5, kc_scalar_narrow=1, mom_length=12, mom_smooth=6,)# use_tr=None, mamode=None,)
                ##print(squeeze_pro) # //WIDE SQUEEZE: ORANGE , NORMAL SQUEEZE: RED ,NARROW SQUEEZE: YELLOW ,FIRED WIDE SQUEEZE: GREEN ,NO SQUEEZE: BLUE
                #df= pd.concat([df, squeeze_pro], axis=1)
                #df['ROC_1']=tb.ROC(df['Close'], timeperiod=1)
                df['ROC_2']=tb.ROC(df['Close'], timeperiod=2)
                #df['ROC_4']=tb.ROC(df['Close'], timeperiod=4)
                #df['ROC_12']=tb.ROC(df['Close'], timeperiod=12)
                #df['ROC_24']=tb.ROC(df['Close'], timeperiod=24)
                #df['ROC_51']=tb.ROC(df['Close'], timeperiod=51)
                #df["SMA_V200"] = tb.EMA(df['Volume'], timeperiod=200)
                #df["SMA_V200"] = tb.MAX(df['Volume'], timeperiod=51)
                #df["SMA_V50"] = tb.SMA(df['Volume'], timeperiod=50)
                df["SMA_V40"] = tb.SMA(df['Volume'], timeperiod=20)
                df["SMA_V7"] = tb.SMA(df['Volume'], timeperiod=7)
                #df["SMA_V4"] = tb.SMA(df['Volume'], timeperiod=4)
                try:
                    df["SMA_30MRP"] = tb.EMA(df['MRP'], timeperiod=90)
                    df["SMA_90MRP"] = tb.EMA(df['MRP'], timeperiod=200)
                except Exception as e:
                    1+1
                df["MaxcloseH"] = tb.MAX(df['Close'])# timeperiod=252)
                df["MaxcloseL"] = tb.MIN(df['Close'])# timeperiod=252)
                df["52wkH"] = tb.MAX(df['Close'], timeperiod=252)
                df["52wkL"] = tb.MIN(df['Close'], timeperiod=252)
                df["MaxVx22"] = tb.MAX(df['Volume'], timeperiod=252) #252*3.5)
                quantile= ta.quantile(close=df['Volume'], length=252, q=.7, offset=None)#,
                df['quantile'] = quantile# ['QTL_958_0.75']
                df["SMA_V3yr"] = tb.SMA(df['Volume'], timeperiod=252) #252*3.5)
                MaxVx =round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-7]*.6),2)
                MaxVxM =round(df['Volume'].iloc[-1]/(df["MaxVx22"].iloc[-7]),2)
                pos1yr= round((df['Close'].iloc[-1]-df["52wkL"].iloc[-1])*1/(df["52wkH"].iloc[-1]-df["52wkL"].iloc[-1]),2)
                #df["RangeBND"] = is_range_bound(dataR, window=200, slope_threshold=0.02)
                #print(df['Volume'].iloc[-1])
                #df["MaxVx"] = df['Volume'].rolling(window=25*3).apply(rolling_two_largest, raw=True).mean(axis=1)
                #try:
                #    df["MaxVx1"] = df['Volume'].rolling(window=252*3).max() #tb.MAX(df['Volume'], timeperiod=252*3)
                #    MaxVxmax = df["MaxVx1"].iloc[-7]*.70
                #    df["MaxVx"] = df['Volume'].rolling(window=(252*3)).apply(lambda x: x.nlargest(2).mean(), raw=True)
                #    MaxVx1 = round(df['Volume'].iloc[-1]/df["MaxVx"].iloc[-3],2)
                #    #print(df["MaxVx"].iloc[-1])
                #    print(df["MaxVx22"])
                #except Exception as e:
                #    MaxVx1 = 0
                #    #print(f"csvVXdaily error: {e}")
                #print(df['Volume'].iloc[-1])
                #print(df["MaxVx"]==df["MaxVx1"])




                    ######################
                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and df["DD_PCT"].iloc[-1] > 5 and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 and df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05:#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0 ) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["52wkL"].iloc[-1]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        ST ="UP" if df["ST"].iloc[-1] > df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        data = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "ROC2": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP": MRP,
                                    #"ROC_2": ROC_2,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBV52wk":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%1yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        DDPCTlist.append(data)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and pos1yr > .70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 and df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] > df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataPos1yrHigh = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "ROC2": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP":MRP,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    "OBV_CATH":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "VX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%1yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        Pos1yrHigh.append(dataPos1yrHigh)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                if 2>0:#base_name in NSE570symbols:
                    if len(df) > 0 and MaxVx > 1 and df['quantile'].iloc[-7]*1 < df["Volume"].iloc[-1] :#  df['quantile'].iloc[-7] and pos1yr > .70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= MaxVxM
                        MRP= f"{round(df['MRP'].iloc[-2], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 else 'D'}"
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] > df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        datamaxVx = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "ROC2": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "MRP":MRP,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    #"OBV_CATH":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "MaxVX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%1yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        #print(datamaxVx)
                        maxVx.append(datamaxVx)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                if 2>0:#base_name in NSE570symbols:
                    if (df['SMA_30MRP'].iloc[-1]*1.05 < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]*1.05) or (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 and df['SMA_30MRP'].iloc[-5]*1.05 < df['SMA_90MRP'].iloc[-5])  :#  df['quantile'].iloc[-7] and pos1yr > .70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        MRP= round(df['MRP'].iloc[-2], 2)
                        MRPUPaa= (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 and df['SMA_30MRP'].iloc[-5]*1.05 < df['SMA_90MRP'].iloc[-5])
                        MRPDWaa= (df['SMA_30MRP'].iloc[-1]*1.05 < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]*1.05)
                        #MRPUP1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] < df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRPDW1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else 'D'}"
                        MRPUP1= MRP if (MRPUPaa == True) else np.nan  #1234567890000
                        MRPDW1=  MRP if (MRPDWaa == True) else np.nan #1234567890000
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        #OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        #LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] > df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        SMA200UP = "UP" if df["EMA_200"].iloc[-1] < df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataMRPcross = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    "MRPUP":MRPUP1,
                                    "MRPDW":MRPDW1,
                                    "ROC2": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    #"OBV_CATH":OBV52wk,
                                    "EMA200":SMA200UP,
                                    "MaxVX": VX,
                                    "Pos1yr":pos1yr,
                                    "DD%1yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        #print(datamaxVx)
                        MRPcross.append(dataMRPcross)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)


                Base_name=symbol_to_company.get(base_name, base_name)
                NSE570s = "Y" if base_name in NSE570symbols  else ""
                if 2>0:#base_name in NSE570symbols:
                    if (df['EMA_100'].iloc[-5]*1.05 < df['EMA_200'].iloc[-1] and df['SMA_30MRP'].iloc[-5]*1.05 < df['SMA_90MRP'].iloc[-1]) and NSE570s == "Y" :#  df['quantile'].iloc[-7] and pos1yr > .70 and df["ADXavg"].iloc[-1] < df["ADX"].iloc[-1] > 25 and df["CCImovavgL"].iloc[-1] < df["CCI"].iloc[-1] and  40 < df["RSI"].iloc[-1] > df["RSIavg"].iloc[-1] and (df['Exp_lin_reg'].iloc[-1] or df['Exp_lin_regslow'].iloc[-1]) > -10 :#and (df["MRP13"].iloc[-1] or df["MRP25"].iloc[-1]) > 0:
                        Base_name=symbol_to_company.get(base_name, base_name)
                        #print(Base_name)
                        DD_PCT=int(df["DD_PCT"].iloc[-1])
                        DD_PCT=f"{int(DD_PCT)}%"
                        VX= round(df['SMA_V7'].iloc[-1]/df["SMA_V40"].iloc[-8],2)
                        MRP= round(df['MRP'].iloc[-2], 2)
                        #MRPUPaa= (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1]*1.05 and df['SMA_30MRP'].iloc[-5]*1.05 < df['SMA_90MRP'].iloc[-5])
                        #MRPDWaa= (df['SMA_30MRP'].iloc[-1]*1.05 < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]*1.05)
                        #MRPUP1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] < df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRPDW1= float(f"{MRP if (df['SMA_30MRP'].iloc[-1] < df['SMA_90MRP'].iloc[-1] and df['SMA_30MRP'].iloc[-5] > df['SMA_90MRP'].iloc[-5]) else ''}")
                        #MRP= f"{round(df['MRP'].iloc[-1], 2)} {'U' if df['SMA_30MRP'].iloc[-1] > df['SMA_90MRP'].iloc[-1] else 'D'}"
                        #MRPUP1= MRP if (MRPUPaa == True) else np.nan  #1234567890000
                        #MRPDW1=  MRP if (MRPDWaa == True) else np.nan #1234567890000
                        RSI = int(df["RSI"].iloc[-1])
                        ADX = int(df["ADX"].iloc[-1])
                        CCI = int(df["CCI"].iloc[-1])
                        MACD = "UP" if (df["macdhist"].iloc[-1] > 0) else ""
                        NSE570s = "Y" if base_name in NSE570symbols  else ""
                        #OBV52wk ="UP" if (df["Close"].iloc[-14:] == df["MaxcloseH"].iloc[-14]).any() and (df["obvmovavg"].iloc[-1] < df["OBV"].iloc[-1]) else ""
                        #LNEXP20 =int(df['Exp_lin_reg'].iloc[-1])
                        #LNEXP20= LNEXP20 if LNEXP20 > 20 else ""
                        LNEXP50 = int(df['Exp_lin_regslow'].iloc[-1])
                        #LNEXP50= LNEXP50 if LNEXP50 > 20 else ""
                        ST ="UP" if df["ST"].iloc[-1] > df['Close'].iloc[-1] else ""
                        ROC_2= int(df['ROC_2'].iloc[-1])
                        sma_crossover = df[df['EMA_200'] > df['EMA_100'] * 1]['EMA_200'].iloc[-1]
                        SMA200pctnumber = int((df['Close'].iloc[-1] - sma_crossover) / sma_crossover * 100)
                        #SMA200pct= SMA200pctnumber if (SMA200pctnumber > -10) else np.nan #1234567890000
                        #SMA200UP = "DW" if df["EMA_200"].iloc[-1] > df["EMA_100"].iloc[-1] else ""# and df["SMA_200"].iloc[-2] > df["SMA_100"].iloc[-2] else ""
                        #SMA200DWN ="DOWN" if df["SMA_200"].iloc[-1] > df["SMA_100"].iloc[-1] and df["SMA_200"].iloc[-2] < df["SMA_100"].iloc[-2] else ""
                        #value_to_append = f"{Base_name}#{round(df['Exp_lin_reg'].iloc[-1], 1)}#{round(df['Exp_lin_regslow'].iloc[-1], 1)}"
                        #value_to_append1 = f"{Base_name}*{int(df['RSI'].iloc[-1])}*{int(VX)}*{int(CCI)}*{int(MRPx)}***{int(DD_PCT)}"
                        dataSMAcross = {
                                    "Company": Base_name,
                                    "N570":NSE570s,
                                    #"MRPUP":MRPUP1,
                                    #"MRPDW":MRPDW1,
                                    "MRP":MRP,
                                    "ROC2": ROC_2,
                                    "RSI": RSI,
                                    "CCI": CCI,
                                    "ADX": ADX,
                                    "MACD":MACD,
                                    "ST":ST,
                                    #"EXP20":LNEXP20,
                                    "EXP50":LNEXP50,
                                    #"MA200UP":SMA200UP,
                                    #"OBV_CATH":OBV52wk,
                                    #"EMA200":SMA200UP,
                                    "MaxVX": VX,
                                    "SMA200pct":SMA200pctnumber,
                                    "Pos1yr":pos1yr,
                                    "DD%1yr": DD_PCT
                                }
                        # Append the dictionary to DDPCTlist
                        #print(datamaxVx)
                        SMAcross.append(dataSMAcross)
                        #DDPCTlist.append(value_to_append1)
                        #indiceNOLONG.append(value_to_append1)

                ##########################
    except Exception as e:
        print(f"csvVXdaily {Base_name} error: {e}")
        traceback_str = traceback.format_exc()
        # Print detailed error information
        print("Error type:", e.__class__.__name__)
        print("Error message:", str(e))
        print("Traceback:\n", traceback_str)
        pass

##########################
print("__________________________________________________________")



'''
#expLonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
#expSonly.sort(key=lambda x: float(x.split('-')[-1].split('--')[0]))
EFIU.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
EFID.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
SMA_V7SMA_V40.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkL.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkH.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
_52wkrange.sort(key=lambda x: float(x.split('*')[-1].split('**')[0]), reverse=True)
SMAUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
SMADWN.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
RSIDWN.sort(key=lambda x: float(x.split('***')[-1]), reverse= False) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
#DDPCTlist.sort(key=lambda x: float(x.split('***')[-1]), reverse=True)
MRPUP.sort(key=lambda x: float(x.split('***')[-1]), reverse=True) #SMAUP.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
MRPDWN.sort(key=lambda x: float(x.split('***')[-1]), reverse=False) #SMADWN.sort(key=lambda x: float(x.split('**')[-1].split('***')[0]), reverse=True)
'''
'''
#indiceNOSHORT.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOSHORT[0] = 'Indices Exp lin Short-Long'

#indiceNOLONG.sort(key=lambda x: float(x.split('-')[-1]))
indiceNOLONG[0] = 'Indices Exp lin Long'

for i in range(0, len(indiceNOSHORT), 35):
        block = indiceNOSHORT[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        ##post_telegram_message('\n'.join(block))

for i in range(0, len(indiceNOLONG), 35):
        block = indiceNOLONG[i:i+35]
        #print('\n'.join(block))
        time.sleep(2)
        #post_telegram_message('\n'.join(block))
'''
# Calculate percentages
#Exp_percentage_mores40 = (S_TTMSqueeze / total_files) * 100
#print(Exp_percentage_mores40)

#mrp25_percentage_mores10 = (mrp25_count_mores10 / total_files) * 100
#mrp13_percentageless0 = (CountBExp / total_files) * 100
#mrp13_percentagemore0 = (mrp13_count_more0 / total_files) * 100
#mrp25_percentageless0 = (mrp25_count_less0 / total_files) * 100
#mrp25_percentagemore0 = (mrp25_count_more0 / total_files) * 100
#mrp25_percentagebothless0 = (mrp13_countbothless0 / total_files) * 100
#mrp25_percentagebothmore0 = (mrp25_countbothmore0 / total_files) * 100
#df = pd.DataFrame({'RP': file_names})
#df = pd.DataFrame({'BullCandle': Bullish})
#df = pd.DataFrame({'BearCandle': Bearish})
BUYmax_length = max(len(file_names), len(BExpShort), len(BExplong), len(B52High) , len(BRSI),len(BMRP),len(BBBTTM),len(B_DD_PCT_30) )
SELLmax_length = max(len(file_names), len(S_TTMSqueeze),len(S_ROC), len(S_fall), len(S_DCH) , len(S_EMS),len(S_DD_PCT_30),)

expmax_length = max(len(file_names), len(expSonly),len(expLonly),len(BExpShort),len(BExplong),len(EFIU),len(EFID))#,len(indiceNO))
VXmax_length = max(len(file_names), len(EFIU),len(EFID),len(SMA_V7SMA_V40))
_52wk_length = max(len(file_names), len(_52wkH),len(_52wkL),len(_52wkrange))
SMA_length = max(len(file_names), len(SMAUP),len(SMADWN),len(SMADWN))
RSI_length = max(len(file_names), len(RSIUP),len(RSIDWN),len(RSIDWN))
#DDPCTlist_length = max(len(file_names), len(DDPCTlist),len(DDPCTlist),len(DDPCTlist))
MRP_length = max(len(file_names), len(MRPUP),len(MRPUP),len(MRPDWN))

'''
MRPlist_data = {
    'MRPUP*RSI**VX***MRP': MRPUP + ['--'] * (MRP_length - len(MRPUP)),
    'MRPDWN*RSI**VX***MRP': MRPDWN + ['--'] * (MRP_length - len(MRPDWN))
}


#DDPCTlist_data = {
#    'DD*RSI*VX*CCI*MRP***DDPCT': DDPCTlist + ['--'] * (DDPCTlist_length - len(DDPCTlist))
#}

RSI_data = {
    'RSIUP*CCI**Vx***RSI': RSIUP + ['--'] * (RSI_length - len(RSIUP)),
    'RSIDWN*CCI**Vx***RSI': RSIDWN + ['--'] * (RSI_length - len(RSIDWN))
    #'52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}


SMA_data = {
    'SMAUP*CCI**Vx***RSI': SMAUP + ['--'] * (SMA_length - len(SMAUP)),
    'SMADWN*CCI**Vx***RSI': SMADWN + ['--'] * (SMA_length - len(SMADWN))
    #'52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

_52wkdata = {
    '52wkH-RSI-CCI--UP': _52wkH + ['--'] * (_52wk_length - len(_52wkH)),
    '52wkL-pos1yr-RSI-CCI--DWN': _52wkL + ['--'] * (_52wk_length - len(_52wkL)),
    '52wkrange-Rally--Vx': _52wkrange + ['--'] * (_52wk_length - len(_52wkrange))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

expdata = {
    'ExpShort-L--S': expSonly + ['--'] * (expmax_length - len(expSonly)),
    'ExpLong-S--L': expLonly + ['--'] * (expmax_length - len(expLonly))
    #'EFIUP-ROC--UP': EFIU + ['--'] * (expmax_length - len(EFIU)),
    #'EFIDWN-ROC--DWN': EFID + ['--'] * (expmax_length - len(EFID))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

VXdata = {
    #'ExpShort-L--S': expSonly + ['--'] * (expmax_length - len(expSonly)),
    #'ExpLong-S--L': expLonly + ['--'] * (expmax_length - len(expLonly))
    'EFIUP-ROC-CCI--UP': EFIU + ['--'] * (VXmax_length - len(EFIU)),
    'EFIDWN-ROC-CCI--DWN': EFID + ['--'] * (VXmax_length - len(EFID)),
    'SMA_V7/V40-ROC--V': SMA_V7SMA_V40 + ['--'] * (VXmax_length - len(SMA_V7SMA_V40))
    #'IndicesEp': indiceNO + ['--'] * (expmax_length - len(indiceNO)),
    #'ExpShortun': BExpShort + ['--'] * (expmax_length - len(BExpShort)),
    #'ExplongUn': BExplong + ['--'] * (expmax_length - len(BExplong))
}

BUYdata = {
    'TTM': BBBTTM + ['--'] * (BUYmax_length - len(BBBTTM)),
    #'ExpShort': BExpShort + ['--'] * (BUYmax_length - len(BExpShort)),
    #'Explong': BExplong + ['--'] * (BUYmax_length - len(BExplong)),
    'RSI': BRSI + ['--'] * (BUYmax_length - len(BRSI)),
    'DD_PCT_25': B_DD_PCT_30 + ['--'] * (BUYmax_length - len(B_DD_PCT_30)),
    '52High': B52High + ['--'] * (BUYmax_length - len(B52High)),
    'MRP': BMRP + ['--'] * (BUYmax_length - len(BMRP))
}

SELLdata = {
    'TTM': S_TTMSqueeze + ['--'] * (SELLmax_length - len(S_TTMSqueeze)),
    'ROC': S_ROC + ['--'] * (SELLmax_length - len(S_ROC)),
    'Fall': S_fall + ['--'] * (SELLmax_length - len(S_fall)),
    'DD_PCT_25': S_DD_PCT_30 + ['--'] * (SELLmax_length - len(S_DD_PCT_30)),
    'DCH': S_DCH + ['--'] * (SELLmax_length - len(S_DCH)),
    'SEMA200': S_EMS + ['--'] * (SELLmax_length - len(S_EMS))
}
'''


dfBUY = pd.DataFrame() #BUYdata
dfSELL = pd.DataFrame() #SELLdata
dfexpdata = pd.DataFrame() #expdata
dfVXdata = pd.DataFrame() #VXdata
df52wkdata = pd.DataFrame() #_52wkdata
dfSMA_data = pd.DataFrame() #SMA_data
dfRSI_data = pd.DataFrame() #RSI_data
#dfDDPCTlist_data =pd.DataFrame(DDPCTlist_data)
#dfMRPlist_data =pd.DataFrame(MRPlist_data)

#print(dfBUY)
#print(dfSELL)
#print(dfexpdata)


old52wkdataWkly_path = '/home/rizpython236/BT5/trade-logs/52wkdatadaily.csv'
old52wkdataWklydf = pd.read_csv(old52wkdataWkly_path)

'''
#dfBUY.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv', index=False)
#dfSELL.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv', index=False)
#dfexpdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv', index=False)
dfVXdata.to_csv('/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv', index=False)
dfSMA_data.to_csv('/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv', index=False)
df52wkdata.to_csv('/home/rizpython236/BT5/trade-logs/52wkdatadaily.csv', index=False)
dfRSI_data.to_csv('/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv', index=False)
#dfDDPCTlist_data.to_csv('/home/rizpython236/BT5/screener-outputs/DDPCTdatadaily.csv', index=False)
dfMRPlist_data.to_csv('/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv', index=False)
'''
#print(DDPCTlist)
try:
    #print(DDPCTlist)
    if len(SMAcross) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''
        SMAcross.sort(key=lambda row: row["SMA200pct"], reverse=False)
        #SMAcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(MRPcross)
        SMAcross = pd.DataFrame(SMAcross)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        SMAcross.fillna("", inplace=True)
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        SMAcross.to_csv('/home/rizpython236/BT5/screener-outputs/SMAcross1yrdaily.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT1yrdaily.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"SMAcross1yrdaily.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/SMAcross1yrdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/SMAcross1yrdaily.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/SMAcross1yrdaily.pdf')
    else:
      print("No data found to write to SMAcross1yrdaily.csv")
except Exception as e:
    print(f"Error in pdf SMAcross1yrdaily- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")

try:
    #print(DDPCTlist)
    if len(MRPcross) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["MRPUP"] > -100, row["ADX"], row["MRPUP"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        '''
        def sort_by_roc_and_maxvx(row):
          try:
            # Attempt to convert MRPUP to a float
            mrpup_value = float(row["MRPUP"])
          except ValueError:
            # Handle potential conversion errors (e.g., set to 0 or NaN)
            mrpup_value = 0  # Or another default value based on your logic
          return (mrpup_value > 0, row["ADX"], mrpup_value)
        '''

        MRPcross.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(MRPcross)
        MRPcross = pd.DataFrame(MRPcross)
        #MRPcross.replace(1234567890000, np.nan, inplace=True)
        MRPcross.fillna("", inplace=True)
        #MRPcross.fillna(1234567890000, inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        MRPcross.to_csv('/home/rizpython236/BT5/screener-outputs/MRPcross1yrdaily.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT1yrdaily.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"MRPcross1yrdaily.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/MRPcross1yrdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MRPcross1yrdaily.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/MRPcross1yrdaily.pdf')
    else:
      print("No data found to write to MRPcross1yrdaily.csv")
except Exception as e:
    print(f"Error in pdf MRPcross1yrdaily- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")


try:
    #print(DDPCTlist)
    if len(maxVx) > 0:  # Check if DDPCTlist has entries before writing
        # Define the folder path (replace 'your_folder_path' with your desired location)
        folder_path = '/home/rizpython236/BT5/screener-outputs/'
        # Custom Sort Function (consider using namedtuple for clarity)
        def sort_by_roc_and_maxvx(row):
          return (row["ROC2"] > 0, row["MaxVX"], row["ROC2"])  # Sort by ROC_2 (positive first), MaxVX, ROC_2

        maxVx.sort(key=sort_by_roc_and_maxvx, reverse=True)
        # Separate lists for ROC_2 positive and negative (optional, for further processing)
        #roc4_positive = [row for row in maxVx if row["ROC_2"] > 0]
        #roc4_negative = [row for row in maxVx if row["ROC_2"] <= 0]

        #maxVx = roc4_positive + roc4_negative
        #print(maxVx)
        maxVx = pd.DataFrame(maxVx)
        maxVx.fillna("", inplace=True)
        #maxVx.fillna("", inplace=True)

        #maxVx.sort(key=lambda row: row["ADX"], reverse=True)
        maxVx.to_csv('/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.csv', index=False)
        '''
        # Create the folder if it doesn't exist
        #import os
        os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

        # Open the CSV file in write mode and write headers
        with open(os.path.join(folder_path, "MaxVxT1yrdaily.csv"), "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=maxVx[0].keys())
            writer.writeheader()

            # Write rows from DDPCTlist to the CSV file
            for row in maxVx:
                writer.writerow(row)
        '''

        print(f"MaxVxT1yrdaily.csv saved successfully in {folder_path}")
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.pdf'  # Replace with desired output PDF file
        time.sleep(10)
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.pdf')
    else:
      print("No data found to write to MaxVxT1yrdaily.csv")
except Exception as e:
    print(f"Error in pdf MaxVxT1yrdaily- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    #print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")

try:
    #print(DDPCTlist)
    if len(DDPCTlist) > 0:  # Check if DDPCTlist has entries before writing
      # Define the folder path (replace 'your_folder_path' with your desired location)
      folder_path = '/home/rizpython236/BT5/screener-outputs/'
      DDPCTlist.sort(key=lambda row: row["ADX"], reverse=True)
      DDPCTlist = pd.DataFrame(DDPCTlist)
      DDPCTlist.fillna("", inplace=True)
      DDPCTlist.fillna("nan", inplace=True)
      DDPCTlist.to_csv('/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.csv', index=False)

      '''
      # Create the folder if it doesn't exist
      #import os
      os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

      # Open the CSV file in write mode and write headers
      with open(os.path.join(folder_path, "DDPCT1yrdaily.csv"), "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=DDPCTlist[0].keys())  #fieldnames=data.keys())
        writer.writeheader()

        # Write rows from DDPCTlist to the CSV file
        for row in DDPCTlist:
            writer.writerow(row)
      '''

      print(f"DDPCT1yrdaily.csv saved successfully in {folder_path}")
      input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.csv'  # Replace with your CSV file
      output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.pdf'  # Replace with desired output PDF file
      time.sleep(10)
      create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
      time.sleep(10)
      post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.pdf')
    else:
      print("No data found to write to DDPCT1yrdaily.csv")
except Exception as e:
    print(f"Error in pdf DDPCT1yrdaily- {e}")
    pass

print("__________________________________________________________")

try:
    #print(DDPCTlist)
    if len(Pos1yrHigh) > 0:  # Check if DDPCTlist has entries before writing
      # Define the folder path (replace 'your_folder_path' with your desired location)
      folder_path = '/home/rizpython236/BT5/screener-outputs/'
      Pos1yrHigh.sort(key=lambda row: row["ADX"], reverse=True)
      #print(Pos1yrHigh)
      Pos1yrHigh = pd.DataFrame(Pos1yrHigh)
      Pos1yrHigh.fillna("", inplace=True)
      Pos1yrHigh.fillna("nan", inplace=True)
      Pos1yrHigh.to_csv('/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.csv', index=False)
      '''
      # Create the folder if it doesn't exist
      #import os
      os.makedirs(folder_path, exist_ok=True)  # Create folders if they don't exist

      # Open the CSV file in write mode and write headers
      with open(os.path.join(folder_path, "Pos1yrHigh1yrdaily.csv"), "w", newline="") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=Pos1yrHigh[0].keys())
        writer.writeheader()

        # Write rows from Pos1yrHigh to the CSV file
        for row in Pos1yrHigh:
            writer.writerow(row)
      '''

      print(f"Pos1yrHigh1yrdaily.csv saved successfully in {folder_path}")
      input_csv_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.csv'  # Replace with your CSV file
      output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.pdf'  # Replace with desired output PDF file
      time.sleep(10)
      create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
      time.sleep(10)
      post_telegram_file('/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.pdf')
    else:
      print("No data found to write to Pos1yrHigh1yrdaily.csv")
except Exception as e:
    print(f"Error in pdf Pos1yrHigh1yrdaily- {e}")
    traceback_str = traceback.format_exc()
    #Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")

# Example usage:
#sector_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#valid_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#output_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'
#replace_values(sector_file, valid_file, output_file)

if weekday != "Tuesday":
    #dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
    #dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
    #dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
    #print("Made copy of Old file")
    1+1


input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/52wkdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/52wkdatadaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

input_csv_file = '/home/rizpython236/BT5/screener-outputs/RSIdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/RSIdatadaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)


input_csv_file = '/home/rizpython236/BT5/screener-outputs/MRPdatadaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MRPdatadaily.pdf'  # Replace with desired output PDF file
#create_pdf(input_csv_file, output_pdf_file)

time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistSELL.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistExpLinR.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/watchlistEFIdaily.pdf')
time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/52wkdatadaily.pdf')

time.sleep(2)
#post_telegram_file('/home/rizpython236/BT5/screener-outputs/MRPdatadaily.pdf')
time.sleep(2)

if dfRSI_data.empty:
    1+1
    #print("RSI_data is empty")
else:
    1+1
    #post_telegram_file('/home/rizpython236/BT5/screener-outputs/RSIdatadaily.pdf')
time.sleep(2)
if dfSMA_data.empty:
    1+1
    #print("SMA_data is empty")
else:
    1+1
    #post_telegram_file('/home/rizpython236/BT5/screener-outputs/200SMACrossdaily.pdf')




try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.pdf'
    if os.path.exists(output_pdf_file) or len(DDPCTlist) < 1:
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/DDPCT1yrdaily.pdf')
except Exception as e:
    print(f"Error in ruuning DDPCT1yrdaily pdf- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass

print("__________________________________________________________")
try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.pdf'
    if os.path.exists(output_pdf_file) or len(Pos1yrHigh) < 1:
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/Pos1yrHigh1yrdaily.pdf')
except Exception as e:
    print(f"Error in ruuning Pos1yrHigh1yrdaily pdf- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass
print("__________________________________________________________")

try:
    output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.pdf'
    if os.path.exists(output_pdf_file) or len(maxVx) < 1:
        1+1
    else:
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file ,pageA4= False)
        time.sleep(10)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/MaxVxT1yrdaily.pdf')
except Exception as e:
    print(f"Error in ruuning MaxVxT1yrdaily pdf- {e}")
    traceback_str = traceback.format_exc()
    # Print detailed error information
    print("Error type:", e.__class__.__name__)
    print("Error message:", str(e))
    print("Traceback:\n", traceback_str)
    pass
print("__________________________________________________________")

'''
##########
new =df52wkdata
old = old52wkdataWklydf
change = pd.DataFrame()

new['52wkH-RSI-CCI--UP'] = new['52wkH-RSI-CCI--UP'].apply(lambda x: x.split('*')[0])
old['52wkH-RSI-CCI--UP'] = old['52wkH-RSI-CCI--UP'].apply(lambda x: x.split('*')[0])

old['52wkL-pos1yr-RSI-CCI--DWN'] = old['52wkL-pos1yr-RSI-CCI--DWN'].apply(lambda x: x.split('*')[0])
new['52wkL-pos1yr-RSI-CCI--DWN'] = new['52wkL-pos1yr-RSI-CCI--DWN'].apply(lambda x: x.split('*')[0])

for column in old.columns:
    change[column] = new[column][~new[column].isin(old[column])]
change.to_csv('/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv', index=False)
#print(change)
time.sleep(2)
input_csv_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.csv'  # Replace with your CSV file
output_pdf_file = '/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.pdf'  # Replace with desired output PDF file
create_pdf(input_csv_file, output_pdf_file)
time.sleep(2)
post_telegram_file('/home/rizpython236/BT5/screener-outputs/Chg52wkdaily.pdf')

#print(df)
#print(Start_countmore0)
#df.to_csv('/home/rizpython236/BT5/screener-outputs/Relative_perf.csv', index=False)

#time.sleep(2)

#input_csv_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.csv'  # Replace with your CSV file
#output_pdf_file = '/home/rizpython236/BT5/screener-outputs/watchlistBUY.pdf'  # Replace with desired output PDF file

#create_pdf(input_csv_file, output_pdf_file)

##post_telegram_file('/home/rizpython236/BT5/screener-outputs/Relative_perf.pdf')
'''

'''

#######################

if 1==1:
#try:
    if weekday == "Wednesday":
        print("Running Chgwatchlist")
        try:
            Buyfile_path = '/home/rizpython236/BT5/OldwatchlistBUY.csv'
            Bolddf = pd.read_csv(Buyfile_path)

            Sellfile_path = '/home/rizpython236/BT5/OldwatchlistSELL.csv'
            Solddf = pd.read_csv(Sellfile_path)

            expfile_path = '/home/rizpython236/BT5/OldwatchlistExpLinR.csv'
            expdf = pd.read_csv(expfile_path)
        except Exception as e:
            print(f"file not found Oldgwatchlist- {e}")
            pass


        dfBUY.to_csv('/home/rizpython236/BT5/OldwatchlistBUY.csv', index=False)
        dfSELL.to_csv('/home/rizpython236/BT5/OldwatchlistSELL.csv', index=False)
        dfexpdata.to_csv('/home/rizpython236/BT5/OldwatchlistExpLinR.csv', index=False)
        print("Made copy of Old file")


        new =dfBUY
        old = Bolddf
        change = pd.DataFrame()
        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])
        #new['DD_PCT_25'] = new['DD_PCT_25'].applymap(lambda x: x.rsplit('-', 1)[-1])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])


        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistBUY.pdf')



        ####

        new =dfSELL
        old = Solddf
        change = pd.DataFrame()

        new['DD_PCT_25'] = new['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        old['DD_PCT_25'] = old['DD_PCT_25'].apply(lambda x: x.rsplit('-', 1)[0])

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistSELL.pdf')


        ####

        new =dfexpdata
        old = expdf
        change = pd.DataFrame()

        new['ExpLong-S--L'] = new['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])
        old['ExpLong-S--L'] = old['ExpLong-S--L'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        old['ExpShort-L--S'] = old['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])
        new['ExpShort-L--S'] = new['ExpShort-L--S'].apply(lambda x: x.rsplit('-', 1)[0])  ###

        for column in old.columns:
            change[column] = new[column][~new[column].isin(old[column])]
        change.to_csv('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv', index=False)
        time.sleep(2)
        input_csv_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.csv'  # Replace with your CSV file
        output_pdf_file = '/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf'  # Replace with desired output PDF file
        create_pdf(input_csv_file, output_pdf_file)
        time.sleep(2)
        post_telegram_file('/home/rizpython236/BT5/screener-outputs/ChgwatchlistExpLinR.pdf')

    else:
        1+1
#except Exception as e:
#    print(f"Error in ruuning Chgwatchlist- {e}")
#    pass
'''


print("done")



























